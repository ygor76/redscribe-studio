# RedScribe v3.5.19

## Ajustes finos do Estúdio

- Largura e altura das faixas voltaram a ser controles de arrastar (sliders), com resposta visual em tempo real.
- É possível adicionar várias faixas horizontais e verticais ao mesmo tempo; uma nova faixa não substitui as anteriores.
- Clique em qualquer faixa/elemento na prévia para selecioná-lo e editar exatamente aquele elemento no painel lateral.
- O painel mostra claramente qual elemento está selecionado e permite alternar entre todos os elementos adicionados.
- O modo Desenquadrar vídeo agora funciona como seleção de objeto: ativar o recurso não prende o mouse; clique no vídeo para editar e clique fora para sair da seleção.
- Fora da seleção, o player volta ao comportamento normal e seus controles continuam utilizáveis.
- Motor de Shorts, legendas Ultra, renderização e demais funções aprovadas foram preservados.
