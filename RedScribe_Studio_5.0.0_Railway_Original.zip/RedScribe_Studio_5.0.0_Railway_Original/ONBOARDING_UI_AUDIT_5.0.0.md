# Auditoria visual — apresentação guiada e Shorts Studio

## Validação inicial

A apresentação guiada foi exibida no primeiro acesso da conta de revisão, sobrepondo o dashboard com contraste adequado e sem esconder a navegação sob uma camada opaca. O primeiro passo apresentou o fluxo de criação e o avanço para o segundo passo confirmou a composição visual do Shorts Studio, com a sequência de três cartões verticais, indicador de progresso `2 de 3` e ação de retorno disponível.

O diálogo preserva o tema escuro do aplicativo e usa apenas preto, branco e cinzas. A validação ainda deve concluir o terceiro passo, conferir a persistência após fechar e verificar o painel de recomendações e os cartões incrementais no Shorts Studio.

O terceiro passo foi apresentado com a mensagem de organização e a ação **Começar agora**. Ao concluir, o diálogo foi removido, deixando o painel inicial interativo. A persistência também foi coberta pela suíte de regressão por meio da rota de conclusão e uma nova leitura de configurações da mesma conta.

Ao abrir o Shorts Studio, o painel de recomendações foi exibido em estado inicial, com uma orientação para a falta de histórico e o controle **Limpar sugestões**. Os atalhos de duração `10 min` e `15 min` foram renderizados ao lado dos atalhos existentes, e o campo passou a informar o intervalo de 15 segundos a 15 minutos. Uma pesquisa de revisão foi iniciada para validar o preenchimento das recomendações a partir do histórico real.

A pesquisa por `podcast marketing digital brasil` retornou dez cartões reais de fontes do YouTube. O mesmo histórico alimentou imediatamente seis recomendações no Shorts Studio, cada uma com miniatura, título, canal, duração, ação **Usar vídeo** e controle individual de remoção. O atalho de 15 minutos atualizou o campo de duração para `900`, confirmando a nova configuração no navegador.
