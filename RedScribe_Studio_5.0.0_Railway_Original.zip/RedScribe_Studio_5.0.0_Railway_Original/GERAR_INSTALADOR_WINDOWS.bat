@echo off
chcp 65001 >nul
cd /d "%~dp0"
title RedScribe Studio 5.0.0 - Gerador do Instalador
cls
echo ============================================================
echo  RedScribe Studio 5.0.0 - Gerador do Instalador
echo ============================================================
echo.
echo Este gerador prepara automaticamente um PC Windows 10/11 x64.
echo Nao e necessario instalar Python, pip, Git, Node ou Inno Setup antes.
echo Internet e necessaria no primeiro build.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_INSTALLER.ps1"
if errorlevel 1 (
  echo.
  echo O build encontrou um erro.
  echo Envie build_log.txt e diagnostico_build.txt para diagnostico.
  pause
  exit /b 1
)
echo.
echo Instalador gerado com sucesso em installer_output.
pause
