# RedScribe v3.5.9

## Correção — Preenchimento total + Enquadramento Inteligente

- Corrigido o comportamento do modo **Preenchimento total · 9:16 sem faixas pretas** quando **Enquadramento Inteligente · seguir pessoa** está ativo.
- Agora o RedScribe preserva exatamente o preenchimento total da v3.4.7 e move apenas o foco horizontal para acompanhar a pessoa.
- A lógica de abrir/adaptar a cena fica restrita à opção **Composição Inteligente · adaptar à cena**.
