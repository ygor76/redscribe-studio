# Especificação de mídia profissional e IA integrada — RedScribe Studio 5.0.0

## Objetivo desta atualização

Esta atualização preserva o fluxo atual de criação e edição, mas torna o resultado mais seguro para vídeos reais: reduz recortes agressivos, permite criar cortes de mídia sem fala, oferece mais proporções de saída e retira a necessidade de uma chave técnica para usar as ações inteligentes mais importantes.

| Área | Decisão | Resultado para a pessoa usuária |
|---|---|---|
| Animação de montagem | Manter apenas o celular em leve movimento em fundo preto. | O processamento continua visível sem brilho pulsante, varredura ou linhas decorativas. |
| Enquadramento | Separar preenchimento máximo de enquadramento seguro. | Quem quer ocupar tudo usa preenchimento; quem quer preservar a pessoa usa composição com fundo tratado e sem bordas pretas. |
| Formatos | Incluir 9:16, 1:1, 4:5 e 16:9 com prévia proporcional. | A mesma fonte pode ser preparada para Shorts, feed, anúncios e vídeo horizontal. |
| 4K | Renderizar em 2160 px somente quando a fonte suportar. | O aplicativo não aumenta artificialmente uma fonte menor só para mostrar “4K”. |
| Mídia sem fala | Selecionar janelas pela duração real quando não houver legenda ou voz útil. | Música instrumental, clipes, sons ambientes e vídeos silenciosos também podem virar cortes. |
| IA | Executar ações editoriais por um núcleo integrado sem chave. | Resumo, tópicos, títulos, descrição, roteiro, perguntas orientadas pelo conteúdo e seleção de trechos já funcionam na primeira abertura. |
| Planos | Permitir escolha local, sem checkout ou bloqueios atuais. | A tela já apresenta a experiência comercial futura, porém todos os recursos continuam liberados nesta edição. |

## Arquitetura de IA pronta para uso

O Claude Code não é um modelo aberto distribuível dentro do instalador e o seu uso oficial exige credenciais autenticadas ou infraestrutura configurada. [1] Por isso, esta versão substitui a dependência obrigatória de chave por um **Núcleo Inteligente Integrado do RedScribe**. Ele funciona no aplicativo e na interface aberta no navegador local, pois é executado pelo próprio serviço do RedScribe.

O núcleo usa análise local de transcrição, relevância lexical, identificação de frases de abertura, estrutura de tópicos, extração de trechos e modelos editoriais próprios. Ele oferece resultados imediatos para tarefas concretas; se no futuro houver um motor de linguagem local completo disponível, a mesma interface poderá utilizá-lo automaticamente como reforço, sem pedir chave. Um motor local separado pode rodar no Windows por HTTP local, porém exige espaço adicional para modelos e requisitos de hardware, portanto não será condição para o primeiro uso. [2]

> A interface não solicitará chave nem exibirá um estado bloqueado. Quando um motor local adicional estiver disponível, o RedScribe o usará como melhoria, mantendo o núcleo integrado como fallback.

## Regras de enquadramento e qualidade

O modo **Preencher 9:16** existente permanece inalterado. O modo anterior de remover faixas será renomeado para expressar que ele preenche totalmente a tela; um novo modo **Enquadramento seguro** detectará barras gravadas, as removerá e preservará a cena no primeiro plano sobre um fundo tratado. Desse modo, não haverá barras pretas, mas também não haverá um zoom forçado no rosto apenas para preencher a proporção.

O render em 4K será exposto como **2160 × 3840 · quando a fonte for 4K**. A fonte será baixada na melhor variante disponível e o pipeline só manterá 2160 px quando o arquivo de origem tiver altura suficiente. Em uma fonte menor, o trabalho seguirá na maior resolução nativa disponível e informará a qualidade efetiva no histórico, em vez de simular ganho de detalhe por ampliação.

## Conteúdo sem fala

Vídeos instrumentais não geram mais erro quando não houver segmentos de fala. O RedScribe utilizará a duração real da mídia para distribuir janelas de corte, desativará automaticamente a gravação de legendas vazias e identificará o método como seleção pela timeline da mídia. Arquivos de áudio e vídeo continuam disponíveis independentemente da existência de texto.

## Referências

[1] [Autenticação do Claude Code](https://code.claude.com/docs/en/authentication)

[2] [Ollama para Windows](https://docs.ollama.com/windows)
