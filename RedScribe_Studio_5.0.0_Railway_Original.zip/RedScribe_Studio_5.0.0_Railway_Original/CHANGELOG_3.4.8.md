# RedScribe v3.5.9 — Auto Reframe inteligente

## Novidades
- Nova opção **Enquadramento Inteligente · seguir pessoa**.
- Nova opção **Composição Inteligente · adaptar à cena**.
- Controle de movimento: Suave, Normal e Dinâmico.
- Detecção visual local de rostos/perfis e fallback de corpo usando OpenCV.
- O enquadramento usa zona segura, suavização e reconhecimento de cortes de câmera para evitar tremedeira.
- Em cenas com duas ou mais pessoas, o RedScribe recentraliza o grupo e pode abrir discretamente o plano sobre um fundo derivado do próprio vídeo.
- As opções são desligadas por padrão: o **Preenchimento total · 9:16 sem faixas pretas** continua exatamente como na v3.4.7 quando o Auto Reframe estiver desligado.
- Nenhuma análise visual pesada roda na inicialização; somente depois de o usuário clicar em **Montar Shorts**.
