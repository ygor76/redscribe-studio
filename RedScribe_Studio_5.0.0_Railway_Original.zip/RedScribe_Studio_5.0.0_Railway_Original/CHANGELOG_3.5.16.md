# RedScribe v3.5.17

## Legendas Ultra — cobertura integral

- Mantida a precisão da v3.5.15 nas duas passagens principais.
- Adicionada uma terceira passagem de cobertura, mais permissiva, para recuperar falas baixas, cantadas ou difíceis que antes podiam desaparecer no meio do Short.
- A passagem de cobertura analisa o áudio inteiro sem depender do VAD para decidir previamente onde existe voz.
- Trechos exclusivos das passagens auxiliares agora podem preencher lacunas temporais sem substituir legendas que já estavam corretas.
- Legendas do YouTube/transcrição de origem continuam sendo apenas apoio; agora também podem preencher uma lacuna totalmente vazia quando houver uma fala conhecida naquele intervalo.

## Shorts Studio — seleção sob demanda

- Os Shorts gerados não exibem mais checkbox o tempo todo.
- Botão **Selecionar** ativa/desativa o modo de seleção.
- Opção **Selecionar tudo**.
- **Adicionar selecionados à Biblioteca**.
- **Limpar não escolhidos** remove do armazenamento temporário os clipes gerados que o usuário decidiu não manter, preservando Shorts já adicionados à Biblioteca e os ainda selecionados.

## Biblioteca — seleção respeita o filtro atual

- Em **Biblioteca > Shorts**, clicar em **Selecionar** mantém o usuário em Shorts e mostra seleção somente nos Shorts.
- Em **Vídeos**, **Áudios**, **Textos** etc., o modo de seleção continua atuando somente sobre o filtro atual.
- Shorts selecionados podem ser enviados à **Lixeira** ou **Excluídos definitivamente**.
- A Lixeira passa a exibir Shorts, com opções de **Restaurar** e **Excluir definitivamente**.
