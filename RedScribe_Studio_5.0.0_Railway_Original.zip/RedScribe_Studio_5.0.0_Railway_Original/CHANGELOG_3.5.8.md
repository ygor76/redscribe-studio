# RedScribe v3.5.9

Base: v3.5.9 — a lógica de seleção/renderização dos Shorts foi mantida.

- Shorts podem ser adicionados a projetos pela Biblioteca.
- Projetos exibem e reproduzem Shorts.
- Estado “Nenhum projeto” centralizado.
- Login/dados persistentes entre atualizações no Windows via LOCALAPPDATA, com migração de dados legados.
- Corrigido “Continuar ouvindo” duplicado quando o áudio já está tocando.
- Selo visual para qualidade Full HD / HD / Leve / Melhor disponível.
- Botão Limpar nos resultados de busca do Shorts Studio.
- Montagem automática recebeu acabamento visual mais profissional sem mudar sua lógica.
