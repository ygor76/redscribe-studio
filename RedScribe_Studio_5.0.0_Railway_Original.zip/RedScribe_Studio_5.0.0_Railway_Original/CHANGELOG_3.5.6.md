# RedScribe v3.5.9

## Correção de regressão ao montar Shorts

- Restauradas as funções auxiliares de enquadramento removidas acidentalmente na v3.5.5 durante a refatoração da limpeza final de faixas pretas.
- Corrigido o erro `name '_source_crop_prefix' is not defined`.
- Restaurados também os helpers do Auto Reframe (`_smart_points_after_source_crop`, `_smart_center_expression`, `_smart_enable_expression`, `_build_smart_follow_full_chain`, `_build_smart_video_chain`).
- Mantida a limpeza final de barras pretas da v3.5.5.
