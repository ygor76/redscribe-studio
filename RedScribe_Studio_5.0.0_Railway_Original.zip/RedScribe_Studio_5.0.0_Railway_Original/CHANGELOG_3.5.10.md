# RedScribe v3.5.10

## Ajustes de interface e padrões

- **Preencher 9:16 · Padrão** agora é o enquadramento inicial dos Shorts.
- Auto Reframe continua desligado por padrão.
- Removida a opção de legenda sincronizada da montagem de Shorts; legendas ficam concentradas no Estúdio.
- IA para melhores momentos continua ligada por padrão.
- Confirmação de direito/permissão agora vem marcada por padrão.
- Biblioteca abre sem checkboxes; o usuário entra em modo de seleção pelo botão **Selecionar**.
- Qualidade em Nova transcrição simplificada para **Full HD**, **HD**, **Leve · até 360p** e **Melhor disponível**.
- Selo de Full HD/HD não exibe mais “até 1080p/720p”.
- Motor de geração de Shorts preservado sem alterações.
