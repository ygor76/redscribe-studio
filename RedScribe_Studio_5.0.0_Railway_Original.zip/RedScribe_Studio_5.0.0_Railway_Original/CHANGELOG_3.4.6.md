# RedScribe 3.4.7 — Shorts Full Frame + Layout Responsivo

- Corrige o modo **Quadro completo**: remove as faixas pretas superior/inferior, preserva o vídeo original inteiro no centro e preenche todo o 9:16 com extensão do próprio vídeo.
- Mantém **Corte central** separado para quem quer ocupação 9:16 com crop.
- Reorganiza o painel de duração/enquadramento para não estourar pela direita em janelas menores.
- A opção de enquadramento ocupa a largura total quando houver espaço e empilha com segurança em larguras menores.
- Biblioteca > Shorts agora usa grade compacta com cards lado a lado, eliminando grandes áreas vazias.
- Preserva salvar novamente, remover da Biblioteca e demais recursos da 3.4.5.
