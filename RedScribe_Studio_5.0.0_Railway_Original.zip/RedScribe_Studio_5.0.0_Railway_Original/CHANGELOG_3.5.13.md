# RedScribe v3.5.14

## Studio — legendas mais naturais de editar

- Removido o interruptor separado de ativar/desativar legendas: as legendas geradas são o conjunto principal do Short.
- Após gerar legendas automáticas, a lista editável fica disponível imediatamente.
- Clique uma vez na legenda sobre o vídeo para editar o texto diretamente na prévia; clique, segure e arraste para reposicionar.
- Alterações feitas na prévia são sincronizadas com o campo lateral.
- Cada fala ganhou controle deslizante para mover seu tempo mantendo a duração.
- O botão de inclusão manual agora é “Adicionar fala”.
- Ao editar conteúdo/estilo/posição, o Studio avisa que é necessário renderizar novamente para gravar a alteração no arquivo.

## Elementos visuais

- Nova opção “Marca d’água em texto”, com texto, tamanho, cor, opacidade, contorno e posição arrastável.
- A faixa pode ultrapassar a largura da tela; 1,0 corresponde à largura total e valores maiores se estendem além do quadro, sendo recortados corretamente no arquivo final.
- Mantidos selo com foto, marca d’água por imagem, B-roll e demais ferramentas da v3.5.12.

## Estabilidade

- O mecanismo de legendas automáticas do backend não foi alterado, preservando a precisão aprovada na v3.5.12.
- O motor principal de Shorts não foi modificado.
