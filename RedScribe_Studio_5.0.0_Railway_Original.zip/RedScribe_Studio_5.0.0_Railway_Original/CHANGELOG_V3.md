# RedScribe 3.5.9 — Quadro completo sem barras + Biblioteca em grade

## Correções desta atualização
- O modo **Quadro completo** não gera mais faixas pretas em cima e embaixo.
- O vídeo original permanece inteiro no centro e o 9:16 é preenchido com extensão do próprio vídeo.
- O painel de duração/enquadramento foi protegido contra quebra lateral.
- A Biblioteca de Shorts agora mostra cards lado a lado em grade compacta.

---

# RedScribe 3.4.5 — Shorts organizados + enquadramento sem corte

- Seus Shorts agora usam uma grade mais compacta e densa, evitando grandes espaços vazios.
- Novo enquadramento **Preencher 9:16 sem corte central · quadro completo**.
- Esse modo preserva 100% do quadro e completa o canvas vertical sem deformar nem recortar.
- Biblioteca → Shorts ganhou **Remover** em cada vídeo.
- O próprio card do Short gerado também permite **Remover da Biblioteca**.
- Remover da Biblioteca não apaga o vídeo original, a transcrição ou cópias já salvas no computador.
- Shorts removidos ficam marcados internamente para não reaparecerem pela migração automática.
- Limpar histórico da V3.4.4 foi preservado.

# RedScribe 3.4.4 — Shorts compactos + Limpar histórico

- Corrige o espaçamento exagerado dos cards em **Seus Shorts**.
- Os Shorts agora aparecem em uma grade vertical compacta, lado a lado, aproveitando melhor a largura da tela.
- Em telas grandes cabem mais cards por linha; em telas menores a grade se adapta automaticamente.
- Novo botão **Limpar histórico** no Shorts Studio.
- A limpeza remove tarefas concluídas/erro e arquivos temporários do histórico, mas **não apaga os Shorts preservados em Biblioteca → Shorts**.
- Tarefas que ainda estejam em processamento são preservadas e continuam normalmente.
- Mantém Biblioteca de Shorts, correções de transcrição, YouTube Runtime Fix, IA e startup otimizado da linha 3.4.x.

---

# RedScribe 3.4.3 — Shorts na Biblioteca

- Nova categoria **Shorts** em Biblioteca → Seus trabalhos.
- Shorts renderizados são preservados automaticamente na biblioteca interna, sem exigir salvar em Downloads.
- Player 9:16 dentro da Biblioteca, com título de origem, canal, duração e indicador de legenda.
- **Salvar novamente** permite exportar qualquer Short preservado quantas vezes quiser.
- Migração lazy de Shorts concluídos pelas versões 3.4.0–3.4.2 quando os arquivos ainda existem.
- Histórico do Shorts Studio e Biblioteca de Shorts agora são independentes.
- Persistência tenta hardlink local antes de copiar, reduzindo uso duplicado de disco.
- Nenhum trabalho extra é executado durante a inicialização do RedScribe.

# RedScribe 3.4.2 — Library Viewer + Live Progress

## Correções
- Corrige o progresso da tela **Nova transcrição** com um endpoint leve `/api/jobs/<id>/progress`, sem cache e sem transferir a transcrição inteira durante cada atualização.
- Ao finalizar, o RedScribe busca o trabalho completo uma única vez e abre o resultado na Biblioteca.
- Evita disputa desnecessária com carregamentos da Home enquanto a transcrição está sendo iniciada.

## Biblioteca
- Nova navegação interna com **Seus trabalhos** e **Aberto agora**.
- O botão **Abrir** envia o item para o visualizador da Biblioteca em vez de voltar para Nova transcrição.
- O visualizador mantém vídeo, áudio, transcrição sincronizada, editor, IA, favoritos e downloads.
- Ao abrir outro trabalho, a mesma aba é reutilizada e o conteúdo anterior é substituído.
- Ao sair da Biblioteca e voltar durante a mesma sessão, a aba atual permanece aberta.

## Base preservada
- Mantém Shorts Studio, YouTube Runtime Fix, IA, ZIP, startup otimizado, F11, recomendações e builder ZERO-SETUP da linha 3.4.1.

---

# RedScribe 3.4.1 — YouTube Runtime Fix

- Corrige a cadeia de download usada pelo Shorts Studio em PCs recém-formatados.
- Adiciona `yt-dlp.exe` oficial ao pacote final como motor primário de download.
- Mantém a API Python do yt-dlp como fallback.
- Empacota `yt_dlp_ejs` explicitamente no PyInstaller.
- Usa caminho explícito para o Deno interno em chamadas do yt-dlp.
- Valida Deno >= 2.3 durante o build.
- Autoteste agora executa FFmpeg, Deno e yt-dlp.exe antes de aceitar o build.
- Diagnóstico do app mostra motor YouTube, Deno/EJS e FFmpeg separadamente.
- Mantém Shorts Studio, IA, busca, recomendações, startup otimizado, F11 e restante da base 3.4.0.
