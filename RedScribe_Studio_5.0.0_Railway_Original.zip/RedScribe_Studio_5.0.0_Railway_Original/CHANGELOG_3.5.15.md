# RedScribe v3.5.17 — Legendas Ultra Precisas

- O botão **Gerar/Atualizar legendas** passa a usar por padrão um pipeline de alta precisão.
- O áudio é preparado em múltiplas versões: fala limpa, voz focada e natural normalizada.
- O reconhecimento executa múltiplas passagens e compara os resultados por confiança e tempo.
- Legendas/transcrição anteriores são usadas somente como contexto linguístico e desempate; o texto principal continua ancorado no áudio.
- O Studio prefere Whisper Medium para maior precisão e cai automaticamente para Small se o Medium não estiver disponível.
- O modelo é reutilizado em memória durante a sessão para evitar recarregamentos desnecessários.
- Timestamps por palavra recebem compensação fina para reduzir legenda atrasada.
- A lógica de Shorts, Biblioteca, Projetos, publicação e renderização foi preservada.
