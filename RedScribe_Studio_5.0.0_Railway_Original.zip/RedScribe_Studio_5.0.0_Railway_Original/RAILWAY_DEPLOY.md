# RedScribe Studio 5.0.0 — Railway

Este pacote preserva os arquivos visuais e fluxos originais do RedScribe 5.0.0.
Não foi criada uma nova interface web.

## O que foi adicionado
- Dockerfile para Linux/Railway
- requirements-cloud.txt com Gunicorn
- railway.toml
- .dockerignore

O frontend original permanece em `templates/` e `static/`.
O backend original permanece em `app.py`, `shorts_tools.py`, `studio_tools.py` e demais módulos.

## Persistência
Configure um volume persistente montado em `/data`.

## Healthcheck
`/health`
