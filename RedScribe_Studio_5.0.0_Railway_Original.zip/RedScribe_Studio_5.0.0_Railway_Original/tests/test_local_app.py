from __future__ import annotations

import importlib
import io
import os
import shutil
import subprocess
import sys
import tempfile
import time
import types
import unittest
import wave
from pathlib import Path
from unittest import mock


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEST_DATA_ROOT = Path(tempfile.mkdtemp(prefix="redscribe-test-data-"))
os.environ["REDSCRIBE_DATA_ROOT"] = str(TEST_DATA_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

core = importlib.import_module("app")
application = core.app
application.config.update(TESTING=True, SECRET_KEY="redscribe-test-secret")


class FakeYoutubeDL:
    last_query = ""

    def __init__(self, options: dict):
        self.options = options

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def extract_info(self, query: str, download: bool = False):
        type(self).last_query = query
        return {
            "entries": [
                {
                    "id": "abcD1234xyz",
                    "title": "Como criar Shorts que prendem atenção",
                    "channel": "Canal Exemplo",
                    "duration": 125,
                    "view_count": 9876,
                    "thumbnail": "https://img.example/shorts.jpg",
                    "ie_key": "Youtube",
                },
                {
                    "id": "invalid999",
                    "title": "Fonte que não é YouTube",
                    "ie_key": "Vimeo",
                },
            ]
        }


FAKE_YT_DLP = types.SimpleNamespace(YoutubeDL=FakeYoutubeDL)


class IdleThread:
    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    def start(self):
        return None


class RedScribeLocalAppTests(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(TEST_DATA_ROOT, ignore_errors=True)

    def setUp(self):
        self.client = application.test_client()

    def register(self, email: str = "criador@exemplo.com"):
        return self.client.post(
            "/api/auth/register",
            json={"name": "Criador de Shorts", "email": email, "password": "senha-segura"},
        )

    def test_landing_and_health_are_available(self):
        landing = self.client.get("/")
        health = self.client.get("/health")

        self.assertEqual(landing.status_code, 200)
        self.assertIn("Short", landing.get_data(as_text=True))
        self.assertNotIn("aplicativo local", landing.get_data(as_text=True).lower())
        self.assertEqual(health.get_json(), {"ok": True, "product": "RedScribe"})

    def test_registration_login_and_full_access_metadata(self):
        registration = self.register()
        self.assertEqual(registration.status_code, 200)
        payload = registration.get_json()

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["redirect"], "/app")
        self.assertEqual(payload["user"]["access_mode"], "full")
        self.assertEqual(payload["user"]["plan"], "preview")
        self.assertIsNone(payload["user"]["shorts_quota"])
        self.assertIsNone(payload["user"]["plan_expires_at"])

        dashboard = self.client.get("/app")
        self.assertEqual(dashboard.status_code, 200)
        dashboard_html = dashboard.get_data(as_text=True)
        self.assertIn("Transforme vídeos em Shorts", dashboard_html)
        self.assertIn("PRODUÇÃO", dashboard_html)
        self.assertIn("CONTA", dashboard_html)
        self.assertIn("Escolha como você quer criar", dashboard_html)
        self.assertIn("Manutenção e ferramentas avançadas", dashboard_html)
        self.assertIn('data-shorts-duration="120"', dashboard_html)
        self.assertIn('data-shorts-duration="600"', dashboard_html)
        self.assertIn('data-shorts-duration="900"', dashboard_html)
        self.assertIn('value="landscape"', dashboard_html)
        self.assertIn('value="safe"', dashboard_html)
        self.assertIn('value="2160"', dashboard_html)
        self.assertIn("IA integrada", dashboard_html)
        self.assertNotIn("Chave API do OpenCode Zen", dashboard_html)
        self.assertIn('id="projectsTotal"', dashboard_html)
        self.assertIn('data-select-plan="studio"', dashboard_html)
        self.assertIn("PRÉVIA DO ESTÚDIO", dashboard_html)
        self.assertIn("Comece por uma sugestão", dashboard_html)
        self.assertIn('id="shortsOutputList"', dashboard_html)
        shorts_controller = (PROJECT_ROOT / "static" / "shorts.js").read_text(encoding="utf-8")
        self.assertIn("processingOutputMarkup", shorts_controller)
        self.assertIn("Math.min(900", shorts_controller)
        self.assertIn("output_format", shorts_controller)
        self.assertIn("performance_profile", shorts_controller)

        me = self.client.get("/api/me")
        self.assertEqual(me.status_code, 200)
        self.assertEqual(me.get_json()["user"]["email"], "criador@exemplo.com")

        self.client.post("/api/auth/logout")
        login = self.client.post(
            "/api/auth/login",
            json={"email": "CRIADOR@EXEMPLO.COM", "password": "senha-segura"},
        )
        self.assertEqual(login.status_code, 200)
        self.assertEqual(login.get_json()["user"]["access_mode"], "full")

    def test_onboarding_is_persisted_after_completion(self):
        self.assertEqual(self.register("onboarding@exemplo.com").status_code, 200)
        initial = self.client.get("/api/settings")
        self.assertEqual(initial.status_code, 200)
        self.assertFalse(initial.get_json()["onboarding_seen"])

        completion = self.client.post("/api/settings/onboarding/complete")
        self.assertEqual(completion.status_code, 200)
        self.assertTrue(completion.get_json()["onboarding_seen"])

        persisted = self.client.get("/api/settings")
        self.assertTrue(persisted.get_json()["onboarding_seen"])

    def test_shorts_task_accepts_fifteen_minutes_and_exposes_render_metadata(self):
        self.assertEqual(self.register("render@exemplo.com").status_code, 200)
        shorts_module = importlib.import_module("shorts_tools")
        payload = {
            "url": "https://www.youtube.com/watch?v=abcD1234xyz",
            "title": "Fonte de teste",
            "channel": "Canal Exemplo",
            "confirmed_rights": True,
            "count": 2,
            "duration_seconds": 900,
            "layout": "crop",
            "quality": "1080",
            "captions": False,
            "use_ai": False,
        }

        with mock.patch.object(shorts_module.threading, "Thread", IdleThread):
            response = self.client.post("/api/shorts/generate", json=payload)

        self.assertEqual(response.status_code, 202)
        task = response.get_json()["task"]
        self.assertEqual(task["target_count"], 2)
        self.assertEqual(task["duration_seconds"], 900)
        self.assertEqual(task["outputs"], [])

    def test_integrated_ai_is_ready_without_a_key_and_answers_from_content(self):
        self.assertEqual(self.register("ia@exemplo.com").status_code, 200)
        status = self.client.get("/api/ai/status")
        self.assertEqual(status.status_code, 200)
        self.assertEqual(status.get_json()["status"], "ready")
        self.assertEqual(status.get_json()["provider"], "RedScribe IA integrada")
        test = self.client.post("/api/ai/test")
        self.assertEqual(test.status_code, 200)
        self.assertIn("RedScribe", test.get_json()["result"])

        ai_module = importlib.import_module("integrated_ai")
        answer = ai_module.response_from_prompt(
            "Resuma a transcrição.\n\nTRANSCRIÇÃO:\nCriar conteúdo com clareza melhora a compreensão. Uma ideia forte precisa de exemplo e conclusão."
        )
        self.assertIn("Visão geral", answer)
        self.assertIn("clareza", answer.lower())
        contextual = ai_module.response_from_prompt("MENSAGEM ATUAL: Quero melhorar a estratégia de conteúdo do meu canal de culinária.")
        self.assertIn("Direção", contextual)
        self.assertIn("culinária", contextual.lower())

    def test_shorts_fast_profile_is_the_default_and_has_safe_encoder_fallback(self):
        self.assertEqual(self.register("rapido@exemplo.com").status_code, 200)
        shorts_module = importlib.import_module("shorts_tools")
        payload = {
            "url": "https://www.youtube.com/watch?v=abcD1234xyz", "confirmed_rights": True,
            "count": 1, "duration_seconds": 30, "layout": "crop", "quality": "1080",
        }
        with mock.patch.object(shorts_module.threading, "Thread", IdleThread):
            response = self.client.post("/api/shorts/generate", json=payload)
        self.assertEqual(response.status_code, 202)
        self.assertEqual(response.get_json()["task"]["performance_profile"], "fast")
        key, config = shorts_module._render_profile("invalid")
        self.assertEqual(key, "fast")
        self.assertEqual(config["preset"], "superfast")
        attempts = shorts_module._encoder_attempts("ffmpeg-inexistente", "fast", "1080")
        self.assertEqual(attempts[-1][0], "CPU otimizada")
        self.assertIn("libx264", attempts[-1][1])

    def test_shorts_task_accepts_safe_landscape_and_four_k_request(self):
        self.assertEqual(self.register("formatos@exemplo.com").status_code, 200)
        shorts_module = importlib.import_module("shorts_tools")
        payload = {
            "url": "https://www.youtube.com/watch?v=abcD1234xyz",
            "title": "Fonte em formato horizontal",
            "channel": "Canal Exemplo",
            "confirmed_rights": True,
            "count": 1,
            "duration_seconds": 60,
            "output_format": "landscape",
            "layout": "safe",
            "quality": "2160",
            "captions": True,
            "use_ai": True,
        }
        with mock.patch.object(shorts_module.threading, "Thread", IdleThread):
            response = self.client.post("/api/shorts/generate", json=payload)
        self.assertEqual(response.status_code, 202)
        task = response.get_json()["task"]
        self.assertEqual(task["output_format"], "landscape")
        self.assertEqual(task["layout"], "safe")
        self.assertEqual(task["quality"], "2160")

    def test_plan_preference_is_saved_without_limiting_access(self):
        self.assertEqual(self.register("plano@exemplo.com").status_code, 200)
        response = self.client.post("/api/plan/select", json={"plan": "studio"})
        self.assertEqual(response.status_code, 200)
        user = response.get_json()["user"]
        self.assertEqual(user["plan"], "studio")
        self.assertEqual(user["access_mode"], "full")
        self.assertIsNone(user["shorts_quota"])
        self.assertIsNone(user["plan_expires_at"])

    def test_image_upload_is_accepted_as_silent_media_source(self):
        self.assertEqual(self.register("imagem@exemplo.com").status_code, 200)
        with mock.patch.object(core.threading, "Thread", IdleThread):
            response = self.client.post(
                "/api/upload",
                data={"media": (io.BytesIO(b"not-a-real-png"), "referencia.png")},
                content_type="multipart/form-data",
            )
        self.assertEqual(response.status_code, 202)
        job_id = response.get_json()["job_id"]
        job = core.get_job(job_id)
        self.assertEqual(job["source_type"], "image")
        self.assertEqual(job["video_quality"], "Imagem convertida")

    def test_library_media_can_be_selected_as_a_shorts_source(self):
        self.assertEqual(self.register("biblioteca-shorts@exemplo.com").status_code, 200)
        user = self.client.get("/api/me").get_json()["user"]
        job_id = "a" * 32
        video_file = core.audio_dir(job_id) / "video.mp4"
        video_file.write_bytes(b"synthetic-video-placeholder")
        core.save_job({
            "id": job_id, "user_id": user["id"], "status": "done", "title": "Trilha instrumental",
            "source_type": "local", "video_ready": True, "video_filename": "video.mp4",
            "video_url": f"/video/{job_id}", "thumbnail_url": None, "duration_label": "00:30",
            "transcript_available": False, "segments": [], "created_at": 1, "updated_at": 1,
        })
        sources = self.client.get("/api/shorts/library-sources")
        self.assertEqual(sources.status_code, 200)
        self.assertEqual(sources.get_json()["items"][0]["id"], job_id)

        shorts_module = importlib.import_module("shorts_tools")
        with mock.patch.object(shorts_module.threading, "Thread", IdleThread):
            response = self.client.post("/api/shorts/generate", json={
                "source_job_id": job_id, "confirmed_rights": True, "count": 1,
                "duration_seconds": 30, "layout": "safe", "quality": "1080",
                "output_format": "vertical", "captions": True, "use_ai": True,
            })
        self.assertEqual(response.status_code, 202)
        task = response.get_json()["task"]
        self.assertEqual(task["source_job_id"], job_id)
        self.assertEqual(task["video_id"], f"library-{job_id}")

    @unittest.skipUnless(core._ffmpeg_location(), "FFmpeg não está disponível neste ambiente")
    def test_instrumental_audio_is_converted_to_a_real_video_source(self):
        work = Path(tempfile.mkdtemp(prefix="redscribe-audio-visual-"))
        try:
            source = work / "instrumental.wav"
            with wave.open(str(source), "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(8000)
                wav.writeframes(b"\x00\x00" * 8000)
            video = core._audio_to_visual_video(source, work)
            self.assertTrue(video.exists())
            self.assertGreater(video.stat().st_size, 1_000)
            self.assertGreater(core._probe_media_duration(video), 0.5)
        finally:
            shutil.rmtree(work, ignore_errors=True)

    @unittest.skipUnless(core._ffmpeg_location(), "FFmpeg não está disponível neste ambiente")
    def test_fast_profile_renders_a_short_from_library_media(self):
        self.assertEqual(self.register("render-real@exemplo.com").status_code, 200)
        user = self.client.get("/api/me").get_json()["user"]
        job_id = "b" * 32
        source = core.audio_dir(job_id) / "video.mp4"
        ffmpeg = core._ffmpeg_location()
        created = subprocess.run([
            ffmpeg, "-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=24",
            "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000", "-t", "3",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(source),
        ], capture_output=True, timeout=30)
        self.assertEqual(created.returncode, 0)
        core.save_job({
            "id": job_id, "user_id": user["id"], "status": "done", "title": "Fonte rápida",
            "source_type": "local", "video_ready": True, "video_filename": "video.mp4",
            "video_url": f"/video/{job_id}", "thumbnail_url": None, "duration_label": "00:03",
            "transcript_available": False, "segments": [], "created_at": 1, "updated_at": 1,
        })
        response = self.client.post("/api/shorts/generate", json={
            "source_job_id": job_id, "confirmed_rights": True, "count": 1, "duration_seconds": 15,
            "layout": "crop", "quality": "720", "performance_profile": "fast", "captions": False,
        })
        self.assertEqual(response.status_code, 202)
        task_id = response.get_json()["task"]["id"]
        deadline = time.time() + 45
        task = None
        while time.time() < deadline:
            task = self.client.get(f"/api/shorts/tasks/{task_id}").get_json()
            if task.get("status") in {"done", "error"}:
                break
            time.sleep(0.25)
        self.assertIsNotNone(task)
        self.assertEqual(task.get("status"), "done", task.get("error"))
        self.assertEqual(task.get("performance_profile"), "fast")
        self.assertEqual(len(task.get("outputs") or []), 1)
        self.assertIn(task["outputs"][0].get("encoder"), {"CPU otimizada", "AMD AMF", "NVIDIA NVENC", "Intel Quick Sync"})

    def test_youtube_search_returns_selectable_source_cards(self):
        self.assertEqual(self.register("youtube@exemplo.com").status_code, 200)

        with mock.patch.dict(sys.modules, {"yt_dlp": FAKE_YT_DLP}):
            response = self.client.get("/api/youtube/search?q=podcast+marketing&limit=10")

        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertEqual(FakeYoutubeDL.last_query, "ytsearch10:podcast marketing")
        self.assertEqual(payload["query"], "podcast marketing")
        self.assertEqual(len(payload["items"]), 1)
        source = payload["items"][0]
        self.assertEqual(source["id"], "abcD1234xyz")
        self.assertEqual(source["channel"], "Canal Exemplo")
        self.assertEqual(source["duration_label"], "2:05")
        self.assertEqual(source["view_count"], 9876)
        self.assertEqual(source["thumbnail_url"], "https://img.example/shorts.jpg")
        self.assertEqual(source["url"], "https://www.youtube.com/watch?v=abcD1234xyz")


if __name__ == "__main__":
    unittest.main(verbosity=2)
