# RedScribe v3.5.12

## Tema escuro
- Corrigido o painel de Shorts no tema escuro: cards, campos e Auto Reframe passam a respeitar as cores do tema.
- O selo “IA visual local” fica legível no tema escuro.

## RedScribe Studio
- Legenda agora permite escolher a cor.
- Geração automática de legendas prioriza, nesta ordem: transcrição já existente no RedScribe, legenda do próprio YouTube e Whisper aprimorado.
- Whisper ganhou filtros de silêncio/alucinação, VAD mais rígido, beam search e segmentação por palavras.
- Novo painel “Elementos visuais”.
- Adição de faixa preta, texto livre e selo de canal arrastáveis na prévia.
- Selo automático usa o nome do usuário como padrão e oferece check azul decorativo opcional.
- Upload de marca d’água/logo com ajuste de tamanho, posição e transparência.
- Elementos são renderizados de forma não destrutiva e a saída vira nova versão na Biblioteca.

## Estabilidade
- Motor de geração dos Shorts e shorts.js permanecem idênticos à v3.5.10.
- Pillow adicionado à checagem automática de dependências para a composição dos elementos gráficos.
