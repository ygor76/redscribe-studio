@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0TESTAR_PYTHON_BUILDER.ps1"
pause
