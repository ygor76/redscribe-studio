@echo off
chcp 65001 >nul
title Reparar suporte ao YouTube
cd /d "%~dp0"

echo ========================================
echo   Reparar YouTube / erro 403
echo ========================================
echo.

if not exist ".venv\Scripts\python.exe" (
  echo Ambiente nao encontrado. Execute INSTALAR_WINDOWS.bat primeiro.
  pause
  exit /b 1
)

echo [1/3] Atualizando yt-dlp, EJS e FFmpeg local...
.venv\Scripts\python.exe -m pip install --upgrade "yt-dlp[default]" "imageio-ffmpeg>=0.6,<1"
if %errorlevel% neq 0 goto :fail

echo.
echo [2/3] Verificando Deno...
where deno >nul 2>&1
if %errorlevel%==0 goto :deno_ok

echo Deno nao encontrado. Tentando instalar pelo Winget...
where winget >nul 2>&1
if %errorlevel% neq 0 goto :no_winget
winget install --id DenoLand.Deno -e --accept-package-agreements --accept-source-agreements
if %errorlevel% neq 0 goto :no_winget

echo.
echo Deno foi instalado. Feche e abra esta ferramenta novamente para atualizar o PATH.
goto :verify

:no_winget
echo.
echo Nao consegui instalar o Deno automaticamente.
echo A ferramenta ainda tentara outras rotas, mas o suporte ao YouTube pode ficar limitado.
goto :verify

:deno_ok
echo Deno encontrado.

:verify
echo.
echo [3/3] Versoes detectadas:
.venv\Scripts\python.exe -m yt_dlp --version
where deno >nul 2>&1
if %errorlevel%==0 deno --version

echo.
echo Reparo concluido. Feche esta janela e execute ABRIR_WINDOWS.bat.
pause
exit /b 0

:fail
echo.
echo Falha ao atualizar o yt-dlp. Verifique sua conexao e tente novamente.
pause
exit /b 1
