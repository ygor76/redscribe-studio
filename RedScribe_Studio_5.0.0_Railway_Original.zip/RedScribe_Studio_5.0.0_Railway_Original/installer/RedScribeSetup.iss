#define MyAppName "RedScribe"
#define MyAppVersion "5.0.0"
#define MyAppPublisher "RedScribe"
#define MyAppExeName "RedScribe.exe"

[Setup]
AppId={{7D5BEEC6-5C60-4FA1-A2CE-9EBA80EE2E5D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\RedScribe
DefaultGroupName=RedScribe
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\installer_output
OutputBaseFilename=RedScribe_Studio_Setup_5.0.0_x64
SetupIconFile=..\assets\redscribe.ico
UninstallDisplayIcon={app}\RedScribe.exe
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
ChangesAssociations=no
VersionInfoVersion=5.0.0.0
VersionInfoCompany=RedScribe
VersionInfoDescription=Instalador do RedScribe Studio
VersionInfoProductName=RedScribe Studio
VersionInfoProductVersion=5.0.0

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"; GroupDescription: "Atalhos:"; Flags: unchecked

[Files]
Source: "..\dist\RedScribe\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\build_tools\MicrosoftEdgeWebview2Setup.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall
Source: "..\build_tools\vc_redist.x64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{group}\RedScribe"; Filename: "{app}\RedScribe.exe"; WorkingDir: "{app}"; IconFilename: "{app}\RedScribe.exe"
Name: "{autodesktop}\RedScribe"; Filename: "{app}\RedScribe.exe"; WorkingDir: "{app}"; IconFilename: "{app}\RedScribe.exe"; Tasks: desktopicon

[Run]
Filename: "{tmp}\vc_redist.x64.exe"; Parameters: "/install /quiet /norestart"; StatusMsg: "Preparando componentes do Windows..."; Flags: runhidden waituntilterminated skipifdoesntexist
Filename: "{tmp}\MicrosoftEdgeWebview2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Preparando o componente visual do RedScribe..."; Flags: runhidden waituntilterminated skipifdoesntexist
Filename: "{app}\RedScribe.exe"; Description: "Abrir RedScribe"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}"

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
end;
