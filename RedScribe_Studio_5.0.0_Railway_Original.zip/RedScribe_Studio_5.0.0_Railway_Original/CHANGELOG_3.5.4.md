# RedScribe v3.5.9

## Correção profunda — barras que aparecem só em algumas cenas

- Identificada a falha da v3.5.3: a pós-validação exigia que a barra aparecesse em boa parte do Short. Em clipes com troca de câmera, uma cena podia ter barra apenas no topo/rodapé e escapar.
- A validação final agora é **scene-aware**: analisa dezenas de frames ao longo de todo o Short e aceita barras recorrentes dentro de uma cena, mesmo que outras cenas estejam totalmente preenchidas.
- Topo e rodapé são analisados separadamente, então o sistema corrige também casos em que uma cena tem faixa em cima e outra tem faixa embaixo.
- O RedScribe calcula o maior envelope confiável de bordas, recorta essas margens e amplia novamente até 9:16.
- Vídeos sem bordas reais continuam sem crop extra.
- A limpeza final pode executar até 3 passes para eliminar linha residual de codec/transição.
