from __future__ import annotations

import re
import shutil
import subprocess
import time
import urllib.request
import zipfile
from pathlib import Path

import imageio_ffmpeg

root = Path(__file__).resolve().parent
tools = root / "tools"
tools.mkdir(exist_ok=True)

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def run_version(path: Path, timeout: int = 20, args: tuple[str, ...] = ("--version",)) -> str:
    try:
        p = subprocess.run(
            [str(path), *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=CREATE_NO_WINDOW,
        )
        if p.returncode != 0:
            return ""
        return (p.stdout or p.stderr or "").strip()
    except Exception:
        return ""


def executable_ok(path: Path, min_bytes: int = 100_000, args: tuple[str, ...] = ("--version",)) -> bool:
    return path.exists() and path.stat().st_size >= min_bytes and bool(run_version(path, args=args))


def download_file(url: str, destination: Path, min_bytes: int, attempts: int = 4) -> None:
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            destination.unlink(missing_ok=True)
            print(f"Baixando {destination.name} (tentativa {attempt}/{attempts})...")
            req = urllib.request.Request(url, headers={"User-Agent": "RedScribe-Builder/3.5.9"})
            with urllib.request.urlopen(req, timeout=180) as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            if destination.stat().st_size < min_bytes:
                raise RuntimeError(f"download de {destination.name} parece incompleto")
            return
        except Exception as exc:
            last_error = exc
            destination.unlink(missing_ok=True)
            time.sleep(min(attempt * 2, 8))
    raise RuntimeError(f"Falha ao baixar {destination.name}: {last_error}")


# FFmpeg used for muxing video+audio and rendering Shorts.
ffmpeg_source = Path(imageio_ffmpeg.get_ffmpeg_exe())
ffmpeg_dest = tools / "ffmpeg.exe"
if not ffmpeg_dest.exists() or ffmpeg_dest.stat().st_size < 5_000_000:
    shutil.copy2(ffmpeg_source, ffmpeg_dest)
if not executable_ok(ffmpeg_dest, 5_000_000, ("-version",)):
    raise RuntimeError("ffmpeg.exe nao passou na validacao")
print(f"FFmpeg: {ffmpeg_dest} | {run_version(ffmpeg_dest, args=("-version",)).splitlines()[0]}")


# Deno is explicitly bundled because current yt-dlp YouTube extraction requires
# an external JavaScript runtime for full format support.
deno = tools / "deno.exe"
deno_version = run_version(deno) if executable_ok(deno) else ""
match = re.search(r"deno\s+(\d+)\.(\d+)\.(\d+)", deno_version, re.I)
deno_supported = bool(match and tuple(map(int, match.groups())) >= (2, 3, 0))
if not deno_supported:
    deno.unlink(missing_ok=True)
    deno_zip = tools / "deno.zip"
    download_file(
        "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip",
        deno_zip,
        5_000_000,
    )
    try:
        with zipfile.ZipFile(deno_zip) as archive:
            archive.extractall(tools)
    finally:
        deno_zip.unlink(missing_ok=True)
    deno_version = run_version(deno)
    match = re.search(r"deno\s+(\d+)\.(\d+)\.(\d+)", deno_version, re.I)
    if not (executable_ok(deno) and match and tuple(map(int, match.groups())) >= (2, 3, 0)):
        raise RuntimeError("deno.exe nao foi instalado em uma versao suportada (>= 2.3)")
print(f"Deno: {deno} | {deno_version.splitlines()[0] if deno_version else 'OK'}")


# IMPORTANT: use the official Windows yt-dlp executable as the primary download
# engine in the frozen RedScribe app. The official executable already bundles the
# matching EJS challenge scripts, avoiding PyInstaller losing yt-dlp-ejs data.
yt_exe = tools / "yt-dlp.exe"
if not executable_ok(yt_exe, 5_000_000):
    download_file(
        "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe",
        yt_exe,
        5_000_000,
    )
if not executable_ok(yt_exe, 5_000_000):
    raise RuntimeError("yt-dlp.exe oficial foi baixado, mas nao executa")
print(f"yt-dlp oficial: {yt_exe} | {run_version(yt_exe)}")

print("Ferramentas de YouTube validadas: FFmpeg + Deno + yt-dlp.exe oficial")
