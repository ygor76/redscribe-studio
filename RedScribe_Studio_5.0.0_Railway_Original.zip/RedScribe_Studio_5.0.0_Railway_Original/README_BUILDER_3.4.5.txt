RedScribe Desktop EXE Builder 3.4.5 — SHORTS LAYOUT + LIBRARY REMOVE / ZERO-SETUP

Execute apenas:
   GERAR_INSTALADOR_WINDOWS.bat

Saída esperada:
   installer_output\RedScribe_Setup_3.4.5_x64.exe

BASE PRESERVADA DA 3.4.3/3.4.4:
- Biblioteca ganhou o filtro Shorts.
- Todo Short concluído é preservado automaticamente na biblioteca interna do RedScribe.
- Shorts antigos das versões 3.4.0–3.4.2 são migrados de forma lazy ao abrir o filtro Shorts, quando os arquivos ainda existem.
- É possível assistir aos vídeos verticais diretamente na Biblioteca.
- Botão Salvar novamente cria uma nova cópia em Downloads\RedScribe\Shorts.
- Limpar o histórico do Shorts Studio não remove os Shorts já preservados na Biblioteca.
- A persistência usa hardlink em NTFS quando possível, evitando duplicar espaço; há fallback para cópia normal.
- Nada novo é processado na inicialização do aplicativo.

NOVIDADE 3.4.5:
- Grade de Shorts mais densa: até 5+ cards lado a lado conforme a largura.
- Novo enquadramento 9:16 sem corte central (quadro completo).
- Remover Short da Biblioteca pelo próprio vídeo ou pela Biblioteca > Shorts.
- Exclusão não apaga vídeo original/transcrição nem cópias já salvas no computador.
