# Especificação de refinamento visual — RedScribe Studio 5.0.0

## Direção visual

O produto passa a ter dois temas realmente distintos e coerentes. O **tema claro** usa fundo branco suave, superfícies brancas, tipografia quase preta e bordas em cinza claro; o **tema escuro** usa fundo preto, superfícies grafite, texto branco e bordas claras discretas. Em ambos, preto e branco permanecem as únicas cores de destaque. Imagens, vídeos e miniaturas não receberão filtro global de escala de cinza.

| Área | Organização proposta |
|---|---|
| Produção | Nova transcrição, Shorts e Estúdio. |
| Organização | Biblioteca, Projetos, Fila, Baixados e Lixeira. |
| Conta | Plano, com leitura do acesso atual e sem bloqueio nesta edição. |
| Sistema | IA e Configurações. |

## Shorts Studio

O fluxo continua com três etapas: escolher fonte, decidir a montagem e revisar os resultados. A configuração principal fica em uma composição mais legível, com cartões para quantidade, duração, formato, enquadramento e qualidade. A duração ganha atalhos rápidos de 30 s, 60 s, 90 s e 2 min, sem remover a digitação manual nem os limites já validados pelo aplicativo. Uma prévia vertical de composição ilustra o resultado antes da geração e pode refletir a fonte selecionada.

## Estúdio

O Estúdio permanece integrado à Biblioteca e preserva player, linha do tempo, legendas, elementos e renderização. Antes de abrir um Short, apresenta uma prévia vertical de referência e comandos de entrada claros; depois da seleção, mantém o player real e os controles existentes. O objetivo é reduzir o estado vazio sem simular trabalhos ou avaliações de usuários.

## Configurações

As opções usuais ficam agrupadas em **Conta e aparência**, **Produção e reprodução** e **Arquivos e backup**. IA, diagnósticos, versão e atualização são transferidos para uma seção de manutenção expansível. Nenhum comando de configuração é removido; apenas muda de posição e agrupamento.
