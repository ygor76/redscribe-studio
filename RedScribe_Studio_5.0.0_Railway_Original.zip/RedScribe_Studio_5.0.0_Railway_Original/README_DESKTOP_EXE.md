# Builder do instalador Windows — RedScribe Studio 5.0.0

O builder prepara uma distribuição nativa para Windows baseada em **Python 3.12**, **PyInstaller** e **Inno Setup**. O executável instalado contém a interface, os templates, o ícone, os componentes de transcrição e as ferramentas necessárias à produção de Shorts.

## Como gerar

1. Extraia este pacote em um computador Windows 10/11 de 64 bits.
2. Execute `GERAR_INSTALADOR_WINDOWS.bat`.
3. Aguarde as onze etapas; a primeira execução prepara os componentes de build.
4. Obtenha o arquivo em `installer_output\RedScribe_Studio_Setup_5.0.0_x64.exe`.

O usuário final recebe **somente** esse arquivo de instalação. Após instalar, abre o RedScribe Studio pelo menu Iniciar ou pelo atalho criado pelo assistente.

## Componentes incorporados

| Componente | Uso |
|---|---|
| Python e bibliotecas | Interface, contas, biblioteca, transcrição e recursos do aplicativo. |
| FFmpeg | Processamento e renderização de mídia. |
| Deno e yt-dlp | Extração de informações e formatos suportados de vídeo. |
| Modelo Whisper Small | Transcrição quando legendas não estiverem disponíveis. |
| WebView2 e Visual C++ Runtime | Integração da janela e bibliotecas Windows necessárias. |

Consulte `README_INSTALACAO_WINDOWS_5.0.0.md` para o procedimento completo e o checklist de aceitação.
