"""Núcleo editorial local do RedScribe.

Funciona sem rede, conta, chave ou modelo baixado. O objetivo não é imitar um
modelo de linguagem genérico: é resolver as tarefas editoriais do produto com
respostas claras e estritamente baseadas no conteúdo fornecido.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from typing import Any


_STOPWORDS = {
    "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "da", "das", "do", "dos", "e", "em", "no", "na", "nos", "nas", "por", "para", "pra", "com", "sem", "que", "se", "como", "mais", "menos", "muito", "muita", "muitos", "muitas", "isso", "esse", "essa", "estes", "estas", "aquele", "aquela", "ele", "ela", "eles", "elas", "eu", "você", "vocês", "nós", "nosso", "sua", "seu", "suas", "seus", "já", "não", "sim", "ser", "estar", "ter", "tem", "têm", "foi", "são", "era", "quando", "onde", "porque", "também", "sobre", "entre", "até", "ou", "ao", "aos", "à", "às", "the", "and", "with", "from", "this", "that", "for", "you", "are", "was", "were", "have", "has", "had",
}


def _compact(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _tokens(text: str) -> list[str]:
    return [token.casefold() for token in re.findall(r"[A-Za-zÀ-ÿ0-9]{3,}", text) if token.casefold() not in _STOPWORDS]


def _sentences(text: str) -> list[str]:
    source = str(text or "").replace("\r", "\n")
    rows = re.split(r"(?<=[.!?])\s+|\n+|\s*[•▪]\s*", source)
    seen: set[str] = set()
    out: list[str] = []
    for row in rows:
        row = _compact(row).strip("-–—• ")
        if len(row) < 18:
            continue
        fingerprint = re.sub(r"[^a-z0-9à-ÿ]+", "", row.casefold())
        if not fingerprint or fingerprint in seen:
            continue
        seen.add(fingerprint)
        out.append(row)
    return out


def _ranked_sentences(text: str, limit: int = 6, query: str = "") -> list[str]:
    rows = _sentences(text)
    if not rows:
        return []
    counts = Counter(_tokens(text))
    query_tokens = set(_tokens(query))
    scored: list[tuple[float, int, str]] = []
    for index, row in enumerate(rows):
        tokens = _tokens(row)
        if not tokens:
            continue
        relevance = sum(1.0 / max(1, counts[token]) for token in set(tokens))
        coverage = len(set(tokens)) / max(1, len(tokens))
        query_score = sum(4.2 for token in set(tokens) if token in query_tokens)
        punctuation = (1.2 if "?" in row else 0) + (0.7 if "!" in row else 0)
        length_score = 2.0 if 44 <= len(row) <= 260 else max(0.0, 1.0 - abs(len(row) - 140) / 240)
        opening_penalty = 0.45 if index == 0 and len(rows) > 4 else 0
        scored.append((relevance + coverage + query_score + punctuation + length_score - opening_penalty, index, row))
    scored.sort(key=lambda item: (-item[0], item[1]))
    selected = sorted(scored[: max(1, limit)], key=lambda item: item[1])
    return [item[2] for item in selected]


def _keywords(text: str, limit: int = 4) -> list[str]:
    counts = Counter(_tokens(text))
    words = [word for word, _count in counts.most_common(36) if not word.isdigit()]
    return words[:limit] or ["conteúdo", "ideia"]


def _first_phrase(text: str, fallback: str = "o conteúdo") -> str:
    rows = _ranked_sentences(text, limit=1)
    return rows[0] if rows else fallback


def _answer_for_action(action: str, transcript: str, question: str = "") -> str:
    transcript = _compact(transcript)
    selected = _ranked_sentences(transcript, limit=6, query=question)
    words = _keywords(transcript, limit=4)
    subject = " · ".join(word.capitalize() for word in words[:2])
    if not transcript:
        return "Não encontrei conteúdo textual suficiente para analisar. Você pode abrir uma transcrição, anexar um documento ou fazer uma pergunta geral."
    if action == "summary":
        lines = selected[:4] or [_first_phrase(transcript)]
        return "## Visão geral\n\n" + " ".join(lines) + "\n\n## Em uma frase\n\n" + (lines[0] if lines else "O conteúdo foi organizado para consulta.")
    if action == "points":
        rows = selected[:6] or [_first_phrase(transcript)]
        return "## Pontos principais\n\n" + "\n".join(f"- {row}" for row in rows)
    if action == "script":
        hook = selected[0] if selected else _first_phrase(transcript)
        development = selected[1:4] or [hook]
        close = selected[4] if len(selected) > 4 else development[-1]
        return "## Roteiro sugerido\n\n**Gancho**\n" + hook + "\n\n**Desenvolvimento**\n" + "\n".join(f"- {row}" for row in development) + "\n\n**Fechamento**\n" + close
    if action == "titles":
        core = words[0].capitalize()
        second = words[1] if len(words) > 1 else "resultado"
        items = [
            f"O que muda quando você entende {core}",
            f"{core}: o ponto que quase ninguém observa",
            f"Como transformar {core.lower()} em {second}",
            f"O detalhe sobre {core.lower()} que vale testar hoje",
            f"Antes de decidir, veja este ponto sobre {core.lower()}",
        ]
        return "## Títulos sugeridos\n\n" + "\n".join(f"- {item}" for item in items)
    if action == "description":
        base = selected[0] if selected else _first_phrase(transcript)
        tags = " ".join(f"#{re.sub(r'[^A-Za-zÀ-ÿ0-9]', '', word.capitalize())}" for word in words[:4])
        return f"{base}\n\n{tags}".strip()
    if action == "post":
        lines = selected[:3] or [_first_phrase(transcript)]
        return "## Post\n\n" + "\n\n".join(lines) + f"\n\nQual parte de {subject.lower()} mais chamou sua atenção?"
    if action == "study":
        rows = selected[:5] or [_first_phrase(transcript)]
        return "## Notas de estudo\n\n" + "\n".join(f"- {row}" for row in rows) + "\n\n## Para revisar\n\n- Qual ideia se conecta diretamente ao seu projeto atual?\n- Que exemplo citado no conteúdo vale testar primeiro?"
    if action == "ask":
        matches = _ranked_sentences(transcript, limit=3, query=question)
        if matches:
            return "## Resposta baseada no conteúdo\n\n" + " ".join(matches)
        return "Não encontrei uma passagem que responda diretamente a essa pergunta no conteúdo selecionado."
    return "## Análise do RedScribe\n\n" + " ".join(selected[:4] or [_first_phrase(transcript)])


def _extract_transcript(prompt: str) -> str:
    markers = ("TRANSCRIÇÃO:", "CONTEÚDO DO MATERIAL:", "CONTEXTO DO CONTEÚDO SELECIONADO")
    text = str(prompt or "")
    for marker in markers:
        pos = text.rfind(marker)
        if pos >= 0:
            chunk = text[pos + len(marker):]
            if marker == "CONTEXTO DO CONTEÚDO SELECIONADO":
                chunk = chunk.split(":", 1)[-1]
            return _compact(chunk)
    return ""


def _extract_current_message(prompt: str) -> str:
    match = re.search(r"MENSAGEM ATUAL:\s*(.+?)(?=\n\n(?:CONTEXTO|ARQUIVOS|ANEXOS)|\Z)", str(prompt or ""), flags=re.I | re.S)
    return _compact(match.group(1)) if match else ""


def _general_editorial_response(message: str) -> str:
    message = _compact(message)
    lower = message.casefold()
    words = _keywords(message, limit=4)
    topic_match = re.search(r"(?:canal|perfil|projeto|negócio|negocio)\s+de\s+([^,.!?]+)", message, flags=re.I)
    subject = _compact(topic_match.group(1)) if topic_match else " ".join(words[:3]).strip()
    subject = subject or "sua ideia"
    if len(message) >= 18 and any(term in lower for term in ("melhorar", "melhore", "ajudar", "estratégia", "estrategia", "ideia", "conteúdo", "conteudo")):
        return (
            f"## Direção para {subject.capitalize()}\n\n"
            f"Entendi que você quer trabalhar **{subject}**. Eu começaria por uma promessa clara: o que a pessoa ganha ou entende depois de assistir? "
            "Em seguida, transforme essa promessa em um exemplo concreto e feche com uma ação simples.\n\n"
            "### Rascunho prático\n\n"
            f"- **Gancho:** “Se você quer melhorar {subject}, comece por este ponto.”\n"
            "- **Prova:** mostre um caso, dado ou situação reconhecível.\n"
            "- **Fechamento:** entregue uma próxima ação que possa ser testada hoje.\n\n"
            "Se você selecionar uma transcrição, eu adapto este rascunho às palavras, exemplos e tom reais do material."
        )
    if any(term in lower for term in ("lista", "tarefas", "organize", "organizar", "planejamento")):
        return f"## Plano para {subject.capitalize()}\n\n1. **Defina o resultado** que precisa estar pronto primeiro.\n2. **Separe o material** necessário em uma lista curta.\n3. **Execute em blocos** de uma etapa por vez.\n4. **Revise e publique** quando o conteúdo estiver claro.\n\nSe você selecionar uma transcrição ou projeto, eu organizo as etapas com base no conteúdo real."
    if any(term in lower for term in ("roteiro", "script", "vídeo")):
        return "## Estrutura de roteiro\n\n**Gancho** — apresente a ideia principal nos primeiros segundos.\n\n**Contexto** — explique por que o assunto importa.\n\n**Desenvolvimento** — entregue dois ou três pontos concretos, com exemplo.\n\n**Fechamento** — recapitule a ideia e indique a próxima ação.\n\nSelecione uma transcrição para eu preencher essa estrutura com o seu conteúdo."
    if any(term in lower for term in ("título", "titulo", "headline")):
        return "## Direções de título\n\n- O ponto principal que vale entender antes de começar\n- O erro comum que muda o resultado\n- Como transformar uma ideia simples em conteúdo claro\n- O detalhe que quase ninguém observa\n\nCom uma transcrição selecionada, posso criar títulos específicos e fiéis ao tema."
    if message:
        return (
            f"## Vamos trabalhar {subject.capitalize()}\n\n"
            "Posso transformar a sua ideia em um resultado editorial concreto. Escolha uma direção abaixo ou diga qual prefere:\n\n"
            f"- **Roteiro curto:** gancho, desenvolvimento e fechamento sobre {subject}.\n"
            f"- **Títulos:** cinco ângulos de título para chamar atenção sem prometer demais.\n"
            f"- **Plano de conteúdo:** uma sequência de ideias publicáveis a partir de {subject}.\n\n"
            "Com uma transcrição selecionada, as sugestões passam a usar o contexto real do seu material."
        )
    return "## RedScribe IA\n\nPosso ajudar a transformar uma ideia em **roteiro**, **lista de tarefas**, **títulos**, **descrição** ou **plano de conteúdo**. Para uma resposta específica, selecione uma transcrição ou projeto como contexto e diga o resultado que deseja criar."


def _choose_candidate_ids(prompt: str) -> str | None:
    if "CANDIDATOS:" not in prompt or "Escolha exatamente" not in prompt:
        return None
    count_match = re.search(r"Escolha exatamente\s+(\d+)", prompt)
    try:
        count = max(1, int(count_match.group(1))) if count_match else 1
        data = json.loads(prompt.split("CANDIDATOS:", 1)[1].strip())
        rows = data if isinstance(data, list) else []
        ranked = sorted(rows, key=lambda row: (-len(_tokens(str(row.get("texto") or ""))), float(row.get("inicio") or 0)))
        return json.dumps({"ids": [int(row["id"]) for row in ranked[:count] if str(row.get("id")).lstrip("-").isdigit()]}, ensure_ascii=False)
    except Exception:
        return None


def response_from_prompt(prompt: str) -> str:
    """Resolve prompts legados e novos, sempre sem rede."""
    prompt = str(prompt or "")
    candidate_answer = _choose_candidate_ids(prompt)
    if candidate_answer is not None:
        return candidate_answer
    transcript = _extract_transcript(prompt)
    current_message = _extract_current_message(prompt)
    if not transcript:
        return _general_editorial_response(current_message)
    lower = prompt.casefold()
    question_match = re.search(r"Pergunta:\s*(.+)", prompt, flags=re.I | re.S)
    question = _compact(question_match.group(1)) if question_match else ""
    if "pontos principais" in lower or "extraia os principais" in lower:
        return _answer_for_action("points", transcript, question)
    if "criar roteiro" in lower or "transforme a transcrição em um roteiro" in lower:
        return _answer_for_action("script", transcript, question)
    if "criar títulos" in lower or "títulos" in lower:
        return _answer_for_action("titles", transcript, question)
    if "criar descrição" in lower or "descrição" in lower:
        return _answer_for_action("description", transcript, question)
    if "transformar em post" in lower or " post" in lower:
        return _answer_for_action("post", transcript, question)
    if "notas de estudo" in lower or "estudo" in lower:
        return _answer_for_action("study", transcript, question)
    if question or "responda somente com base" in lower:
        return _answer_for_action("ask", transcript, question)
    if "resuma" in lower or transcript:
        return _answer_for_action("summary", transcript, question)
    return _general_editorial_response(current_message)


def streamed_response(prompt: str, chunk_size: int = 88):
    text = response_from_prompt(prompt)
    yield {"type": "status", "message": "RedScribe IA está organizando o conteúdo..."}
    for pos in range(0, len(text), max(20, int(chunk_size))):
        yield {"type": "token", "text": text[pos:pos + max(20, int(chunk_size))]}
