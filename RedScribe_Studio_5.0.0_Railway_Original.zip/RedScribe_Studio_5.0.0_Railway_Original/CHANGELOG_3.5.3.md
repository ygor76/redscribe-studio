# RedScribe v3.5.9

## Correção definitiva — Preenchimento total sem barras pretas

- Mantida a detecção de bordas no vídeo de origem.
- Adicionada uma **segunda validação no MP4 final já renderizado**.
- Se ainda houver faixa preta persistente no topo/rodapé, o RedScribe recorta a faixa e amplia o conteúdo novamente para 9:16.
- A validação usa múltiplos frames para não confundir cenas escuras com letterbox.
- Pode executar até 2 passes de limpeza e nunca usa `pad`, fundo preto ou encaixe com `contain` no arquivo final.
- Prévia dos Shorts também usa preenchimento visual (`cover`).
