RedScribe Desktop EXE Builder 3.5.9 — SHORTS SMART AUTO-REFRAME / ZERO-SETUP

Base: 3.4.5.

Principais correções:
1. Quadro completo 9:16 sem faixas pretas.
2. Painel de montagem responsivo sem quebra lateral.
3. Biblioteca de Shorts em grade, com vídeos lado a lado.

Para gerar o instalador, use GERAR_INSTALADOR_WINDOWS.bat.
Saída esperada: installer_output\RedScribe_Setup_3.5.9_x64.exe
