RedScribe v3.5.14 — Studio Creator Update

Base estável: v3.5.10.

Principais mudanças:
- Shorts Studio corrigido para tema escuro.
- Cor personalizável nas legendas do editor.
- Legendas automáticas aprimoradas: transcrição RedScribe > legenda YouTube > Whisper aprimorado.
- Elementos visuais arrastáveis: faixa, texto e selo de canal.
- Marca d'água/logo com tamanho, posição e opacidade.
- Renderização não destrutiva: cria nova versão na Biblioteca.

Importante:
O motor de geração dos Shorts (shorts_tools.py) e shorts.js não foram alterados em relação à v3.5.10.
