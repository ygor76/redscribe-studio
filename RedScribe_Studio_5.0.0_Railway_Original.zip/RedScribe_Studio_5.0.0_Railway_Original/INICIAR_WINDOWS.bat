@echo off
chcp 65001 >nul
title RedScribe Studio 5.0.0
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
  set PY=py
) else (
  where python >nul 2>&1
  if %errorlevel% neq 0 (
    echo Python 3.10 ou superior nao foi encontrado.
    echo Instale o Python, marque "Add Python to PATH" e execute este arquivo novamente.
    pause
    exit /b 1
  )
  set PY=python
)

if not exist ".venv\Scripts\python.exe" (
  echo Primeira execucao: preparando a ferramenta...
  %PY% -m venv .venv || goto :fail
  .venv\Scripts\python.exe -m pip install --upgrade pip || goto :fail
  .venv\Scripts\python.exe -m pip install -r requirements.txt || goto :fail
)

rem Verifica dependencias adicionadas nas versoes mais recentes.
.venv\Scripts\python.exe -c "import imageio_ffmpeg, docx, cv2; from PIL import Image" >nul 2>&1
if %errorlevel% neq 0 (
  echo Atualizando componentes do RedScribe...
  .venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt || goto :fail
)

rem Usa 5050 quando estiver livre. Se uma versao antiga ainda estiver aberta,
rem procura automaticamente outra porta para garantir que ESTE codigo seja executado.
set "PORT="
for /l %%P in (5050,1,5060) do (
  if not defined PORT (
    powershell -NoProfile -Command "$p=%%P; $busy=Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue; if(-not $busy){exit 0}else{exit 1}" >nul 2>&1
    if not errorlevel 1 set "PORT=%%P"
  )
)
if not defined PORT set "PORT=5061"

echo.
echo ============================================================
echo  RedScribe Studio v5.0.0
echo  Abrindo: http://127.0.0.1:%PORT%/app
echo ============================================================
echo.
start "" http://127.0.0.1:%PORT%/app
.venv\Scripts\python.exe app.py
exit /b 0

:fail
echo.
echo Nao foi possivel concluir a instalacao automatica.
pause
exit /b 1
