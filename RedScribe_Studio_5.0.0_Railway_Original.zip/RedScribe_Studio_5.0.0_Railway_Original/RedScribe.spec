# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, copy_metadata

ROOT = Path(SPEC).resolve().parent

datas = [
    (str(ROOT / "templates"), "templates"),
    (str(ROOT / "static"), "static"),
    (str(ROOT / "assets"), "assets"),
    (str(ROOT / "VERSION.txt"), "."),
]

if (ROOT / "models" / "faster-whisper-small").exists():
    datas.append((str(ROOT / "models" / "faster-whisper-small"), "models/faster-whisper-small"))

binaries = []
hiddenimports = [
    "webview.platforms.edgechromium",
    "webview.platforms.winforms",
    "yt_dlp",
    "yt_dlp_ejs",
    "faster_whisper",
]

# Packages that load plugins, native libraries or data dynamically.
for package in [
    "webview",
    "yt_dlp",
    "yt_dlp_ejs",
    "faster_whisper",
    "ctranslate2",
    "tokenizers",
    "av",
    "imageio_ffmpeg",
    "reportlab",
    "docx",
    "pypdf",
    "youtube_transcript_api",
    "cv2",
]:
    try:
        d, b, h = collect_all(package)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception:
        pass

for package in ["flask", "werkzeug", "yt-dlp", "yt-dlp-ejs", "faster-whisper", "ctranslate2", "tokenizers", "opencv-python-headless"]:
    try:
        datas += copy_metadata(package)
    except Exception:
        pass

# Tools are kept as normal files in the onedir distribution.
if (ROOT / "tools").exists():
    datas.append((str(ROOT / "tools"), "tools"))


a = Analysis(
    [str(ROOT / "desktop.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["PyQt5", "PyQt6", "PySide2", "PySide6", "cefpython3", "gtk"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="RedScribe",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(ROOT / "assets" / "redscribe.ico"),
    version=str(ROOT / "version_info.txt"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="RedScribe",
)
