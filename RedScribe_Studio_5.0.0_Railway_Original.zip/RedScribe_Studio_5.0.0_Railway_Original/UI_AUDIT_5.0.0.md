# Auditoria de interface — RedScribe Studio 5.0.0

## Tema

O botão de tema alterna o atributo `data-theme` do documento, mas `static/autonomous.css` define as mesmas variáveis escuras para os modos claro e escuro. A regra também força `color-scheme: dark`, superfícies escuras e um filtro de escala de cinza sobre todo o dashboard. Como resultado, o tema claro permanece visualmente escuro e a mídia perde cor.

Após a atualização da camada visual, a inspeção de estilos computados confirmou que o tema claro usa `#f5f5f3` no fundo principal, painéis brancos e texto quase preto. A camada também removeu o filtro global de escala de cinza que afetava miniaturas, vídeos e recomendações.

## Navegação atual

O menu lateral já separa itens em Criar, Produzir, Organizar e Sistema, mas a classificação pode ser mais clara para o fluxo de trabalho. A nova estrutura deve apresentar **Produção** com Nova transcrição, Shorts e Estúdio; **Organização** com Biblioteca, Projetos, Fila, Baixados e Lixeira; **Conta** com Plano; e **Sistema** com IA e Configurações.

## Produção

O Shorts Studio possui pesquisa, seleção de fonte, configuração de quantidade/duração/formato/enquadramento/qualidade, progresso e resultados. A melhoria deve dar mais destaque à prévia vertical e concentrar as escolhas principais em cartões de decisão, preservando os IDs consumidos pelo JavaScript. O Estúdio já contém player vertical, linha do tempo, legendas, elementos e renderização; precisa receber uma área de prévia mais informativa quando não há Short aberto e uma hierarquia visual mais direta.

## Validação da atualização

A navegação atualizada foi renderizada com as seções Workspace, Produção, Organização, Conta e Sistema. A nova página Plano abriu corretamente, informa acesso liberado e deixa explícito que não há bloqueio de recursos. No tema claro, os cartões e fundos passaram a branco/cinza neutro, e realces herdados em rosa foram neutralizados.

O Shorts Studio foi ajustado para empilhar fonte e configuração no espaço disponível do aplicativo. A configuração passou a exibir uma prévia vertical de composição e atalhos de 30 s, 1 min, 90 s e 2 min. O atalho de 2 min foi testado e atualizou o campo de duração para 120 segundos.

O Estúdio agora apresenta uma prévia vertical de entrada e uma explicação direta dos recursos disponíveis antes de haver um Short na Biblioteca. Configurações passou a exibir Perfil, Aparência e Armazenamento primeiro; IA, comportamento, backup, diagnóstico, atualização e atalhos foram agrupados em **Manutenção e ferramentas avançadas**.

## Configurações

As preferências reúnem perfil, aparência, armazenamento, IA, comportamento, backup e manutenção em uma grade extensa. A revisão deve agrupar opções usuais em seções de acesso direto e mover recursos avançados para detalhes expansíveis, sem remover comandos ou contratos existentes.
