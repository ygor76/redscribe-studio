(() => {
  const form = document.getElementById('authForm');
  if (!form) return;
  const mode = document.body.dataset.authMode;
  const submit = document.getElementById('authSubmit');
  const error = document.getElementById('authError');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    error.classList.add('hidden');
    submit.disabled = true;
    const old = submit.textContent;
    submit.textContent = mode === 'login' ? 'Entrando...' : 'Criando conta...';
    const payload = {
      email: document.getElementById('authEmail').value.trim(),
      password: document.getElementById('authPassword').value,
    };
    const name = document.getElementById('authName');
    if (name) payload.name = name.value.trim();
    try {
      const response = await fetch(`/api/auth/${mode}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Não foi possível continuar.');
      window.location.href = data.redirect || '/app';
    } catch (err) {
      error.textContent = err.message;
      error.classList.remove('hidden');
    } finally {
      submit.disabled = false;
      submit.textContent = old;
    }
  });
})();
