// RedScribe 3.5.9 — Shorts Studio. All heavy work is strictly user-triggered.
(() => {
  'use strict';

  if (typeof viewMeta !== 'undefined') viewMeta.shorts = ['Shorts', 'Crie vídeos nos formatos certos a partir dos melhores momentos.'];

  const state = {selected:null, items:[], librarySources:[], activeTaskId:localStorage.getItem('redscribe_active_shorts_task')||null, poll:null, initialized:false, tasks:[], outputSelectionMode:false, selectedOutputIndexes:new Set(), outputTaskId:null, pollDelay:1100, lastOutputCount:0};
  const shortsJSON = (url, opts) => fetchJSON(url, opts);
  const FORMAT_META={vertical:{ratio:'9 / 16',badge:'9:16',label:'Vertical 9:16',help:'Ideal para TikTok, Reels e Shorts.'},portrait:{ratio:'4 / 5',badge:'4:5',label:'Retrato 4:5',help:'Composição pensada para o feed do Instagram.'},square:{ratio:'1 / 1',badge:'1:1',label:'Quadrado 1:1',help:'Formato versátil para feed, catálogo e campanhas.'},landscape:{ratio:'16 / 9',badge:'16:9',label:'Horizontal 16:9',help:'Ideal para YouTube, apresentações e vídeo horizontal.'}};
  const setActiveTask=id=>{state.activeTaskId=id||null;if(id)localStorage.setItem('redscribe_active_shorts_task',id);else localStorage.removeItem('redscribe_active_shorts_task')};
  const viewsText = n => {n=Number(n||0);if(!n)return '';if(n>=1e6)return `${(n/1e6).toFixed(n>=1e7?0:1).replace('.',',')} mi visualizações`;if(n>=1e3)return `${(n/1e3).toFixed(n>=1e4?0:1).replace('.',',')} mil visualizações`;return `${n} visualizações`};

  function isShortsActive(){return !!document.querySelector('[data-view-panel="shorts"]')?.classList.contains('active')}
  function setStateBox(text='',error=false){const box=$('shortsSearchState');if(!box)return;box.textContent=text;box.classList.toggle('hidden',!text);box.classList.toggle('is-error',!!error)}
  function selectedReady(){const ready=!!state.selected,fromLibrary=!!state.selected?.source_job_id,download=$('shortsDownloadSourceBtn');if(download){download.disabled=!ready||fromLibrary;download.textContent=fromLibrary?'Fonte na Biblioteca':'Baixar fonte'}$('shortsGenerateBtn').disabled=!ready}

  function updateComposerPreview(item=null){
    const title=$('shortsPreviewTitle'),meta=$('shortsPreviewMeta');
    if(!title||!meta)return;
    if(item){title.textContent=item.title||'Vídeo do YouTube';meta.textContent=[item.channel||'YouTube',item.duration_label||''].filter(Boolean).join(' · ').toUpperCase()}
    else{title.textContent='A prévia do seu Short aparece aqui.';meta.textContent='SELECIONE UMA FONTE'}
  }
  function syncFormatPreview(){
    const key=$('shortsPlatform')?.value||'vertical',meta=FORMAT_META[key]||FORMAT_META.vertical,preview=document.querySelector('.shorts-live-preview'),phone=document.querySelector('.shorts-live-phone');
    if(preview)preview.dataset.outputFormat=key;
    if(phone)phone.style.setProperty('--shorts-preview-ratio',meta.ratio);
    if($('shortsFormatBadge'))$('shortsFormatBadge').textContent=`${meta.badge} automático`;
    if($('shortsConfigPreviewBadge'))$('shortsConfigPreviewBadge').textContent=`PRÉVIA ${meta.badge}`;
    if($('shortsFormatHelp'))$('shortsFormatHelp').textContent=`${meta.help} A prévia acompanha esta proporção.`;
    const previewBadge=document.querySelector('.shorts-live-preview-top b');if(previewBadge)previewBadge.textContent=meta.badge;
  }

  function selectVideo(item){
    state.selected={...item};
    $('shortsSelectedTitle').textContent=item.title||'Vídeo do YouTube';
    $('shortsSelectedMeta').textContent=[item.channel||'YouTube',item.duration_label||''].filter(Boolean).join(' · ');
    $('shortsSelectedThumb').innerHTML=item.thumbnail_url?`<img src="${escapeHtml(item.thumbnail_url)}" alt="Miniatura" referrerpolicy="no-referrer">`:'';
    $('shortsSelectedVideo').classList.remove('hidden');updateComposerPreview(item);selectedReady();
    $('shortsSelectedVideo').scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  function clearSelection(){state.selected=null;const sourceSelect=$('shortsLibrarySource');if(sourceSelect)sourceSelect.value='';$('shortsSelectedVideo').classList.add('hidden');updateComposerPreview();selectedReady()}

  async function loadLibrarySources(){
    const select=$('shortsLibrarySource');if(!select)return;
    try{const data=await shortsJSON('/api/shorts/library-sources');state.librarySources=data.items||[];select.innerHTML='<option value="">Selecione um vídeo, imagem ou áudio já processado</option>'+state.librarySources.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(item.title||'Mídia da Biblioteca')}${item.duration_label?` · ${escapeHtml(item.duration_label)}`:''}</option>`).join('')}
    catch{state.librarySources=[];select.innerHTML='<option value="">Biblioteca indisponível no momento</option>'}
  }

  function selectLibrarySource(){const select=$('shortsLibrarySource'),item=state.librarySources.find(row=>row.id===select?.value);if(!item){if(select?.value==='')clearSelection();return}selectVideo({...item,url:'',source_job_id:item.id})}

  function renderSearch(){
    const box=$('shortsSearchResults');
    if(!state.items.length){box.innerHTML='<div class="empty-state">Nenhum vídeo encontrado.</div>';return}
    box.innerHTML=state.items.map((item,i)=>`<article class="shorts-search-card">
      <span class="shorts-search-thumb"><img src="${escapeHtml(item.thumbnail_url||'')}" alt="Miniatura" loading="lazy" referrerpolicy="no-referrer"><span>${escapeHtml(item.duration_label||'')}</span></span>
      <span class="shorts-search-copy"><strong>${escapeHtml(item.title||'Vídeo')}</strong><small>${escapeHtml(item.channel||'YouTube')}</small><em>${escapeHtml(viewsText(item.view_count))}</em></span>
      <button class="btn btn-secondary btn-small" data-shorts-select="${i}" type="button">Usar vídeo</button>
    </article>`).join('');
    box.querySelectorAll('[data-shorts-select]').forEach(btn=>btn.addEventListener('click',()=>selectVideo(state.items[Number(btn.dataset.shortsSelect)])));
  }

  function shortsRecommendationMarkup(item){return `<article class="shorts-recommendation-card" data-shorts-rec-id="${escapeHtml(item.id)}"><div class="shorts-recommendation-thumb"><img src="${escapeHtml(item.thumbnail_url||'')}" alt="Miniatura de ${escapeHtml(item.title||'vídeo')}" loading="lazy" referrerpolicy="no-referrer"><span>${escapeHtml(item.duration_label||'')}</span></div><div class="shorts-recommendation-copy"><strong>${escapeHtml(item.title||'Vídeo do YouTube')}</strong><small>${escapeHtml(item.channel||'YouTube')}</small><div><button class="btn btn-secondary btn-small" data-shorts-rec-select="${escapeHtml(item.id)}" type="button">Usar vídeo</button><button class="shorts-recommendation-dismiss" data-shorts-rec-dismiss="${escapeHtml(item.id)}" type="button" title="Não tenho interesse">×</button></div></div></article>`}
  function renderShortsRecommendations(items=[],reason=''){
    const panel=$('shortsRecommendationsPanel'),box=$('shortsRecommendationsList'),reasonEl=$('shortsRecommendationsReason');if(!panel||!box)return;
    if(reasonEl)reasonEl.textContent=reason||'Com base no que você já pesquisa e assiste.';
    if(!items.length){box.innerHTML='<div class="shorts-recommendations-empty"><span>⌕</span><strong>Suas sugestões aparecerão aqui.</strong><p>Pesquise ou assista vídeos no RedScribe para começar a receber recomendações.</p></div>';return}
    const byId=new Map(items.map(item=>[item.id,item]));box.innerHTML=items.map(shortsRecommendationMarkup).join('');
    box.querySelectorAll('[data-shorts-rec-select]').forEach(btn=>btn.addEventListener('click',()=>{const item=byId.get(btn.dataset.shortsRecSelect);if(item){selectVideo(item);panel.classList.add('has-selection')}}));
    box.querySelectorAll('[data-shorts-rec-dismiss]').forEach(btn=>btn.addEventListener('click',async()=>{try{await shortsJSON('/api/recommendations/dismiss',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:btn.dataset.shortsRecDismiss})});const card=btn.closest('.shorts-recommendation-card');card?.remove();if(!box.querySelector('.shorts-recommendation-card'))renderShortsRecommendations([],reason)}catch(err){toast(err.message)}}));
  }
  async function loadShortsRecommendations(){try{const data=await shortsJSON('/api/recommendations?cache_only=1');renderShortsRecommendations(data.items||[],data.reason||'')}catch{renderShortsRecommendations()}}
  async function clearShortsRecommendations(){const cards=[...document.querySelectorAll('[data-shorts-rec-id]')];if(!cards.length){renderShortsRecommendations();return}try{await Promise.all(cards.map(card=>shortsJSON('/api/recommendations/dismiss',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:card.dataset.shortsRecId})})));renderShortsRecommendations();toast('Sugestões limpas')}catch(err){toast(err.message)}}

  async function searchShorts(){
    const q=$('shortsSearchInput').value.trim();if(q.length<2)return toast('Digite pelo menos 2 caracteres para pesquisar.');
    const btn=$('shortsSearchBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Pesquisando...';setStateBox('Pesquisando no YouTube...');
    try{const data=await shortsJSON(`/api/youtube/search/v2?q=${encodeURIComponent(q)}&limit=10&remember=1`);state.items=data.items||[];setStateBox('');renderSearch();loadShortsRecommendations()}
    catch(err){state.items=[];renderSearch();setStateBox(err.message,true)}
    finally{btn.disabled=false;btn.textContent=old}
  }

  function taskProgress(task){
    const p=Math.max(0,Math.min(100,Number(task?.progress||0))),panel=$('shortsProgressPanel');panel?.classList.remove('hidden');panel?.classList.toggle('is-complete',task?.status==='done');
    $('shortsProgressStage').textContent=task?.stage||'Processando...';$('shortsProgressPercent').textContent=`${p}%`;$('shortsProgressBar').style.width=`${p}%`;
    let detail=task?.kind==='download'?'Preparando e salvando o vídeo original.':'Preparando a fonte, escolhendo momentos e montando os vídeos verticais.';
    if(task?.source_reused)detail='Fonte e transcrição reutilizadas da Biblioteca; pulando etapas que já estão prontas.';
    if(task?.selection_method)detail=task.selection_method;if(task?.error)detail=task.error;$('shortsProgressDetail').textContent=detail;
    const ready=(task?.outputs||[]).length,target=Number(task?.target_count||0);
    if($('shortsRenderCount'))$('shortsRenderCount').textContent=task?.kind==='download'?'Preparando arquivo...':target?`${ready} de ${target} Short${target===1?'':'s'} pronto${ready===1?'':'s'} para assistir`:`${ready} Short${ready===1?'':'s'} pronto${ready===1?'':'s'} para assistir`;
    if($('shortsRenderStatus'))$('shortsRenderStatus').textContent=task?.status==='done'?'Montagem concluída':ready?`Short ${ready} liberado · o restante continua sendo criado`:(task?.stage||'Preparando a montagem');
  }

  function updateOutputSelectionUI(task){
    const bulk=$('shortsOutputBulkActions'),tools=$('shortsOutputSelectionTools'),modeBtn=$('shortsOutputSelectionModeBtn');
    const outputs=task?.outputs||[];
    if(!bulk||!outputs.length)return;
    bulk.classList.remove('hidden');
    bulk.dataset.taskId=task.id||'';
    tools?.classList.toggle('hidden',!state.outputSelectionMode);
    if(modeBtn){modeBtn.textContent=state.outputSelectionMode?'Cancelar seleção':'Selecionar';modeBtn.classList.toggle('is-active',state.outputSelectionMode)}
    const pending=outputs.filter(o=>!o.library_id);
    const selected=[...state.selectedOutputIndexes].filter(idx=>pending.some(o=>Number(o.index)===Number(idx)));
    state.selectedOutputIndexes=new Set(selected);
    const all=$('shortsOutputSelectAll');if(all){all.checked=!!pending.length&&pending.every(o=>state.selectedOutputIndexes.has(Number(o.index)));all.indeterminate=selected.length>0&&selected.length<pending.length}
    if($('shortsOutputSelectedCount'))$('shortsOutputSelectedCount').textContent=`${selected.length} selecionado(s)`;
    if($('shortsAddSelectedLibraryBtn'))$('shortsAddSelectedLibraryBtn').disabled=!selected.length;
    if($('shortsClearUnselectedBtn'))$('shortsClearUnselectedBtn').disabled=!pending.length;
  }

  function outputCardMarkup(o){return `<article class="shorts-output-card ${state.outputSelectionMode&&state.selectedOutputIndexes.has(Number(o.index))?'power-selected':''}" data-output-index="${Number(o.index)||0}">
      ${state.outputSelectionMode&&!o.library_id?`<label class="shorts-output-select" title="Selecionar"><input type="checkbox" data-short-library-check="${o.index}" ${state.selectedOutputIndexes.has(Number(o.index))?'checked':''}><span></span></label>`:''}
      <div class="shorts-output-video"><video controls preload="metadata" playsinline src="${escapeHtml(o.url||'')}"></video></div>
      <div class="shorts-output-copy"><strong>Short ${String(o.index||1).padStart(2,'0')}</strong>
        <div class="shorts-output-meta"><span>${Math.round(Number(o.duration||0))}s</span><span>${formatShortTime(o.start)} → ${formatShortTime(o.end)}</span>${o.output_format?`<span>${escapeHtml((FORMAT_META[o.output_format]||FORMAT_META.vertical).badge)}</span>`:''}${o.quality?`<span>${escapeHtml(o.quality)}p</span>`:''}${o.captions_applied?'<span>✓ Legenda</span>':o.captions_requested?'<span>Sem legenda gravada</span>':''}${o.library_id?'<span>✓ Biblioteca</span>':'<span>Pronto para assistir</span>'}</div>
        <div class="shorts-output-actions"><button class="btn btn-primary btn-small" data-save-short="${o.index}" type="button">${o.saved_path?'✓ Salvo':'Salvar no computador'}</button>${o.library_id?`<button class="btn btn-secondary btn-small" data-edit-short="${escapeHtml(o.library_id)}" type="button">Editar</button><button class="btn btn-secondary btn-small" data-publish-short="${escapeHtml(o.library_id)}" type="button">Publicar</button><button class="btn btn-secondary btn-small shorts-remove-library" data-remove-short-library="${escapeHtml(o.library_id)}" data-remove-short-index="${o.index}" type="button">Remover da Biblioteca</button>`:`<button class="btn btn-secondary btn-small" data-add-short-library="${o.index}" type="button">＋ Adicionar à Biblioteca</button>`}</div>
      </div>
    </article>`}

  function taskTargetCount(task){return Math.max(0,Math.min(50,Number(task?.target_count||task?.count||0)||0))}
  function processingOutputMarkup(index,task){const duration=Math.round(Number(task?.duration_seconds||0)),format=(FORMAT_META[task?.output_format]||FORMAT_META.vertical).badge;return `<article class="shorts-output-card shorts-output-card--rendering" data-processing-index="${index}" aria-label="Short ${String(index).padStart(2,'0')} em montagem"><div class="shorts-processing-video"><div class="shorts-processing-phone"><span class="shorts-processing-frame frame-one"></span><span class="shorts-processing-frame frame-two"></span><span class="shorts-processing-frame frame-three"></span><b>▶</b></div></div><div class="shorts-output-copy shorts-processing-copy"><strong>Short ${String(index).padStart(2,'0')}</strong><div class="shorts-output-meta"><span>${duration?`${duration}s`:'Preparando'}</span><span>${format}</span><span>Em montagem</span></div><div class="shorts-processing-status"><span>Montando o Short...</span></div></div></article>`}

  function bindOutputCards(box,task){
    box.querySelectorAll('[data-output-index]:not([data-output-bound])').forEach(card=>{
      card.dataset.outputBound='1';
      card.querySelectorAll('[data-short-library-check]').forEach(c=>c.addEventListener('change',()=>{const idx=Number(c.dataset.shortLibraryCheck);c.checked?state.selectedOutputIndexes.add(idx):state.selectedOutputIndexes.delete(idx);renderOutputs(task,true)}));
      card.querySelectorAll('[data-edit-short]').forEach(btn=>btn.addEventListener('click',()=>window.openStudioAsset?.(btn.dataset.editShort)));
      card.querySelectorAll('[data-publish-short]').forEach(btn=>btn.addEventListener('click',()=>window.openPublishModal?.(btn.dataset.publishShort)));
      card.querySelectorAll('[data-save-short]').forEach(btn=>btn.addEventListener('click',()=>saveShort(task.id,Number(btn.dataset.saveShort),btn)));
      card.querySelectorAll('[data-add-short-library]').forEach(btn=>btn.addEventListener('click',()=>addShortToLibrary(task.id,Number(btn.dataset.addShortLibrary),btn)));
      card.querySelectorAll('[data-remove-short-library]').forEach(btn=>btn.addEventListener('click',()=>removeShortFromLibrary(task.id,Number(btn.dataset.removeShortIndex||0),btn.dataset.removeShortLibrary,btn)));
    });
  }

  function renderOutputs(task,force=false){
    const box=$('shortsOutputList'),outputs=task?.outputs||[],bulk=$('shortsOutputBulkActions');
    const isGenerating=task?.kind==='generate'&&['queued','processing'].includes(task?.status);
    const target=taskTargetCount(task);
    if(!task){box.innerHTML='<div class="empty-state">Os vídeos gerados aparecerão aqui.</div>';if(bulk)bulk.classList.add('hidden');state.outputSelectionMode=false;state.selectedOutputIndexes.clear();state.outputTaskId=null;return}
    if(!outputs.length&&!isGenerating){box.innerHTML='<div class="empty-state">Nenhum Short foi concluído nesta montagem.</div>';if(bulk)bulk.classList.add('hidden');state.outputSelectionMode=false;state.selectedOutputIndexes.clear();return}
    const sameTask=state.outputTaskId===task.id;
    if(!sameTask){state.outputTaskId=task.id||null;state.outputSelectionMode=false;state.selectedOutputIndexes.clear();force=true}
    if(bulk){bulk.classList.toggle('hidden',!outputs.length);bulk.dataset.taskId=task.id||''}

    const byIndex=new Map(outputs.map(output=>[Number(output.index),output]));
    const order=Array.from({length:Math.max(target,outputs.length)},(_,offset)=>offset+1);
    const markup=index=>byIndex.has(index)?outputCardMarkup(byIndex.get(index)):isGenerating?processingOutputMarkup(index,task):'';

    // Enquanto os renders chegam, trocamos apenas o celular correspondente. Players já
    // concluídos não são recriados, portanto continuam reproduzindo normalmente.
    if(!force&&sameTask&&!state.outputSelectionMode&&box.querySelector('[data-output-index]')){
      order.forEach(index=>{const output=byIndex.get(index),ready=box.querySelector(`[data-output-index="${index}"]`),pending=box.querySelector(`[data-processing-index="${index}"]`);if(output&&!ready){if(pending)pending.outerHTML=outputCardMarkup(output);else box.insertAdjacentHTML('beforeend',outputCardMarkup(output))}else if(!output&&isGenerating&&!pending&&!ready){box.insertAdjacentHTML('beforeend',processingOutputMarkup(index,task))}else if(!output&&!isGenerating&&pending){pending.remove()}});
      bindOutputCards(box,task);updateOutputSelectionUI(task);return;
    }
    const cards=order.map(markup).filter(Boolean).join('');box.innerHTML=cards||'<div class="empty-state">Nenhum Short foi concluído nesta montagem.</div>';bindOutputCards(box,task);updateOutputSelectionUI(task);
  }
  function formatShortTime(seconds){seconds=Math.max(0,Math.round(Number(seconds||0)));const m=Math.floor(seconds/60),s=seconds%60;return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}

  async function saveShort(taskId,index,btn){const old=btn.textContent;btn.disabled=true;btn.textContent='Salvando...';try{const d=await shortsJSON(`/api/shorts/save/${taskId}/${index}`,{method:'POST'});toast(`${d.filename} salvo`);const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);renderOutputs(task,true);loadShortsHistory(false)}catch(err){toast(err.message,5000)}finally{btn.disabled=false;if(btn.isConnected&&btn.textContent==='Salvando...')btn.textContent=old}}

  async function addShortToLibrary(taskId,index,btn){
    const old=btn?.textContent||'';if(btn){btn.disabled=true;btn.textContent='Adicionando...'}
    try{await shortsJSON(`/api/shorts/library/add/${taskId}/${index}`,{method:'POST'});toast(`Short ${String(index).padStart(2,'0')} adicionado à Biblioteca.`);const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);renderOutputs(task,true);if(typeof loadLibrary==='function'&&typeof libraryFilter!=='undefined'&&libraryFilter==='shorts')loadLibrary('shorts')}
    catch(err){toast(err.message,5000)}finally{if(btn?.isConnected){btn.disabled=false;if(btn.textContent==='Adicionando...')btn.textContent=old}}
  }
  async function addSelectedShortsToLibrary(){
    const taskId=$('shortsOutputBulkActions')?.dataset.taskId;if(!taskId)return;
    const ids=[...state.selectedOutputIndexes].map(Number).filter(Boolean);if(!ids.length){toast('Selecione pelo menos um Short.');return}
    const btn=$('shortsAddSelectedLibraryBtn'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Adicionando...'}
    try{for(const index of ids)await shortsJSON(`/api/shorts/library/add/${taskId}/${index}`,{method:'POST'});toast(`${ids.length} Short(s) adicionado(s) à Biblioteca.`);state.selectedOutputIndexes.clear();const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);renderOutputs(task,true);if(typeof loadLibrary==='function')loadLibrary(typeof libraryFilter!=='undefined'?libraryFilter:'all')}
    catch(err){toast(err.message,6000)}finally{if(btn){btn.disabled=false;btn.textContent=old}}
  }

  async function clearUnselectedGeneratedShorts(){
    const taskId=$('shortsOutputBulkActions')?.dataset.taskId;if(!taskId)return;
    const keep=[...state.selectedOutputIndexes].map(Number).filter(Boolean);
    const msg=keep.length?`Limpar todos os Shorts gerados que NÃO estão selecionados?\n\n${keep.length} selecionado(s) continuarão disponíveis.`:'Limpar todos os Shorts gerados que ainda não foram enviados para a Biblioteca?';
    if(!confirm(msg))return;
    const btn=$('shortsClearUnselectedBtn'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Limpando...'}
    try{const d=await shortsJSON(`/api/shorts/tasks/${taskId}/cleanup-outputs`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keep_indexes:keep})});toast(`${Number(d.removed||0)} Short(s) removido(s).`);const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);renderOutputs(task,true);loadShortsHistory(false)}
    catch(err){toast(err.message,6000)}finally{if(btn){btn.disabled=false;btn.textContent=old}}
  }


  async function removeShortFromLibrary(taskId,index,assetId,btn){
    if(!assetId)return;
    if(!confirm('Remover este Short da Biblioteca?\n\nO vídeo original, a transcrição e qualquer cópia já salva no computador não serão apagados.'))return;
    const old=btn.textContent;btn.disabled=true;btn.textContent='Removendo...';
    try{
      await shortsJSON(`/api/shorts/library/${encodeURIComponent(assetId)}`,{method:'DELETE'});
      toast('Short removido da Biblioteca.');window.notifyStudioAssetDeleted?.(assetId);
      const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);
      renderOutputs(task,true);
      if(typeof loadLibrary==='function' && typeof libraryFilter!=='undefined' && libraryFilter==='shorts')loadLibrary('shorts');
    }catch(err){toast(err.message,5000)}
    finally{if(btn.isConnected){btn.disabled=false;if(btn.textContent==='Removendo...')btn.textContent=old}}
  }

  function renderHistory(){
    const box=$('shortsHistoryList');
    if(!state.tasks.length){box.innerHTML='<div class="empty-state">Nenhuma montagem feita ainda.</div>';return}
    box.innerHTML=state.tasks.slice(0,16).map(t=>{const done=t.status==='done',error=t.status==='error',running=['queued','processing'].includes(t.status);const count=(t.outputs||[]).length;return `<article class="shorts-history-row">
      <span class="shorts-history-icon">${t.kind==='download'?'↓':'▯'}</span>
      <span class="shorts-history-copy"><strong>${escapeHtml(t.title||'Vídeo')}</strong><small>${escapeHtml(t.kind==='download'?(done?'Vídeo original salvo':t.stage||'Download'):done?`${count} Short(s) · ${t.selection_method||'Concluído'}`:t.stage||'Montagem')} · ${formatDate(t.created_at)}</small></span>
      <span class="shorts-history-status">${running?`<span class="shorts-mini-progress"><i style="width:${Math.max(0,Math.min(100,Number(t.progress||0)))}%"></i></span>`:''}${done&&t.kind==='generate'?`<button class="btn btn-secondary btn-small" data-open-shorts-task="${t.id}" type="button">Ver</button>`:''}${error?'<span class="status-badge danger">Erro</span>':done?'<span class="status-badge success">Pronto</span>':''}<button class="shorts-history-delete" data-delete-shorts-task="${t.id}" type="button" title="Remover do histórico">×</button></span>
    </article>`}).join('');
    box.querySelectorAll('[data-open-shorts-task]').forEach(btn=>btn.addEventListener('click',async()=>{try{const task=await shortsJSON(`/api/shorts/tasks/${btn.dataset.openShortsTask}`);setActiveTask(task.id);taskProgress(task);renderOutputs(task,true);$('shortsOutputList').scrollIntoView({behavior:'smooth',block:'start'})}catch(err){toast(err.message)}}));
    box.querySelectorAll('[data-delete-shorts-task]').forEach(btn=>btn.addEventListener('click',async()=>{if(!confirm('Remover esta tarefa do histórico? Os Shorts já gerados continuarão disponíveis na Biblioteca.'))return;try{await shortsJSON(`/api/shorts/tasks/${btn.dataset.deleteShortsTask}`,{method:'DELETE'});if(state.activeTaskId===btn.dataset.deleteShortsTask){setActiveTask(null);$('shortsProgressPanel').classList.add('hidden');renderOutputs(null)}loadShortsHistory(false)}catch(err){toast(err.message)}}));
  }

  async function loadShortsHistory(resume=true){
    try{const d=await shortsJSON('/api/shorts/tasks');state.tasks=d.items||[];renderHistory();if(resume&&!state.activeTaskId){const running=state.tasks.find(t=>['queued','processing'].includes(t.status));if(running){setActiveTask(running.id);taskProgress(running);startPoll()}}}
    catch(err){$('shortsHistoryList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
  }

  async function clearShortsHistory(){
    const removable=state.tasks.filter(t=>!['queued','processing'].includes(t.status)).length;
    if(!removable){toast(state.tasks.length?'Aguarde a montagem atual terminar para limpar o restante do histórico.':'O histórico já está vazio.');return}
    if(!confirm(`Limpar ${removable} item(ns) do histórico do Shorts Studio?\n\nOs Shorts preservados na Biblioteca NÃO serão apagados.`))return;
    const btn=$('shortsClearHistoryBtn'),old=btn?.textContent||'Limpar histórico';
    if(btn){btn.disabled=true;btn.textContent='Limpando...'}
    try{
      const current=state.tasks.find(t=>t.id===state.activeTaskId);
      const currentIsRunning=!!current&&['queued','processing'].includes(current.status);
      const d=await shortsJSON('/api/shorts/tasks',{method:'DELETE'});
      if(state.activeTaskId&&!currentIsRunning){setActiveTask(null);$('shortsProgressPanel')?.classList.add('hidden');renderOutputs(null)}
      await loadShortsHistory(false);
      toast(`${Number(d.removed||0)} item(ns) removido(s) do histórico. Seus Shorts da Biblioteca foram mantidos.`,4600);
    }catch(err){toast(err.message,5000)}
    finally{if(btn){btn.disabled=false;btn.textContent=old}}
  }

  async function pollActive(){
    if(!state.activeTaskId)return;
    try{
      const task=await shortsJSON(`/api/shorts/tasks/${state.activeTaskId}`);
      const outputCount=(task.outputs||[]).length;
      const gotNewOutput=outputCount>state.lastOutputCount;
      state.lastOutputCount=outputCount;
      taskProgress(task);
      if(task.kind==='generate'||outputCount)renderOutputs(task);
      if(task.status==='done'){
        stopPoll();setActiveTask(null);
        if(task.kind==='download'){toast(`Vídeo salvo: ${task.filename||'concluído'}`,4200)}else{toast(`${task.outputs?.length||0} Short(s) pronto(s)`,4200)}
        loadShortsHistory(false);
        return;
      }
      if(task.status==='error'){renderOutputs(task,true);stopPoll();setActiveTask(null);toast(task.error||'Falha no Shorts Studio',6000);loadShortsHistory(false);return}
      state.pollDelay=gotNewOutput?900:Math.min(2600,state.pollDelay+180);
    }catch(err){stopPoll();setActiveTask(null);toast(err.message,5000);return}
    if(state.activeTaskId)state.poll=setTimeout(pollActive,state.pollDelay);
  }
  function startPoll(){stopPoll();state.pollDelay=900;state.lastOutputCount=0;pollActive()}
  function stopPoll(){if(state.poll){clearTimeout(state.poll);state.poll=null}}

  function syncSmartControls(){
    const layout=$('shortsLayout')?.value||'crop';
    const supported=['fit','crop'].includes(layout);
    const follow=$('shortsSmartFollow'),compose=$('shortsSmartCompose'),motion=$('shortsSmartMotion'),box=$('shortsSmartBox'),note=$('shortsSmartNote');
    if(follow)follow.disabled=!supported;if(compose)compose.disabled=!supported;if(motion)motion.disabled=!supported||!follow?.checked;
    box?.classList.toggle('is-disabled',!supported);
    if(note)note.textContent=supported?'Disponível neste enquadramento. A análise visual só roda depois de clicar em “Montar Shorts”.':'Escolha Preencher totalmente ou Preenchimento máximo para usar o Auto Reframe inteligente.';
  }

  function payloadBase(){
    if(!state.selected)throw new Error('Escolha um vídeo primeiro.');
    if(!$('shortsRights').checked)throw new Error('Confirme que você tem permissão para reutilizar este vídeo.');
    return {url:state.selected.url,title:state.selected.title,channel:state.selected.channel,thumbnail_url:state.selected.thumbnail_url,source_job_id:state.selected.source_job_id||null,confirmed_rights:true};
  }
  async function downloadSource(){
    try{const payload={...payloadBase(),quality:$('shortsQuality').value};const btn=$('shortsDownloadSourceBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Preparando...';try{const d=await shortsJSON('/api/shorts/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});setActiveTask(d.task.id);taskProgress(d.task);startPoll();loadShortsHistory(false)}finally{btn.disabled=false;btn.textContent=old}}
    catch(err){toast(err.message,5000)}
  }
  async function generateShorts(){
    try{
      const duration=Math.max(15,Math.min(900,Number($('shortsDuration').value||60)));$('shortsDuration').value=String(duration);
      const count=Math.max(1,Math.min(50,Math.floor(Number($('shortsCount').value||2))));$('shortsCount').value=String(count);
      const payload={...payloadBase(),count,duration_seconds:duration,captions:false,use_ai:$('shortsUseAi').checked,output_format:$('shortsPlatform').value,layout:$('shortsLayout').value,quality:$('shortsQuality').value,performance_profile:$('shortsPerformance')?.value||'fast',smart_follow:!!$('shortsSmartFollow')?.checked,smart_compose:!!$('shortsSmartCompose')?.checked,smart_motion:$('shortsSmartMotion')?.value||'smooth'};
      const btn=$('shortsGenerateBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Iniciando...';
      try{const d=await shortsJSON('/api/shorts/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});setActiveTask(d.task.id);renderOutputs(d.task,true);taskProgress(d.task);$('shortsProgressPanel')?.scrollIntoView({behavior:'smooth',block:'center'});startPoll();loadShortsHistory(false)}
      finally{btn.disabled=false;btn.textContent=old}
    }catch(err){toast(err.message,5000)}
  }

  function bindDurationPresets(){
    const duration=$('shortsDuration');
    if(!duration)return;
    $$('[data-shorts-duration]').forEach(btn=>btn.addEventListener('click',()=>{
      const value=Math.max(15,Math.min(900,Number(btn.dataset.shortsDuration)||60));
      duration.value=String(value);
      $$('[data-shorts-duration]').forEach(item=>item.classList.toggle('is-active',item===btn));
    }));
    duration.addEventListener('input',()=>{
      const value=Number(duration.value||0);
      $$('[data-shorts-duration]').forEach(btn=>btn.classList.toggle('is-active',Number(btn.dataset.shortsDuration)===value));
    });
  }

  function initShorts(){
    if(state.initialized)return;state.initialized=true;
    // Padrões da montagem: 9:16 padrão, Auto Reframe desligado, IA ligada e permissão marcada.
    if($('shortsLayout'))$('shortsLayout').value='crop';
    if($('shortsPlatform'))$('shortsPlatform').value='vertical';
    if($('shortsSmartFollow'))$('shortsSmartFollow').checked=false;
    if($('shortsSmartCompose'))$('shortsSmartCompose').checked=false;
    if($('shortsUseAi'))$('shortsUseAi').checked=true;
    if($('shortsRights'))$('shortsRights').checked=true;
    bindDurationPresets();
    $('shortsClearRecommendationsBtn')?.addEventListener('click',clearShortsRecommendations);
    loadShortsRecommendations();
    loadLibrarySources();
    $('shortsLibrarySource')?.addEventListener('change',selectLibrarySource);
    $('shortsRefreshLibrarySourcesBtn')?.addEventListener('click',loadLibrarySources);
    $('shortsSearchBtn')?.addEventListener('click',searchShorts);$('shortsSearchInput')?.addEventListener('keydown',e=>{if(e.key==='Enter')searchShorts()});$('shortsClearSearchBtn')?.addEventListener('click',()=>{const input=$('shortsSearchInput'),results=$('shortsSearchResults'),stateBox=$('shortsSearchState');if(input)input.value='';if(results)results.innerHTML='<div class=\"empty-state\">Pesquise um vídeo para começar.</div>';if(stateBox){stateBox.classList.add('hidden');stateBox.textContent=''}input?.focus()});$('shortsClearSelectionBtn')?.addEventListener('click',clearSelection);$('shortsDownloadSourceBtn')?.addEventListener('click',downloadSource);$('shortsGenerateBtn')?.addEventListener('click',generateShorts);$('shortsOutputSelectionModeBtn')?.addEventListener('click',async()=>{state.outputSelectionMode=!state.outputSelectionMode;if(!state.outputSelectionMode)state.selectedOutputIndexes.clear();const taskId=$('shortsOutputBulkActions')?.dataset.taskId||state.activeTaskId;if(taskId){try{const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);renderOutputs(task,true)}catch{}}});$('shortsOutputSelectAll')?.addEventListener('change',async e=>{const taskId=$('shortsOutputBulkActions')?.dataset.taskId||state.activeTaskId;if(!taskId)return;try{const task=await shortsJSON(`/api/shorts/tasks/${taskId}`);state.selectedOutputIndexes.clear();if(e.target.checked)(task.outputs||[]).filter(o=>!o.library_id).forEach(o=>state.selectedOutputIndexes.add(Number(o.index)));renderOutputs(task,true)}catch(err){toast(err.message)}});$('shortsAddSelectedLibraryBtn')?.addEventListener('click',addSelectedShortsToLibrary);$('shortsClearUnselectedBtn')?.addEventListener('click',clearUnselectedGeneratedShorts);$('shortsRefreshHistoryBtn')?.addEventListener('click',()=>loadShortsHistory(false));$('shortsClearHistoryBtn')?.addEventListener('click',clearShortsHistory);$('shortsLayout')?.addEventListener('change',syncSmartControls);$('shortsPlatform')?.addEventListener('change',syncFormatPreview);$('shortsSmartFollow')?.addEventListener('change',syncSmartControls);syncSmartControls();syncFormatPreview();selectedReady();if(state.activeTaskId)startPoll();
  }

  const previousSwitchView=window.switchView || switchView;
  switchView=function(name){previousSwitchView(name);if(name==='shorts'){initShorts();loadShortsHistory(true)}if(state.activeTaskId&&!state.poll)startPoll()};
})();
