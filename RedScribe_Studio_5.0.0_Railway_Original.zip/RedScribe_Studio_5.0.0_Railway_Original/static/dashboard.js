const $ = (id) => document.getElementById(id);
const $$ = (sel) => [...document.querySelectorAll(sel)];
const body = document.body;
const userName = body.dataset.userName || 'Usuário';

let activeJob = null;
let currentJob = null;
let processingJobId = null;
let pollTimer = null;
let jobPollToken = 0;
let libraryPane = 'works';
let libraryViewerJobId = null;
let libraryItems = [];
let shortsLibraryItems = [];
let shortsLibrarySelectionMode = false;
const selectedShortLibrary = new Set();
let trashSelectionMode = false;
let trashItems = [];
const selectedTrashItems = new Set();
let homeHistoryItems = [];
let downloadItems = [];
let projects = [];
let libraryFilter = 'all';
let downloadFilter = 'all';
let currentSource = 'link';
let pendingSeek = null;
let searchTimer = null;
let globalSearchTimer = null;
let youtubeLiveTimer = null;
let queueRefreshTimer = null;
let settingsCache = {};
const notifiedJobs = new Set();
let onboardingStep = 0;
let onboardingCompleted = false;

function initials(name){return (name || 'U').trim().split(/\s+/).slice(0,2).map(p=>p[0]).join('').toUpperCase();}
['sidebarAvatar','settingsAvatar'].forEach(id=>{const el=$(id);if(el)el.textContent=initials(userName)});

const viewMeta = {
  home:['Início','Visão geral da sua biblioteca.'],
  new:['Nova transcrição','Link, pesquisa no YouTube, arquivo ou fila de vídeos.'],
  library:['Biblioteca','Seus trabalhos, Shorts, mídia e transcrições em um só lugar.'],
  studio:['Estúdio','Edite, personalize e prepare seus Shorts para publicação.'],
  projects:['Projetos','Organize seus trabalhos por contexto.'],
  ai:['IA','Assistente integrado para organizar, criar e analisar conteúdo.'],
  queue:['Fila','Acompanhe os processamentos em sequência.'],
  downloads:['Baixados','Arquivos realmente salvos no computador.'],
  trash:['Lixeira','Itens removidos ficam aqui por até 30 dias.'],
  plan:['Plano','Acompanhe o acesso disponível nesta edição do RedScribe.'],
  settings:['Configurações','Preferências essenciais e ferramentas de manutenção.']
};

function switchView(name){
  if(!viewMeta[name]) return;
  if(name!=='home' && typeof musicTrack==='function' && musicTrack()) setMusicCollapsed(true);
  $$('.app-view').forEach(v=>v.classList.toggle('active',v.dataset.viewPanel===name));
  $$('.nav-item').forEach(v=>v.classList.toggle('active',v.dataset.view===name));
  $('viewTitle').textContent=viewMeta[name][0];
  $('viewSubtitle').textContent=viewMeta[name][1];
  $('sidebar').classList.remove('open');
  clearInterval(queueRefreshTimer); queueRefreshTimer=null;
  if(name==='home') loadHistory();
  if(name==='library'){syncLibraryPane();if(libraryPane==='works')loadLibrary(libraryFilter)}
  if(name==='projects') loadProjects(true);
  if(name==='studio' && window.loadStudioHome) window.loadStudioHome();
  if(name==='ai'){loadAIStatus();loadAIHistory();loadAIContextOptions()}
  if(name==='plan') loadPlanPreference();
  if(name==='queue'){loadQueue();queueRefreshTimer=setInterval(loadQueue,3500)}
  if(name==='downloads') loadDownloads();
  if(name==='trash') loadTrash();
  if(name==='settings'){loadSettings();loadStorageStats();loadUpdateStatus()}
}
$$('.nav-item').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
$$('[data-go-new]').forEach(b=>b.addEventListener('click',()=>switchView('new')));
$$('[data-view-target]').forEach(b=>b.addEventListener('click',()=>{const target=b.dataset.viewTarget;if(target==='library')libraryPane='works';switchView(target)}));
$('mobileMenu').addEventListener('click',()=>$('sidebar').classList.add('open'));
$('sidebarClose').addEventListener('click',()=>$('sidebar').classList.remove('open'));

function toast(msg,ms=2400){const el=$('toast');el.textContent=msg;el.classList.remove('hidden');clearTimeout(el._t);el._t=setTimeout(()=>el.classList.add('hidden'),ms)}
function escapeHtml(value){const d=document.createElement('div');d.textContent=value??'';return d.innerHTML}
function formatDate(ts){if(!ts)return '—';return new Intl.DateTimeFormat('pt-BR',{dateStyle:'short',timeStyle:'short'}).format(new Date(ts*1000))}
function formatBytes(bytes){if(!Number.isFinite(Number(bytes)))return '0 B';const n=Number(bytes);if(n<1024)return `${n} B`;if(n<1048576)return `${(n/1024).toFixed(1)} KB`;if(n<1073741824)return `${(n/1048576).toFixed(1)} MB`;return `${(n/1073741824).toFixed(2)} GB`}
function statusBadge(item){if(item.status==='done')return item.media_only?'<span class="status-badge neutral">Só mídia</span>':'<span class="status-badge success">Concluído</span>';if(item.status==='error')return '<span class="status-badge danger">Erro</span>';if(item.status==='queued')return '<span class="status-badge neutral">Na fila</span>';return `<span class="status-badge neutral">${Math.max(0,Math.min(100,Number(item.progress||0)))}%</span>`}
function assetChips(item){let out='';if(item.transcript_available)out+='<span class="asset-chip text">Texto</span>';if(item.media_only)out+='<span class="asset-chip media">Sem fala</span>';if(item.audio_ready)out+='<span class="asset-chip audio">Áudio</span>';if(item.video_ready)out+=`<span class="asset-chip video">${escapeHtml(item.video_quality||'Vídeo')}</span>`;return out}
function thumbHtml(item){const src=item.thumbnail_url;if(src)return `<span class="history-thumb thumb-image"><img src="${escapeHtml(src)}" alt="Miniatura do vídeo" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.parentElement.classList.remove('thumb-image');this.remove()"></span>`;return '<span class="history-thumb" aria-hidden="true"></span>'}
function projectName(id){return (projects.find(p=>p.id===id)||{}).name||''}

function setQueueIndicators(value){const n=Math.max(0,Number(value)||0);$('queueCount').textContent=n;$('queueCount').classList.toggle('hidden',n===0);$('statQueue').textContent=n}
function bumpQueueIndicators(delta=1){const current=Math.max(Number($('queueCount').textContent)||0,Number($('statQueue').textContent)||0);setQueueIndicators(current+Number(delta||0))}

async function fetchJSON(url,opts){const r=await fetch(url,opts);let data={};try{data=await r.json()}catch{data={}}if(r.status===401){location.href='/login';throw new Error('Sessão expirada.')}if(!r.ok)throw new Error(data.error||'Erro ao carregar.');return data}

const planPresentation={
  essencial:{name:'Essencial',description:'Uma referência para transformar fontes e ideias em conteúdo recorrente.'},
  studio:{name:'Studio',description:'Uma referência para produção avançada, revisão e publicação.'},
  equipe:{name:'Equipe',description:'Uma referência para organizar canais, clientes e fluxos compartilhados.'},
  preview:{name:'Studio Preview',description:'Todos os recursos de produção estão disponíveis nesta etapa: transcrição, Shorts, Estúdio, Biblioteca e exportações.'}
};
function renderPlanPreference(user){const plan=String(user?.plan||'preview').toLowerCase(),meta=planPresentation[plan]||planPresentation.preview;$('currentPlanName')&&( $('currentPlanName').textContent=meta.name);$('currentPlanDescription')&&($('currentPlanDescription').textContent=meta.description);$('currentPlanStatus')&&($('currentPlanStatus').textContent=plan==='preview'?'Uso liberado':`${meta.name} selecionado`);$$('[data-plan-card]').forEach(card=>card.classList.toggle('is-selected',card.dataset.planCard===plan));$$('[data-select-plan]').forEach(btn=>{const active=btn.dataset.selectPlan===plan;btn.textContent=active?'Plano selecionado':`Escolher ${planPresentation[btn.dataset.selectPlan]?.name||'plano'}`;btn.classList.toggle('btn-primary',active);btn.classList.toggle('btn-secondary',!active)})}
async function loadPlanPreference(){try{const data=await fetchJSON('/api/me');renderPlanPreference(data.user)}catch(err){toast(err.message)}}
$$('[data-select-plan]').forEach(btn=>btn.addEventListener('click',async()=>{const plan=btn.dataset.selectPlan;btn.disabled=true;try{const data=await fetchJSON('/api/plan/select',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plan})});renderPlanPreference(data.user);toast(data.message||'Plano salvo')}catch(err){toast(err.message)}finally{btn.disabled=false}}));

async function loadProjects(render=false){
  try{
    const data=await fetchJSON('/api/projects');projects=data.items||[];
    ['projectSelect','libraryProjectFilter'].forEach(id=>{const el=$(id);if(!el)return;const current=el.value;const first=id==='libraryProjectFilter'?'<option value="">Todos os projetos</option>':'<option value="">Sem projeto</option>';el.innerHTML=first+projects.map(p=>`<option value="${p.id}">${escapeHtml(p.name)}${id==='libraryProjectFilter'?` (${p.count||0})`:''}</option>`).join('');if([...el.options].some(o=>o.value===current))el.value=current});
    if(render)renderProjects();
  }catch(err){if(render)$('projectsList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
function renderProjects(){
  const list=$('projectsList');
  const totals=projects.reduce((acc,item)=>{acc.items+=Number(item.count||0);acc.shorts+=Number(item.short_count||0);acc.audio+=Number(item.audio_count||0);return acc},{items:0,shorts:0,audio:0});
  if($('projectsTotal'))$('projectsTotal').textContent=String(projects.length);
  if($('projectsItemsTotal'))$('projectsItemsTotal').textContent=String(totals.items);
  if($('projectsShortsTotal'))$('projectsShortsTotal').textContent=String(totals.shorts);
  if($('projectsAudioTotal'))$('projectsAudioTotal').textContent=String(totals.audio);
  list.innerHTML=projects.length?projects.map(p=>`<article class="project-card"><span class="project-icon ${p.audio_count?'has-audio':''}">${p.audio_count?'♫':'▣'}</span><div><strong>${escapeHtml(p.name)}</strong><small>${p.count||0} item(ns)${p.short_count?` · ${p.short_count} Short(s)`:''}${p.audio_count?` · ${p.audio_count} áudio(s)`:''}</small></div><div class="project-actions"><button class="row-action" data-open-project="${p.id}">Abrir</button>${p.audio_count?`<button class="row-action project-playlist-btn" data-play-project="${p.id}">▶ Ouvir playlist</button>`:''}<button class="row-action" data-rename-project="${p.id}">Renomear</button><button class="row-action danger" data-delete-project="${p.id}">Excluir</button></div></article>`).join(''):'<div class="empty-library project-empty-state"><strong>Nenhum projeto</strong>Crie um projeto para separar canais, clientes ou temas.</div>';
  list.querySelectorAll('[data-open-project]').forEach(b=>b.addEventListener('click',()=>{libraryPane='works';switchView('library');$('libraryProjectFilter').value=b.dataset.openProject;loadLibrary('all')}));
  list.querySelectorAll('[data-play-project]').forEach(b=>b.addEventListener('click',()=>startProjectPlaylist(b.dataset.playProject)));
  list.querySelectorAll('[data-rename-project]').forEach(b=>b.addEventListener('click',async()=>{const p=projects.find(x=>x.id===b.dataset.renameProject);const name=prompt('Novo nome do projeto:',p?.name||'');if(!name)return;try{await fetchJSON(`/api/projects/${b.dataset.renameProject}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});toast('Projeto renomeado');loadProjects(true)}catch(err){toast(err.message)}}));
  list.querySelectorAll('[data-delete-project]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Excluir este projeto? Os trabalhos não serão apagados, apenas ficarão sem projeto.'))return;try{await fetchJSON(`/api/projects/${b.dataset.deleteProject}`,{method:'DELETE'});toast('Projeto excluído');loadProjects(true)}catch(err){toast(err.message)}}));
}
$('newProjectBtn').addEventListener('click',()=>{$('projectNameInput').value='';$('projectModal').classList.remove('hidden');setTimeout(()=>$('projectNameInput').focus(),50)});
$('cancelProjectBtn').addEventListener('click',()=>$('projectModal').classList.add('hidden'));
$('createProjectBtn').addEventListener('click',async()=>{const name=$('projectNameInput').value.trim();if(!name)return;try{await fetchJSON('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});$('projectModal').classList.add('hidden');toast('Projeto criado');loadProjects(true)}catch(err){toast(err.message)}});
$('projectNameInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('createProjectBtn').click()});

async function loadHistory(){
  try{const data=await fetchJSON('/api/history');homeHistoryItems=data.items||[];
    $('statJobs').textContent=data.stats.jobs||0;$('statAudio').textContent=data.stats.audio||0;$('statVideo').textContent=data.stats.video||0;$('statDownloads').textContent=data.stats.downloads||0;$('statFavorites').textContent=data.stats.favorites||0;setQueueIndicators(data.stats.queued||0);
    const items=data.items.slice(0,6);$('recentList').innerHTML=items.length?items.map(historyRow).join(''):'<div class="empty-library"><strong>Nenhum trabalho ainda</strong>Comece criando sua primeira transcrição.</div>';bindHistoryActions($('recentList'));
    const fav=(data.items||[]).filter(i=>i.favorite).slice(0,5);$('favoriteList').innerHTML=fav.length?fav.map(historyRow).join(''):'<div class="empty-library"><strong>Sem favoritos</strong>Marque trabalhos importantes com a estrela.</div>';bindHistoryActions($('favoriteList'));
  }catch(err){$('recentList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
function historyRow(item){return `<article class="history-row">${thumbHtml(item)}<div class="history-copy"><strong>${escapeHtml(item.title||'Trabalho')}</strong><div class="history-meta"><span>${escapeHtml(item.duration_label||'Duração indisponível')}</span><span>${formatDate(item.created_at)}</span>${item.source?`<span>${escapeHtml(item.source)}</span>`:''}</div><div class="asset-chips">${assetChips(item)}</div></div><div class="history-actions">${statusBadge(item)}<button class="favorite-mini ${item.favorite?'active':''}" data-favorite-job="${item.id}" data-favorite-state="${item.favorite?'1':'0'}" title="Favoritar">★</button><button class="row-action" data-open-job="${item.id}">Abrir</button></div></article>`}
function bindHistoryActions(root){
  root.querySelectorAll('[data-open-job]').forEach(b=>b.addEventListener('click',()=>openJob(b.dataset.openJob)));
  root.querySelectorAll('[data-favorite-job]').forEach(b=>b.addEventListener('click',()=>toggleFavorite(b.dataset.favoriteJob,b.dataset.favoriteState!=='1')));
}
function syncLibraryPane(){
  const viewer=libraryPane==='viewer';
  $$('.library-workspace-tab').forEach(b=>b.classList.toggle('active',b.dataset.libraryPage===libraryPane));
  $$('[data-library-page-panel]').forEach(p=>p.classList.toggle('hidden',p.dataset.libraryPagePanel!==libraryPane));
  if($('libraryPageTitle'))$('libraryPageTitle').textContent=viewer?(currentJob?.title||'Trabalho aberto'):'Seus trabalhos';
  if($('libraryPageSubtitle'))$('libraryPageSubtitle').textContent=viewer?'Vídeo, áudio, transcrição sincronizada, editor e IA do trabalho aberto.':'Pesquise títulos, filtre por projeto e encontre até palavras faladas dentro dos vídeos.';
  if($('libraryViewerCurrentTitle'))$('libraryViewerCurrentTitle').textContent=currentJob?.title||'Nenhum trabalho aberto';
  if($('libraryViewerEmpty'))$('libraryViewerEmpty').classList.toggle('hidden',!!(currentJob&&currentJob.status==='done'));
  if($('resultCard')&&viewer&&!currentJob)$('resultCard').classList.add('hidden');
}
function setLibraryPane(name,{load=true}={}){
  libraryPane=name==='viewer'?'viewer':'works';syncLibraryPane();
  if(libraryPane==='works'&&load)loadLibrary(libraryFilter);
}
$$('[data-library-page]').forEach(b=>b.addEventListener('click',()=>setLibraryPane(b.dataset.libraryPage)));
$('libraryViewerBackBtn')?.addEventListener('click',()=>setLibraryPane('works'));
function showLibraryJob(job,{fromCompletion=false}={}){
  if(!job||job.status!=='done')return;
  currentJob=job;activeJob=job.id;libraryViewerJobId=job.id;
  libraryPane='viewer';switchView('library');syncLibraryPane();
  $('libraryViewerEmpty')?.classList.add('hidden');
  renderJob(job);
  if(fromCompletion){toast('Transcrição concluída e salva na Biblioteca',3600);loadLibrary('all')}
}
$('openFavoritesBtn').addEventListener('click',()=>{libraryPane='works';switchView('library');$$('[data-library-filter]').forEach(x=>x.classList.toggle('active',x.dataset.libraryFilter==='favorites'));loadLibrary('favorites')});
async function toggleFavorite(id,state){try{await fetchJSON(`/api/jobs/${id}/meta`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({favorite:state})});toast(state?'Adicionado aos favoritos':'Removido dos favoritos');if(currentJob&&currentJob.id===id){currentJob.favorite=state;updateCurrentFavoriteButton()}loadHistory();if(document.querySelector('[data-view-panel="library"]').classList.contains('active'))loadLibrary(libraryFilter)}catch(err){toast(err.message)}}
function updateCurrentFavoriteButton(){const b=$('favoriteCurrentBtn');if(!currentJob)return;b.textContent=currentJob.favorite?'★ Favoritado':'☆ Favoritar';b.classList.toggle('active',!!currentJob.favorite)}
$('favoriteCurrentBtn').addEventListener('click',()=>{if(currentJob)toggleFavorite(currentJob.id,!currentJob.favorite)});

function setLibraryShortsMode(enabled){
  $('libraryPageTitle').textContent=enabled?'Shorts':'Seus trabalhos';
  $('libraryPageSubtitle').textContent=enabled?'Todos os Shorts já montados pelo RedScribe. Assista aqui e salve novamente quando quiser.':'Pesquise títulos, filtre por projeto e encontre até palavras faladas dentro dos vídeos.';
  $('libraryProjectFilter').disabled=enabled;
  const tagFilter=$('libraryTagFilter');if(tagFilter)tagFilter.disabled=enabled;
  $('librarySearch').placeholder=enabled?'Buscar Short por título ou canal...':'Buscar por título, fala ou tag...';
  if(enabled){
    $('libraryBulkBar')?.classList.add('hidden');
    const btn=$('librarySelectionModeBtn');if(btn){btn.textContent=shortsLibrarySelectionMode?'Cancelar seleção':'Selecionar';btn.classList.toggle('is-active',shortsLibrarySelectionMode)}
  }else{
    shortsLibrarySelectionMode=false;selectedShortLibrary.clear();$('libraryShortsBulkBar')?.classList.add('hidden');
  }
}

async function loadLibrary(kind='all'){
  libraryFilter=kind;$('libraryList').innerHTML='<div class="skeleton-list"></div>';
  const shortsMode=kind==='shorts';setLibraryShortsMode(shortsMode);
  try{
    if(shortsMode){const data=await fetchJSON('/api/shorts/library');shortsLibraryItems=data.items||[];renderShortsLibrary();return}
    const pid=$('libraryProjectFilter').value||'';const data=await fetchJSON(`/api/history?kind=${encodeURIComponent(kind)}&project_id=${encodeURIComponent(pid)}`);libraryItems=data.items;renderLibrary()
  }catch(err){$('libraryList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
function projectMoveSelect(item){return `<select class="inline-project-select" data-move-project="${item.id}"><option value="">Sem projeto</option>${projects.map(p=>`<option value="${p.id}" ${item.project_id===p.id?'selected':''}>${escapeHtml(p.name)}</option>`).join('')}</select>`}
function renderLibrary(itemsOverride=null){
  $('libraryList').classList.remove('is-shorts-grid');
  const q=($('librarySearch').value||'').trim().toLowerCase();const base=itemsOverride||libraryItems;const items=itemsOverride?base:base.filter(i=>!q||(i.title||'').toLowerCase().includes(q)||(i.preview||'').toLowerCase().includes(q));
  $('libraryList').innerHTML=items.length?items.map(item=>`<article class="library-card library-card-v3">${thumbHtml(item)}<div class="history-copy"><strong>${escapeHtml(item.title||'Trabalho')}</strong><div class="history-meta"><span>${formatDate(item.created_at)}</span><span>${escapeHtml(item.duration_label||'—')}</span>${item.word_count?`<span>${item.word_count} palavras</span>`:''}${item.project_id?`<span>▣ ${escapeHtml(projectName(item.project_id))}</span>`:''}</div>${item.match_snippet?`<p class="match-snippet">…${escapeHtml(item.match_snippet)}…</p>`:''}<div class="asset-chips">${assetChips(item)}</div></div><div class="history-actions">${statusBadge(item)}<button class="favorite-mini ${item.favorite?'active':''}" data-favorite-job="${item.id}" data-favorite-state="${item.favorite?'1':'0'}">★</button>${projectMoveSelect(item)}<button class="row-action" data-open-job="${item.id}" ${item.match_start!=null?`data-open-at="${item.match_start}"`:''}>Abrir</button><button class="row-action danger" data-delete-job="${item.id}">Lixeira</button></div></article>`).join(''):'<div class="empty-library"><strong>Nada por aqui</strong>Nenhum item corresponde a este filtro.</div>';
  bindHistoryActions($('libraryList'));
  $('libraryList').querySelectorAll('[data-open-at]').forEach(b=>b.addEventListener('click',e=>{e.stopImmediatePropagation();pendingSeek=Number(b.dataset.openAt);openJob(b.dataset.openJob)}));
  $('libraryList').querySelectorAll('[data-delete-job]').forEach(b=>b.addEventListener('click',()=>deleteJob(b.dataset.deleteJob)));
  $('libraryList').querySelectorAll('[data-move-project]').forEach(sel=>sel.addEventListener('change',async()=>{try{await fetchJSON(`/api/jobs/${sel.dataset.moveProject}/meta`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:sel.value||null})});toast('Projeto atualizado');loadLibrary(libraryFilter);loadProjects()}catch(err){toast(err.message)}}));
}
function shortProjectSelect(item){return `<select class="inline-project-select short-project-select" data-move-short-project="${item.id}"><option value="">Sem projeto</option>${projects.map(p=>`<option value="${p.id}" ${item.project_id===p.id?'selected':''}>${escapeHtml(p.name)}</option>`).join('')}</select>`}
function shortClock(seconds){seconds=Math.max(0,Math.round(Number(seconds||0)));const m=Math.floor(seconds/60),s=seconds%60;return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function updateShortLibrarySelectionUI(){
  const items=shortsLibraryItems;
  const bar=$('libraryShortsBulkBar'),btn=$('librarySelectionModeBtn');
  bar?.classList.toggle('hidden',!shortsLibrarySelectionMode);
  if(btn&&libraryFilter==='shorts'){btn.textContent=shortsLibrarySelectionMode?'Cancelar seleção':'Selecionar';btn.classList.toggle('is-active',shortsLibrarySelectionMode)}
  const selected=[...selectedShortLibrary].filter(id=>items.some(x=>x.id===id));
  for(const id of [...selectedShortLibrary])if(!selected.includes(id))selectedShortLibrary.delete(id);
  if($('libraryShortsSelectedCount'))$('libraryShortsSelectedCount').textContent=`${selected.length} selecionado(s)`;
  const all=$('libraryShortsSelectAll');if(all){all.checked=!!items.length&&items.every(x=>selectedShortLibrary.has(x.id));all.indeterminate=selected.length>0&&selected.length<items.length}
  if($('libraryShortsTrashBtn'))$('libraryShortsTrashBtn').disabled=!selected.length;
  if($('libraryShortsDeleteBtn'))$('libraryShortsDeleteBtn').disabled=!selected.length;
}
function toggleShortLibrarySelectionMode(){
  shortsLibrarySelectionMode=!shortsLibrarySelectionMode;
  if(!shortsLibrarySelectionMode)selectedShortLibrary.clear();
  renderShortsLibrary();
}
window.toggleShortLibrarySelectionMode=toggleShortLibrarySelectionMode;

function renderShortsLibrary(){
  $('libraryList').classList.add('is-shorts-grid');
  const q=($('librarySearch').value||'').trim().toLowerCase();
  const items=shortsLibraryItems.filter(i=>!q||(i.title||'').toLowerCase().includes(q)||(i.short_title||'').toLowerCase().includes(q)||(i.channel||'').toLowerCase().includes(q));
  $('libraryList').innerHTML=items.length?items.map(item=>`<article class="library-card library-short-card ${shortsLibrarySelectionMode&&selectedShortLibrary.has(item.id)?'power-selected':''}" style="position:relative">
    ${shortsLibrarySelectionMode?`<input class="library-select-check" type="checkbox" data-short-library-select="${item.id}" ${selectedShortLibrary.has(item.id)?'checked':''} aria-label="Selecionar este Short">`:''}
    <div class="library-short-preview"><video controls preload="metadata" playsinline src="${escapeHtml(item.url||'')}"></video></div>
    <div class="history-copy library-short-copy"><strong>${escapeHtml(item.short_title||item.title||'Short')}</strong><div class="history-meta"><span>${formatDate(item.created_at)}</span><span>${shortClock(item.duration)}</span><span>${escapeHtml(item.channel||'YouTube')}</span>${item.captions_applied?'<span>✓ Legenda</span>':''}</div><div class="asset-chips"><span class="asset-chip video">9:16</span>${item.quality?`<span class="asset-chip media">${escapeHtml(String(item.quality))}p</span>`:''}${item.saved_exists?'<span class="asset-chip audio">Salvo no computador</span>':''}</div></div>
    <div class="history-actions library-short-actions"><span class="status-badge success">Short</span>${shortProjectSelect(item)}<button class="row-action" data-edit-library-short="${item.id}" type="button">Editar</button><button class="row-action" data-publish-library-short="${item.id}" type="button">Publicar</button><button class="row-action" data-save-library-short="${item.id}" type="button">Salvar novamente</button><button class="row-action danger" data-delete-library-short="${item.id}" type="button">Remover</button></div>
  </article>`).join(''):'<div class="empty-library"><strong>Nenhum Short ainda</strong>Os Shorts que você escolher no Shorts Studio aparecerão aqui.</div>';
  $('libraryList').querySelectorAll('[data-short-library-select]').forEach(c=>c.addEventListener('change',()=>{c.checked?selectedShortLibrary.add(c.dataset.shortLibrarySelect):selectedShortLibrary.delete(c.dataset.shortLibrarySelect);renderShortsLibrary()}));
  $('libraryList').querySelectorAll('[data-edit-library-short]').forEach(btn=>btn.addEventListener('click',()=>window.openStudioAsset?.(btn.dataset.editLibraryShort)));
  $('libraryList').querySelectorAll('[data-publish-library-short]').forEach(btn=>btn.addEventListener('click',()=>window.openPublishModal?.(btn.dataset.publishLibraryShort)));
  $('libraryList').querySelectorAll('[data-save-library-short]').forEach(btn=>btn.addEventListener('click',()=>saveLibraryShort(btn.dataset.saveLibraryShort,btn)));
  $('libraryList').querySelectorAll('[data-delete-library-short]').forEach(btn=>btn.addEventListener('click',()=>deleteLibraryShort(btn.dataset.deleteLibraryShort,btn)));
  $('libraryList').querySelectorAll('[data-move-short-project]').forEach(sel=>sel.addEventListener('change',async()=>{const id=sel.dataset.moveShortProject;try{await fetchJSON(`/api/shorts/library/${encodeURIComponent(id)}/project`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:sel.value||null})});const row=shortsLibraryItems.find(x=>x.id===id);if(row)row.project_id=sel.value||null;toast(sel.value?'Short adicionado ao projeto':'Short removido do projeto');loadProjects(false)}catch(err){toast(err.message);renderShortsLibrary()}}));
  updateShortLibrarySelectionUI();
}
async function trashSelectedLibraryShorts(){
  const ids=[...selectedShortLibrary];if(!ids.length)return;
  if(!confirm(`Mover ${ids.length} Short(s) para a Lixeira?`))return;
  const btn=$('libraryShortsTrashBtn'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Movendo...'}
  try{for(const id of ids)await fetchJSON(`/api/shorts/library/${encodeURIComponent(id)}/trash`,{method:'POST'});selectedShortLibrary.clear();shortsLibrarySelectionMode=false;toast(`${ids.length} Short(s) movido(s) para a Lixeira.`);await loadLibrary('shorts')}
  catch(err){toast(err.message,5000)}finally{if(btn){btn.disabled=false;btn.textContent=old}}
}
async function deleteSelectedLibraryShorts(){
  const ids=[...selectedShortLibrary];if(!ids.length)return;
  if(!confirm(`Excluir definitivamente ${ids.length} Short(s)?\n\nEssa ação não pode ser desfeita.`))return;
  const btn=$('libraryShortsDeleteBtn'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Excluindo...'}
  try{for(const id of ids){await fetchJSON(`/api/shorts/library/${encodeURIComponent(id)}`,{method:'DELETE'});window.notifyStudioAssetDeleted?.(id)}selectedShortLibrary.clear();shortsLibrarySelectionMode=false;toast(`${ids.length} Short(s) excluído(s) definitivamente.`);await loadLibrary('shorts')}
  catch(err){toast(err.message,5000)}finally{if(btn){btn.disabled=false;btn.textContent=old}}
}
$('libraryShortsSelectAll')?.addEventListener('change',e=>{selectedShortLibrary.clear();if(e.target.checked)shortsLibraryItems.forEach(x=>selectedShortLibrary.add(x.id));renderShortsLibrary()});
$('libraryShortsTrashBtn')?.addEventListener('click',trashSelectedLibraryShorts);
$('libraryShortsDeleteBtn')?.addEventListener('click',deleteSelectedLibraryShorts);
async function deleteLibraryShort(id,btn){
  if(!confirm('Remover este Short da Biblioteca?\n\nO vídeo original, a transcrição e qualquer cópia já salva no computador não serão apagados.'))return;
  const old=btn.textContent;btn.disabled=true;btn.textContent='Removendo...';
  try{await fetchJSON(`/api/shorts/library/${encodeURIComponent(id)}`,{method:'DELETE'});shortsLibraryItems=shortsLibraryItems.filter(x=>x.id!==id);renderShortsLibrary();window.notifyStudioAssetDeleted?.(id);toast('Short removido da Biblioteca.')}catch(err){toast(err.message,5000)}finally{if(btn.isConnected){btn.disabled=false;btn.textContent=old}}
}
async function saveLibraryShort(id,btn){const old=btn.textContent;btn.disabled=true;btn.textContent='Salvando...';try{const data=await fetchJSON(`/api/shorts/library/save/${id}`,{method:'POST'});toast(`${data.filename} salvo`);const row=shortsLibraryItems.find(x=>x.id===id);if(row)row.saved_exists=true;renderShortsLibrary()}catch(err){toast(err.message,5000)}finally{if(btn.isConnected){btn.disabled=false;if(btn.textContent==='Salvando...')btn.textContent=old}}}
$$('[data-library-filter]').forEach(b=>b.addEventListener('click',()=>{$$('[data-library-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');loadLibrary(b.dataset.libraryFilter)}));
$('libraryProjectFilter').addEventListener('change',()=>{if(libraryFilter!=='shorts')loadLibrary(libraryFilter)});
$('librarySearch').addEventListener('input',()=>{clearTimeout(searchTimer);if(libraryFilter==='shorts'){renderShortsLibrary();return}const q=$('librarySearch').value.trim();if(q.length<2){renderLibrary();return}searchTimer=setTimeout(async()=>{try{const pid=$('libraryProjectFilter').value||'';const data=await fetchJSON(`/api/search?q=${encodeURIComponent(q)}&project_id=${encodeURIComponent(pid)}`);renderLibrary(data.items)}catch{renderLibrary()}},280)});
async function deleteJob(id){if(!confirm('Mover este trabalho para a lixeira? Ele poderá ser restaurado durante 30 dias.'))return;try{await fetchJSON(`/api/jobs/${id}`,{method:'DELETE'});toast('Movido para a lixeira');loadLibrary(libraryFilter);loadHistory()}catch(err){toast(err.message)}}

async function loadQueue(){try{const data=await fetchJSON('/api/history?kind=processing');const items=data.items||[];setQueueIndicators(items.length);$('queueList').innerHTML=items.length?items.map(item=>`<article class="library-card">${thumbHtml(item)}<div class="history-copy"><strong>${escapeHtml(item.title||'Na fila')}</strong><div class="history-meta"><span>${escapeHtml(item.stage||'Aguardando')}</span><span>${item.progress||0}%</span></div><div class="mini-progress"><span style="width:${Math.max(0,Math.min(100,Number(item.progress||0)))}%"></span></div></div><div class="history-actions">${statusBadge(item)}<button class="row-action" data-open-job="${item.id}">Abrir</button></div></article>`).join(''):'<div class="empty-library"><strong>Fila vazia</strong>Nenhum processamento aguardando.</div>';bindHistoryActions($('queueList'));loadHistory()}catch(err){$('queueList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}}

async function loadDownloads(){
  $('downloadsList').innerHTML='<div class="skeleton-list"></div>';
  try{const data=await fetchJSON('/api/downloads');downloadItems=data.items;renderDownloads()}catch(err){$('downloadsList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
function renderDownloads(){
  const items=downloadItems.filter(i=>downloadFilter==='all'||i.kind===downloadFilter);
  $('downloadsList').innerHTML=items.length?items.map(i=>`<article class="download-row"><span class="download-kind">${escapeHtml(i.kind)}</span><div><strong>${escapeHtml(i.filename||i.title)}</strong><small>${escapeHtml(i.title||'')} · ${formatDate(i.downloaded_at)}${i.size_bytes?` · ${formatBytes(i.size_bytes)}`:''}${i.saved_exists?' · Salvo no computador':''}</small></div>${i.available?`<button class="row-action" type="button" data-resave-job="${i.job_id}" data-resave-kind="${i.kind}">Salvar novamente</button>`:(i.saved_exists?'<span class="status-badge success">Salvo</span>':'<span class="status-badge neutral">Arquivo removido</span>')}</article>`).join(''):'<div class="empty-downloads"><strong>Nenhum download neste filtro</strong>Os arquivos que você salvar aparecerão aqui.</div>';
  $('downloadsList').querySelectorAll('[data-resave-job]').forEach(btn=>btn.addEventListener('click',()=>saveAsset(btn.dataset.resaveJob,btn.dataset.resaveKind,btn)));
}
$$('[data-download-filter]').forEach(b=>b.addEventListener('click',()=>{$$('[data-download-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');downloadFilter=b.dataset.downloadFilter;renderDownloads()}));
$('clearDownloadsBtn').addEventListener('click',async()=>{if(!downloadItems.length){toast('O histórico já está vazio');return}if(!confirm('Limpar o histórico? Os arquivos físicos não serão apagados.'))return;try{await fetchJSON('/api/downloads',{method:'DELETE'});downloadItems=[];renderDownloads();loadHistory();toast('Histórico limpo')}catch(err){toast(err.message)}});

function trashSelectionKey(item){return `${item.kind}:${item.id}`}
function syncTrashSelectionUi(){
  const tools=$('trashSelectionTools'),btn=$('trashSelectionModeBtn'),all=$('trashSelectAll'),count=$('trashSelectedCount');
  tools?.classList.toggle('hidden',!trashSelectionMode);if(btn){btn.textContent=trashSelectionMode?'Cancelar seleção':'Selecionar';btn.classList.toggle('is-active',trashSelectionMode)}
  if(count)count.textContent=`${selectedTrashItems.size} selecionado(s)`;
  if(all){all.checked=!!trashItems.length&&trashItems.every(i=>selectedTrashItems.has(trashSelectionKey(i)));all.indeterminate=selectedTrashItems.size>0&&!all.checked}
}
function renderTrash(){
  const list=$('trashList');if(!list)return;
  const html=trashItems.map(item=>{const key=trashSelectionKey(item),checked=selectedTrashItems.has(key),select=trashSelectionMode?`<label class="trash-item-select"><input type="checkbox" data-trash-select="${escapeHtml(key)}" ${checked?'checked':''}></label>`:'';
    if(item.kind==='short')return `<article class="library-card library-card-v3 trash-card-v3 trash-short-card ${checked?'is-selected':''}">${select}<div class="library-short-preview"><video controls preload="metadata" playsinline src="${escapeHtml(item.url||'')}"></video></div><div class="history-copy"><strong>${escapeHtml(item.short_title||item.title||'Short')}</strong><div class="history-meta"><span>Short</span><span>Excluído ${formatDate(item.trashed_at)}</span><span>${shortClock(item.duration)}</span></div></div><div class="history-actions"><button class="row-action" data-restore-short="${item.id}">Restaurar</button><button class="row-action danger" data-permanent-short="${item.id}">Excluir definitivamente</button></div></article>`;
    return `<article class="library-card library-card-v3 trash-card-v3 ${checked?'is-selected':''}">${select}${thumbHtml(item)}<div class="history-copy"><strong>${escapeHtml(item.title||'Trabalho')}</strong><div class="history-meta"><span>Excluído ${formatDate(item.trashed_at)}</span><span>${item.trash_days_left??0} dia(s) restantes</span></div></div><div class="history-actions"><button class="row-action" data-restore-job="${item.id}">Restaurar</button><button class="row-action danger" data-permanent-job="${item.id}">Excluir definitivamente</button></div></article>`;
  }).join('');
  list.innerHTML=html||'<div class="empty-library"><strong>Lixeira vazia</strong>Itens removidos aparecerão aqui.</div>';
  list.querySelectorAll('[data-trash-select]').forEach(c=>c.addEventListener('change',()=>{c.checked?selectedTrashItems.add(c.dataset.trashSelect):selectedTrashItems.delete(c.dataset.trashSelect);renderTrash();syncTrashSelectionUi()}));
  list.querySelectorAll('[data-restore-job]').forEach(b=>b.addEventListener('click',async()=>{try{await fetchJSON(`/api/jobs/${b.dataset.restoreJob}/restore`,{method:'POST'});selectedTrashItems.delete(`job:${b.dataset.restoreJob}`);toast('Trabalho restaurado');loadTrash();loadHistory()}catch(err){toast(err.message)}}));
  list.querySelectorAll('[data-permanent-job]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Excluir definitivamente? Essa ação não pode ser desfeita.'))return;try{await fetchJSON(`/api/jobs/${b.dataset.permanentJob}/permanent`,{method:'DELETE'});selectedTrashItems.delete(`job:${b.dataset.permanentJob}`);toast('Excluído definitivamente');loadTrash()}catch(err){toast(err.message)}}));
  list.querySelectorAll('[data-restore-short]').forEach(b=>b.addEventListener('click',async()=>{try{await fetchJSON(`/api/shorts/trash/${b.dataset.restoreShort}/restore`,{method:'POST'});selectedTrashItems.delete(`short:${b.dataset.restoreShort}`);toast('Short restaurado');loadTrash();if(libraryFilter==='shorts')loadLibrary('shorts')}catch(err){toast(err.message)}}));
  list.querySelectorAll('[data-permanent-short]').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Excluir definitivamente este Short? Essa ação não pode ser desfeita.'))return;try{await fetchJSON(`/api/shorts/trash/${b.dataset.permanentShort}/permanent`,{method:'DELETE'});selectedTrashItems.delete(`short:${b.dataset.permanentShort}`);window.notifyStudioAssetDeleted?.(b.dataset.permanentShort);toast('Short excluído definitivamente');loadTrash()}catch(err){toast(err.message)}}));
  syncTrashSelectionUi();
}
async function loadTrash(){
  const list=$('trashList');if(list&&!trashItems.length)list.innerHTML='<div class="skeleton-list"></div>';
  try{const [jobsData,shortsData]=await Promise.all([fetchJSON('/api/trash'),fetchJSON('/api/shorts/trash').catch(()=>({items:[]}))]);trashItems=[...(jobsData.items||[]).map(x=>({...x,kind:'job'})),...(shortsData.items||[]).map(x=>({...x,kind:'short'}))];for(const key of [...selectedTrashItems])if(!trashItems.some(i=>trashSelectionKey(i)===key))selectedTrashItems.delete(key);renderTrash()}catch(err){if(list)list.innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
async function deleteSelectedTrash(){
  const chosen=trashItems.filter(i=>selectedTrashItems.has(trashSelectionKey(i)));if(!chosen.length){toast('Selecione pelo menos um item.');return}if(!confirm(`Excluir definitivamente ${chosen.length} item(ns)? Essa ação não pode ser desfeita.`))return;
  const btn=$('trashDeleteSelectedBtn'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Excluindo...'};let ok=0,failed=0;
  for(const item of chosen){try{if(item.kind==='short'){await fetchJSON(`/api/shorts/trash/${item.id}/permanent`,{method:'DELETE'});window.notifyStudioAssetDeleted?.(item.id)}else await fetchJSON(`/api/jobs/${item.id}/permanent`,{method:'DELETE'});selectedTrashItems.delete(trashSelectionKey(item));ok++}catch{failed++}}
  if(btn){btn.disabled=false;btn.textContent=old||'Excluir definitivamente'};toast(failed?`${ok} excluído(s) · ${failed} falhou(aram)`:`${ok} item(ns) excluído(s) definitivamente`,4000);loadTrash();
}
$('trashSelectionModeBtn')?.addEventListener('click',()=>{trashSelectionMode=!trashSelectionMode;if(!trashSelectionMode)selectedTrashItems.clear();renderTrash();syncTrashSelectionUi()});
$('trashSelectAll')?.addEventListener('change',e=>{selectedTrashItems.clear();if(e.target.checked)trashItems.forEach(i=>selectedTrashItems.add(trashSelectionKey(i)));renderTrash();syncTrashSelectionUi()});
$('trashDeleteSelectedBtn')?.addEventListener('click',deleteSelectedTrash);

// Busca global
function searchResultMarkup(items){
  return items.length?items.map(i=>`<button class="search-result" type="button" data-search-job="${i.id}" data-search-start="${i.match_start??''}">${thumbHtml(i)}<span><strong>${escapeHtml(i.title||'Trabalho')}</strong><small>${escapeHtml(i.match_snippet||i.preview||'Correspondência no título')}</small></span>${i.match_start!=null?`<em>${fmtTime(i.match_start)}</em>`:''}</button>`).join(''):'<div class="empty-state">Nenhuma correspondência.</div>';
}
function bindQuickSearchResults(container){
  container.querySelectorAll('[data-search-job]').forEach(b=>b.addEventListener('click',()=>{const value=b.dataset.searchStart;pendingSeek=value!==''?Number(value):null;closeQuickSearch();$('globalQuickSearchInput').blur();openJob(b.dataset.searchJob)}));
}
function openSearch(){
  const input=$('globalQuickSearchInput');
  input.focus();
  if(input.value.trim().length>=2)runGlobalQuickSearch();
}
function closeQuickSearch(){ $('globalQuickSearchResults').classList.add('hidden') }
async function runGlobalQuickSearch(){
  const input=$('globalQuickSearchInput'),results=$('globalQuickSearchResults');
  const q=input.value.trim();
  if(!q){results.classList.add('hidden');results.innerHTML='';return}
  results.classList.remove('hidden');
  if(q.length<2){results.innerHTML='<div class="empty-state">Digite pelo menos 2 caracteres.</div>';return}
  try{
    const data=await fetchJSON(`/api/search?q=${encodeURIComponent(q)}`);
    if(input.value.trim()!==q)return;
    const items=data.items||[];results.innerHTML=searchResultMarkup(items);bindQuickSearchResults(results);
  }catch(err){if(input.value.trim()===q)results.innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
}
$('globalQuickSearchInput').addEventListener('input',()=>{
  clearTimeout(globalSearchTimer);
  const q=$('globalQuickSearchInput').value.trim();
  const results=$('globalQuickSearchResults');
  if(!q){results.innerHTML='';results.classList.add('hidden');return}
  results.classList.remove('hidden');
  results.innerHTML=q.length<2?'<div class="empty-state">Digite pelo menos 2 caracteres.</div>':'<div class="empty-state">Buscando...</div>';
  if(q.length>=2)globalSearchTimer=setTimeout(runGlobalQuickSearch,180);
});
$('globalQuickSearchInput').addEventListener('focus',()=>{if($('globalQuickSearchInput').value.trim())runGlobalQuickSearch()});
$('globalQuickSearchInput').addEventListener('keydown',e=>{if(e.key==='Escape'){closeQuickSearch();e.currentTarget.blur()}});
document.addEventListener('click',e=>{if(!$('globalQuickSearch').contains(e.target))closeQuickSearch()});
// Mantém o modal antigo funcional para compatibilidade, mas Ctrl+K agora foca a busca do topo.
$('closeSearchBtn').addEventListener('click',()=>$('searchModal').classList.add('hidden'));
$('searchModal').addEventListener('click',e=>{if(e.target===$('searchModal'))$('searchModal').classList.add('hidden')});
$('globalSearchInput').addEventListener('input',()=>{clearTimeout(globalSearchTimer);const q=$('globalSearchInput').value.trim();if(q.length<2){$('globalSearchResults').innerHTML='<div class="empty-state">Digite pelo menos 2 caracteres.</div>';return}globalSearchTimer=setTimeout(async()=>{try{const data=await fetchJSON(`/api/search?q=${encodeURIComponent(q)}`);const items=data.items||[];$('globalSearchResults').innerHTML=searchResultMarkup(items);$('globalSearchResults').querySelectorAll('[data-search-job]').forEach(b=>b.addEventListener('click',()=>{const value=b.dataset.searchStart;pendingSeek=value!==''?Number(value):null;$('searchModal').classList.add('hidden');openJob(b.dataset.searchJob)}))}catch(err){$('globalSearchResults').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}},180)});

// Configurações
function renderOnboarding(){
  const modal=$('onboardingModal');if(!modal)return;
  $$('[data-onboarding-slide]').forEach(slide=>slide.classList.toggle('active',Number(slide.dataset.onboardingSlide)===onboardingStep));
  $$('.onboarding-progress i').forEach((dot,index)=>dot.classList.toggle('active',index===onboardingStep));
  $('onboardingStepLabel').textContent=`${onboardingStep+1} de 3`;
  $('onboardingBackBtn').classList.toggle('hidden',onboardingStep===0);
  $('onboardingNextBtn').textContent=onboardingStep===2?'Começar agora':'Continuar';
}
async function finishOnboarding(){
  if(onboardingCompleted)return;
  onboardingCompleted=true;$('onboardingModal')?.classList.add('hidden');
  try{await fetchJSON('/api/settings/onboarding/complete',{method:'POST'});settingsCache={...settingsCache,onboarding_seen:true}}catch(err){toast('Não foi possível salvar a apresentação agora. Ela será exibida novamente na próxima abertura.');onboardingCompleted=false}
}
function maybeShowOnboarding(settings){
  if(onboardingCompleted||settings?.onboarding_seen)return;
  const modal=$('onboardingModal');if(!modal)return;
  onboardingStep=0;renderOnboarding();modal.classList.remove('hidden');
}
$('onboardingNextBtn')?.addEventListener('click',()=>{if(onboardingStep<2){onboardingStep+=1;renderOnboarding()}else finishOnboarding()});
$('onboardingBackBtn')?.addEventListener('click',()=>{if(onboardingStep>0){onboardingStep-=1;renderOnboarding()}});
$('onboardingSkipBtn')?.addEventListener('click',finishOnboarding);
$('onboardingModal')?.addEventListener('click',event=>{if(event.target===$('onboardingModal'))finishOnboarding()});
async function loadSettings(){try{const data=await fetchJSON('/api/settings');settingsCache=data;$('storagePath').value=data.storage_parent||'';$('storageResolvedPath').textContent=data.storage_root||'—';$('notificationsSetting').checked=data.notifications!==false;$('syncSetting').checked=data.sync_transcript!==false;$('appVersion').textContent=data.version||'—';loadAIStatus();setTimeout(()=>maybeShowOnboarding(data),260)}catch(err){toast(err.message)}}
async function saveStoragePath(){const directory=$('storagePath').value.trim();if(!directory){toast('Informe uma pasta');return}const btn=$('saveStorageBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Salvando...';try{const data=await fetchJSON('/api/settings/storage',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({directory})});$('storagePath').value=data.storage_parent;$('storageResolvedPath').textContent=data.storage_root;toast('Armazenamento atualizado');loadStorageStats()}catch(err){toast(err.message)}finally{btn.disabled=false;btn.textContent=old}}
$('saveStorageBtn').addEventListener('click',saveStoragePath);$('storagePath').addEventListener('keydown',e=>{if(e.key==='Enter')saveStoragePath()});
$('chooseStorageBtn').addEventListener('click',async()=>{const btn=$('chooseStorageBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Abrindo...';try{const data=await fetchJSON('/api/settings/storage/pick',{method:'POST'});if(!data.cancelled){$('storagePath').value=data.storage_parent||'';$('storageResolvedPath').textContent=data.storage_root||'—';toast('Pasta selecionada');loadStorageStats()}}catch(err){toast(err.message)}finally{btn.disabled=false;btn.textContent=old}});
$('resetStorageBtn').addEventListener('click',async()=>{if(!confirm('Restaurar a pasta padrão?'))return;try{const data=await fetchJSON('/api/settings/storage/reset',{method:'POST'});$('storagePath').value=data.storage_parent;$('storageResolvedPath').textContent=data.storage_root;toast('Pasta padrão restaurada');loadStorageStats()}catch(err){toast(err.message)}});
async function loadStorageStats(){try{const data=await fetchJSON('/api/storage/stats');$('storageTotalLabel').textContent=`${formatBytes(data.total_bytes||0)} usados pelo RedScribe · ${formatBytes(data.exports_bytes||0)} em arquivos salvos`;$('storageBreakdown').innerHTML=Object.entries(data.categories||{}).map(([name,size])=>`<div class="storage-stat"><span>${escapeHtml(name)}</span><strong>${formatBytes(size)}</strong></div>`).join('')}catch(err){$('storageTotalLabel').textContent=err.message}}
$('refreshStorageBtn').addEventListener('click',loadStorageStats);
$('clearCacheBtn').addEventListener('click',async()=>{if(!confirm('Limpar o cache de áudio/vídeo dos trabalhos? Os arquivos já salvos na pasta RedScribe não serão apagados. Para ouvir novamente um item limpo, será necessário processá-lo outra vez.'))return;try{const d=await fetchJSON('/api/storage/cleanup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media:true})});toast(`${formatBytes(d.freed_bytes||0)} liberados`);loadStorageStats();loadHistory()}catch(err){toast(err.message)}});
$('notificationsSetting').addEventListener('change',savePreferences);$('syncSetting').addEventListener('change',savePreferences);
async function savePreferences(){try{const notifications=$('notificationsSetting').checked;const sync_transcript=$('syncSetting').checked;await fetchJSON('/api/settings/preferences',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({notifications,sync_transcript})});settingsCache={...settingsCache,notifications,sync_transcript};if(notifications&&'Notification'in window&&Notification.permission==='default')Notification.requestPermission();toast('Preferências salvas')}catch(err){toast(err.message)}}

$('exportBackupBtn').addEventListener('click',async()=>{const b=$('exportBackupBtn'),old=b.textContent;b.disabled=true;b.textContent='Criando...';try{const data=await fetchJSON('/api/backup/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({include_media:$('backupMedia').checked})});$('backupStatus').textContent=`Backup criado: ${data.saved_path} (${formatBytes(data.size_bytes)})`;toast('Backup criado')}catch(err){toast(err.message)}finally{b.disabled=false;b.textContent=old}});
$('restoreBackupBtn').addEventListener('click',()=>$('backupFile').click());$('backupFile').addEventListener('change',async()=>{const f=$('backupFile').files[0];if(!f)return;if(!confirm('Restaurar este backup e mesclar com a conta atual?'))return;const fd=new FormData();fd.append('backup',f);try{const data=await fetchJSON('/api/backup/restore',{method:'POST',body:fd});toast(`${data.restored_jobs||0} trabalho(s) restaurado(s)`);await loadProjects();loadHistory()}catch(err){toast(err.message)}finally{$('backupFile').value=''}});
async function loadUpdateStatus(){try{const d=await fetchJSON('/api/update/status');$('appVersion').textContent=d.app_version||'—';if($('ytDlpVersion'))$('ytDlpVersion').textContent=d.yt_dlp||'—';if($('redscribeEngineStatus'))$('redscribeEngineStatus').textContent='Componentes essenciais do RedScribe prontos.';if(d.packaged){$('updateComponentsBtn').textContent='Atualização pelo instalador';$('updateComponentsBtn').disabled=true;$('updateComponentsBtn').title='Os componentes essenciais são atualizados junto com o RedScribe.'}}catch{}}
$('checkUpdateBtn').addEventListener('click',async()=>{await loadUpdateStatus();toast('RedScribe verificado')});$('updateComponentsBtn').addEventListener('click',async()=>{if(!confirm('Atualizar os componentes essenciais do RedScribe agora?'))return;const b=$('updateComponentsBtn'),old=b.textContent;b.disabled=true;b.textContent='Atualizando RedScribe...';try{await fetchJSON('/api/update/components',{method:'POST'});toast('RedScribe atualizado. Reinicie o aplicativo.',4200);loadUpdateStatus()}catch(err){toast(err.message,4200)}finally{b.disabled=false;b.textContent=old}});
$('logoutBtn').addEventListener('click',async()=>{try{await fetchJSON('/api/auth/logout',{method:'POST'});location.href='/'}catch{location.href='/'}});

// Origem: link, arquivo, lote
function setSourceTab(name){currentSource=name;$$('.source-tab').forEach(b=>b.classList.toggle('active',b.dataset.sourceTab===name));$$('.source-panel').forEach(p=>p.classList.toggle('active',p.dataset.sourcePanel===name));$('quality').closest('.field-block').classList.toggle('option-muted',name==='file');$('whisper').closest('.switch-row').classList.toggle('option-muted',name==='file');$('transcribeBtn').closest('.form-actions').classList.toggle('hidden',name==='youtube-search')}
function syncQualitySeal(){const q=$('quality')?.value||'1080',seal=$('qualitySeal'),main=$('qualitySealMain'),sub=$('qualitySealSub');if(!seal||!main||!sub)return;seal.className='quality-seal';const map={"1080":["FULL HD","","quality-seal-fhd"],"720":["HD","","quality-seal-hd"],"360":["LEVE","ATÉ 360p","quality-seal-lite"],"best":["MAX","MELHOR DISP.","quality-seal-best"]},v=map[q]||map['1080'];main.textContent=v[0];sub.textContent=v[1];sub.classList.toggle('hidden',!v[1]);seal.classList.add(v[2])}
$('quality')?.addEventListener('change',syncQualitySeal);syncQualitySeal();
$$('.source-tab').forEach(b=>b.addEventListener('click',()=>setSourceTab(b.dataset.sourceTab)));
$('pasteBtn').addEventListener('click',async()=>{try{$('url').value=(await navigator.clipboard.readText()).trim()}catch{}$('url').focus()});
$('chooseMediaBtn').addEventListener('click',e=>{e.stopPropagation();$('mediaFile').click()});$('dropZone').addEventListener('click',e=>{if(e.target.tagName!=='BUTTON')$('mediaFile').click()});
['dragenter','dragover'].forEach(ev=>$('dropZone').addEventListener(ev,e=>{e.preventDefault();$('dropZone').classList.add('dragging')}));['dragleave','drop'].forEach(ev=>$('dropZone').addEventListener(ev,e=>{e.preventDefault();$('dropZone').classList.remove('dragging')}));$('dropZone').addEventListener('drop',e=>{const f=e.dataTransfer.files[0];if(f){const dt=new DataTransfer();dt.items.add(f);$('mediaFile').files=dt.files;updateSelectedFile()}});$('mediaFile').addEventListener('change',updateSelectedFile);function updateSelectedFile(){const f=$('mediaFile').files[0];$('selectedMediaName').textContent=f?`${f.name} · ${formatBytes(f.size)}`:'Nenhum arquivo selecionado'}

const audioPlayer=$('audioPlayer'),videoPlayer=$('videoPlayer'),playbackSpeed=$('playbackSpeed'),videoPlaybackSpeed=$('videoPlaybackSpeed');
function resetMedia(){[audioPlayer,videoPlayer].forEach(p=>{p.pause();p.removeAttribute('src');p.load();p.playbackRate=1});playbackSpeed.value='1';videoPlaybackSpeed.value='1';$('speedBadge').textContent='1x';$('videoSpeedBadge').textContent='1x';$('audioTime').textContent='00:00 / 00:00';$('videoTime').textContent='00:00 / 00:00'}
function setBusy(v){$('transcribeBtn').disabled=v;$('transcribeBtn').querySelector('span').textContent=v?'Processando...':'Processar'}
function stopJobPolling(){jobPollToken++;if(pollTimer)clearTimeout(pollTimer);pollTimer=null;processingJobId=null}
function showError(message){stopJobPolling();setBusy(false);$('progressCard').classList.add('hidden');$('errorMessage').textContent=message||'Erro desconhecido.';$('errorCard').classList.remove('hidden');loadHistory()}
function setResultTab(name){if(currentJob&&!currentJob.transcript_available&&['sync','editor','ai'].includes(name))name=currentJob.video_ready?'video':'audio';$$('.result-tab').forEach(b=>b.classList.toggle('active',b.dataset.resultTab===name));$$('.result-content').forEach(p=>p.classList.toggle('active',p.dataset.resultPanel===name))}
$$('.result-tab').forEach(b=>b.addEventListener('click',()=>setResultTab(b.dataset.resultTab)));

function renderSyncTranscript(job){const root=$('syncTranscript');const segments=job.segments||[];if(!job.transcript_available||!segments.length){root.innerHTML='<div class="empty-state">Não há fala transcrita neste conteúdo.</div>';return}root.innerHTML=segments.map((s,i)=>`<button class="sync-line" type="button" data-sync-index="${i}" data-sync-start="${Number(s.start||0)}"><time>${fmtTime(Number(s.start||0))}</time><span>${escapeHtml(s.text||'')}</span></button>`).join('');root.querySelectorAll('[data-sync-start]').forEach(b=>b.addEventListener('click',()=>seekMedia(Number(b.dataset.syncStart),true)))}
function seekMedia(sec,autoplay=false){const player=currentJob?.video_ready?videoPlayer:audioPlayer;if(!player||!player.src)return;try{player.currentTime=Math.max(0,sec||0);if(autoplay)player.play().catch(()=>{})}catch{}setResultTab(currentJob?.video_ready?'video':'audio')}
function syncActiveLine(time){if(!settingsCache.sync_transcript||!currentJob?.segments?.length)return;const segs=currentJob.segments;let idx=-1;for(let i=0;i<segs.length;i++){const start=Number(segs[i].start||0),end=start+Math.max(.25,Number(segs[i].duration||0));if(time>=start&&time<end){idx=i;break}if(time>=start)idx=i}$$('.sync-line.active').forEach(x=>x.classList.remove('active'));const line=document.querySelector(`[data-sync-index="${idx}"]`);if(line){line.classList.add('active');if(document.querySelector('[data-result-panel="sync"]').classList.contains('active'))line.scrollIntoView({block:'nearest',behavior:'smooth'})}}

function setEditorText(text){$('transcript').value=text||'';$('transcriptEditor').textContent=text||''}
function getEditorText(){const text=($('transcriptEditor').innerText||'').replace(/\n{3,}/g,'\n\n').trim();$('transcript').value=text;return text}
$('transcriptEditor').addEventListener('input',()=>{$('transcript').value=$('transcriptEditor').innerText||''});

function renderProgressState(job){
  const p=Math.max(0,Math.min(100,Number(job?.progress||0)));
  $('stage').textContent=job?.stage||'Processando...';$('percentage').textContent=`${p}%`;$('progressBar').style.width=`${p}%`;
  $('statusDetail').textContent=job?.title&&job.title!=='Transcrição do YouTube'?job.title:(job?.status==='queued'?'Aguardando a vez na fila.':'O conteúdo está sendo analisado.');
}
function renderJob(job){
  renderProgressState(job);
  if(job.status==='error'){showError(job.error||'Falha ao processar.');return true}if(job.status!=='done')return false;
  const wasProcessing=!currentJob||currentJob.status!=='done'||currentJob.id!==job.id;currentJob=job;activeJob=job.id;libraryViewerJobId=job.id;setBusy(false);$('progressCard').classList.add('hidden');$('errorCard').classList.add('hidden');$('resultCard').classList.remove('hidden');$('videoTitle').textContent=job.title||'Trabalho';setEditorText(job.transcript||'');updateCurrentFavoriteButton();
  $('meta').innerHTML=[job.media_only?'Mídia sem fala':`${job.word_count||0} palavras`,job.duration_label||'Duração indisponível',job.detected_language?`Idioma: ${job.detected_language}`:null,job.source||null,job.project_id?`Projeto: ${projectName(job.project_id)}`:null].filter(Boolean).map(x=>`<span>${escapeHtml(x)}</span>`).join('');
  $('mediaOnlyNotice').classList.toggle('hidden',!job.media_only);$('resultStatusBadge').textContent=job.media_only?'Mídia pronta':'Concluído';$('resultStatusBadge').className=`status-badge ${job.media_only?'neutral':'success'}`;
  const textReady=!!job.transcript_available;$$('.text-export').forEach(b=>b.classList.toggle('disabled-download',!textReady));$('saveBtn').disabled=!textReady;$('copyBtn').disabled=!textReady;$$('[data-result-tab="sync"],[data-result-tab="editor"],[data-result-tab="ai"]').forEach(b=>b.classList.toggle('tab-disabled',!textReady));$('aiWorkspace').classList.toggle('hidden',!textReady);$('aiUnavailable').classList.toggle('hidden',textReady);
  renderSyncTranscript(job);
  $('audioDownloadBtn').classList.toggle('disabled-download',!(job.audio_ready&&job.audio_url));$('videoDownloadBtn').classList.toggle('disabled-download',!(job.video_ready&&job.video_url));
  if(job.audio_ready&&job.audio_url){$('audioUnavailable').classList.add('hidden');audioPlayer.src=`${job.audio_url}?v=${encodeURIComponent(job.updated_at||Date.now())}`;audioPlayer.load();$('audioPanel').classList.remove('hidden');$('audioBadge').textContent='Pronto'}else{$('audioPanel').classList.add('hidden');$('audioUnavailable').textContent=job.audio_error?`Áudio indisponível: ${job.audio_error}`:'Áudio indisponível.';$('audioUnavailable').classList.remove('hidden')}
  if(job.video_ready&&job.video_url){$('videoUnavailable').classList.add('hidden');videoPlayer.src=`${job.video_url}?v=${encodeURIComponent(job.updated_at||Date.now())}`;videoPlayer.load();$('videoPanel').classList.remove('hidden');$('videoBadge').textContent='Pronto';$('videoQualityBadge').textContent=job.video_is_full_hd?`Full HD · ${job.video_quality||'1080p'}`:(job.video_quality||'Melhor disponível')}else{$('videoPanel').classList.add('hidden');$('videoUnavailable').textContent=job.video_error?`Vídeo indisponível: ${job.video_error}`:'Este item não possui vídeo.';$('videoUnavailable').classList.remove('hidden')}
  setResultTab(textReady?'sync':(job.video_ready?'video':'audio'));loadHistory();loadProjects();syncLibraryPane();
  if(pendingSeek!=null){const sec=pendingSeek;pendingSeek=null;setTimeout(()=>seekMedia(sec,false),450)}
  if(wasProcessing)notifyFinished(job);
  return true;
}
async function pollJobTick(id,token){
  if(token!==jobPollToken||processingJobId!==id)return;
  try{
    const state=await fetchJSON(`/api/jobs/${id}/progress?_=${Date.now()}`,{cache:'no-store',headers:{'Cache-Control':'no-cache'}});
    if(token!==jobPollToken||processingJobId!==id)return;
    renderProgressState(state);
    if(state.status==='error'){showError(state.error||'Falha ao processar.');return}
    if(state.status==='done'){
      const job=await fetchJSON(`/api/jobs/${id}?_=${Date.now()}`,{cache:'no-store',headers:{'Cache-Control':'no-cache'}});
      if(token!==jobPollToken||processingJobId!==id)return;
      stopJobPolling();renderProgressState({...job,progress:100});showLibraryJob(job,{fromCompletion:true});return;
    }
    pollTimer=setTimeout(()=>pollJobTick(id,token),850);
  }catch(err){if(token===jobPollToken)showError(err.message)}
}
function pollJob(id){
  if(!id)return;stopJobPolling();processingJobId=id;const token=jobPollToken;pollJobTick(id,token);
}
async function openJob(id){
  $('errorCard').classList.add('hidden');
  try{
    const job=await fetchJSON(`/api/jobs/${id}?_=${Date.now()}`,{cache:'no-store'});
    if(job.status==='done'){showLibraryJob(job);return}
    switchView('new');
    if(job.status==='error'){showError(job.error||'Falha ao processar.');return}
    $('progressCard').classList.remove('hidden');setBusy(true);renderProgressState(job);pollJob(id);
  }catch(err){switchView('new');showError(err.message)}
}

function beginProgress(){stopJobPolling();$('errorCard').classList.add('hidden');$('progressCard').classList.remove('hidden');$('stage').textContent='Iniciando...';$('percentage').textContent='0%';$('progressBar').style.width='0%';$('statusDetail').textContent='Criando a tarefa e preparando o processamento...';setBusy(true)}
let youtubeSearchQuery='';
let youtubeSearchOffset=0;
let youtubeSearchBusy=false;
let youtubeSearchController=null;
let youtubeSearchSeq=0;
const youtubeQueuedUrls=new Set();

function formatViews(value){const n=Number(value);if(!Number.isFinite(n)||n<=0)return '';return `${new Intl.NumberFormat('pt-BR',{notation:'compact',maximumFractionDigits:1}).format(n)} visualizações`}
function bindYoutubeSearchActions(list){
  list.querySelectorAll('.youtube-search-thumb img').forEach(img=>{if(img.dataset.bound)return;img.dataset.bound='1';img.addEventListener('error',()=>{const box=img.closest('.youtube-search-thumb');if(box)box.classList.add('failed');img.remove()})});
  list.querySelectorAll('[data-search-transcribe]').forEach(btn=>{if(btn.dataset.bound)return;btn.dataset.bound='1';btn.addEventListener('click',()=>startSearchVideo(btn.dataset.searchTranscribe,false,btn))});
  list.querySelectorAll('[data-search-queue]').forEach(btn=>{if(btn.dataset.bound)return;btn.dataset.bound='1';btn.addEventListener('click',()=>startSearchVideo(btn.dataset.searchQueue,true,btn))});
}
function renderYoutubeSearchResults(items,append=false){
  const list=$('youtubeSearchResults');
  if(!append)list.innerHTML='';
  if(!items.length&&!append){list.innerHTML='<div class="empty-state">Nenhum vídeo encontrado para essa pesquisa.</div>';return}
  const html=items.map(item=>{const queued=youtubeQueuedUrls.has(item.url);return `<article class="youtube-search-card" data-youtube-url="${escapeHtml(item.url)}"><div class="youtube-search-thumb"><img src="${escapeHtml(item.thumbnail_url||'')}" alt="Miniatura de ${escapeHtml(item.title||'vídeo')}" loading="lazy" referrerpolicy="no-referrer"><span>${escapeHtml(item.duration_label||'')}</span></div><div class="youtube-search-copy"><strong>${escapeHtml(item.title||'Vídeo do YouTube')}</strong><small>${escapeHtml(item.channel||'YouTube')}</small><em>${escapeHtml(formatViews(item.view_count))}</em></div><div class="youtube-search-actions"><button class="btn btn-primary btn-small" data-search-transcribe="${escapeHtml(item.url)}" type="button">Transcrever</button><button class="btn btn-secondary btn-small ${queued?'is-added':''}" data-search-queue="${escapeHtml(item.url)}" type="button" ${queued?'disabled':''}>${queued?'✓ Na fila':'＋ Fila'}</button></div></article>`}).join('');
  list.insertAdjacentHTML('beforeend',html);bindYoutubeSearchActions(list);
}
function clearYoutubeSearch(clearInput=true){
  clearTimeout(youtubeLiveTimer);
  if(youtubeSearchController){youtubeSearchController.abort();youtubeSearchController=null}
  youtubeSearchSeq++;
  youtubeSearchBusy=false;youtubeSearchQuery='';youtubeSearchOffset=0;
  if(clearInput)$('youtubeSearchInput').value='';
  $('youtubeSearchResults').innerHTML='';
  $('youtubeSearchState').textContent='';$('youtubeSearchState').classList.add('hidden');
  $('youtubeSearchMoreBtn').classList.add('hidden');
  $('youtubeSearchBtn').disabled=false;$('youtubeSearchBtn').textContent='Pesquisar';
  if(clearInput)$('youtubeSearchInput').focus();
}
async function searchYoutube(loadMore=false,silent=false){
  const query=loadMore?youtubeSearchQuery:$('youtubeSearchInput').value.trim();
  if(query.length<2){
    if(!silent&&query)toast('Digite pelo menos 2 caracteres para pesquisar.');
    if(!loadMore){$('youtubeSearchResults').innerHTML='';$('youtubeSearchMoreBtn').classList.add('hidden');}
    return;
  }
  if(loadMore&&youtubeSearchBusy)return;
  if(!loadMore&&youtubeSearchController)youtubeSearchController.abort();
  const controller=new AbortController();youtubeSearchController=controller;
  const seq=++youtubeSearchSeq;youtubeSearchBusy=true;
  const state=$('youtubeSearchState'),more=$('youtubeSearchMoreBtn'),button=$('youtubeSearchBtn');
  if(!loadMore){youtubeSearchQuery=query;youtubeSearchOffset=0;$('youtubeSearchResults').innerHTML='';}
  state.textContent=loadMore?'Buscando mais vídeos...':'Pesquisando no YouTube...';state.classList.remove('hidden');more.classList.add('hidden');button.disabled=true;button.textContent='Buscando...';
  try{
    const data=await fetchJSON(`/api/youtube/search?q=${encodeURIComponent(query)}&offset=${youtubeSearchOffset}&limit=10`,{signal:controller.signal});
    if(seq!==youtubeSearchSeq||(!loadMore&&$('youtubeSearchInput').value.trim()!==query))return;
    const items=data.items||[];renderYoutubeSearchResults(items,loadMore);youtubeSearchOffset=Number(data.next_offset||youtubeSearchOffset+items.length);more.classList.toggle('hidden',!data.has_more||!items.length);state.classList.add('hidden');
  }catch(err){
    if(err?.name==='AbortError')return;
    if(seq===youtubeSearchSeq){state.textContent=err.message;state.classList.remove('hidden')}
  }finally{
    if(seq===youtubeSearchSeq){youtubeSearchBusy=false;button.disabled=false;button.textContent='Pesquisar'}
  }
}
async function startSearchVideo(url,queueOnly,button){
  const old=button.textContent;button.disabled=true;button.textContent=queueOnly?'Adicionando...':'Iniciando...';let keepState=false;
  const common={language:$('language').value,timestamps:$('timestamps').checked,allow_whisper:$('whisper').checked,confirmed_rights:$('rights').checked,quality:$('quality').value,project_id:$('projectSelect').value||null};
  if(!common.confirmed_rights){button.disabled=false;button.textContent=old;toast('Confirme que você tem permissão para processar o conteúdo.');return}
  try{
    if(queueOnly){
      const data=await fetchJSON('/api/transcribe/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,urls:[url]})});
      youtubeQueuedUrls.add(url);bumpQueueIndicators((data.job_ids||[]).length||1);button.textContent='✓ Na fila';button.classList.add('is-added');button.disabled=true;keepState=true;toast('Vídeo adicionado à fila');loadHistory();
    }else{
      beginProgress();const data=await fetchJSON('/api/transcribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,url})});processingJobId=data.job_id;bumpQueueIndicators(1);loadHistory();pollJob(processingJobId);
    }
  }catch(err){showError(err.message)}finally{if(!keepState){button.disabled=false;button.textContent=old}}
}
$('youtubeSearchBtn').addEventListener('click',()=>searchYoutube(false,false));
$('youtubeSearchMoreBtn').addEventListener('click',()=>searchYoutube(true,false));
$('youtubeSearchClearBtn').addEventListener('click',()=>clearYoutubeSearch(true));
$('youtubeSearchInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(youtubeLiveTimer);searchYoutube(false,false)}if(e.key==='Escape')clearYoutubeSearch(true)});
$('youtubeSearchInput').addEventListener('input',()=>{
  clearTimeout(youtubeLiveTimer);
  const q=$('youtubeSearchInput').value.trim();
  if(youtubeSearchController){youtubeSearchController.abort();youtubeSearchController=null}
  youtubeSearchSeq++;youtubeSearchBusy=false;youtubeSearchOffset=0;youtubeSearchQuery='';
  $('youtubeSearchMoreBtn').classList.add('hidden');$('youtubeSearchResults').innerHTML='';
  if(!q){$('youtubeSearchState').classList.add('hidden');$('youtubeSearchState').textContent='';return}
  if(q.length<2){$('youtubeSearchState').textContent='Digite mais um caractere para pesquisar.';$('youtubeSearchState').classList.remove('hidden');return}
  $('youtubeSearchState').textContent='Aguardando para pesquisar...';$('youtubeSearchState').classList.remove('hidden');
  youtubeLiveTimer=setTimeout(()=>searchYoutube(false,true),380);
});

$('transcribeBtn').addEventListener('click',async()=>{
  if(!$('rights').checked)return showError('Confirme que você tem permissão para processar este conteúdo.');beginProgress();
  const common={language:$('language').value,timestamps:$('timestamps').checked,allow_whisper:$('whisper').checked,confirmed_rights:true,quality:$('quality').value,project_id:$('projectSelect').value||null};
  try{
    if(currentSource==='link'){
      const url=$('url').value.trim();if(!url)throw new Error('Cole o link de um vídeo do YouTube.');const data=await fetchJSON('/api/transcribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,url})});processingJobId=data.job_id;bumpQueueIndicators(1);loadHistory();pollJob(processingJobId);
    }else if(currentSource==='file'){
      const file=$('mediaFile').files[0];if(!file)throw new Error('Escolha um arquivo de áudio ou vídeo.');const fd=new FormData();fd.append('media',file);fd.append('language',common.language);fd.append('timestamps',String(common.timestamps));fd.append('project_id',common.project_id||'');const data=await fetchJSON('/api/upload',{method:'POST',body:fd});processingJobId=data.job_id;bumpQueueIndicators(1);loadHistory();pollJob(processingJobId);
    }else{
      const urls=$('batchUrls').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(!urls.length)throw new Error('Adicione pelo menos um link à fila.');const data=await fetchJSON('/api/transcribe/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,urls})});bumpQueueIndicators(data.job_ids.length);setBusy(false);$('progressCard').classList.add('hidden');toast(`${data.job_ids.length} item(ns) adicionados à fila`);switchView('queue');loadQueue();
    }
  }catch(err){showError(err.message)}
});

$('saveBtn').addEventListener('click',async()=>{if(!activeJob||!currentJob?.transcript_available)return;const btn=$('saveBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Salvando...';try{await fetchJSON(`/api/jobs/${activeJob}/transcript`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({transcript:getEditorText()})});currentJob.transcript=getEditorText();btn.textContent='Salvo';toast('Transcrição salva');setTimeout(()=>btn.textContent=old,1100)}catch(err){toast(err.message);btn.textContent=old}finally{btn.disabled=false}});
$('copyBtn').addEventListener('click',async()=>{if(!currentJob?.transcript_available)return;try{await navigator.clipboard.writeText(getEditorText());toast('Texto copiado')}catch{const range=document.createRange();range.selectNodeContents($('transcriptEditor'));const sel=window.getSelection();sel.removeAllRanges();sel.addRange(range);document.execCommand('copy');sel.removeAllRanges();toast('Texto copiado')}});
$('replaceOneBtn').addEventListener('click',()=>{const find=$('findText').value;if(!find)return;const value=getEditorText();const i=value.toLowerCase().indexOf(find.toLowerCase());if(i<0)return toast('Texto não encontrado');setEditorText(value.slice(0,i)+$('replaceText').value+value.slice(i+find.length));toast('Uma ocorrência substituída')});
$('replaceAllBtn').addEventListener('click',()=>{const find=$('findText').value;if(!find)return;const esc=find.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const re=new RegExp(esc,'gi');const before=getEditorText();const after=before.replace(re,$('replaceText').value);setEditorText(after);toast(before===after?'Texto não encontrado':'Ocorrências substituídas')});

function fmtTime(sec){if(!Number.isFinite(sec)||sec<0)return'00:00';const t=Math.floor(sec),h=Math.floor(t/3600),m=Math.floor((t%3600)/60),s=t%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function updateAudioClock(){$('audioTime').textContent=`${fmtTime(audioPlayer.currentTime)} / ${fmtTime(audioPlayer.duration)}`;syncActiveLine(audioPlayer.currentTime)}
function updateVideoClock(){$('videoTime').textContent=`${fmtTime(videoPlayer.currentTime)} / ${fmtTime(videoPlayer.duration)}`;syncActiveLine(videoPlayer.currentTime)}
audioPlayer.addEventListener('loadedmetadata',updateAudioClock);audioPlayer.addEventListener('timeupdate',updateAudioClock);audioPlayer.addEventListener('play',()=>$('audioBadge').textContent='Reproduzindo');audioPlayer.addEventListener('pause',()=>$('audioBadge').textContent=audioPlayer.ended?'Finalizado':'Pausado');videoPlayer.addEventListener('loadedmetadata',updateVideoClock);videoPlayer.addEventListener('timeupdate',updateVideoClock);videoPlayer.addEventListener('play',()=>$('videoBadge').textContent='Reproduzindo');videoPlayer.addEventListener('pause',()=>$('videoBadge').textContent=videoPlayer.ended?'Finalizado':'Pausado');
$('back10Btn').addEventListener('click',()=>audioPlayer.currentTime=Math.max(0,audioPlayer.currentTime-10));$('forward10Btn').addEventListener('click',()=>{if(Number.isFinite(audioPlayer.duration))audioPlayer.currentTime=Math.min(audioPlayer.duration,audioPlayer.currentTime+10)});$('videoBack10Btn').addEventListener('click',()=>videoPlayer.currentTime=Math.max(0,videoPlayer.currentTime-10));$('videoForward10Btn').addEventListener('click',()=>{if(Number.isFinite(videoPlayer.duration))videoPlayer.currentTime=Math.min(videoPlayer.duration,videoPlayer.currentTime+10)});playbackSpeed.addEventListener('change',()=>{const r=Number(playbackSpeed.value);audioPlayer.playbackRate=r;$('speedBadge').textContent=`${String(r).replace('.',',')}x`});videoPlaybackSpeed.addEventListener('change',()=>{const r=Number(videoPlaybackSpeed.value);videoPlayer.playbackRate=r;$('videoSpeedBadge').textContent=`${String(r).replace('.',',')}x`});

async function saveAsset(jobId,kind,button){if(!jobId||!kind)return;if(button&&button.classList.contains('disabled-download'))return;const old=button?button.textContent:'';if(button){button.disabled=true;button.textContent='Salvando...'}try{const data=await fetchJSON(`/api/save/${jobId}/${kind}`,{method:'POST'});toast(`${data.filename} salvo`);loadHistory();if(document.querySelector('[data-view-panel="downloads"]').classList.contains('active'))loadDownloads();loadStorageStats()}catch(err){toast(err.message)}finally{if(button){button.disabled=false;button.textContent=old}}}
['txtBtn','pdfBtn','docxBtn','srtBtn','vttBtn','audioDownloadBtn','videoDownloadBtn'].forEach(id=>$(id).addEventListener('click',()=>{const btn=$(id);if(btn.classList.contains('disabled-download'))return;saveAsset(activeJob,btn.dataset.saveKind,btn)}));

// Player persistente de áudio por projeto
const projectMusicAudio=$('projectMusicAudio');
let projectMusicPlaylist=[];
let projectMusicIndex=-1;
let projectMusicProject=null;
let projectMusicShuffle=false;
let projectMusicRepeat='off';

function musicTrack(){return projectMusicPlaylist[projectMusicIndex]||null}
function musicTime(sec){return fmtTime(Number(sec)||0)}
function updateMusicPlayingState(){const playing=!!projectMusicAudio.src&&!projectMusicAudio.paused&&!projectMusicAudio.ended;$('musicPlayBtn').textContent=playing?'Ⅱ':'▶';$('homeNowPlayingToggle').textContent=playing?'Ⅱ':'▶';$('projectMusicPlayer').classList.toggle('is-playing',playing);$('musicCollapsedButton').classList.toggle('is-playing',playing);$('homeNowPlaying').classList.toggle('is-playing',playing)}
function updateMusicMetadata(){const track=musicTrack();if(!track)return;const pname=projectMusicProject?.name||projectName(track.project_id)||'Projeto';$('musicPlayerTitle').textContent=track.title||'Áudio';$('musicPlayerProject').textContent=pname;$('musicCollapsedTitle').textContent=track.title||'Áudio';$('homeNowPlayingTitle').textContent=track.title||'Áudio';$('homeNowPlayingProject').textContent=pname;$('homeNowPlaying').classList.remove('hidden');const thumb=$('musicPlayerThumb');if(track.thumbnail_url){thumb.innerHTML=`<img src="${escapeHtml(track.thumbnail_url)}" alt="Miniatura" referrerpolicy="no-referrer">`;const img=thumb.querySelector('img');img.addEventListener('error',()=>{thumb.innerHTML='<span>♪</span>'})}else thumb.innerHTML='<span>♪</span>';renderMusicQueue();updateMusicPlayingState()}
function updateMusicProgress(){const d=Number(projectMusicAudio.duration)||0,c=Number(projectMusicAudio.currentTime)||0;$('musicCurrentTime').textContent=musicTime(c);$('musicDuration').textContent=musicTime(d);$('musicProgress').value=d?Math.round((c/d)*1000):0}
function renderMusicQueue(){const list=$('musicQueueList');$('musicQueueTitle').textContent=projectMusicProject?.name||'Músicas';list.innerHTML=projectMusicPlaylist.length?projectMusicPlaylist.map((track,i)=>`<button class="music-queue-track ${i===projectMusicIndex?'active':''}" data-music-index="${i}" type="button"><span class="music-queue-thumb">${track.thumbnail_url?`<img src="${escapeHtml(track.thumbnail_url)}" alt="" referrerpolicy="no-referrer">`:'♪'}</span><span><strong>${escapeHtml(track.title||'Áudio')}</strong><small>${escapeHtml(track.duration_label||'Duração indisponível')}</small></span><em>${i===projectMusicIndex&&!projectMusicAudio.paused?'Tocando':'▶'}</em></button>`).join(''):'<div class="empty-state">Nenhum áudio neste projeto.</div>';list.querySelectorAll('[data-music-index]').forEach(btn=>btn.addEventListener('click',()=>playProjectTrack(Number(btn.dataset.musicIndex),true)));list.querySelectorAll('.music-queue-thumb img').forEach(img=>img.addEventListener('error',()=>img.remove()))}
async function startProjectPlaylist(projectId,startJobId=null){try{const p=projects.find(x=>x.id===projectId)||{id:projectId,name:'Projeto'};const data=await fetchJSON(`/api/history?kind=audio&project_id=${encodeURIComponent(projectId)}`);const items=(data.items||[]).filter(x=>x.audio_ready&&x.status==='done').sort((a,b)=>Number(a.created_at||0)-Number(b.created_at||0));if(!items.length){toast('Este projeto ainda não possui áudios prontos.',3600);return}projectMusicProject=p;projectMusicPlaylist=items;let idx=startJobId?items.findIndex(x=>x.id===startJobId):0;if(idx<0)idx=0;switchView('home');setMusicCollapsed(false);await playProjectTrack(idx,true);renderMusicQueue()}catch(err){toast(err.message,5000)}}
async function playProjectTrack(index,autoplay=true){if(!projectMusicPlaylist.length)return;index=(index+projectMusicPlaylist.length)%projectMusicPlaylist.length;projectMusicIndex=index;const track=musicTrack();projectMusicAudio.src=`/audio/${track.id}?v=${encodeURIComponent(track.updated_at||Date.now())}`;projectMusicAudio.load();updateMusicMetadata();if(autoplay){try{await projectMusicAudio.play()}catch{toast('Clique em Play para iniciar o áudio.',3000)}}updateMusicPlayingState()}
function nextProjectTrack(manual=false){if(!projectMusicPlaylist.length)return;if(projectMusicRepeat==='one'&&!manual){projectMusicAudio.currentTime=0;projectMusicAudio.play().catch(()=>{});return}let next;if(projectMusicShuffle&&projectMusicPlaylist.length>1){do{next=Math.floor(Math.random()*projectMusicPlaylist.length)}while(next===projectMusicIndex)}else next=projectMusicIndex+1;if(next>=projectMusicPlaylist.length){if(projectMusicRepeat==='all')next=0;else{projectMusicAudio.pause();projectMusicAudio.currentTime=0;updateMusicPlayingState();return}}playProjectTrack(next,true)}
function prevProjectTrack(){if(projectMusicAudio.currentTime>4){projectMusicAudio.currentTime=0;return}if(!projectMusicPlaylist.length)return;let prev=projectMusicIndex-1;if(prev<0)prev=projectMusicRepeat==='all'?projectMusicPlaylist.length-1:0;playProjectTrack(prev,true)}
function setMusicCollapsed(value){$('projectMusicPlayer').classList.toggle('hidden',!!value);$('musicCollapsedButton').classList.toggle('hidden',!value||!musicTrack())}
function closeProjectMusic(){projectMusicAudio.pause();projectMusicAudio.removeAttribute('src');projectMusicAudio.load();projectMusicPlaylist=[];projectMusicIndex=-1;projectMusicProject=null;$('projectMusicPlayer').classList.add('hidden');$('musicCollapsedButton').classList.add('hidden');$('musicQueueDrawer').classList.add('hidden');$('homeNowPlaying').classList.add('hidden')}
projectMusicAudio.volume=.85;projectMusicAudio.addEventListener('play',()=>{updateMusicPlayingState();renderMusicQueue()});projectMusicAudio.addEventListener('pause',()=>{updateMusicPlayingState();renderMusicQueue()});projectMusicAudio.addEventListener('ended',()=>nextProjectTrack(false));projectMusicAudio.addEventListener('loadedmetadata',updateMusicProgress);projectMusicAudio.addEventListener('timeupdate',updateMusicProgress);projectMusicAudio.addEventListener('error',()=>toast('Não foi possível reproduzir este áudio.',3600));
$('musicPlayBtn').addEventListener('click',()=>{if(!musicTrack())return;if(projectMusicAudio.paused)projectMusicAudio.play().catch(()=>{});else projectMusicAudio.pause()});$('homeNowPlayingToggle').addEventListener('click',()=>$('musicPlayBtn').click());$('homeNowPlayingOpen').addEventListener('click',()=>setMusicCollapsed(false));$('musicCollapsedButton').addEventListener('click',()=>setMusicCollapsed(false));$('musicPrevBtn').addEventListener('click',prevProjectTrack);$('musicNextBtn').addEventListener('click',()=>nextProjectTrack(true));$('musicProgress').addEventListener('input',()=>{const d=Number(projectMusicAudio.duration)||0;if(d)projectMusicAudio.currentTime=(Number($('musicProgress').value)/1000)*d});$('musicVolume').addEventListener('input',()=>projectMusicAudio.volume=Math.max(0,Math.min(1,Number($('musicVolume').value)||0)));$('musicShuffleBtn').addEventListener('click',()=>{projectMusicShuffle=!projectMusicShuffle;$('musicShuffleBtn').classList.toggle('active',projectMusicShuffle);toast(projectMusicShuffle?'Embaralhar ativado':'Embaralhar desativado')});$('musicRepeatBtn').addEventListener('click',()=>{projectMusicRepeat=projectMusicRepeat==='off'?'all':projectMusicRepeat==='all'?'one':'off';$('musicRepeatBtn').classList.toggle('active',projectMusicRepeat!=='off');$('musicRepeatBtn').textContent=projectMusicRepeat==='one'?'↻¹':'↻';toast(projectMusicRepeat==='off'?'Repetição desativada':projectMusicRepeat==='all'?'Repetir playlist':'Repetir música')});$('musicQueueBtn').addEventListener('click',()=>{$('musicQueueDrawer').classList.toggle('hidden');renderMusicQueue()});$('musicQueueClose').addEventListener('click',()=>$('musicQueueDrawer').classList.add('hidden'));$('musicMinimizeBtn').addEventListener('click',()=>setMusicCollapsed(true));$('musicCloseBtn').addEventListener('click',closeProjectMusic);

let aiStatusPollTimer = null;
let activeAIController=null;
let activePageAIController=null;

function renderAIStatus(data){
  const box=$('aiStatusBox'), title=$('aiStatusTitle'), detail=$('aiStatusDetail');
  const page=$('aiPageStatus');
  const status=data?.status||'runtime_missing';
  const ready=status==='ready';
  const installing=status==='installing';
  let titleText='IA integrada pronta';
  if(ready)titleText='IA pronta';
  else if(installing)titleText='Preparando IA integrada...';
  else if(status==='error')titleText='Falha temporária na IA';
  const detailText=data?.message||'Não foi possível verificar a IA.';
  if(box&&title&&detail){
    title.textContent=titleText;detail.textContent=detailText;
    box.classList.toggle('neutral',!ready);box.classList.toggle('success',ready);
  }
  if(page){page.classList.toggle('neutral',!ready);page.classList.toggle('success',ready);page.innerHTML=`<strong>${escapeHtml(titleText)}</strong><span>${escapeHtml(detailText)}</span>`}
  const test=$('testAiBtn');if(test)test.disabled=!ready;
  clearTimeout(aiStatusPollTimer);
  if(installing)aiStatusPollTimer=setTimeout(loadAIStatus,2200);
}

async function loadAIStatus(){
  try{const data=await fetchJSON('/api/ai/status');renderAIStatus(data);return data}catch(err){renderAIStatus({status:'error',message:err.message});return null}
}

if($('testAiBtn'))$('testAiBtn').addEventListener('click',async()=>{const b=$('testAiBtn'),old=b.textContent;b.disabled=true;b.textContent='Testando...';try{const d=await fetchJSON('/api/ai/test',{method:'POST'});toast(d.result||'IA pronta',4200);renderAIStatus(d.status)}catch(err){toast(err.message,5200);loadAIStatus()}finally{b.disabled=false;b.textContent=old}});


const aiPendingAttachments=[];
let aiVoiceRecorder=null;
let aiVoiceStream=null;
let aiVoiceChunks=[];
let aiVoiceBusy=false;

function inlineMarkdown(text){
  let x=escapeHtml(text||'');
  x=x.replace(/`([^`\n]+)`/g,'<code>$1</code>');
  x=x.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
  x=x.replace(/__([^_]+)__/g,'<strong>$1</strong>');
  x=x.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g,'$1<em>$2</em>');
  return x;
}
function renderMarkdown(markdown){
  const source=String(markdown||'').replace(/\r\n?/g,'\n'),lines=source.split('\n'),out=[];let i=0;
  while(i<lines.length){
    const trim=lines[i].trim();if(!trim){i++;continue}
    if(trim.startsWith('```')){const lang=trim.slice(3).trim(),body=[];i++;while(i<lines.length&&!lines[i].trim().startsWith('```')){body.push(lines[i]);i++}if(i<lines.length)i++;out.push(`<pre><code${lang?` data-language="${escapeHtml(lang)}"`:''}>${escapeHtml(body.join('\n'))}</code></pre>`);continue}
    const h=trim.match(/^(#{1,4})\s+(.+)$/);if(h){const level=Math.min(4,h[1].length+1);out.push(`<h${level}>${inlineMarkdown(h[2])}</h${level}>`);i++;continue}
    if(/^[-*]\s+/.test(trim)){const items=[];while(i<lines.length&&/^\s*[-*]\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*[-*]\s+/,''));i++}out.push('<ul>'+items.map(v=>`<li>${inlineMarkdown(v)}</li>`).join('')+'</ul>');continue}
    if(/^\d+[.)]\s+/.test(trim)){const items=[];while(i<lines.length&&/^\s*\d+[.)]\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*\d+[.)]\s+/,''));i++}out.push('<ol>'+items.map(v=>`<li>${inlineMarkdown(v)}</li>`).join('')+'</ol>');continue}
    if(trim.startsWith('> ')){const items=[];while(i<lines.length&&lines[i].trim().startsWith('> ')){items.push(lines[i].trim().slice(2));i++}out.push(`<blockquote>${items.map(inlineMarkdown).join('<br>')}</blockquote>`);continue}
    const para=[trim];i++;while(i<lines.length&&lines[i].trim()&&!/^(#{1,4})\s+/.test(lines[i].trim())&&!/^\s*[-*]\s+/.test(lines[i])&&!/^\s*\d+[.)]\s+/.test(lines[i])&&!lines[i].trim().startsWith('```')&&!lines[i].trim().startsWith('> ')){para.push(lines[i].trim());i++}out.push(`<p>${inlineMarkdown(para.join(' '))}</p>`)
  }
  return out.join('')||'<p></p>';
}
function formatFileSize(bytes){const n=Number(bytes||0);if(n<1024)return `${n} B`;if(n<1048576)return `${(n/1024).toFixed(1)} KB`;return `${(n/1048576).toFixed(1)} MB`}
function attachmentChipHtml(item,removable=false){return `<span class="ai-attachment-chip" data-attachment-id="${escapeHtml(item.id||'')}"><span class="ai-file-icon">${escapeHtml(String(item.ext||'DOC').replace('.','').toUpperCase().slice(0,5))}</span><span><strong>${escapeHtml(item.name||'Arquivo')}</strong><small>${formatFileSize(item.size)}</small></span>${removable?'<button type="button" class="ai-attachment-remove" aria-label="Remover anexo">×</button>':''}</span>`}
function renderPendingAttachments(){const box=$('aiAttachmentList');if(!box)return;box.classList.toggle('hidden',!aiPendingAttachments.length);box.innerHTML=aiPendingAttachments.map(x=>attachmentChipHtml(x,true)).join('');box.querySelectorAll('.ai-attachment-remove').forEach(btn=>btn.addEventListener('click',async()=>{const id=btn.closest('[data-attachment-id]')?.dataset.attachmentId,idx=aiPendingAttachments.findIndex(x=>x.id===id);if(idx>=0)aiPendingAttachments.splice(idx,1);renderPendingAttachments();if(id){try{await fetch(`/api/ai/attachments/${encodeURIComponent(id)}`,{method:'DELETE'})}catch{}}}))}
function clearPendingAttachments(){aiPendingAttachments.splice(0);renderPendingAttachments()}
async function uploadAIAttachments(files){const list=[...files].slice(0,8);if(!list.length)return;const form=new FormData();list.forEach(f=>form.append('files',f));const btn=$('aiAttachBtn');btn.disabled=true;btn.classList.add('busy');try{const r=await fetch('/api/ai/attachments',{method:'POST',body:form});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Não foi possível anexar o arquivo.');for(const item of d.items||[])if(!aiPendingAttachments.some(x=>x.id===item.id))aiPendingAttachments.push(item);renderPendingAttachments();toast(`${(d.items||[]).length} arquivo(s) anexado(s)`)}catch(err){toast(err.message,5200)}finally{btn.disabled=false;btn.classList.remove('busy');$('aiFileInput').value=''}}
async function startOrStopAIVoice(){const btn=$('aiVoiceBtn'),status=$('aiVoiceStatus');if(aiVoiceBusy)return;if(aiVoiceRecorder&&aiVoiceRecorder.state==='recording'){aiVoiceRecorder.stop();return}if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined'){toast('O microfone não está disponível neste ambiente.',4200);return}try{aiVoiceStream=await navigator.mediaDevices.getUserMedia({audio:true});aiVoiceChunks=[];const preferred=['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'];let mime='';for(const m of preferred){if(MediaRecorder.isTypeSupported(m)){mime=m;break}}aiVoiceRecorder=new MediaRecorder(aiVoiceStream,mime?{mimeType:mime}:undefined);aiVoiceRecorder.addEventListener('dataavailable',e=>{if(e.data?.size)aiVoiceChunks.push(e.data)});aiVoiceRecorder.addEventListener('stop',async()=>{aiVoiceStream?.getTracks().forEach(t=>t.stop());aiVoiceStream=null;btn.classList.remove('recording');status.textContent='Transcrevendo...';aiVoiceBusy=true;try{const blob=new Blob(aiVoiceChunks,{type:aiVoiceRecorder.mimeType||'audio/webm'}),form=new FormData();form.append('audio',blob,'ditado.webm');form.append('language','pt');const r=await fetch('/api/ai/dictate',{method:'POST',body:form});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Não foi possível transcrever o ditado.');const input=$('aiChatInput');input.value=(input.value.trim()?input.value.trim()+' ':'')+(d.text||'');input.focus();status.textContent='Ditado pronto'}catch(err){status.textContent='';toast(err.message,5200)}finally{aiVoiceBusy=false;setTimeout(()=>{if(!aiVoiceBusy)status.textContent=''},1800)}});aiVoiceRecorder.start(250);btn.classList.add('recording');status.textContent='Ouvindo... clique para parar'}catch(err){aiVoiceStream?.getTracks().forEach(t=>t.stop());aiVoiceStream=null;btn.classList.remove('recording');status.textContent='';toast(`Não foi possível acessar o microfone: ${err.message}`,5200)}}

// IA dentro de uma transcrição
async function runAI(action,question=''){
  if(!currentJob?.transcript_available)return;const result=$('aiResult');if(activeAIController)activeAIController.abort();const controller=new AbortController();activeAIController=controller;result.innerHTML='<span class="ai-loading">Iniciando RedScribe IA...</span>';let accumulated='';
  try{const response=await fetch(`/api/jobs/${currentJob.id}/ai/stream`,{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({action,question})});if(response.status===401){location.href='/login';throw new Error('Sessão expirada.')}if(!response.ok){let data={};try{data=await response.json()}catch{}throw new Error(data.error||'Não foi possível iniciar a IA.')}if(!response.body)throw new Error('Streaming da IA não está disponível neste sistema.');const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()||'';for(const line of lines){if(!line.trim())continue;let event;try{event=JSON.parse(line)}catch{continue}if(event.type==='status'&&!accumulated)result.innerHTML=`<span class="ai-loading">${escapeHtml(event.message||'RedScribe IA está analisando...')}</span>`;if(event.type==='token'){accumulated+=event.text||'';result.innerHTML=renderMarkdown(accumulated)}if(event.type==='error')throw new Error(event.error||'Erro na IA.')}}if(!accumulated.trim())throw new Error('A IA terminou sem retornar resposta. Use Configurações > IA > Testar IA integrada.');result.innerHTML=renderMarkdown(accumulated)}catch(err){if(err.name==='AbortError')return;result.innerHTML=`<span class="ai-error">${escapeHtml(err.message)}</span>`}finally{if(activeAIController===controller)activeAIController=null}
}
$$('[data-ai-action]').forEach(b=>b.addEventListener('click',()=>runAI(b.dataset.aiAction)));$('askVideoBtn').addEventListener('click',()=>{const q=$('aiQuestion').value.trim();if(q)runAI('ask',q)});$('aiQuestion').addEventListener('keydown',e=>{if(e.key==='Enter')$('askVideoBtn').click()});

function aiMessageHtml(item){const isUser=item.role==='user',who=isUser?'Você':'RedScribe IA',attachments=Array.isArray(item.attachments)?item.attachments:[],attachmentHtml=attachments.length?`<div class="ai-message-attachments">${attachments.map(x=>attachmentChipHtml(x,false)).join('')}</div>`:'',content=isUser?`<p>${escapeHtml(item.text||'').replace(/\n/g,'<br>')}</p>`:renderMarkdown(item.text||''),avatar=isUser?escapeHtml(initials(userName)):'✦';return `<article class="ai-chat-message ${isUser?'user':'assistant'}"><div class="ai-message-avatar" aria-hidden="true">${avatar}</div><div class="ai-message-stack"><span class="ai-message-name">${who}</span><div class="ai-message-content">${content}${attachmentHtml}</div></div></article>`}
async function loadAIHistory(){try{const d=await fetchJSON('/api/ai/history');const list=$('aiChatMessages'),items=d.items||[];list.innerHTML=items.length?items.map(aiMessageHtml).join(''):'<div class="ai-chat-empty"><span class="ai-orb">✦</span><strong>Como posso ajudar?</strong><p>Faça uma pergunta, dite por voz, anexe documentos ou selecione uma transcrição.</p></div>';list.scrollTop=list.scrollHeight}catch(err){$('aiChatMessages').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}}
async function loadAIContextOptions(){try{const d=await fetchJSON('/api/history');const items=(d.items||[]).filter(x=>x.transcript_available).slice(0,60),el=$('aiContextJob'),current=el.value;el.innerHTML='<option value="">Sem transcrição selecionada</option>'+items.map(x=>`<option value="${x.id}">${escapeHtml(x.title||'Transcrição')}</option>`).join('');if([...el.options].some(o=>o.value===current))el.value=current}catch{}}
async function sendAIChat(){const input=$('aiChatInput'),message=input.value.trim();if(!message&&!aiPendingAttachments.length)return;if(activePageAIController)activePageAIController.abort();const controller=new AbortController();activePageAIController=controller,list=$('aiChatMessages');if(list.querySelector('.ai-chat-empty'))list.innerHTML='';const outgoingAttachments=aiPendingAttachments.map(x=>({...x})),visibleMessage=message||'Analise os arquivos anexados.';list.insertAdjacentHTML('beforeend',aiMessageHtml({role:'user',text:visibleMessage,attachments:outgoingAttachments}));const holder=document.createElement('article');holder.className='ai-chat-message assistant';holder.innerHTML='<div class="ai-message-avatar" aria-hidden="true">✦</div><div class="ai-message-stack"><span class="ai-message-name">RedScribe IA</span><div class="ai-message-content ai-loading">Analisando...</div></div>';list.appendChild(holder);list.scrollTop=list.scrollHeight;input.value='';clearPendingAttachments();let accumulated='';const sendBtn=$('aiChatSend');sendBtn.disabled=true;sendBtn.classList.add('sending');sendBtn.setAttribute('aria-busy','true');try{const response=await fetch('/api/ai/chat/stream',{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({message,job_id:$('aiContextJob').value||null,attachment_ids:outgoingAttachments.map(x=>x.id)})});if(!response.ok){let d={};try{d=await response.json()}catch{}throw new Error(d.error||'Não foi possível iniciar a IA.')}if(!response.body)throw new Error('Streaming indisponível.');const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()||'';for(const line of lines){if(!line.trim())continue;let ev;try{ev=JSON.parse(line)}catch{continue}const content=holder.querySelector('.ai-message-content');if(ev.type==='status'&&!accumulated){content.classList.add('ai-loading');content.textContent=ev.message||'Analisando...'}if(ev.type==='token'){content.classList.remove('ai-loading');accumulated+=ev.text||'';content.innerHTML=renderMarkdown(accumulated);list.scrollTop=list.scrollHeight}if(ev.type==='done')content.classList.remove('ai-loading');if(ev.type==='error')throw new Error(ev.error||'Erro na IA.')}}const content=holder.querySelector('.ai-message-content');content.classList.remove('ai-loading');if(!accumulated.trim())throw new Error('A IA terminou sem resposta.');content.innerHTML=renderMarkdown(accumulated)}catch(err){if(err.name==='AbortError')return;const content=holder.querySelector('.ai-message-content');content.classList.remove('ai-loading');content.innerHTML=`<span class="ai-error">${escapeHtml(err.message)}</span>`}finally{sendBtn.disabled=false;sendBtn.classList.remove('sending');sendBtn.removeAttribute('aria-busy');if(activePageAIController===controller)activePageAIController=null}}
window.redscribeAIChatSend=sendAIChat;
if($('aiChatSend'))$('aiChatSend').addEventListener('click',()=>window.redscribeAIChatSend?.());if($('aiChatInput'))$('aiChatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();window.redscribeAIChatSend?.()}});if($('clearAiChatBtn'))$('clearAiChatBtn').addEventListener('click',async()=>{if(activePageAIController)activePageAIController.abort();clearPendingAttachments();try{await fetchJSON('/api/ai/history',{method:'DELETE'});loadAIHistory();toast('Nova conversa iniciada')}catch(err){toast(err.message)}});if($('aiAttachBtn'))$('aiAttachBtn').addEventListener('click',()=>$('aiFileInput').click());if($('aiFileInput'))$('aiFileInput').addEventListener('change',e=>uploadAIAttachments(e.target.files));if($('aiVoiceBtn'))$('aiVoiceBtn').addEventListener('click',startOrStopAIVoice);

function notifyFinished(job){if(!settingsCache.notifications||notifiedJobs.has(job.id))return;notifiedJobs.add(job.id);if('Notification'in window&&Notification.permission==='granted'){new Notification('RedScribe',{body:job.media_only?`${job.title}: mídia pronta, sem fala detectada.`:`${job.title}: transcrição concluída.`})}}

// Atalhos
window.addEventListener('keydown',e=>{
  const tag=(document.activeElement?.tagName||'').toLowerCase();const typing=['input','textarea','select'].includes(tag)||document.activeElement?.isContentEditable;
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openSearch();return}
  if(e.key==='Escape'){closeSearch();$('projectModal').classList.add('hidden');return}
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'&&currentJob?.transcript_available){e.preventDefault();$('saveBtn').click();return}
  if(!typing&&e.key.toLowerCase()==='n'){e.preventDefault();switchView('new');return}
  if(!typing&&e.code==='Space'&&currentJob){e.preventDefault();const p=currentJob.video_ready?videoPlayer:audioPlayer;if(p.paused)p.play().catch(()=>{});else p.pause();return}
  if(!typing&&e.key==='ArrowLeft'&&currentJob){e.preventDefault();const p=currentJob.video_ready?videoPlayer:audioPlayer;p.currentTime=Math.max(0,p.currentTime-10)}
  if(!typing&&e.key==='ArrowRight'&&currentJob){e.preventDefault();const p=currentJob.video_ready?videoPlayer:audioPlayer;if(Number.isFinite(p.duration))p.currentTime=Math.min(p.duration,p.currentTime+10)}
});


function clearAccidentalYoutubeEmailAutofill(){
  const input=$('youtubeSearchInput');if(!input)return;
  const email=(document.body.dataset.userEmail||'').trim().toLowerCase();
  const value=(input.value||'').trim().toLowerCase();
  if(email&&value===email){input.value='';input.dispatchEvent(new Event('input',{bubbles:true}))}
}
[0,120,650,1500].forEach(ms=>setTimeout(clearAccidentalYoutubeEmailAutofill,ms));
$('youtubeSearchInput')?.addEventListener('focus',clearAccidentalYoutubeEmailAutofill);

// Inicialização
Promise.all([loadProjects(),loadSettings()]).then(()=>loadHistory());
