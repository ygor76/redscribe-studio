// RedScribe 3.3.5 Power Tools — loaded after stable dashboard.js
(() => {
  'use strict';

  const power = {
    selectedLibrary: new Set(), selectedProject: new Set(), selectedSearch: new Set(), selectedPlaylist: new Set(),
    projectId: null, projectItems: [], searchItems: [], playlistItems: [], aiConversationId: null,
    preferences: {autosave_transcript:true,recover_interrupted:true,remember_player:true,recommendations_enabled:true},
    searchSelectionMode: false, librarySelectionMode: false, aiSending: false,
    autosaveTimer: null, autosaveSeq: 0, musicSaveAt: 0,
  };

  function powerJSON(url, opts){return fetchJSON(url, opts)}

  function powerDialog({title='RedScribe', message='', input=false, inputValue='', buttons=[]}){
    return new Promise(resolve => {
      const root=$('powerDialog'), t=$('powerDialogTitle'), m=$('powerDialogMessage'), inp=$('powerDialogInput'), actions=$('powerDialogActions');
      t.textContent=title; m.textContent=message; inp.classList.toggle('hidden',!input); inp.value=inputValue||''; actions.innerHTML=''; root.classList.remove('hidden');
      const finish=(value)=>{root.classList.add('hidden');resolve({value,input:inp.value.trim()})};
      (buttons.length?buttons:[['Cancelar',null,'btn-secondary'],['OK',true,'btn-primary']]).forEach(([label,value,cls])=>{const b=document.createElement('button');b.type='button';b.className=`btn ${cls||'btn-secondary'}`;b.textContent=label;b.addEventListener('click',()=>finish(value));actions.appendChild(b)});
      if(input){setTimeout(()=>{inp.focus();inp.select()},40);inp.onkeydown=e=>{if(e.key==='Enter')finish(true);if(e.key==='Escape')finish(null)}}
      root.onclick=e=>{if(e.target===root)finish(null)};
    });
  }
  async function powerConfirm(message,title='RedScribe'){const r=await powerDialog({title,message,buttons:[['Cancelar',false,'btn-secondary'],['Confirmar',true,'btn-primary']]});return r.value===true}
  async function powerPrompt(message,value='',title='RedScribe'){const r=await powerDialog({title,message,input:true,inputValue:value,buttons:[['Cancelar',null,'btn-secondary'],['Salvar',true,'btn-primary']]});return r.value===true?r.input:null}
  async function powerPickProject(message='Escolha o projeto de destino'){
    return new Promise(resolve=>{
      const root=$('powerDialog'),t=$('powerDialogTitle'),m=$('powerDialogMessage'),inp=$('powerDialogInput'),actions=$('powerDialogActions');
      t.textContent='RedScribe';m.textContent=message;inp.classList.add('hidden');actions.innerHTML='';root.classList.remove('hidden');
      const select=document.createElement('select');select.style.cssText='width:100%;height:42px;margin-top:10px';select.innerHTML='<option value="">Sem projeto</option>'+projects.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)}</option>`).join('');m.after(select);
      const finish=v=>{select.remove();root.classList.add('hidden');resolve(v)};
      const cancel=document.createElement('button');cancel.className='btn btn-secondary';cancel.textContent='Cancelar';cancel.onclick=()=>finish(null);
      const ok=document.createElement('button');ok.className='btn btn-primary';ok.textContent='Mover';ok.onclick=()=>finish(select.value);
      actions.append(cancel,ok);root.onclick=e=>{if(e.target===root)finish(null)};
    })
  }

  // ---- Top search now searches YouTube in real time ----
  $('globalQuickSearchInput').placeholder='Pesquisar no YouTube';
  runGlobalQuickSearch = async function(){
    const input=$('globalQuickSearchInput'),results=$('globalQuickSearchResults'),q=input.value.trim();
    if(!q){results.classList.add('hidden');results.innerHTML='';return}
    results.classList.remove('hidden');
    if(q.length<2){results.innerHTML='<div class="empty-state">Digite pelo menos 2 caracteres.</div>';return}
    results.innerHTML='<div class="empty-state">Buscando no YouTube...</div>';
    try{
      const data=await powerJSON(`/api/youtube/search/v2?q=${encodeURIComponent(q)}&limit=6`);
      if(input.value.trim()!==q)return;
      const items=data.items||[];
      results.innerHTML=items.length?items.map(i=>`<button class="search-result" type="button" data-power-youtube="${escapeHtml(i.url)}" data-power-id="${escapeHtml(i.id)}" data-power-title="${escapeHtml(i.title||'Vídeo')}" data-power-channel="${escapeHtml(i.channel||'YouTube')}" data-power-query="${escapeHtml(q)}">${thumbHtml(i)}<span><strong>${escapeHtml(i.title||'Vídeo')}</strong><small>${escapeHtml(i.channel||'YouTube')}${i.in_library?' · Já na Biblioteca':''}</small></span><em>▶ ${escapeHtml(i.duration_label||'')}</em></button>`).join(''):'<div class="empty-state">Nenhum vídeo encontrado.</div>';
      results.querySelectorAll('[data-power-youtube]').forEach(b=>b.addEventListener('click',()=>{closeQuickSearch();input.blur();openYoutubeWatch({id:b.dataset.powerId,url:b.dataset.powerYoutube,title:b.dataset.powerTitle,channel:b.dataset.powerChannel})}));
    }catch(err){if(input.value.trim()===q)results.innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
  };

  // ---- Enhanced YouTube search ----
  const stableClearYoutubeSearch=clearYoutubeSearch;
  clearYoutubeSearch=function(clearInput=true){power.selectedSearch.clear();power.searchItems=[];power.searchSelectionMode=false;stableClearYoutubeSearch(clearInput);updateSearchSelectionButtons();loadRecentSearchChips()};
  function updateSearchSelectionButtons(){
    const n=power.selectedSearch.size,queueBtn=$('youtubeSearchQueueSelectedBtn'),modeBtn=$('youtubeSelectionModeBtn'),actions=$('youtubeSelectionActions'),allBtn=$('youtubeSearchSelectAllBtn');
    if(queueBtn){queueBtn.disabled=n===0;queueBtn.textContent=n?`＋ ${n} selecionado(s) à fila`:'＋ Selecionados à fila'}
    if(modeBtn){modeBtn.classList.toggle('active',power.searchSelectionMode);modeBtn.setAttribute('aria-pressed',power.searchSelectionMode?'true':'false');modeBtn.textContent=power.searchSelectionMode?'✓ Seleção ativa':'☑ Selecionar vários'}
    if(actions)actions.classList.toggle('hidden',!power.searchSelectionMode);
    if(allBtn&&power.searchSelectionMode){const eligible=power.searchItems.filter(x=>!x.in_library),all=eligible.length&&eligible.every(x=>power.selectedSearch.has(x.url));allBtn.textContent=all?'Limpar seleção':'Selecionar todos'}
  }
  function searchCard(item){
    const selected=power.selectedSearch.has(item.url),exists=item.in_library&&item.existing_job,selecting=power.searchSelectionMode;
    const checkbox=selecting?`<label class="youtube-search-select-wrap" title="Selecionar vídeo"><input class="youtube-search-select" type="checkbox" data-search-select="${escapeHtml(item.url)}" ${selected?'checked':''} ${exists?'disabled':''}><span></span></label>`:'';
    return `<article class="youtube-search-card ${selecting?'selection-mode':''} ${selected?'power-selected':''}" data-youtube-url="${escapeHtml(item.url)}">${checkbox}<div class="youtube-search-thumb"><img src="${escapeHtml(item.thumbnail_url||'')}" alt="Miniatura de ${escapeHtml(item.title||'vídeo')}" loading="lazy" decoding="async" referrerpolicy="no-referrer"><span>${escapeHtml(item.duration_label||'')}</span></div><div class="youtube-search-copy"><strong>${escapeHtml(item.title||'Vídeo do YouTube')}</strong><small>${escapeHtml(item.channel||'YouTube')}</small><em>${escapeHtml(formatViews(item.view_count))}</em>${exists?'<span class="duplicate-badge">✓ Já na Biblioteca</span>':''}</div><div class="youtube-search-actions"><button class="btn btn-secondary btn-small" data-watch-video="${escapeHtml(item.id)}" data-watch-url="${escapeHtml(item.url)}" data-watch-title="${escapeHtml(item.title||'Vídeo')}" data-watch-channel="${escapeHtml(item.channel||'YouTube')}" type="button">▶ Assistir</button>${exists?`<button class="btn btn-secondary btn-small open-existing-btn" data-open-existing="${exists.id}" type="button">Abrir existente</button><button class="btn btn-secondary btn-small" data-force-transcribe="${escapeHtml(item.url)}" type="button">Transcrever novamente</button>`:`<button class="btn btn-primary btn-small" data-search-transcribe="${escapeHtml(item.url)}" type="button">Transcrever</button><button class="btn btn-secondary btn-small ${youtubeQueuedUrls.has(item.url)?'is-added':''}" data-search-queue="${escapeHtml(item.url)}" type="button" ${youtubeQueuedUrls.has(item.url)?'disabled':''}>${youtubeQueuedUrls.has(item.url)?'✓ Na fila':'＋ Fila'}</button>`}</div></article>`;
  }
  renderYoutubeSearchResults=function(items,append=false){
    const list=$('youtubeSearchResults');if(!append){list.innerHTML='';power.searchItems=[];power.selectedSearch.clear()}
    if(!items.length&&!append){list.innerHTML='<div class="empty-state">Nenhum vídeo encontrado para essa pesquisa.</div>';updateSearchSelectionButtons();return}
    const known=new Set(power.searchItems.map(x=>x.url));for(const item of items){if(!known.has(item.url)){power.searchItems.push(item);known.add(item.url)}}
    list.innerHTML=power.searchItems.map(searchCard).join('');
    list.querySelectorAll('.youtube-search-thumb img').forEach(img=>img.addEventListener('error',()=>{const box=img.closest('.youtube-search-thumb');if(box)box.classList.add('failed');img.remove()}));
    list.querySelectorAll('[data-search-select]').forEach(c=>c.addEventListener('change',()=>{c.checked?power.selectedSearch.add(c.dataset.searchSelect):power.selectedSearch.delete(c.dataset.searchSelect);c.closest('.youtube-search-card')?.classList.toggle('power-selected',c.checked);updateSearchSelectionButtons()}));
    if(power.searchSelectionMode){list.querySelectorAll('.youtube-search-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button,input,label,a'))return;const c=card.querySelector('[data-search-select]');if(!c||c.disabled)return;c.checked=!c.checked;c.dispatchEvent(new Event('change'))}))}
    list.querySelectorAll('[data-search-transcribe]').forEach(b=>b.addEventListener('click',()=>startSearchVideo(b.dataset.searchTranscribe,false,b)));
    list.querySelectorAll('[data-search-queue]').forEach(b=>b.addEventListener('click',()=>startSearchVideo(b.dataset.searchQueue,true,b)));
    list.querySelectorAll('[data-force-transcribe]').forEach(b=>b.addEventListener('click',()=>startSearchVideo(b.dataset.forceTranscribe,false,b,true)));
    list.querySelectorAll('[data-open-existing]').forEach(b=>b.addEventListener('click',()=>openJob(b.dataset.openExisting)));
    list.querySelectorAll('[data-watch-video]').forEach(b=>b.addEventListener('click',()=>openYoutubeWatch({id:b.dataset.watchVideo,url:b.dataset.watchUrl,title:b.dataset.watchTitle,channel:b.dataset.watchChannel})));
    updateSearchSelectionButtons();
  };
  searchYoutube=async function(loadMore=false,silent=false){
    const query=loadMore?youtubeSearchQuery:$('youtubeSearchInput').value.trim();
    if(query.length<2){if(!silent&&query)toast('Digite pelo menos 2 caracteres para pesquisar.');if(!loadMore){$('youtubeSearchResults').innerHTML='';$('youtubeSearchMoreBtn').classList.add('hidden')}return}
    if(loadMore&&youtubeSearchBusy)return;if(!loadMore&&youtubeSearchController)youtubeSearchController.abort();
    const controller=new AbortController();youtubeSearchController=controller;const seq=++youtubeSearchSeq;youtubeSearchBusy=true;
    const state=$('youtubeSearchState'),more=$('youtubeSearchMoreBtn'),button=$('youtubeSearchBtn');
    if(!loadMore){youtubeSearchQuery=query;youtubeSearchOffset=0;$('youtubeSearchResults').innerHTML='';power.searchItems=[];power.selectedSearch.clear()}
    state.textContent=loadMore?'Buscando mais vídeos...':'Pesquisando no YouTube...';state.classList.remove('hidden');more.classList.add('hidden');button.disabled=true;button.textContent='Buscando...';
    try{
      const sort=$('youtubeSearchSort')?.value||'relevance',duration=$('youtubeSearchDuration')?.value||'any';
      const data=await powerJSON(`/api/youtube/search/v2?q=${encodeURIComponent(query)}&offset=${youtubeSearchOffset}&limit=12&sort=${encodeURIComponent(sort)}&duration=${encodeURIComponent(duration)}&remember=${silent?0:1}`,{signal:controller.signal});
      if(seq!==youtubeSearchSeq||(!loadMore&&$('youtubeSearchInput').value.trim()!==query))return;
      const items=data.items||[];renderYoutubeSearchResults(items,loadMore);youtubeSearchOffset=Number(data.next_offset||youtubeSearchOffset+items.length);more.classList.toggle('hidden',!data.has_more||!items.length);state.classList.add('hidden');loadRecentSearchChips();
    }catch(err){if(err?.name==='AbortError')return;if(seq===youtubeSearchSeq){state.textContent=err.message;state.classList.remove('hidden')}}finally{if(seq===youtubeSearchSeq){youtubeSearchBusy=false;button.disabled=false;button.textContent='Pesquisar'}}
  };
  startSearchVideo=async function(url,queueOnly,button,force=false){
    const old=button?.textContent||'';if(button){button.disabled=true;button.textContent=queueOnly?'Adicionando...':'Iniciando...'}
    const common={language:$('language').value,timestamps:$('timestamps').checked,allow_whisper:$('whisper').checked,confirmed_rights:$('rights').checked,quality:$('quality').value,project_id:$('projectSelect').value||null,force};
    if(!common.confirmed_rights){if(button){button.disabled=false;button.textContent=old}return toast('Confirme que você tem permissão para processar o conteúdo.')}
    try{
      const data=await powerJSON('/api/transcribe/batch/v2',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,urls:[url]})});
      if(data.duplicates?.length&&!force){const d=data.duplicates[0];const choice=await powerDialog({title:'Vídeo já existente',message:`“${d.title||'Este vídeo'}” já está na sua Biblioteca.`,buttons:[['Cancelar','cancel','btn-secondary'],['Abrir existente','open','btn-secondary'],['Transcrever novamente','force','btn-primary']]});if(choice.value==='open')return openJob(d.id);if(choice.value==='force')return startSearchVideo(url,queueOnly,button,true);return}
      const jid=data.job_ids?.[0];if(!jid)throw new Error('O vídeo não foi adicionado.');youtubeQueuedUrls.add(url);bumpQueueIndicators(1);loadHistory();
      if(queueOnly){if(button){button.textContent='✓ Na fila';button.classList.add('is-added')}toast('Vídeo adicionado à fila')}else{beginProgress();processingJobId=jid;pollJob(jid)}
    }catch(err){if(!queueOnly)showError(err.message);else toast(err.message,4500)}finally{if(button&&(!queueOnly||!youtubeQueuedUrls.has(url))){button.disabled=false;button.textContent=old}}
  };

  async function queueUrls(urls){
    urls=[...new Set(urls)].filter(Boolean);if(!urls.length)return toast('Selecione pelo menos um vídeo.');
    const common={language:$('language').value,timestamps:$('timestamps').checked,allow_whisper:$('whisper').checked,confirmed_rights:$('rights').checked,quality:$('quality').value,project_id:$('projectSelect').value||null};
    if(!common.confirmed_rights)return toast('Confirme que você tem permissão para processar o conteúdo.');
    try{const d=await powerJSON('/api/transcribe/batch/v2',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...common,urls})});const created=d.created||[];if(created.length)created.forEach(row=>youtubeQueuedUrls.add(row.url));else (d.job_ids||[]).forEach((_,i)=>youtubeQueuedUrls.add(urls[i]));bumpQueueIndicators((d.job_ids||[]).length);toast(`${(d.job_ids||[]).length} vídeo(s) adicionado(s) à fila${d.duplicates?.length?` · ${d.duplicates.length} já existiam`:''}`,4200);loadHistory();if(d.duplicates?.length)renderYoutubeSearchResults(power.searchItems,false)}catch(err){toast(err.message,5000)}
  }
  $('youtubeSelectionModeBtn')?.addEventListener('click',()=>{power.searchSelectionMode=!power.searchSelectionMode;power.selectedSearch.clear();renderYoutubeSearchResults(power.searchItems,false);updateSearchSelectionButtons()});
  $('youtubeSearchSelectAllBtn')?.addEventListener('click',()=>{if(!power.searchSelectionMode)return;const eligible=power.searchItems.filter(x=>!x.in_library);const all=eligible.length&&eligible.every(x=>power.selectedSearch.has(x.url));power.selectedSearch.clear();if(!all)eligible.forEach(x=>power.selectedSearch.add(x.url));renderYoutubeSearchResults(power.searchItems,false)});
  $('youtubeSearchQueueSelectedBtn')?.addEventListener('click',async()=>{await queueUrls([...power.selectedSearch]);power.selectedSearch.clear();power.searchSelectionMode=false;renderYoutubeSearchResults(power.searchItems,false)});
  $('youtubeSearchQueueAllBtn')?.addEventListener('click',()=>queueUrls(power.searchItems.filter(x=>!x.in_library).map(x=>x.url)));
  ['youtubeSearchSort','youtubeSearchDuration'].forEach(id=>$(id)?.addEventListener('change',()=>{if($('youtubeSearchInput').value.trim().length>=2)searchYoutube(false,true)}));
  async function loadRecentSearchChips(){try{const d=await powerJSON('/api/youtube/search-history');const box=$('youtubeRecentSearchChips');if(box){box.innerHTML=(d.items||[]).slice(0,8).map(x=>`<button class="recent-search-chip" type="button" data-recent-query="${escapeHtml(x.query)}">${escapeHtml(x.query)}</button>`).join('');box.querySelectorAll('[data-recent-query]').forEach(b=>b.addEventListener('click',()=>{$('youtubeSearchInput').value=b.dataset.recentQuery;searchYoutube(false,false)}))}renderHomeRecentSearches(d.items||[])}catch{}}

  // ---- Playlist import ----
  const stableSetSourceTab=setSourceTab;
  setSourceTab=function(name){stableSetSourceTab(name);$('transcribeBtn').closest('.form-actions').classList.toggle('hidden',name==='youtube-search'||name==='playlist')};
  async function loadPlaylistPreview(){
    const url=$('youtubePlaylistUrl').value.trim(),state=$('playlistImportState'),head=$('playlistImportHead'),list=$('playlistImportResults');if(!url)return toast('Cole o link da playlist.');
    state.textContent='Carregando playlist...';state.classList.remove('hidden');head.classList.add('hidden');list.innerHTML='';power.selectedPlaylist.clear();
    try{const d=await powerJSON(`/api/youtube/playlist?url=${encodeURIComponent(url)}`);power.playlistItems=d.items||[];$('playlistImportTitle').textContent=d.title||'Playlist';$('playlistImportMeta').textContent=`${d.count||0} vídeos · ${d.channel||'YouTube'}`;head.classList.remove('hidden');state.classList.add('hidden');renderPlaylistItems()}catch(err){state.textContent=err.message;state.classList.remove('hidden')}
  }
  function renderPlaylistItems(){const list=$('playlistImportResults');list.innerHTML=power.playlistItems.length?power.playlistItems.map(x=>{const exists=x.in_library&&x.existing_job,sel=power.selectedPlaylist.has(x.url);return `<article class="playlist-import-item"><input class="playlist-select" type="checkbox" data-playlist-select="${escapeHtml(x.url)}" ${sel?'checked':''} ${exists?'disabled':''}><img src="${escapeHtml(x.thumbnail_url||'')}" alt="" referrerpolicy="no-referrer"><div><strong>${escapeHtml(x.title||'Vídeo')}</strong><small>${escapeHtml(x.channel||'YouTube')} · ${escapeHtml(x.duration_label||'')}</small>${exists?'<span class="duplicate-badge">✓ Já na Biblioteca</span>':''}</div>${exists?`<button class="row-action" data-open-existing="${exists.id}" type="button">Abrir</button>`:'<span class="status-badge neutral">Novo</span>'}</article>`}).join(''):'<div class="empty-state">Nenhum vídeo na playlist.</div>';list.querySelectorAll('[data-playlist-select]').forEach(c=>c.addEventListener('change',()=>{c.checked?power.selectedPlaylist.add(c.dataset.playlistSelect):power.selectedPlaylist.delete(c.dataset.playlistSelect);updatePlaylistButtons()}));list.querySelectorAll('[data-open-existing]').forEach(b=>b.addEventListener('click',()=>openJob(b.dataset.openExisting)));updatePlaylistButtons()}
  function updatePlaylistButtons(){const b=$('playlistQueueSelectedBtn');b.disabled=!power.selectedPlaylist.size;b.textContent=power.selectedPlaylist.size?`Adicionar ${power.selectedPlaylist.size} à fila`:'Adicionar selecionados à fila'}
  $('loadPlaylistBtn')?.addEventListener('click',loadPlaylistPreview);$('youtubePlaylistUrl')?.addEventListener('keydown',e=>{if(e.key==='Enter')loadPlaylistPreview()});
  $('playlistSelectAllBtn')?.addEventListener('click',()=>{const eligible=power.playlistItems.filter(x=>!x.in_library),all=eligible.length&&eligible.every(x=>power.selectedPlaylist.has(x.url));power.selectedPlaylist.clear();if(!all)eligible.forEach(x=>power.selectedPlaylist.add(x.url));renderPlaylistItems()});
  $('playlistQueueSelectedBtn')?.addEventListener('click',()=>queueUrls([...power.selectedPlaylist]));

  // ---- Smart duplicate handling for direct links and batches. Local-file flow remains stable. ----
  $('transcribeBtn')?.addEventListener('click',async e=>{
    if(currentSource!=='link'&&currentSource!=='batch')return;
    e.preventDefault();e.stopImmediatePropagation();
    if(!$('rights').checked)return toast('Confirme que você tem permissão para processar o conteúdo.');
    if(currentSource==='batch'){
      const urls=($('batchUrls')?.value||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      if(!urls.length)return toast('Cole pelo menos um link do YouTube.');
      const btn=$('transcribeBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Adicionando à fila...';
      try{await queueUrls(urls);$('batchUrls').value='';switchView('queue')}finally{btn.disabled=false;btn.textContent=old}
      return;
    }
    const url=$('url').value.trim();if(!url)return toast('Cole o link de um vídeo do YouTube.');
    try{const dup=await powerJSON(`/api/duplicates/check?url=${encodeURIComponent(url)}`);if(dup.duplicate){const r=await powerDialog({title:'Vídeo já existente',message:`“${dup.item?.title||'Este vídeo'}” já está na Biblioteca. O que deseja fazer?`,buttons:[['Cancelar','cancel','btn-secondary'],['Abrir existente','open','btn-secondary'],['Transcrever novamente','force','btn-primary']]});if(r.value==='open')return openJob(dup.item.id);if(r.value!=='force')return;return startSearchVideo(url,false,$('transcribeBtn'),true)}return startSearchVideo(url,false,$('transcribeBtn'),false)}catch(err){toast(err.message,4500)}
  },true);

  // ---- Library bulk actions + tags ----
  const stableRenderLibrary=renderLibrary;
  renderLibrary=function(itemsOverride=null){
    const base=itemsOverride||libraryItems,q=($('librarySearch').value||'').trim().toLowerCase(),tag=$('libraryTagFilter')?.value||'';
    const filtered=base.filter(i=>(!q||(i.title||'').toLowerCase().includes(q)||(i.preview||'').toLowerCase().includes(q)||(i.tags||[]).some(t=>String(t).toLowerCase().includes(q)))&&(!tag||(i.tags||[]).includes(tag)));
    stableRenderLibrary(filtered);enhanceLibraryCards(filtered);
  };
  function enhanceLibraryCards(items){
    const map=new Map(items.map(x=>[x.id,x]));$('libraryList').querySelectorAll('.library-card').forEach(card=>{const open=card.querySelector('[data-open-job]'),id=open?.dataset.openJob,item=map.get(id);if(!id||!item)return;card.style.position='relative';const selected=power.librarySelectionMode&&power.selectedLibrary.has(id);card.classList.toggle('power-selected',selected);const existing=card.querySelector('[data-library-select]');if(!power.librarySelectionMode){existing?.remove()}else if(!existing){const c=document.createElement('input');c.type='checkbox';c.className='library-select-check';c.dataset.librarySelect=id;c.checked=selected;c.setAttribute('aria-label','Selecionar este trabalho');c.addEventListener('click',ev=>ev.stopPropagation());c.addEventListener('change',()=>{c.checked?power.selectedLibrary.add(id):power.selectedLibrary.delete(id);card.classList.toggle('power-selected',c.checked);updateLibraryBulk()});card.appendChild(c)}else existing.checked=selected;const copy=card.querySelector('.history-copy');if(copy&&!copy.querySelector('.tag-chips')&&(item.tags||[]).length){const tags=document.createElement('div');tags.className='tag-chips';tags.innerHTML=item.tags.map(t=>`<span class="tag-chip">#${escapeHtml(t)}</span>`).join('');copy.appendChild(tags)}});updateLibraryBulk()
  }
  async function loadTagFilter(){try{const d=await powerJSON('/api/tags'),el=$('libraryTagFilter'),cur=el.value;el.innerHTML='<option value="">Todas as tags</option>'+(d.items||[]).map(x=>`<option value="${escapeHtml(x.name)}">#${escapeHtml(x.name)} (${x.count})</option>`).join('');if([...el.options].some(o=>o.value===cur))el.value=cur}catch{}}
  $('libraryTagFilter')?.addEventListener('change',()=>renderLibrary());
  function updateLibraryBulk(){const n=power.selectedLibrary.size,bar=$('libraryBulkBar'),btn=$('librarySelectionModeBtn');bar?.classList.toggle('hidden',!power.librarySelectionMode);if($('librarySelectedCount'))$('librarySelectedCount').textContent=`${n} selecionado(s)`;if($('librarySelectAll'))$('librarySelectAll').checked=!!libraryItems.length&&libraryItems.every(x=>power.selectedLibrary.has(x.id));if(btn){btn.textContent=power.librarySelectionMode?'Cancelar seleção':'Selecionar';btn.classList.toggle('is-active',power.librarySelectionMode)}}
  $('librarySelectionModeBtn')?.addEventListener('click',()=>{if(typeof libraryFilter!=='undefined'&&libraryFilter==='shorts'&&typeof window.toggleShortLibrarySelectionMode==='function'){window.toggleShortLibrarySelectionMode();return}power.librarySelectionMode=!power.librarySelectionMode;if(!power.librarySelectionMode)power.selectedLibrary.clear();renderLibrary()});
  $('librarySelectAll')?.addEventListener('change',e=>{if(typeof libraryFilter!=='undefined'&&libraryFilter==='shorts')return;power.librarySelectionMode=true;if(e.target.checked)libraryItems.forEach(x=>power.selectedLibrary.add(x.id));else power.selectedLibrary.clear();renderLibrary()});
  async function bulkAction(action,extra={}){const ids=[...power.selectedLibrary];if(!ids.length)return;try{const d=await powerJSON('/api/jobs/bulk',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:ids,action,...extra})});toast(`${d.updated||0} trabalho(s) atualizados`);power.selectedLibrary.clear();power.librarySelectionMode=false;await loadProjects();loadLibrary(libraryFilter);loadHistory();loadTagFilter()}catch(err){toast(err.message,4500)}}
  $('bulkMoveBtn')?.addEventListener('click',()=>bulkAction('move',{project_id:$('bulkProjectSelect').value||null}));$('bulkFavoriteBtn')?.addEventListener('click',()=>bulkAction('favorite'));
  $('bulkTrashBtn')?.addEventListener('click',async()=>{if(await powerConfirm(`Mover ${power.selectedLibrary.size} trabalho(s) para a lixeira?`))bulkAction('trash')});
  $('bulkTagBtn')?.addEventListener('click',async()=>{const tag=await powerPrompt('Digite a tag que será adicionada aos trabalhos selecionados:','','Adicionar tag');if(tag)bulkAction('tag_add',{tag})});
  $('bulkAudioBtn')?.addEventListener('click',async()=>{const ids=[...power.selectedLibrary];try{const d=await powerJSON('/api/jobs/bulk/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:ids,kind:'audio'})});toast(`${d.saved?.length||0} áudio(s) salvos${d.errors?.length?` · ${d.errors.length} indisponíveis`:''}`,4200);loadDownloads()}catch(err){toast(err.message)}});
  $('bulkExportBtn')?.addEventListener('click',async()=>{try{const d=await powerJSON('/api/jobs/bulk/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:[...power.selectedLibrary]})});toast(`${d.count} transcrição(ões) exportadas em ${d.filename}`,5200)}catch(err){toast(err.message)}});

  // Keep project selects in the new bulk toolbar synchronized.
  const stableLoadProjects=loadProjects;
  loadProjects=async function(render=false){const r=await stableLoadProjects(render);const el=$('bulkProjectSelect');if(el){const cur=el.value;el.innerHTML='<option value="">Sem projeto</option>'+projects.map(p=>`<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('');if([...el.options].some(o=>o.value===cur))el.value=cur}populateAIProjectContext();return r};

  // ---- Project workspace ----
  const stableRenderProjects=renderProjects;
  renderProjects=function(){stableRenderProjects();$('projectsList').querySelectorAll('.project-card').forEach(card=>{const open=card.querySelector('[data-open-project]'),id=open?.dataset.openProject;if(!id)return;if(!card.querySelector('[data-manage-project]')){const b=document.createElement('button');b.className='row-action';b.type='button';b.dataset.manageProject=id;b.textContent='Gerenciar';card.querySelector('.project-actions')?.prepend(b);b.addEventListener('click',e=>{e.stopPropagation();openProjectWorkspace(id)})}})};
  async function openProjectWorkspace(id){power.projectId=id;power.selectedProject.clear();$('projectWorkspace').classList.remove('hidden');$('projectsList').closest('.panel').classList.add('hidden');await loadProjectWorkspace()}
  async function loadProjectWorkspace(){if(!power.projectId)return;const q=$('projectWorkspaceSearch').value.trim(),sort=$('projectWorkspaceSort').value;try{const d=await powerJSON(`/api/projects/${power.projectId}/detail?q=${encodeURIComponent(q)}&sort=${encodeURIComponent(sort)}`);power.projectItems=d.items||[];$('projectWorkspaceTitle').textContent=d.project?.name||'Projeto';$('projectWorkspaceStats').textContent=`${d.stats?.total||0} itens · ${d.stats?.shorts||0} Shorts · ${d.stats?.audio||0} áudios · ${d.stats?.text||0} textos · ${d.stats?.favorites||0} favoritos`;$('projectWorkspacePlay').disabled=!(d.stats?.audio>0);renderProjectWorkspace()}catch(err){$('projectWorkspaceList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}}
  function renderProjectWorkspace(){const list=$('projectWorkspaceList');list.innerHTML=power.projectItems.length?power.projectItems.map(item=>{if(item.item_type==='short')return `<article class="library-card library-card-v3 project-short-item"><div class="project-short-media"><video controls preload="metadata" playsinline src="${escapeHtml(item.video_url||'')}"></video></div><div class="history-copy"><strong>${escapeHtml(item.title||'Short')}</strong><div class="history-meta"><span>${formatDate(item.created_at)}</span><span>${escapeHtml(item.duration_label||'—')}</span><span>Short 9:16</span>${item.channel?`<span>${escapeHtml(item.channel)}</span>`:''}</div><div class="asset-chips"><span class="asset-chip video">Short</span><span class="asset-chip media">${escapeHtml(item.video_quality||'1080p')}</span></div></div><div class="history-actions"><span class="status-badge success">Short</span></div></article>`;return `<article class="library-card library-card-v3 ${power.selectedProject.has(item.id)?'power-selected':''}" style="position:relative"><input class="library-select-check" type="checkbox" data-project-select="${item.id}" ${power.selectedProject.has(item.id)?'checked':''}>${thumbHtml(item)}<div class="history-copy"><strong>${escapeHtml(item.title||'Trabalho')}</strong><div class="history-meta"><span>${formatDate(item.created_at)}</span><span>${escapeHtml(item.duration_label||'—')}</span></div><div class="asset-chips">${assetChips(item)}</div>${(item.tags||[]).length?`<div class="tag-chips">${item.tags.map(t=>`<span class="tag-chip">#${escapeHtml(t)}</span>`).join('')}</div>`:''}</div><div class="history-actions">${statusBadge(item)}${item.audio_ready?`<button class="row-action" data-play-project-job="${item.id}" type="button">▶ Ouvir</button>`:''}<button class="row-action" data-open-job="${item.id}" type="button">Abrir</button></div></article>`}).join(''):'<div class="empty-library project-empty-state"><strong>Nada encontrado</strong>Este projeto não possui itens para o filtro atual.</div>';bindHistoryActions(list);list.querySelectorAll('[data-project-select]').forEach(c=>c.addEventListener('change',()=>{c.checked?power.selectedProject.add(c.dataset.projectSelect):power.selectedProject.delete(c.dataset.projectSelect);renderProjectWorkspace();updateProjectBulk()}));list.querySelectorAll('[data-play-project-job]').forEach(b=>b.addEventListener('click',()=>startProjectPlaylist(power.projectId,b.dataset.playProjectJob)));updateProjectBulk()}
  function updateProjectBulk(){const n=power.selectedProject.size;$('projectWorkspaceBulk').classList.toggle('hidden',!n);$('projectWorkspaceSelectedCount').textContent=`${n} selecionado(s)`;$('projectWorkspaceSelectAll').checked=!!power.projectItems.length&&power.projectItems.every(x=>power.selectedProject.has(x.id))}
  $('closeProjectWorkspace')?.addEventListener('click',()=>{$('projectWorkspace').classList.add('hidden');$('projectsList').closest('.panel').classList.remove('hidden');power.projectId=null;power.selectedProject.clear()});
  let projectSearchTimer=null;$('projectWorkspaceSearch')?.addEventListener('input',()=>{clearTimeout(projectSearchTimer);projectSearchTimer=setTimeout(loadProjectWorkspace,240)});$('projectWorkspaceSort')?.addEventListener('change',loadProjectWorkspace);$('projectWorkspaceSelectAll')?.addEventListener('change',e=>{power.selectedProject.clear();if(e.target.checked)power.projectItems.forEach(x=>power.selectedProject.add(x.id));renderProjectWorkspace()});$('projectWorkspacePlay')?.addEventListener('click',()=>startProjectPlaylist(power.projectId));
  async function projectBulk(action,extra={}){const ids=[...power.selectedProject];if(!ids.length)return;try{await powerJSON('/api/jobs/bulk',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:ids,action,...extra})});power.selectedProject.clear();loadProjectWorkspace();loadProjects(true);loadHistory()}catch(err){toast(err.message)}}
  $('projectBulkFavorite')?.addEventListener('click',()=>projectBulk('favorite'));$('projectBulkTrash')?.addEventListener('click',async()=>{if(await powerConfirm('Mover os trabalhos selecionados para a lixeira?'))projectBulk('trash')});$('projectBulkMove')?.addEventListener('click',async()=>{const pid=await powerPickProject();if(pid!==null)projectBulk('move',{project_id:pid})});$('projectBulkAudio')?.addEventListener('click',async()=>{try{const d=await powerJSON('/api/jobs/bulk/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_ids:[...power.selectedProject],kind:'audio'})});toast(`${d.saved?.length||0} áudio(s) salvos`)}catch(err){toast(err.message)}});

  // ---- Collapsible AI conversation rail ----
  function setAIConversationRailCollapsed(collapsed){
    const grid=document.querySelector('.power-ai-grid'),panel=$('aiConversationPanel'),btn=$('toggleAIConversationsBtn');
    if(!grid||!panel||!btn)return;
    grid.classList.toggle('ai-conversations-collapsed',collapsed);
    panel.classList.toggle('collapsed',collapsed);
    btn.setAttribute('aria-expanded',collapsed?'false':'true');
    btn.setAttribute('aria-label',collapsed?'Abrir conversas':'Recolher conversas');
    btn.title=collapsed?'Abrir conversas':'Recolher conversas';
    btn.textContent=collapsed?'›':'‹';
  }
  function initAIConversationRail(){
    const btn=$('toggleAIConversationsBtn');if(!btn||btn.dataset.bound)return;btn.dataset.bound='1';
    // Toda nova execução começa com a lateral recolhida para dar mais espaço ao chat.
    setAIConversationRailCollapsed(true);
    btn.addEventListener('click',()=>setAIConversationRailCollapsed(!document.querySelector('.power-ai-grid')?.classList.contains('ai-conversations-collapsed')));
  }
  initAIConversationRail();

  // ---- AI conversations + project-wide context ----
  let aiConversations=[];

  function setAIContextOpen(open){const wrap=$('aiContextWrap');const btn=$('aiContextToggle');if(!wrap||!btn)return;wrap.classList.toggle('hidden',!open);btn.setAttribute('aria-expanded',open?'true':'false');btn.querySelector('.ai-context-toggle-icon').textContent=open?'⌄':'⌃'}
  function initAIContextToggle(){const btn=$('aiContextToggle');if(!btn||btn.dataset.bound)return;btn.dataset.bound='1';setAIContextOpen(false);btn.addEventListener('click',()=>setAIContextOpen(btn.getAttribute('aria-expanded')!=='true'))}
  function setAIActiveTitle(title){const el=$('aiActiveConversationTitle');if(el)el.textContent=title||'Nova conversa'}
  async function ensureConversation(){
    if(power.aiConversationId){
      const d=await powerJSON('/api/ai/conversations');
      if((d.items||[]).some(x=>x.id===power.aiConversationId))return power.aiConversationId;
      power.aiConversationId=null;
    }
    const d=await powerJSON('/api/ai/conversations');
    const valid=(d.items||[]).find(x=>x.id===d.active_id)||(d.items||[])[0];
    if(valid){power.aiConversationId=valid.id;setAIActiveTitle(valid.title);return valid.id}
    const c=await powerJSON('/api/ai/conversations',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    power.aiConversationId=c.item.id;setAIActiveTitle(c.item.title);return power.aiConversationId;
  }
  async function loadAIConversations(){try{const d=await powerJSON('/api/ai/conversations');aiConversations=d.items||[];if(!power.aiConversationId||!aiConversations.some(x=>x.id===power.aiConversationId))power.aiConversationId=(aiConversations.find(x=>x.id===d.active_id)||aiConversations[0]||{}).id||null;const active=aiConversations.find(x=>x.id===power.aiConversationId);setAIActiveTitle(active?.title||'Nova conversa');renderAIConversations();if(!power.aiConversationId){await newAIConversation(false)}}catch(err){$('aiConversationList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}}
  function renderAIConversations(){const box=$('aiConversationList');box.innerHTML=aiConversations.length?aiConversations.map(c=>`<article class="ai-conversation-item ${c.id===power.aiConversationId?'active':''}" data-ai-conversation="${c.id}"><span class="ai-conversation-icon">✦</span><span class="ai-conversation-copy"><strong>${escapeHtml(c.title||'Conversa')}</strong><small>${escapeHtml(c.preview||`${c.message_count||0} mensagens`)}</small></span><button class="ai-conversation-menu" data-ai-conversation-menu="${c.id}" type="button" aria-label="Opções">⋯</button></article>`).join(''):'<div class="empty-state">Nenhuma conversa ainda.</div>';box.querySelectorAll('[data-ai-conversation]').forEach(row=>row.addEventListener('click',e=>{if(e.target.closest('[data-ai-conversation-menu]'))return;power.aiConversationId=row.dataset.aiConversation;const c=aiConversations.find(x=>x.id===power.aiConversationId);setAIActiveTitle(c?.title||'Conversa');loadAIHistory();renderAIConversations()}));box.querySelectorAll('[data-ai-conversation-menu]').forEach(b=>b.addEventListener('click',async()=>{const c=aiConversations.find(x=>x.id===b.dataset.aiConversationMenu);const r=await powerDialog({title:c?.title||'Conversa',message:'Escolha uma ação para esta conversa.',buttons:[['Cancelar','cancel','btn-secondary'],['Renomear','rename','btn-secondary'],['Excluir','delete','btn-secondary']]});if(r.value==='rename'){const name=await powerPrompt('Novo nome da conversa:',c?.title||'','Renomear conversa');if(name){await powerJSON(`/api/ai/conversations/${c.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:name})});loadAIConversations()}}if(r.value==='delete'&&await powerConfirm('Excluir esta conversa?')){await powerJSON(`/api/ai/conversations/${c.id}`,{method:'DELETE'});if(power.aiConversationId===c.id)power.aiConversationId=null;await loadAIConversations();loadAIHistory()}}))}
  async function newAIConversation(showToast=true){try{if(activePageAIController)activePageAIController.abort();const d=await powerJSON('/api/ai/conversations',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});power.aiConversationId=d.item.id;setAIActiveTitle(d.item.title);clearPendingAttachments();await loadAIConversations();await loadAIHistory();if(showToast)toast('Nova conversa criada')}catch(err){toast(err.message)}}
  $('clearAiChatBtn')?.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();newAIConversation()},true);$('newAIConversationBtn')?.addEventListener('click',()=>newAIConversation());initAIContextToggle();
  loadAIHistory=async function(){try{const cid=await ensureConversation(),d=await powerJSON(`/api/ai/conversations/${cid}/messages`),list=$('aiChatMessages'),items=d.items||[];setAIActiveTitle(d.conversation?.title||aiConversations.find(x=>x.id===cid)?.title||'Conversa');list.innerHTML=items.length?items.map(aiMessageHtml).join(''):'<div class="ai-chat-empty"><span class="ai-orb">✦</span><strong>Como posso ajudar?</strong><p>Converse normalmente, anexe documentos ou use uma transcrição/projeto como contexto.</p><div class="ai-empty-suggestions"><button type="button" data-ai-suggestion="Resuma os principais pontos para mim.">Resumir conteúdo</button><button type="button" data-ai-suggestion="Organize isso em uma lista de tarefas.">Criar lista</button><button type="button" data-ai-suggestion="Me ajude a transformar este conteúdo em um roteiro.">Criar roteiro</button></div></div>';bindAISuggestions();list.scrollTop=list.scrollHeight;loadAIConversations()}catch(err){$('aiChatMessages').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}};
  function populateAIProjectContext(){const el=$('aiContextProject');if(!el)return;const cur=el.value;el.innerHTML='<option value="">Sem projeto selecionado</option>'+projects.map(p=>`<option value="${p.id}">${escapeHtml(p.name)} (${p.count||0})</option>`).join('');if([...el.options].some(o=>o.value===cur))el.value=cur}
  const stableLoadAIContextOptions=loadAIContextOptions;loadAIContextOptions=async function(){await stableLoadAIContextOptions();populateAIProjectContext()};
  $('aiContextJob')?.addEventListener('change',()=>{if($('aiContextJob').value)$('aiContextProject').value=''});$('aiContextProject')?.addEventListener('change',()=>{if($('aiContextProject').value)$('aiContextJob').value=''});
  function bindAISuggestions(){document.querySelectorAll('[data-ai-suggestion]').forEach(b=>{if(b.dataset.bound)return;b.dataset.bound='1';b.addEventListener('click',()=>{const input=$('aiChatInput');input.value=b.dataset.aiSuggestion||'';input.focus()})})}
  async function powerSendAIChat(){
    if(power.aiSending)return;
    const input=$('aiChatInput'),message=input.value.trim();if(!message&&!aiPendingAttachments.length)return;
    if(activePageAIController)activePageAIController.abort();const controller=new AbortController();activePageAIController=controller;power.aiSending=true;
    const list=$('aiChatMessages');if(list.querySelector('.ai-chat-empty'))list.innerHTML='';const outgoing=aiPendingAttachments.map(x=>({...x})),visible=message||'Analise os arquivos anexados.';
    list.insertAdjacentHTML('beforeend',aiMessageHtml({role:'user',text:visible,attachments:outgoing}));
    const holder=document.createElement('article');holder.className='ai-chat-message assistant';holder.innerHTML='<div class="ai-message-avatar" aria-hidden="true">✦</div><div class="ai-message-stack"><span class="ai-message-name">RedScribe IA</span><div class="ai-message-content ai-loading"><span class="ai-thinking-dots"><i></i><i></i><i></i></span><span> Analisando...</span></div></div>';list.appendChild(holder);list.scrollTop=list.scrollHeight;
    input.value='';clearPendingAttachments();let accumulated='';const btn=$('aiChatSend');btn.disabled=true;btn.classList.add('sending');btn.setAttribute('aria-busy','true');
    try{
      const cid=await ensureConversation();
      const response=await fetch(`/api/ai/conversations/${cid}/chat/stream`,{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({message,job_id:$('aiContextJob').value||null,project_id:$('aiContextProject').value||null,attachment_ids:outgoing.map(x=>x.id)})});
      if(!response.ok){let d={};try{d=await response.json()}catch{}throw new Error(d.error||`Não foi possível iniciar a IA (${response.status}).`)}
      if(!response.body)throw new Error('A resposta em tempo real não está disponível.');
      const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';
      while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()||'';for(const line of lines){if(!line.trim())continue;let ev;try{ev=JSON.parse(line)}catch{continue}const content=holder.querySelector('.ai-message-content');if(ev.type==='status'&&!accumulated){content.classList.add('ai-loading');content.innerHTML=`<span class="ai-thinking-dots"><i></i><i></i><i></i></span><span> ${escapeHtml(ev.message||'Analisando...')}</span>`}if(ev.type==='token'){content.classList.remove('ai-loading');accumulated+=ev.text||'';content.innerHTML=renderMarkdown(accumulated);list.scrollTop=list.scrollHeight}if(ev.type==='error')throw new Error(ev.error||'Erro na IA.')}}
      const content=holder.querySelector('.ai-message-content');content.classList.remove('ai-loading');if(!accumulated.trim())throw new Error('A IA terminou sem resposta.');content.innerHTML=renderMarkdown(accumulated);await loadAIConversations();
    }catch(err){if(err.name!=='AbortError'){const content=holder.querySelector('.ai-message-content');content.classList.remove('ai-loading');content.innerHTML=`<span class="ai-error">${escapeHtml(err.message)}</span>`;toast('A mensagem não pôde ser enviada.',3200)}}finally{power.aiSending=false;btn.disabled=false;btn.classList.remove('sending');btn.removeAttribute('aria-busy');if(activePageAIController===controller)activePageAIController=null;input.focus()}
  }
  window.redscribeAIChatSend=powerSendAIChat;bindAISuggestions();

  // Expanded tools inside a transcript use v2 endpoint.
  runAI=async function(action,question=''){if(!currentJob?.transcript_available)return;const result=$('aiResult');if(activeAIController)activeAIController.abort();const controller=new AbortController();activeAIController=controller;result.innerHTML='<span class="ai-loading">Iniciando IA...</span>';let accumulated='';try{const response=await fetch(`/api/jobs/${currentJob.id}/ai/v2/stream`,{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({action,question})});if(!response.ok){let d={};try{d=await response.json()}catch{}throw new Error(d.error||'Não foi possível iniciar a IA.')}const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()||'';for(const line of lines){if(!line.trim())continue;let ev;try{ev=JSON.parse(line)}catch{continue}if(ev.type==='status'&&!accumulated)result.innerHTML=`<span class="ai-loading">${escapeHtml(ev.message||'Analisando...')}</span>`;if(ev.type==='token'){accumulated+=ev.text||'';result.innerHTML=renderMarkdown(accumulated)}if(ev.type==='error')throw new Error(ev.error||'Erro na IA.')}}if(!accumulated.trim())throw new Error('A IA terminou sem retornar resposta.');result.innerHTML=renderMarkdown(accumulated)}catch(err){if(err.name!=='AbortError')result.innerHTML=`<span class="ai-error">${escapeHtml(err.message)}</span>`}finally{if(activeAIController===controller)activeAIController=null}};

  // ---- Autosave / undo / redo / word count ----
  function editorCount(){const n=(getEditorText().match(/\S+/g)||[]).length;$('editorWordCount').textContent=`${n} palavra${n===1?'':'s'}`}
  async function autosaveEditor(){if(!power.preferences.autosave_transcript||!currentJob?.id||!currentJob.transcript_available)return;const text=getEditorText();if(!text||text===String(currentJob.transcript||'').trim()){$('editorAutosaveState').textContent='Salvo';$('editorAutosaveState').className='saved';return}const seq=++power.autosaveSeq;$('editorAutosaveState').textContent='Salvando...';$('editorAutosaveState').className='saving';try{await powerJSON(`/api/jobs/${currentJob.id}/transcript`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({transcript:text})});if(seq!==power.autosaveSeq)return;currentJob.transcript=text;currentJob.word_count=(text.match(/\S+/g)||[]).length;$('editorAutosaveState').textContent='Salvo automaticamente';$('editorAutosaveState').className='saved'}catch(err){if(seq===power.autosaveSeq){$('editorAutosaveState').textContent='Falha ao salvar';$('editorAutosaveState').className='error'}}}
  $('transcriptEditor')?.addEventListener('input',()=>{editorCount();$('editorAutosaveState').textContent=power.preferences.autosave_transcript?'Alterações pendentes':'Salvamento manual';$('editorAutosaveState').className='';clearTimeout(power.autosaveTimer);if(power.preferences.autosave_transcript)power.autosaveTimer=setTimeout(autosaveEditor,1100)});
  $('editorUndoBtn')?.addEventListener('click',()=>{document.execCommand('undo');$('transcriptEditor').dispatchEvent(new Event('input'))});$('editorRedoBtn')?.addEventListener('click',()=>{document.execCommand('redo');$('transcriptEditor').dispatchEvent(new Event('input'))});
  const stableSetEditorText=setEditorText;setEditorText=function(text){stableSetEditorText(text);setTimeout(()=>{editorCount();$('editorAutosaveState').textContent='Salvo';$('editorAutosaveState').className='saved'},0)};

  // ---- Persistent internal project player (no extra desktop window) ----
  const musicStateKey=`redscribe_music_state_${body.dataset.userEmail||userName}`;
  function saveMusicState(){if(!power.preferences.remember_player||!musicTrack()||!projectMusicProject)return;const now=Date.now();if(now-power.musicSaveAt<1200)return;power.musicSaveAt=now;try{localStorage.setItem(musicStateKey,JSON.stringify({project_id:projectMusicProject.id,project_name:projectMusicProject.name,job_id:musicTrack().id,title:musicTrack().title,time:Number(projectMusicAudio.currentTime)||0,volume:Number(projectMusicAudio.volume)||.85,speed:Number(projectMusicAudio.playbackRate)||1,shuffle:projectMusicShuffle,repeat:projectMusicRepeat,updated_at:Date.now()}));renderContinueListening()}catch{}}
  function readMusicState(){try{return JSON.parse(localStorage.getItem(musicStateKey)||'null')}catch{return null}}
  function renderContinueListening(){const st=readMusicState(),box=$('homeContinueListening');if(!st||!st.project_id||!st.job_id){box.classList.add('hidden');return}const current=musicTrack();if(current&&projectMusicProject?.id===st.project_id&&current.id===st.job_id){box.classList.add('hidden');return}box.classList.remove('hidden');$('homeContinueTitle').textContent=st.title||'Áudio';$('homeContinueMeta').textContent=`${st.project_name||'Projeto'} · ${fmtTime(Number(st.time)||0)}`}
  $('homeContinueBtn')?.addEventListener('click',async()=>{const st=readMusicState();if(!st)return;projectMusicShuffle=!!st.shuffle;projectMusicRepeat=st.repeat||'off';projectMusicAudio.volume=Math.max(0,Math.min(1,Number(st.volume)||.85));$('musicVolume').value=String(projectMusicAudio.volume);await startProjectPlaylist(st.project_id,st.job_id);$('homeContinueListening')?.classList.add('hidden');projectMusicAudio.playbackRate=Number(st.speed)||1;$('musicSpeed').value=String(projectMusicAudio.playbackRate);const seek=()=>{if(Number.isFinite(projectMusicAudio.duration))projectMusicAudio.currentTime=Math.min(projectMusicAudio.duration,Number(st.time)||0)};if(projectMusicAudio.readyState>=1)seek();else projectMusicAudio.addEventListener('loadedmetadata',seek,{once:true})});$('homeForgetContinueBtn')?.addEventListener('click',()=>{localStorage.removeItem(musicStateKey);renderContinueListening()});
  $('musicSpeed')?.addEventListener('change',()=>{projectMusicAudio.playbackRate=Number($('musicSpeed').value)||1;saveMusicState()});projectMusicAudio.addEventListener('timeupdate',saveMusicState);projectMusicAudio.addEventListener('volumechange',saveMusicState);projectMusicAudio.addEventListener('ratechange',saveMusicState);projectMusicAudio.addEventListener('pause',saveMusicState);projectMusicAudio.addEventListener('ended',saveMusicState);

  // ---- Watch YouTube inside RedScribe ----
  let youtubeWatchCurrent=null;
  function youtubeEmbedUrl(videoId){const origin=encodeURIComponent(location.origin);return `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?autoplay=1&playsinline=1&rel=0&origin=${origin}`}
  async function openYoutubeWatch(item){
    if(!item?.id)return;youtubeWatchCurrent={...item};
    const modal=$('youtubeWatchModal'),frame=$('youtubeWatchFrame');
    $('youtubeWatchTitle').textContent=item.title||'Vídeo do YouTube';$('youtubeWatchChannel').textContent=item.channel||'YouTube';
    $('youtubeWatchExternal').href=item.url||`https://www.youtube.com/watch?v=${item.id}`;
    modal.classList.remove('hidden');frame.src=youtubeEmbedUrl(item.id);
    try{await powerJSON('/api/youtube/watch-event',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:item.id,url:item.url||'',title:item.title||'',channel:item.channel||'',query:youtubeSearchQuery||''})})}catch{}
  }
  function closeYoutubeWatch(){const modal=$('youtubeWatchModal'),frame=$('youtubeWatchFrame');modal?.classList.add('hidden');if(frame)frame.src='about:blank';youtubeWatchCurrent=null}
  $('youtubeWatchClose')?.addEventListener('click',closeYoutubeWatch);$('youtubeWatchModal')?.addEventListener('click',e=>{if(e.target===$('youtubeWatchModal'))closeYoutubeWatch()});
  $('youtubeWatchTranscribe')?.addEventListener('click',async()=>{if(!youtubeWatchCurrent)return;const b=$('youtubeWatchTranscribe');await startSearchVideo(youtubeWatchCurrent.url||`https://www.youtube.com/watch?v=${youtubeWatchCurrent.id}`,false,b);closeYoutubeWatch()});
  $('youtubeWatchQueue')?.addEventListener('click',async()=>{if(!youtubeWatchCurrent)return;const b=$('youtubeWatchQueue');await startSearchVideo(youtubeWatchCurrent.url||`https://www.youtube.com/watch?v=${youtubeWatchCurrent.id}`,true,b)});

  // ---- Local recommendation engine UI ----
  function recommendationCard(item){return `<article class="recommendation-card" data-rec-id="${escapeHtml(item.id)}"><div class="recommendation-thumb"><img src="${escapeHtml(item.thumbnail_url||'')}" alt="Miniatura de ${escapeHtml(item.title||'vídeo')}" loading="lazy" decoding="async" referrerpolicy="no-referrer"><span>${escapeHtml(item.duration_label||'')}</span></div><div class="recommendation-copy"><strong>${escapeHtml(item.title||'Vídeo do YouTube')}</strong><small>${escapeHtml(item.channel||'YouTube')}</small></div><div class="recommendation-actions"><button class="btn btn-primary btn-small watch-primary" data-rec-watch="${escapeHtml(item.id)}" type="button">▶ Assistir</button><button class="btn btn-secondary btn-small" data-rec-transcribe="${escapeHtml(item.url)}" type="button">Transcrever</button><button class="btn btn-secondary btn-small" data-rec-queue="${escapeHtml(item.url)}" type="button">＋ Fila</button><button class="recommendation-dismiss" data-rec-dismiss="${escapeHtml(item.id)}" type="button">Não tenho interesse</button></div></article>`}
  function bindRecommendationCards(items){const box=$('homeRecommendations');if(!box)return;const byId=new Map(items.map(x=>[x.id,x]));box.querySelectorAll('[data-rec-watch]').forEach(b=>b.addEventListener('click',()=>{const i=byId.get(b.dataset.recWatch);if(i)openYoutubeWatch(i)}));box.querySelectorAll('[data-rec-transcribe]').forEach(b=>b.addEventListener('click',()=>{switchView('new');setSourceTab('youtube-search');startSearchVideo(b.dataset.recTranscribe,false,b)}));box.querySelectorAll('[data-rec-queue]').forEach(b=>b.addEventListener('click',()=>startSearchVideo(b.dataset.recQueue,true,b)));box.querySelectorAll('[data-rec-dismiss]').forEach(b=>b.addEventListener('click',async()=>{try{await powerJSON('/api/recommendations/dismiss',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:b.dataset.recDismiss})});b.closest('.recommendation-card')?.remove();if(!$('homeRecommendations').children.length)loadRecommendations(true)}catch(err){toast(err.message)}}))}
  async function loadRecommendations(mode='cache'){
    const panel=$('homeRecommendationsPanel'),box=$('homeRecommendations'),reason=$('homeRecommendationsReason');
    if(!panel||!box)return;
    if(power.preferences.recommendations_enabled===false){panel.classList.add('hidden');return}
    panel.classList.remove('hidden');
    const force=mode==='refresh';
    if(force)box.innerHTML='<div class="empty-state">Atualizando recomendações locais...</div>';
    try{
      const d=await powerJSON(`/api/recommendations${force?'?refresh=1':'?cache_only=1'}`);
      const items=d.items||[];
      reason.classList.toggle('hidden',!d.reason);reason.textContent=d.reason||'';
      if(items.length){box.innerHTML=items.map(recommendationCard).join('');bindRecommendationCards(items)}
      else box.innerHTML='<div class="empty-state">As recomendações aparecem conforme você pesquisa e assiste vídeos no RedScribe.</div>';
    }catch(err){if(force)box.innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}
  }
  $('refreshRecommendationsBtn')?.addEventListener('click',()=>loadRecommendations('refresh'));

  // ---- Native F11 fullscreen ----
  async function toggleRedScribeFullscreen(){try{if(window.pywebview?.api?.toggle_fullscreen){await window.pywebview.api.toggle_fullscreen();return}}catch{}try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();else await document.exitFullscreen()}catch{}}
  document.addEventListener('keydown',e=>{if(e.key==='F11'){e.preventDefault();toggleRedScribeFullscreen()}if(e.key==='Escape'&&!$('youtubeWatchModal')?.classList.contains('hidden'))closeYoutubeWatch()});

  // ---- Power settings, recovery, diagnostics, updater ----
  async function loadPowerPreferences(){try{const d=await powerJSON('/api/power/preferences');power.preferences={...power.preferences,...d};$('autosaveTranscriptSetting').checked=d.autosave_transcript!==false;$('recoverInterruptedSetting').checked=d.recover_interrupted!==false;$('rememberPlayerSetting').checked=d.remember_player!==false;if($('recommendationsSetting'))$('recommendationsSetting').checked=d.recommendations_enabled!==false;renderContinueListening();if(power.preferences.recommendations_enabled!==false)loadRecommendations('cache');else $('homeRecommendationsPanel')?.classList.add('hidden')}catch{renderContinueListening()}}
  async function savePowerPreferences(){const payload={autosave_transcript:$('autosaveTranscriptSetting').checked,recover_interrupted:$('recoverInterruptedSetting').checked,remember_player:$('rememberPlayerSetting').checked,recommendations_enabled:$('recommendationsSetting')?$('recommendationsSetting').checked:true};try{await powerJSON('/api/power/preferences',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});power.preferences={...power.preferences,...payload};if(payload.recommendations_enabled===false)$('homeRecommendationsPanel')?.classList.add('hidden');else loadRecommendations('cache');toast('Preferências salvas')}catch(err){toast(err.message)}}
  ['autosaveTranscriptSetting','recoverInterruptedSetting','rememberPlayerSetting','recommendationsSetting'].forEach(id=>$(id)?.addEventListener('change',savePowerPreferences));
  let diagnosticsReport='';$('runDiagnosticsBtn')?.addEventListener('click',async()=>{const b=$('runDiagnosticsBtn');b.disabled=true;b.textContent='Verificando...';try{const d=await powerJSON('/api/diagnostics');diagnosticsReport=d.report||'';$('diagnosticsList').innerHTML=(d.checks||[]).map(x=>`<div class="diagnostic-row ${x.ok?'ok':'fail'}"><i>${x.ok?'✓':'!'}</i><strong>${escapeHtml(x.name)}</strong><span>${escapeHtml(x.detail)}</span></div>`).join('');$('copyDiagnosticsBtn').classList.remove('hidden')}catch(err){$('diagnosticsList').innerHTML=`<div class="empty-state">${escapeHtml(err.message)}</div>`}finally{b.disabled=false;b.textContent='Executar diagnóstico'}});$('copyDiagnosticsBtn')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(diagnosticsReport);toast('Relatório copiado')}catch{toast('Não foi possível copiar o relatório')}});
  $('checkAppUpdatePowerBtn')?.addEventListener('click',async()=>{const box=$('appUpdatePowerStatus'),b=$('checkAppUpdatePowerBtn');b.disabled=true;b.textContent='Verificando...';try{const d=await powerJSON('/api/app-update/check');if(d.available){box.className='smart-notice success';box.innerHTML=`<strong>RedScribe ${escapeHtml(d.latest)} disponível</strong><span>${escapeHtml(d.notes||'Nova versão disponível para download.')}</span>`;$('downloadAppUpdatePowerBtn').classList.remove('hidden')}else{box.className='smart-notice neutral';box.innerHTML=`<strong>Você está atualizado</strong><span>${escapeHtml(d.message||`Versão atual: ${d.current}`)}</span>`;$('downloadAppUpdatePowerBtn').classList.add('hidden')}}catch(err){box.className='smart-notice neutral';box.innerHTML=`<strong>Não foi possível verificar</strong><span>${escapeHtml(err.message)}</span>`}finally{b.disabled=false;b.textContent='Verificar atualização'}});$('downloadAppUpdatePowerBtn')?.addEventListener('click',async()=>{const b=$('downloadAppUpdatePowerBtn');b.disabled=true;b.textContent='Baixando...';try{const d=await powerJSON('/api/app-update/download',{method:'POST'});toast(`Atualização baixada em: ${d.saved_path}`,6500)}catch(err){toast(err.message,5200)}finally{b.disabled=false;b.textContent='Baixar atualização'}});

  // ---- Home dashboard extras ----
  function renderHomeProjects(){const box=$('homeRecentProjects');if(!box)return;const rows=[...projects].sort((a,b)=>Number(b.created_at||0)-Number(a.created_at||0)).slice(0,4);box.innerHTML=rows.length?rows.map(p=>`<button class="power-mini-item" data-home-project="${p.id}" type="button"><i class="power-mini-icon">▣</i><span><strong>${escapeHtml(p.name)}</strong><small>${p.count||0} trabalhos${p.audio_count?` · ${p.audio_count} áudios`:''}</small></span></button>`).join(''):'<div class="empty-state">Nenhum projeto ainda.</div>';box.querySelectorAll('[data-home-project]').forEach(b=>b.addEventListener('click',()=>{switchView('projects');setTimeout(()=>openProjectWorkspace(b.dataset.homeProject),30)}))}
  function renderHomeRecentSearches(items){const box=$('homeRecentSearches');if(!box)return;box.innerHTML=items.length?items.slice(0,5).map(x=>`<button class="power-mini-item" data-home-search="${escapeHtml(x.query)}" type="button"><i class="power-mini-icon">⌕</i><span><strong>${escapeHtml(x.query)}</strong><small>Pesquisar novamente no YouTube</small></span></button>`).join(''):'<div class="empty-state">Nenhuma pesquisa recente.</div>';box.querySelectorAll('[data-home-search]').forEach(b=>b.addEventListener('click',()=>{switchView('new');setSourceTab('youtube-search');$('youtubeSearchInput').value=b.dataset.homeSearch;searchYoutube(false,false)}))}
  function loadHomeQueuePreview(){try{const items=(homeHistoryItems||[]).filter(x=>['queued','processing'].includes(x.status)).slice(0,4),box=$('homeQueuePreview');box.innerHTML=items.length?items.map(x=>`<button class="power-mini-item" data-home-job="${x.id}" type="button"><i class="power-mini-icon">${x.progress||0}%</i><span><strong>${escapeHtml(x.title||'Processando')}</strong><small>${escapeHtml(x.stage||'Na fila')}</small></span></button>`).join(''):'<div class="empty-state">Fila vazia.</div>';box.querySelectorAll('[data-home-job]').forEach(b=>b.addEventListener('click',()=>openJob(b.dataset.homeJob)))}catch{}}
  async function loadPowerHome(){renderHomeProjects();loadRecentSearchChips();loadHomeQueuePreview();renderContinueListening();if(power.preferences.recommendations_enabled!==false)loadRecommendations('cache')}
  $('clearRecentSearchesHome')?.addEventListener('click',async()=>{await powerJSON('/api/youtube/search-history',{method:'DELETE'});loadRecentSearchChips();toast('Pesquisas recentes limpas')});
  const stableLoadHistory=loadHistory;loadHistory=async function(){const r=await stableLoadHistory();loadPowerHome();return r};

  // ---- Lightweight initialization: keep the stable 3.2.7 startup path fast. ----
  const stableSwitchViewPower=switchView;
  switchView=function(name){
    stableSwitchViewPower(name);
    if(name==='library')loadTagFilter();
    if(name==='new')loadRecentSearchChips();
    if(name==='ai')populateAIProjectContext();
    if(name==='home'&&power.preferences.recommendations_enabled!==false)loadRecommendations('cache');
    if(name==='queue'&&power.preferences.recover_interrupted!==false&&!power.recoveryChecked){power.recoveryChecked=true;setTimeout(async()=>{try{const r=await powerJSON('/api/recovery/check',{method:'POST'});if(r.restarted){toast(`${r.restarted} tarefa(s) interrompida(s) retomada(s)`,3800);loadQueue()}}catch{}},350)}
  };
  renderContinueListening();
  // Preferences are intentionally deferred. requestIdleCallback may fire while
  // WebView2 is still painting its first frame on Windows, so use a fixed small
  // delay and keep every heavy task out of this startup path.
  setTimeout(()=>loadPowerPreferences(),1400);
})();
