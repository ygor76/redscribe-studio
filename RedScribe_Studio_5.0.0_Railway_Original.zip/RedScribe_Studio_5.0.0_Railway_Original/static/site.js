(() => {
  const root = document.documentElement;
  const saved = localStorage.getItem('redscribe_theme');
  const preferred = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  const theme = saved || preferred;
  root.dataset.theme = theme;

  function setTheme(value) {
    const next = value === 'dark' ? 'dark' : 'light';
    root.dataset.theme = next;
    localStorage.setItem('redscribe_theme', next);
    document.querySelectorAll('[data-set-theme]').forEach(btn => btn.classList.toggle('selected', btn.dataset.setTheme === next));
  }

  document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
    btn.addEventListener('click', () => setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'));
  });
  document.querySelectorAll('[data-set-theme]').forEach(btn => btn.addEventListener('click', () => setTheme(btn.dataset.setTheme)));
  setTheme(theme);
})();
