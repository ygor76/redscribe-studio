# RedScribe v3.5.9 — Hard No Black Bars

- Corrigido um erro silencioso do pós-processamento: margens ímpares podiam gerar altura ímpar e fazer o FFmpeg rejeitar o recorte, entregando o Short antigo com barras.
- Corrigido o regex do fallback `cropdetect` do FFmpeg.
- A remoção final não depende mais do OpenCV: OpenCV e FFmpeg trabalham em paralelo e as margens detectadas são unidas.
- Crop final normalizado para dimensões pares, compatível com H.264/YUV420.
- Áudio é reencodado em AAC durante a limpeza final para evitar falhas de cópia de stream.
- Até quatro passes de validação.
- Nenhum `pad`, overlay ou fundo artificial é usado no modo Preenchimento total.
