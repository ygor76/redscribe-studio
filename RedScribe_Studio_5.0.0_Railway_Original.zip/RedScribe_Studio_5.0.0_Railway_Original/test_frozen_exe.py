from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        print("Uso: test_frozen_exe.py <caminho-do-RedScribe.exe>", file=sys.stderr)
        return 10

    exe = Path(sys.argv[1]).expanduser().resolve()
    if not exe.is_file():
        print(f"ERRO: executavel nao encontrado: {exe}", file=sys.stderr)
        return 11

    selftest_log = Path(tempfile.gettempdir()) / "RedScribe_selftest.log"
    try:
        selftest_log.unlink(missing_ok=True)
    except Exception:
        pass

    print(f"Executavel final: {exe}")
    print(f"Diretorio de trabalho: {exe.parent}")

    env = os.environ.copy()
    try:
        completed = subprocess.run(
            [str(exe), "--self-test"],
            cwd=str(exe.parent),
            env=env,
            timeout=180,
            check=False,
        )
    except subprocess.TimeoutExpired:
        print("ERRO: o autoteste do RedScribe excedeu 180 segundos.", file=sys.stderr)
        return 12
    except OSError as exc:
        print(f"ERRO ao iniciar o executavel final: {exc}", file=sys.stderr)
        return 13

    print(f"Codigo de saida do RedScribe.exe: {completed.returncode}")
    if completed.returncode != 0:
        detail = ""
        if selftest_log.is_file():
            try:
                detail = selftest_log.read_text(encoding="utf-8", errors="replace").strip()
            except Exception:
                detail = ""
        if detail:
            print("--- RedScribe_selftest.log ---", file=sys.stderr)
            print(detail, file=sys.stderr)
            print("--- fim do selftest ---", file=sys.stderr)
        else:
            print("O executavel retornou erro e nao gerou RedScribe_selftest.log.", file=sys.stderr)
        return 14

    if not selftest_log.is_file():
        print("ERRO: o processo terminou com codigo 0, mas o log de autoteste nao foi criado.", file=sys.stderr)
        return 15

    content = selftest_log.read_text(encoding="utf-8", errors="replace").strip()
    if content != "OK":
        print(f"ERRO: resultado inesperado do autoteste: {content!r}", file=sys.stderr)
        return 16

    print("Autoteste do RedScribe.exe: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
