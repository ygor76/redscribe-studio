# RedScribe 4.0.0 — Aurora Reconstruction

## Experiência e identidade

A interface recebeu uma camada visual unificada com superfícies em camadas, hierarquia de navegação por intenção, estados vazios mais claros, foco acessível, microinterações discretas e suporte consistente aos temas claro e escuro. A landing, o cadastro e o dashboard agora compartilham a mesma direção de produto.

A sidebar foi reorganizada visualmente em Workspace, Criar, Produzir, Organizar e Sistema. Nenhuma ferramenta foi removida e os seletores existentes continuam compatíveis com os scripts da aplicação.

## Shorts Studio

O painel de montagem agora prioriza os controles essenciais e agrupa Auto Reframe, composição e movimento em um bloco de controles profissionais expansível. A área de resultados mantém a renderização incremental e recebe uma hierarquia visual mais forte para prévias, ações e estados de processamento.

O polling do frontend tornou-se adaptativo. Ele consulta mais rapidamente quando um output novo chega e reduz a frequência durante etapas longas, diminuindo chamadas desnecessárias sem atrasar a liberação dos clipes.

## Desempenho de geração

A preparação da fonte continua reutilizando vídeo e transcrição existentes na Biblioteca. A etapa de renderização passou a usar um conjunto limitado de workers dentro da tarefa, com até três processos concorrentes conforme a capacidade disponível. Cada Short é persistido assim que termina e aparece no frontend sem aguardar a conclusão do lote inteiro.

O Auto Reframe continua opcional e só é executado quando solicitado. O semáforo global permanece protegendo a etapa de preparação para evitar concorrência descontrolada entre tarefas independentes.

## Compatibilidade

A versão do núcleo, builder, metadados do executável e instalador foi atualizada para 4.0.0. As rotas existentes, o armazenamento local, a Biblioteca, o Estúdio, a IA, a fila e os scripts Windows foram preservados.
