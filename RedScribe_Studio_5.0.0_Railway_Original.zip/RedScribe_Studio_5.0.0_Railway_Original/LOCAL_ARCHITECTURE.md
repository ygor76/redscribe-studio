# Arquitetura do RedScribe Desktop Autônomo

O RedScribe Desktop executa um servidor local de interface no próprio computador e o abre em uma janela nativa do Windows. A aplicação não depende de uma publicação externa para apresentar a landing page, permitir cadastro, login ou acessar a biblioteca.

| Camada | Responsabilidade | Persistência |
|---|---|---|
| Janela nativa | Inicia uma única instância e abre a experiência do produto | Não armazena conteúdo do usuário |
| Aplicação local | Landing, cadastro, login, dashboard, busca, fila, editor e biblioteca | Sessão protegida por segredo local |
| Dados de usuários | Contas com senhas protegidas por hash e perfis separados | `%LOCALAPPDATA%\RedScribe\data\accounts.json` |
| Dados criativos | Tarefas, transcrições, mídia, Shorts e projetos por usuário | `%LOCALAPPDATA%\RedScribe\data\users\` e `%LOCALAPPDATA%\RedScribe\data\shorts_library\` |
| Ferramentas de mídia | Busca, download, transcrição e renderização | Empacotadas junto ao instalador quando aplicável |

O primeiro cadastro cria uma conta local. Os próximos acessos são feitos pela mesma tela de login. A estrutura de plano, limites e período de teste continuará interna ao aplicativo para uma futura ativação comercial; ela não restringirá esta versão.
