$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# RedScribe Studio 5.0.0: aplicativo autônomo com instalador nativo.
$builderVersion = "5.0.0 AUTONOMOUS SHORTS STUDIO"
$transcriptStarted = $false
$diagPath = Join-Path $PSScriptRoot "diagnostico_build.txt"
$buildTools = Join-Path $PSScriptRoot "build_tools"
New-Item -ItemType Directory -Force -Path $buildTools | Out-Null

function Log-Diag([string]$Text) {
    Add-Content -Path $diagPath -Value $Text -Encoding UTF8
}

function Format-GB([double]$Bytes) { return [math]::Round($Bytes / 1GB, 2) }

function Test-Command([string]$Name) {
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Download-File([string[]]$Urls, [string]$Destination, [long]$MinBytes = 1024, [int]$Retries = 4) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
    $lastError = $null
    foreach ($Url in $Urls) {
        for ($attempt = 1; $attempt -le $Retries; $attempt++) {
            Remove-Item $Destination -Force -ErrorAction SilentlyContinue
            Write-Host "Baixando ($attempt/$Retries): $Url" -ForegroundColor DarkGray
            try {
                try {
                    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination -TimeoutSec 120
                } catch {
                    if (Test-Command "curl.exe") {
                        & curl.exe -L --fail --retry 3 --retry-delay 2 --connect-timeout 20 -o $Destination $Url
                        if ($LASTEXITCODE -ne 0) { throw "curl retornou $LASTEXITCODE" }
                    } elseif (Test-Command "Start-BitsTransfer") {
                        Start-BitsTransfer -Source $Url -Destination $Destination -ErrorAction Stop
                    } else {
                        throw
                    }
                }
                if (!(Test-Path $Destination)) { throw "O download nao criou o arquivo." }
                if ((Get-Item $Destination).Length -lt $MinBytes) { throw "Arquivo baixado menor que o esperado." }
                return
            } catch {
                $lastError = $_.Exception.Message
                Start-Sleep -Seconds ([math]::Min(2 * $attempt, 8))
            }
        }
    }
    throw "Falha ao baixar $Destination. Ultimo erro: $lastError"
}

function Test-UvExe([string]$ExePath) {
    if ([string]::IsNullOrWhiteSpace($ExePath) -or !(Test-Path $ExePath)) { return $false }
    try { & $ExePath --version *> $null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}

function Ensure-Uv {
    $uvVersion = "0.12.4"
    $uvRoot = Join-Path $buildTools "uv-$uvVersion"
    $uvExe = Join-Path $uvRoot "uv.exe"
    if (Test-UvExe $uvExe) {
        Write-Host "uv portatil: OK" -ForegroundColor Green
        return $uvExe
    }
    $uvZip = Join-Path $buildTools "uv-$uvVersion-windows-x64.zip"
    Download-File @(
        "https://releases.astral.sh/github/uv/releases/download/$uvVersion/uv-x86_64-pc-windows-msvc.zip",
        "https://github.com/astral-sh/uv/releases/download/$uvVersion/uv-x86_64-pc-windows-msvc.zip"
    ) $uvZip 10MB
    Remove-Item -Recurse -Force $uvRoot -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $uvRoot | Out-Null
    Expand-Archive -Path $uvZip -DestinationPath $uvRoot -Force
    $found = Get-ChildItem $uvRoot -Recurse -Filter "uv.exe" -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if (!$found) { throw "uv.exe nao foi encontrado depois da extracao." }
    if ($found.FullName -ne $uvExe) { Copy-Item $found.FullName $uvExe -Force }
    if (!(Test-UvExe $uvExe)) { throw "uv.exe foi baixado, mas nao executa neste Windows." }
    Write-Host "uv portatil preparado: OK" -ForegroundColor Green
    return $uvExe
}

function Find-InnoSetup {
    $roots = @(
        (Join-Path $buildTools "InnoSetup7"),
        (Join-Path $buildTools "InnoSetup7-default"),
        "$env:LOCALAPPDATA\Programs\Inno Setup 7",
        "$env:ProgramFiles\Inno Setup 7",
        "${env:ProgramFiles(x86)}\Inno Setup 7",
        "$env:LOCALAPPDATA\Programs\Inno Setup 6",
        "$env:ProgramFiles\Inno Setup 6",
        "${env:ProgramFiles(x86)}\Inno Setup 6"
    )
    foreach ($root in $roots) {
        if ([string]::IsNullOrWhiteSpace($root)) { continue }
        try {
            $direct = Join-Path $root "ISCC.exe"
            if (Test-Path $direct) { return (Resolve-Path $direct).Path }
            if (Test-Path $root) {
                $found = Get-ChildItem $root -Recurse -Filter "ISCC.exe" -File -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($found) { return $found.FullName }
            }
        } catch {}
    }
    return $null
}

function Invoke-ExeAndWait([string]$FilePath, [string[]]$Arguments, [string]$WorkingDirectory = "") {
    if (!(Test-Path $FilePath)) { throw "Executavel nao encontrado: $FilePath" }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $quoted = foreach ($arg in $Arguments) {
        if ($null -eq $arg) { '""' }
        elseif ($arg -match '[\s"]') { '"' + ($arg -replace '"','\"') + '"' }
        else { $arg }
    }
    $psi.Arguments = ($quoted -join ' ')
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    if (![string]::IsNullOrWhiteSpace($WorkingDirectory)) { $psi.WorkingDirectory = $WorkingDirectory }
    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    if (!$proc.Start()) { throw "Nao foi possivel iniciar: $FilePath" }
    $proc.WaitForExit()
    return $proc.ExitCode
}

function Wait-FindInnoSetup([int]$Seconds = 20) {
    $deadline = (Get-Date).AddSeconds($Seconds)
    do {
        $found = Find-InnoSetup
        if ($found) { return $found }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $deadline)
    return $null
}

function Ensure-InnoSetup {
    $existing = Find-InnoSetup
    if ($existing) { Write-Host "Inno Setup: OK ($existing)" -ForegroundColor Green; Log-Diag "Inno Setup: $existing"; return $existing }

    # Nao depende de winget. Usa o modo PORTABLE oficial do proprio instalador do Inno Setup.
    # O processo GUI e aguardado explicitamente; chamar apenas com '&' podia devolver o controle cedo demais.
    $innoRoot = Join-Path $buildTools "InnoSetup7"
    $installer = Join-Path $buildTools "innosetup-7.1.0-x64.exe"
    $innoInstallLog = Join-Path $buildTools "inno_setup_install.log"
    Write-Host "Inno Setup nao encontrado. Preparando compilador local/portatil..." -ForegroundColor Yellow
    Download-File @(
        "https://github.com/jrsoftware/issrc/releases/download/is-7_1_0/innosetup-7.1.0-x64.exe"
    ) $installer 5MB
    try {
        $sig = Get-AuthenticodeSignature -FilePath $installer
        Write-Host "Assinatura Inno Setup: $($sig.Status)" -ForegroundColor DarkGray
        Log-Diag "Assinatura Inno Setup: $($sig.Status)"
    } catch {}

    Remove-Item -Recurse -Force $innoRoot -ErrorAction SilentlyContinue
    Remove-Item $innoInstallLog -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $innoRoot | Out-Null

    $portableArgs = @(
        '/PORTABLE=1',
        '/VERYSILENT',
        '/SUPPRESSMSGBOXES',
        '/NORESTART',
        '/SP-',
        '/CURRENTUSER',
        ("/DIR={0}" -f $innoRoot),
        ("/LOG={0}" -f $innoInstallLog)
    )
    $code = Invoke-ExeAndWait $installer $portableArgs $buildTools
    Log-Diag "Inno portable exit code: $code"
    $found = Wait-FindInnoSetup 15

    # Fallback: se alguma versao do instalador ignorar PORTABLE/DIR, instala no local padrao do usuario.
    if (!$found) {
        Write-Host "A copia portatil nao apareceu no caminho esperado. Tentando instalacao silenciosa no perfil do usuario..." -ForegroundColor Yellow
        $fallbackLog = Join-Path $buildTools "inno_setup_fallback.log"
        Remove-Item $fallbackLog -Force -ErrorAction SilentlyContinue
        $fallbackArgs = @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/SP-','/CURRENTUSER',("/LOG={0}" -f $fallbackLog))
        $fallbackCode = Invoke-ExeAndWait $installer $fallbackArgs $buildTools
        Log-Diag "Inno fallback exit code: $fallbackCode"
        $found = Wait-FindInnoSetup 20
    }

    # Ultimo fallback opcional. ZERO-SETUP nao depende do winget, mas pode usa-lo se ja existir.
    if (!$found -and (Test-Command "winget.exe")) {
        Write-Host "Tentando winget apenas como ultimo fallback..." -ForegroundColor Yellow
        & winget.exe install --id JRSoftware.InnoSetup.7 -e -s winget --silent --accept-package-agreements --accept-source-agreements
        $found = Wait-FindInnoSetup 20
    }

    if (!$found) {
        $extra = ""
        foreach ($lp in @($innoInstallLog,(Join-Path $buildTools 'inno_setup_fallback.log'))) {
            if (Test-Path $lp) {
                try {
                    $tail = (Get-Content $lp -Tail 20 -ErrorAction SilentlyContinue) -join " | "
                    if ($tail) { Log-Diag "Inno log ($lp): $tail"; $extra = " Consulte: $lp" }
                } catch {}
            }
        }
        throw "Inno Setup foi baixado, mas ISCC.exe nao foi localizado apos a instalacao sincronizada.$extra"
    }
    Write-Host "Inno Setup preparado: OK ($found)" -ForegroundColor Green
    Log-Diag "Inno Setup preparado: $found"
    return $found
}

function Test-Internet {
    $targets = @(
        "https://pypi.org/pypi/pip/json",
        "https://github.com",
        "https://huggingface.co"
    )
    $ok = 0
    foreach ($u in $targets) {
        try {
            $r = Invoke-WebRequest -UseBasicParsing -Uri $u -Method Head -TimeoutSec 12
            if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { $ok++ }
        } catch {
            # HEAD pode ser bloqueado por alguns proxies; curl apenas testa conexao.
            if (Test-Command "curl.exe") {
                & curl.exe -I -L --silent --max-time 12 $u *> $null
                if ($LASTEXITCODE -eq 0) { $ok++ }
            }
        }
    }
    return ($ok -ge 2)
}

function Test-WriteAccess([string]$Folder) {
    $p = Join-Path $Folder (".write-test-" + [guid]::NewGuid().ToString('N') + ".tmp")
    try { Set-Content -Path $p -Value "ok" -Encoding ASCII; Remove-Item $p -Force; return $true } catch { return $false }
}

function Invoke-Uv([string[]]$UvArgs, [string]$FailureMessage) {
    Write-Host ("uv " + ($UvArgs -join " ")) -ForegroundColor DarkGray
    & $script:uvExe @UvArgs
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw "$FailureMessage (codigo de saida $code)." }
}

try {
    try { Start-Transcript -Path (Join-Path $PSScriptRoot "build_log.txt") -Force | Out-Null; $transcriptStarted = $true } catch {}
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

    Write-Host "============================================" -ForegroundColor Red
    Write-Host " RedScribe Studio - Builder" -ForegroundColor White
    Write-Host " App: 5.0.0 | Builder: $builderVersion" -ForegroundColor DarkGray
    Write-Host "============================================" -ForegroundColor Red

    Remove-Item $diagPath -Force -ErrorAction SilentlyContinue
    Log-Diag "RedScribe Builder $builderVersion"
    Log-Diag "Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

    Write-Host "[0/11] Analisando este computador..." -ForegroundColor Cyan
    $os = Get-CimInstance Win32_OperatingSystem
    $is64 = [Environment]::Is64BitOperatingSystem
    $psVersion = $PSVersionTable.PSVersion.ToString()
    $driveRoot = [System.IO.Path]::GetPathRoot($PSScriptRoot)
    $driveName = $driveRoot.TrimEnd('\').TrimEnd(':')
    $drive = Get-PSDrive -Name $driveName -ErrorAction SilentlyContinue
    $freeGB = if ($drive) { Format-GB $drive.Free } else { 0 }
    $systemPython = $null
    foreach ($cmd in @('py.exe','python.exe','python3.exe')) {
        $c = Get-Command $cmd -ErrorAction SilentlyContinue
        if ($c) { $systemPython = $c.Source; break }
    }

    Log-Diag "Windows: $($os.Caption) $($os.Version) build $($os.BuildNumber)"
    Log-Diag "Arquitetura 64-bit: $is64"
    Log-Diag "PowerShell: $psVersion"
    Log-Diag "Pasta do builder: $PSScriptRoot"
    Log-Diag "Espaco livre: $freeGB GB"
    Log-Diag "Python do sistema: $(if($systemPython){$systemPython}else{'nao instalado (OK; o builder usa Python proprio)'})"
    Log-Diag "winget: $(if(Test-Command 'winget.exe'){'presente'}else{'ausente (nao obrigatorio)'})"
    Log-Diag "curl: $(if(Test-Command 'curl.exe'){'presente'}else{'ausente (fallback via PowerShell/BITS)'})"

    if (!$is64) { throw "Este builder requer Windows 64 bits." }
    if ([version]$os.Version -lt [version]'10.0') { throw "Use Windows 10 ou Windows 11 64 bits." }
    if ($PSVersionTable.PSVersion.Major -lt 5) { throw "PowerShell 5.1 ou superior e necessario." }
    if (!(Test-WriteAccess $PSScriptRoot)) { throw "O builder nao consegue gravar nesta pasta. Extraia o ZIP para uma pasta do usuario e tente novamente." }
    if ($drive -and $drive.Free -lt 6GB) { throw "Espaco insuficiente. Deixe pelo menos 6 GB livres no disco do builder." }
    if ($drive -and $drive.Free -lt 10GB) { Write-Host "Aviso: ha menos de 10 GB livres. O build pode consumir varios GB temporariamente." -ForegroundColor Yellow }
    if (!(Test-Internet)) { throw "A conexao com os servidores necessarios nao esta disponivel. Verifique internet, proxy/firewall e tente novamente." }
    Write-Host "Windows/arquitetura/escrita/internet: OK" -ForegroundColor Green
    if ($systemPython) { Write-Host "Python do Windows detectado, mas NAO sera usado. O builder usa CPython 3.12 isolado." -ForegroundColor DarkGray }
    else { Write-Host "Python nao instalado: OK. O builder vai baixar CPython 3.12 automaticamente." -ForegroundColor Green }

    $script:uvExe = Ensure-Uv
    $managedPythonDir = Join-Path $PSScriptRoot ".uv-python"
    $uvCache = Join-Path $buildTools "uv-cache"
    New-Item -ItemType Directory -Force -Path $managedPythonDir, $uvCache | Out-Null
    foreach ($name in @('UV_PYTHON_PREFERENCE','UV_MANAGED_PYTHON','UV_NO_MANAGED_PYTHON','UV_PYTHON','UV_PYTHON_BIN_DIR','UV_PYTHON_NO_REGISTRY','UV_PYTHON_INSTALL_REGISTRY','VIRTUAL_ENV')) { Remove-Item ("Env:" + $name) -ErrorAction SilentlyContinue }
    $env:UV_PYTHON_INSTALL_DIR = $managedPythonDir
    $env:UV_CACHE_DIR = $uvCache
    Remove-Item -Recurse -Force ".buildenv", ".python-test", ".venv" -ErrorAction SilentlyContinue

    Write-Host "[1/11] Preparando Python 3.12 x64 gerenciado..."
    Invoke-Uv @('python','install','3.12') "Nao foi possivel baixar/preparar Python 3.12"

    $runtimeCheck = Join-Path $PSScriptRoot "build_runtime_check.py"
    $pyinstallerBuild = Join-Path $PSScriptRoot "build_pyinstaller.py"
    $req = Join-Path $PSScriptRoot "requirements-build.txt"
    $prepareTools = Join-Path $PSScriptRoot "preparar_tools.py"
    $prepareModel = Join-Path $PSScriptRoot "preparar_modelo.py"
    $testFrozenExe = Join-Path $PSScriptRoot "test_frozen_exe.py"
    foreach ($required in @($runtimeCheck,$pyinstallerBuild,$req,$prepareTools,$prepareModel,$testFrozenExe)) { if (!(Test-Path $required)) { throw "Arquivo necessario nao encontrado: $required" } }

    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12',$runtimeCheck,'runtime') "Python 3.12 x64 nao passou na validacao"
    Write-Host "Python 3.12 x64: OK" -ForegroundColor Green

    Write-Host "[2/11] Preparando Inno Setup automaticamente..."
    $iscc = Ensure-InnoSetup

    Write-Host "[3/11] Preparando dependencias Python do build..."
    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12','--with-requirements',$req,$runtimeCheck,'deps') "Falha ao preparar/validar dependencias Python"
    Write-Host "Dependencias Python: OK" -ForegroundColor Green

    Write-Host "[4/11] Preparando FFmpeg, Deno e motor oficial do YouTube..."
    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12','--with-requirements',$req,$prepareTools) "Falha ao preparar FFmpeg/Deno/yt-dlp.exe"
    foreach ($toolName in @('ffmpeg.exe','deno.exe','yt-dlp.exe')) {
        $toolPath = Join-Path $PSScriptRoot ("tools\" + $toolName)
        if (!(Test-Path $toolPath)) { throw "Ferramenta obrigatoria ausente depois da preparacao: $toolName" }
        Log-Diag "Ferramenta: $toolName = $toolPath"
    }
    Write-Host "Motor do YouTube: OK" -ForegroundColor Green

    Write-Host "[5/11] Preparando Whisper Small..."
    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12','--with-requirements',$req,$prepareModel) "Falha ao preparar modelo Whisper"

    Write-Host "[6/11] Preparando runtimes para PC formatado..."
    $wv2 = Join-Path $buildTools "MicrosoftEdgeWebview2Setup.exe"
    if (!(Test-Path $wv2) -or ((Get-Item $wv2).Length -lt 1MB)) { Download-File @('https://go.microsoft.com/fwlink/p/?LinkId=2124703') $wv2 1MB }
    $vcRedist = Join-Path $buildTools "vc_redist.x64.exe"
    if (!(Test-Path $vcRedist) -or ((Get-Item $vcRedist).Length -lt 10MB)) { Download-File @('https://aka.ms/vc14/vc_redist.x64.exe') $vcRedist 10MB }
    Write-Host "WebView2 + Visual C++ Runtime: OK" -ForegroundColor Green

    Write-Host "[7/11] Gerando RedScribe.exe com PyInstaller..."
    Remove-Item -Recurse -Force ".pyinstaller-work", "dist", "build" -ErrorAction SilentlyContinue
    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12','--with-requirements',$req,$pyinstallerBuild) "PyInstaller retornou erro"

    $desktopExe = Join-Path $PSScriptRoot "dist\RedScribe\RedScribe.exe"
    if (!(Test-Path $desktopExe)) { throw "RedScribe.exe nao foi gerado." }
    $pythonDll = Get-ChildItem (Join-Path $PSScriptRoot "dist\RedScribe") -Recurse -Filter "python312.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (!$pythonDll) { throw "python312.dll nao esta no pacote final." }
    Write-Host "Runtime Python embutido no app: OK" -ForegroundColor Green

    Write-Host "[8/11] Autoteste do executavel final..."
    Invoke-Uv @('run','--no-project','--managed-python','--python','3.12',$testFrozenExe,$desktopExe) "RedScribe.exe falhou no autoteste"
    Write-Host "Autoteste: OK" -ForegroundColor Green
    Remove-Item -Recurse -Force ".pyinstaller-work", "build" -ErrorAction SilentlyContinue

    Write-Host "[9/11] Validando arquivos que entrarao no instalador..."
    foreach ($p in @($desktopExe,$wv2,$vcRedist,(Join-Path $PSScriptRoot 'installer\RedScribeSetup.iss'))) {
        if (!(Test-Path $p)) { throw "Arquivo do instalador ausente: $p" }
    }
    Write-Host "Pacote do instalador: OK" -ForegroundColor Green

    Write-Host "[10/11] Limpando saida anterior..."
    Remove-Item -Recurse -Force ".\installer_output" -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path ".\installer_output" | Out-Null

    Write-Host "[11/11] Criando instalador final..."
    & $iscc ".\installer\RedScribeSetup.iss"
    if ($LASTEXITCODE -ne 0) { throw "Inno Setup retornou erro durante a compilacao." }
    $setup = Get-ChildItem ".\installer_output\RedScribe_Studio_Setup_*.exe" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (!$setup) { throw "O instalador final nao foi encontrado." }

    Log-Diag "RESULTADO: SUCESSO"
    Log-Diag "Instalador: $($setup.FullName)"
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Green
    Write-Host " PRONTO - PC PREPARADO E INSTALADOR GERADO" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host "Instalador: $($setup.FullName)" -ForegroundColor Cyan
    Write-Host "Diagnostico: $diagPath" -ForegroundColor DarkGray
    Write-Host "Log: $(Join-Path $PSScriptRoot 'build_log.txt')" -ForegroundColor DarkGray
    exit 0
}
catch {
    Log-Diag "RESULTADO: ERRO"
    Log-Diag "Mensagem: $($_.Exception.Message)"
    Log-Diag "Detalhe: $($_ | Out-String)"
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Red
    Write-Host " BUILD INTERROMPIDO" -ForegroundColor Red
    Write-Host "============================================" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Envie build_log.txt + diagnostico_build.txt se precisar diagnosticar." -ForegroundColor Yellow
    Write-Host "Dica: execute COMPILAR_INSTALADOR.cmd para a janela permanecer aberta e o diagnostico abrir automaticamente." -ForegroundColor Yellow
    exit 1
}
finally {
    if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch {} }
}
