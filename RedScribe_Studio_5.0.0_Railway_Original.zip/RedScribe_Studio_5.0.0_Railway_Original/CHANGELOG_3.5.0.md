# RedScribe v3.5.9

## Correção definitiva — Preenchimento total + Seguir pessoa

- Base visual do modo **Preenchimento total · 9:16 sem faixas pretas** mantida igual à v3.4.7.
- **Enquadramento Inteligente · seguir pessoa** agora só altera a posição horizontal do crop; não usa overlay, fundo, pad ou fit/decrease.
- **Composição Inteligente** continua separada e é a única opção autorizada a abrir/adaptar uma cena.
- Flags booleanas agora são interpretadas de forma estrita para impedir que `false` seja tratado como ativo.
- Inicialização em navegador escolhe uma porta livre, evitando que uma versão antiga já aberta na porta 5050 seja usada sem perceber.
- A interface mostra **RedScribe v3.5.9** no cartão lateral para confirmar qual versão está em execução.
