from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import uuid
from collections import Counter
from pathlib import Path
from typing import Any

from flask import jsonify, request, send_file

_SHORTS_LOCK = threading.RLock()
# Um worker global continua protegendo o download/transcrição, enquanto a etapa
# de renderização usa concorrência limitada dentro da própria tarefa.
_SHORTS_PROCESSING = threading.Semaphore(1)
_SHORTS_MAX_TASKS = 120
_SHORTS_RENDER_WORKERS = max(1, min(2, int(os.environ.get("REDSCRIBE_SHORTS_RENDER_WORKERS", "1"))))
_FFMPEG_ENCODERS: dict[str, set[str]] = {}
_FFMPEG_ENCODERS_LOCK = threading.Lock()

_RENDER_PROFILES: dict[str, dict[str, Any]] = {
    "fast": {"label": "Rápido", "preset": "superfast", "crf": "23", "workers": 1, "threads": 2},
    "balanced": {"label": "Equilibrado", "preset": "veryfast", "crf": "20", "workers": 1, "threads": 2},
    "quality": {"label": "Qualidade alta", "preset": "faster", "crf": "18", "workers": 1, "threads": 2},
}


def _render_profile(value: str | None) -> tuple[str, dict[str, Any]]:
    key = str(value or "fast").strip().lower()
    return key if key in _RENDER_PROFILES else "fast", _RENDER_PROFILES.get(key, _RENDER_PROFILES["fast"])


def _available_ffmpeg_encoders(ffmpeg: str) -> set[str]:
    with _FFMPEG_ENCODERS_LOCK:
        cached = _FFMPEG_ENCODERS.get(ffmpeg)
        if cached is not None:
            return cached
        try:
            result = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=20, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            names = set(re.findall(r"\b(h264_(?:amf|nvenc|qsv)|libx264)\b", result.stdout or ""))
        except Exception:
            names = {"libx264"}
        names.add("libx264")
        _FFMPEG_ENCODERS[ffmpeg] = names
        return names


def _encoder_attempts(ffmpeg: str, profile_key: str, quality: str) -> list[tuple[str, list[str]]]:
    """Prefere GPU sem depender de fabricante; software é o fallback garantido."""
    _, profile = _render_profile(profile_key)
    names = _available_ffmpeg_encoders(ffmpeg)
    attempts: list[tuple[str, list[str]]] = []
    if quality != "2160" and "h264_amf" in names:
        attempts.append(("AMD AMF", ["-c:v", "h264_amf", "-quality", "speed", "-rc", "cqp", "-qp_i", "22", "-qp_p", "24", "-qp_b", "26"]))
    if quality != "2160" and "h264_nvenc" in names:
        attempts.append(("NVIDIA NVENC", ["-c:v", "h264_nvenc", "-preset", "p1", "-cq", "23", "-b:v", "0"]))
    if quality != "2160" and "h264_qsv" in names:
        attempts.append(("Intel Quick Sync", ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "23"]))
    crf = "18" if quality == "2160" else str(profile["crf"])
    attempts.append(("CPU otimizada", ["-c:v", "libx264", "-preset", str(profile["preset"]), "-crf", crf, "-threads", str(profile["threads"])]))
    return attempts


def _render_worker_count(profile_key: str, quality: str, total: int) -> int:
    _, profile = _render_profile(profile_key)
    if str(quality) == "2160":
        return 1
    return max(1, min(_SHORTS_RENDER_WORKERS, int(profile["workers"]), max(1, int(total))))

_FORMAT_PRESETS: dict[str, dict[str, Any]] = {
    "vertical": {"label": "Vertical 9:16", "ratio": (9, 16), "sizes": {"720": (720, 1280), "1080": (1080, 1920), "2160": (2160, 3840)}},
    "square": {"label": "Quadrado 1:1", "ratio": (1, 1), "sizes": {"720": (720, 720), "1080": (1080, 1080), "2160": (2160, 2160)}},
    "portrait": {"label": "Retrato 4:5", "ratio": (4, 5), "sizes": {"720": (720, 900), "1080": (1080, 1350), "2160": (2160, 2700)}},
    "landscape": {"label": "Horizontal 16:9", "ratio": (16, 9), "sizes": {"720": (1280, 720), "1080": (1920, 1080), "2160": (3840, 2160)}},
}


def _output_dimensions(output_format: str, quality: str) -> tuple[int, int]:
    preset = _FORMAT_PRESETS.get(str(output_format or "vertical"), _FORMAT_PRESETS["vertical"])
    return tuple(preset["sizes"].get(str(quality or "1080"), preset["sizes"]["1080"]))


def _source_video_height(source: Path) -> int:
    try:
        import cv2  # type: ignore
        cap = cv2.VideoCapture(str(source))
        try:
            if cap.isOpened():
                return max(0, int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0))
        finally:
            cap.release()
    except Exception:
        return 0
    return 0


def _effective_render_quality(source: Path, requested: str) -> tuple[str, int]:
    """Evita ampliação artificial: 4K só permanece quando a fonte é 4K."""
    requested = str(requested or "1080")
    source_height = _source_video_height(source)
    if requested != "2160" or source_height >= 2160:
        return requested, source_height
    if source_height >= 1080:
        return "1080", source_height
    return "720", source_height


def _flag(value: Any) -> bool:
    """Parseia flags do JSON sem transformar a string "false" em True."""
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    if isinstance(value, (int, float)):
        return value != 0
    return str(value).strip().lower() in {"1", "true", "yes", "on", "sim"}


_SMART_ANALYSIS_MAX_SAMPLES = 110


def _smart_dedupe_boxes(boxes: list[tuple[int, int, int, int]]) -> list[tuple[int, int, int, int]]:
    """Remove deteccoes quase duplicadas vindas dos detectores frontal/perfil."""
    kept: list[tuple[int, int, int, int]] = []
    for box in sorted(boxes, key=lambda b: b[2] * b[3], reverse=True):
        x, y, w, h = box
        cx, cy = x + w / 2.0, y + h / 2.0
        duplicate = False
        for kx, ky, kw, kh in kept:
            kcx, kcy = kx + kw / 2.0, ky + kh / 2.0
            if abs(cx - kcx) <= max(w, kw) * 0.42 and abs(cy - kcy) <= max(h, kh) * 0.42:
                duplicate = True
                break
        if not duplicate:
            kept.append(box)
    return kept[:8]


def _smart_reframe_analysis(source: Path, start: float, duration: float, *, follow: bool, compose: bool, motion: str = "smooth") -> dict[str, Any] | None:
    """Analisa poucos frames do trecho. Nao roda se o usuario nao ativar a opcao inteligente."""
    try:
        import cv2  # importacao tardia: zero custo na inicializacao do RedScribe
    except Exception:
        return None

    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        return None
    try:
        src_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        src_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        if src_w < 32 or src_h < 32:
            return None

        # Mantem a analise leve ate em Shorts longos (o limite do app chega a 10 min).
        sample_step = max(0.70, float(duration) / float(_SMART_ANALYSIS_MAX_SAMPLES))
        total_samples = max(2, int(math.ceil(float(duration) / sample_step)) + 1)
        haar_dir = getattr(getattr(cv2, "data", None), "haarcascades", "")
        frontal = cv2.CascadeClassifier(str(Path(haar_dir) / "haarcascade_frontalface_default.xml")) if haar_dir else None
        profile = cv2.CascadeClassifier(str(Path(haar_dir) / "haarcascade_profileface.xml")) if haar_dir else None
        if frontal is not None and frontal.empty(): frontal = None
        if profile is not None and profile.empty(): profile = None
        hog = None
        try:
            hog = cv2.HOGDescriptor()
            hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        except Exception:
            hog = None

        alpha = {"smooth": 0.28, "normal": 0.42, "dynamic": 0.60}.get(str(motion), 0.28)
        dead_zone = {"smooth": 0.038, "normal": 0.028, "dynamic": 0.018}.get(str(motion), 0.038)
        base_visible = min(1.0, max(0.08, (src_h * 9.0 / 16.0) / max(1.0, src_w)))
        previous_center = 0.5
        missing = 0
        previous_hist = None
        samples: list[dict[str, Any]] = []

        for i in range(total_samples):
            t = min(float(duration), i * sample_step)
            cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, float(start) + t) * 1000.0)
            ok, frame = cap.read()
            if not ok or frame is None:
                continue

            fh, fw = frame.shape[:2]
            detect_scale = min(1.0, 960.0 / max(1.0, fw))
            if detect_scale < 0.999:
                small = cv2.resize(frame, (max(2, int(fw * detect_scale)), max(2, int(fh * detect_scale))), interpolation=cv2.INTER_AREA)
            else:
                small = frame
            sh, sw = small.shape[:2]
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            gray_eq = cv2.equalizeHist(gray)

            # Mudanca forte de histograma = provavel corte de camera. Nesse caso o enquadramento
            # pode reposicionar imediatamente, sem "arrastar" o foco da cena anterior.
            scene_cut = False
            try:
                hist = cv2.calcHist([gray], [0], None, [32], [0, 256])
                cv2.normalize(hist, hist)
                if previous_hist is not None:
                    scene_cut = cv2.compareHist(previous_hist, hist, cv2.HISTCMP_BHATTACHARYYA) > 0.56
                previous_hist = hist
            except Exception:
                pass

            boxes: list[tuple[int, int, int, int]] = []
            min_side = max(22, int(min(sw, sh) * 0.045))
            if frontal is not None:
                try:
                    boxes += [tuple(map(int, b)) for b in frontal.detectMultiScale(gray, scaleFactor=1.10, minNeighbors=4, minSize=(min_side, min_side))]
                    if not boxes:
                        boxes += [tuple(map(int, b)) for b in frontal.detectMultiScale(gray_eq, scaleFactor=1.11, minNeighbors=5, minSize=(min_side, min_side))]
                except Exception:
                    pass
            if profile is not None and len(boxes) < 2:
                try:
                    boxes += [tuple(map(int, b)) for b in profile.detectMultiScale(gray, scaleFactor=1.12, minNeighbors=4, minSize=(min_side, min_side))]
                    # O cascade de perfil favorece uma direcao. Rodar espelhado melhora cenas de filme/podcast.
                    flipped = cv2.flip(gray, 1)
                    for x, y, w, h in profile.detectMultiScale(flipped, scaleFactor=1.12, minNeighbors=4, minSize=(min_side, min_side)):
                        boxes.append((int(sw - x - w), int(y), int(w), int(h)))
                except Exception:
                    pass
            boxes = _smart_dedupe_boxes(boxes)

            # Se nenhum rosto apareceu, usa detector de corpo com frequencia menor.
            # Isso cobre apresentadores de costas/perfil e planos mais abertos sem pesar tanto.
            if not boxes and hog is not None and (i % 2 == 0):
                try:
                    hog_scale = min(1.0, 480.0 / max(1.0, sw))
                    hog_frame = cv2.resize(small, (max(2, int(sw * hog_scale)), max(2, int(sh * hog_scale))), interpolation=cv2.INTER_AREA) if hog_scale < 0.999 else small
                    rects, weights = hog.detectMultiScale(hog_frame, winStride=(8, 8), padding=(8, 8), scale=1.08)
                    inv = 1.0 / hog_scale
                    body_boxes = []
                    for j, rect in enumerate(rects):
                        score = float(weights[j]) if j < len(weights) else 1.0
                        if score < 0.18:
                            continue
                        x, y, w, h = map(int, rect)
                        body_boxes.append((int(x * inv), int(y * inv), int(w * inv), int(h * inv)))
                    boxes = _smart_dedupe_boxes(body_boxes)
                except Exception:
                    pass

            target = previous_center
            compose_level = 0
            people_count = len(boxes)
            if boxes:
                missing = 0
                normalized = []
                for x, y, w, h in boxes:
                    cx = (x + w / 2.0) / max(1.0, sw)
                    wn = w / max(1.0, sw)
                    hn = h / max(1.0, sh)
                    normalized.append({"cx": cx, "w": wn, "area": wn * hn})
                normalized.sort(key=lambda b: b["area"], reverse=True)

                # Pessoa principal: favorece quem e maior e quem ja estava sendo acompanhado.
                primary = max(normalized, key=lambda b: b["area"] / (1.0 + abs(b["cx"] - previous_center) * 2.2))
                target = float(primary["cx"]) if follow else 0.5

                if compose and len(normalized) >= 2:
                    # Considera ate 4 pessoas mais relevantes e expande um pouco a largura do rosto/corpo
                    # para estimar a area real que precisa ficar visivel.
                    group = normalized[:4]
                    left = min(b["cx"] - max(0.045, b["w"] * 1.15) for b in group)
                    right = max(b["cx"] + max(0.045, b["w"] * 1.15) for b in group)
                    left, right = max(0.0, left), min(1.0, right)
                    span = max(0.0, right - left)
                    target = (left + right) / 2.0
                    needed = span + 0.045
                    if needed > base_visible * 2.20:
                        compose_level = 3  # plano bem aberto: prioriza manter o grupo visivel
                    elif needed > base_visible * 1.55:
                        compose_level = 2  # plano mais aberto
                    elif needed > base_visible * 1.05:
                        compose_level = 1  # recuo discreto
            else:
                missing += 1
                # Nao recentraliza por causa de um unico frame perdido; depois volta suavemente ao centro.
                if missing >= 3:
                    target = 0.5

            target = max(0.0, min(1.0, float(target)))
            if scene_cut:
                current = target
            elif abs(target - previous_center) <= dead_zone:
                current = previous_center
            else:
                current = previous_center + (target - previous_center) * alpha
            current = max(0.0, min(1.0, current))
            previous_center = current
            samples.append({"t": t, "center": current, "level": compose_level, "people": people_count, "cut": scene_cut})

        if not samples:
            return None

        # Reduz os pontos sem perder o movimento: FFmpeg interpola linearmente entre eles.
        points: list[tuple[float, float]] = []
        for row in samples:
            t, center = float(row["t"]), float(row["center"])
            if not points or row.get("cut") or abs(center - points[-1][1]) >= 0.018 or t - points[-1][0] >= 2.0:
                points.append((t, center))
        if points[0][0] > 0.001:
            points.insert(0, (0.0, points[0][1]))
        if points[-1][0] < float(duration) - 0.001:
            points.append((float(duration), points[-1][1]))

        # Intervalos de composicao: exige confirmacao em amostra vizinha quando possivel,
        # reduzindo falsos positivos sem perder cenas curtas com duas pessoas.
        intervals: list[tuple[float, float, int]] = []
        for i, row in enumerate(samples):
            level = int(row.get("level") or 0)
            if level <= 0:
                continue
            neighbor = False
            if i > 0 and int(samples[i - 1].get("level") or 0) > 0: neighbor = True
            if i + 1 < len(samples) and int(samples[i + 1].get("level") or 0) > 0: neighbor = True
            if not neighbor and float(duration) > sample_step * 2.4:
                continue
            a = max(0.0, float(row["t"]) - sample_step * 0.62)
            b = min(float(duration), float(row["t"]) + sample_step * 0.62)
            intervals.append((a, b, level))

        merged: list[list[float | int]] = []
        for a, b, level in sorted(intervals):
            if merged and a <= float(merged[-1][1]) + 0.12 and int(merged[-1][2]) == level:
                merged[-1][1] = max(float(merged[-1][1]), b)
            else:
                merged.append([a, b, level])

        return {
            "source_width": src_w,
            "source_height": src_h,
            "points": points,
            "compose_intervals": [(float(a), float(b), int(level)) for a, b, level in merged],
            "detected_samples": sum(1 for s in samples if int(s.get("people") or 0) > 0),
            "sample_count": len(samples),
        }
    finally:
        cap.release()


def _detect_embedded_black_bars_cv(source: Path, start: float, duration: float) -> tuple[int, int, int, int] | None:
    """Detecção inteligente de barras pretas embutidas usando análise direta dos pixels.

    Regras:
    - só recorta quando as bordas escuras são estáveis em vários pontos do Short;
    - se não houver barras, não recorta nada;
    - prioriza top/bottom, mas também identifica pillarbox/windowbox quando real.
    """
    try:
        import cv2  # type: ignore
    except Exception:
        return None

    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        return None
    try:
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        src_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        src_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        if src_w < 32 or src_h < 32:
            return None

        dur = max(1.0, float(duration))
        sample_times = []
        for frac in (0.07, 0.22, 0.50, 0.78, 0.93):
            t = max(0.0, float(start) + dur * frac)
            if not sample_times or abs(t - sample_times[-1]) > 0.20:
                sample_times.append(t)

        detections: list[tuple[int, int, int, int]] = []
        for t in sample_times:
            if fps > 0 and total > 0:
                frame_index = max(0, min(total - 1, int(round(t * fps))))
                cap.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
            ok, frame = cap.read()
            if not ok or frame is None:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Pequeno blur ajuda a não tratar ruído/legenda como conteúdo.
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            small_w = min(320, gray.shape[1])
            if small_w != gray.shape[1]:
                scale = small_w / float(gray.shape[1])
                gray = cv2.resize(gray, (small_w, max(2, int(round(gray.shape[0] * scale)))), interpolation=cv2.INTER_AREA)
            h, w = gray.shape[:2]
            if h < 32 or w < 32:
                continue

            row_means = gray.mean(axis=1)
            row_dark = (gray <= 18).mean(axis=1)
            col_means = gray.mean(axis=0)
            col_dark = (gray <= 18).mean(axis=0)

            def edge_run(means, darks, reverse=False, max_frac=0.30):
                idxs = range(len(means)-1, -1, -1) if reverse else range(len(means))
                limit = max(2, int(round(len(means) * max_frac)))
                run = 0
                for i, idx in enumerate(idxs):
                    if i >= limit:
                        break
                    m = float(means[idx])
                    d = float(darks[idx])
                    # faixa preta real = linha/coluna quase toda escura e homogênea
                    if m <= 24.0 and d >= 0.965:
                        run += 1
                        continue
                    # pequena tolerância em transição muito escura, sem engolir conteúdo
                    if run >= 2 and m <= 30.0 and d >= 0.92:
                        run += 1
                        continue
                    break
                return run

            top = edge_run(row_means, row_dark, reverse=False, max_frac=0.28)
            bottom = edge_run(row_means, row_dark, reverse=True, max_frac=0.28)
            left = edge_run(col_means, col_dark, reverse=False, max_frac=0.18)
            right = edge_run(col_means, col_dark, reverse=True, max_frac=0.18)

            # Só aceita margens minimamente relevantes.
            min_tb = max(2, int(round(h * 0.018)))
            min_lr = max(2, int(round(w * 0.012)))
            if top < min_tb: top = 0
            if bottom < min_tb: bottom = 0
            if left < min_lr: left = 0
            if right < min_lr: right = 0

            # Converte para o tamanho original.
            sx = src_w / float(w)
            sy = src_h / float(h)
            crop_x = int(round(left * sx))
            crop_y = int(round(top * sy))
            crop_w = int(round(src_w - (left + right) * sx))
            crop_h = int(round(src_h - (top + bottom) * sy))
            crop_w = max(2, min(src_w, crop_w))
            crop_h = max(2, min(src_h, crop_h))
            if crop_w < src_w or crop_h < src_h:
                detections.append((crop_w, crop_h, crop_x, crop_y))

        if not detections:
            return None

        # Mantém somente as detecções estáveis entre amostras.
        tol_x = max(6, int(round(src_w * 0.02)))
        tol_y = max(6, int(round(src_h * 0.02)))
        stable: list[tuple[int, int, int, int]] = []
        for cand in detections:
            cw, ch, cx, cy = cand
            matches = sum(1 for ow, oh, ox, oy in detections if abs(cw-ow) <= tol_x and abs(ch-oh) <= tol_y and abs(cx-ox) <= tol_x and abs(cy-oy) <= tol_y)
            if matches >= max(2, min(3, len(detections))):
                stable.append(cand)
        if not stable:
            return None

        # Entre as estáveis, preferimos a menos agressiva.
        best = max(stable, key=lambda c: c[0] * c[1])
        bw, bh, bx, by = best
        left = max(0, bx)
        top = max(0, by)
        right = max(0, src_w - (bx + bw))
        bottom = max(0, src_h - (by + bh))

        # Não recorta conteúdo se praticamente não houver borda.
        if max(left, right, top, bottom) < max(3, int(round(min(src_w, src_h) * 0.004))):
            return None

        # Se recortar em ambos eixos, exige simetria aproximada ou barras reais nos dois eixos.
        if (left or right) and (top or bottom):
            if abs(left - right) > max(12, int(round(src_w * 0.025))) or abs(top - bottom) > max(12, int(round(src_h * 0.025))):
                # prefere preservar só o eixo dominante.
                if (top + bottom) >= (left + right):
                    best = (src_w, src_h - top - bottom, 0, top)
                else:
                    best = (src_w - left - right, src_h, left, 0)
        return best
    finally:
        cap.release()


def _detect_embedded_black_bars(ffmpeg: str, source: Path, start: float, duration: float) -> tuple[int, int, int, int] | None:
    """Detecta letterbox/pillarbox que já vem gravado dentro do vídeo.

    Estratégia híbrida:
    1) análise de pixels com OpenCV para detectar barras reais com mais precisão;
    2) cropdetect do FFmpeg como validação/fallback;
    3) se não houver borda estável, não recorta nada.
    """
    cv_crop = _detect_embedded_black_bars_cv(source, start, duration)
    probes: list[float] = []
    dur = max(1.0, float(duration))
    for frac in (0.08, 0.50, 0.92):
        pos = max(0.0, float(start) + max(0.0, dur * frac - 0.7))
        if not probes or abs(pos - probes[-1]) > 0.35:
            probes.append(pos)

    candidates: list[tuple[int, int, int, int]] = []
    probe_best: list[tuple[int, int, int, int]] = []
    source_sizes: list[tuple[int, int]] = []
    crop_re = re.compile(r"crop=(\d+):(\d+):(\d+):(\d+)")
    size_re = re.compile(r"Video:[^\r\n]*?\b(\d{2,5})x(\d{2,5})\b")
    for pos in probes:
        cmd = [
            ffmpeg, "-hide_banner", "-loglevel", "info", "-ss", f"{pos:.3f}", "-i", str(source),
            "-t", "1.6", "-vf", "fps=4,cropdetect=limit=32:round=2:reset=0",
            "-an", "-f", "null", "-",
        ]
        try:
            r = subprocess.run(
                cmd, capture_output=True, text=True, timeout=28,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception:
            continue
        blob = (r.stderr or "") + "\n" + (r.stdout or "")
        sm = size_re.search(blob)
        if sm:
            try:
                source_sizes.append((int(sm.group(1)), int(sm.group(2))))
            except Exception:
                pass
        local: list[tuple[int, int, int, int]] = []
        for m in crop_re.finditer(blob):
            w, h, x, y = map(int, m.groups())
            if w >= 32 and h >= 32:
                item = (w, h, x, y)
                candidates.append(item)
                local.append(item)
        if local:
            probe_best.append(max(local, key=lambda c: c[0] * c[1]))

    if not candidates:
        return None

    # O maior retângulo é o mais conservador. Se alguma amostra disser "quadro inteiro",
    # isso vence uma falsa detecção causada por uma cena muito escura.
    best = max(candidates, key=lambda c: c[0] * c[1])
    bw, bh, bx, by = best

    # Confirma que realmente existe margem removida. Com o tamanho original conseguimos
    # detectar inclusive barras assimétricas (só em cima/baixo ou só em um dos lados).
    if source_sizes:
        src_w, src_h = max(source_sizes, key=lambda s: s[0] * s[1])

        # Barras verdadeiras ficam paradas no mesmo lugar. Exigimos consistência entre
        # os pontos analisados para não confundir palco/cenário escuro com letterbox.
        if len(probe_best) >= 2:
            tol_w = max(8, int(round(src_w * 0.012)))
            tol_h = max(8, int(round(src_h * 0.012)))
            stable: list[tuple[int, int, int, int]] = []
            for cand in probe_best:
                cw, ch, cx, cy = cand
                matches = sum(
                    1 for ow, oh, ox, oy in probe_best
                    if abs(cw-ow) <= tol_w and abs(ch-oh) <= tol_h and abs(cx-ox) <= tol_w and abs(cy-oy) <= tol_h
                )
                if matches >= 2:
                    stable.append(cand)
            if not stable:
                return None
            # Entre as detecções estáveis, continua escolhendo a menos agressiva.
            best = max(stable, key=lambda c: c[0] * c[1])
            bw, bh, bx, by = best

        left = max(0, bx)
        top = max(0, by)
        right = max(0, src_w - (bx + bw))
        bottom = max(0, src_h - (by + bh))
        min_x = max(3, int(round(src_w * 0.003)))
        min_y = max(3, int(round(src_h * 0.003)))
        if max(left, right) < min_x and max(top, bottom) < min_y:
            return None

        # Letterbox costuma manter praticamente toda a largura; pillarbox, praticamente
        # toda a altura. Se ambos os eixos forem cortados, só aceitamos margens quase
        # simétricas (windowbox real), evitando zoom indevido em fundos pretos.
        horizontal_band = max(top, bottom) >= min_y and bw >= int(src_w * 0.94)
        vertical_band = max(left, right) >= min_x and bh >= int(src_h * 0.94)
        symmetric_windowbox = (
            max(top, bottom) >= min_y and max(left, right) >= min_x
            and abs(left - right) <= max(10, int(src_w * 0.02))
            and abs(top - bottom) <= max(10, int(src_h * 0.02))
        )
        if not (horizontal_band or vertical_band or symmetric_windowbox):
            return None
    elif bx <= 2 and by <= 2:
        # Fallback para builds em que a linha de dimensões não pôde ser lida.
        max_w = max(c[0] + 2 * c[2] for c in candidates)
        max_h = max(c[1] + 2 * c[3] for c in candidates)
        if abs(max_w - bw) <= 4 and abs(max_h - bh) <= 4:
            return None

    # Reconcilia OpenCV e cropdetect. Se ambos concordarem, usa a interseção menos agressiva.
    # Se só um encontrar barras estáveis, usa esse resultado. Se divergirem muito, prioriza
    # a análise por pixels para top/bottom embutido, mantendo o crop mais conservador.
    ffmpeg_best = best
    if cv_crop and ffmpeg_best:
        cw, ch, cx, cy = cv_crop
        fw, fh, fx, fy = ffmpeg_best
        if source_sizes:
            src_w, src_h = max(source_sizes, key=lambda s: s[0] * s[1])
        else:
            src_w, src_h = max(cw + cx, fw + fx), max(ch + cy, fh + fy)
        cv_l, cv_t, cv_r, cv_b = cx, cy, max(0, src_w - (cx + cw)), max(0, src_h - (cy + ch))
        ff_l, ff_t, ff_r, ff_b = fx, fy, max(0, src_w - (fx + fw)), max(0, src_h - (fy + fh))
        tol_x = max(10, int(round(src_w * 0.025)))
        tol_y = max(10, int(round(src_h * 0.025)))
        agree = abs(cv_l-ff_l) <= tol_x and abs(cv_r-ff_r) <= tol_x and abs(cv_t-ff_t) <= tol_y and abs(cv_b-ff_b) <= tol_y
        if agree:
            left = min(cv_l, ff_l)
            right = min(cv_r, ff_r)
            top = min(cv_t, ff_t)
            bottom = min(cv_b, ff_b)
            best = (max(2, src_w-left-right), max(2, src_h-top-bottom), left, top)
        else:
            # Mantém o menos agressivo, mas se OpenCV detectar claramente barras top/bottom,
            # ele vence para preservar o comportamento desejado pelo usuário.
            cv_tb = cv_t + cv_b
            ff_tb = ff_t + ff_b
            if cv_tb >= max(8, int(round(src_h * 0.02))):
                best = cv_crop
            else:
                best = max([cv_crop, ffmpeg_best], key=lambda c: c[0] * c[1])
    elif cv_crop:
        best = cv_crop
    else:
        best = ffmpeg_best
    return best


def _detect_final_horizontal_black_bars(video_path: Path) -> tuple[int, int] | None:
    """Detecta barras horizontais no MP4 final, inclusive quando aparecem só em algumas cenas.

    A v3.5.3 exigia que a barra aparecesse na maior parte do Short. Isso falhava em clipes
    com troca de câmera/aspect ratio: uma cena podia ter barra no topo e outra no rodapé.
    Agora fazemos uma análise *scene-aware*: amostramos o vídeo inteiro, detectamos barras
    fortes por frame, agrupamos alturas recorrentes e usamos o maior envelope confiável.

    Resultado: se QUALQUER cena relevante do Short trouxer letterbox real, o crop final
    remove essa margem de todo o Short e amplia novamente para 9:16. Vídeo sem barra real
    continua sem crop extra.
    """
    try:
        import cv2  # type: ignore
        import numpy as np  # type: ignore
    except Exception:
        return None

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return None
    try:
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if width < 64 or height < 128:
            return None

        duration_s = (total / fps) if (total > 0 and fps > 0) else 15.0
        # ~4 amostras/s nos Shorts comuns; limite evita custo excessivo em vídeos longos.
        sample_count = int(min(180, max(25, math.ceil(duration_s * 4.0))))
        if total > 0:
            indices = [
                max(0, min(total - 1, int(round((total - 1) * ((i + 0.5) / sample_count)))))
                for i in range(sample_count)
            ]
        else:
            indices = list(range(sample_count))

        # (sample_index, run_px, confidence)
        top_hits: list[tuple[int, int, float]] = []
        bottom_hits: list[tuple[int, int, float]] = []

        def scan_edge(gray, from_top: bool) -> tuple[int, float]:
            h0, w0 = gray.shape[:2]
            # Reduz para análise, preservando proporção.
            if w0 > 480:
                new_w = 480
                scale_down = new_w / float(w0)
                new_h = max(2, int(round(h0 * scale_down)))
                gray = cv2.resize(gray, (new_w, new_h), interpolation=cv2.INTER_AREA)
            h, w = gray.shape[:2]
            max_scan = max(6, int(round(h * 0.30)))
            rows = gray[:max_scan] if from_top else gray[h-max_scan:][::-1]

            means = rows.mean(axis=1)
            stds = rows.std(axis=1)
            dark_ratio = (rows <= 48).mean(axis=1)
            # percentil 90: em uma barra real quase todos os pixels seguem escuros.
            p90 = np.percentile(rows, 90, axis=1)

            run = 0
            transition_budget = 0
            for i in range(len(means)):
                m = float(means[i]); s = float(stds[i]); d = float(dark_ratio[i]); q = float(p90[i])
                strong = (m <= 34.0 and q <= 48.0 and d >= 0.93 and s <= 28.0)
                soft = (m <= 42.0 and q <= 58.0 and d >= 0.86 and s <= 34.0)
                if strong:
                    run += 1
                    transition_budget = 1
                    continue
                if run >= 2 and transition_budget > 0 and soft:
                    run += 1
                    transition_budget -= 1
                    continue
                break

            if run <= 0:
                return 0, 0.0

            # A barra precisa ter tamanho visível. Linhas de codec não contam.
            min_run = max(3, int(round(h * 0.008)))
            if run < min_run:
                return 0, 0.0

            if from_top:
                band = gray[:run]
                c0 = min(h, run + max(2, int(round(h * 0.006))))
                c1 = min(h, c0 + max(8, int(round(h * 0.055))))
                content = gray[c0:c1]
            else:
                band = gray[max(0, h-run):h]
                c1 = max(0, h-run-max(2, int(round(h * 0.006))))
                c0 = max(0, c1-max(8, int(round(h * 0.055))))
                content = gray[c0:c1]
            if band.size == 0 or content.size == 0:
                return 0, 0.0

            band_mean = float(band.mean()); band_std = float(band.std())
            content_mean = float(content.mean()); content_std = float(content.std())
            # O limite entre barra e conteúdo costuma ter salto de brilho ou textura.
            mean_gain = content_mean - band_mean
            texture_gain = content_std - band_std
            confidence = 0.0
            if mean_gain >= 6.0: confidence += min(1.0, mean_gain / 24.0)
            if texture_gain >= 7.0: confidence += min(1.0, texture_gain / 28.0)
            # barras bem pretas/uniformes recebem peso adicional
            if band_mean <= 20.0: confidence += 0.55
            if band_std <= 16.0: confidence += 0.35
            if confidence < 0.70:
                return 0, 0.0

            # Converte de volta para pixels do vídeo original.
            scale_up = h0 / float(h)
            return int(round(run * scale_up)), confidence

        read_ok = 0
        for sample_i, idx in enumerate(indices):
            if total > 0:
                cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            elif fps > 0:
                cap.set(cv2.CAP_PROP_POS_MSEC, (sample_i / max(1, sample_count-1)) * duration_s * 1000.0)
            ok, frame = cap.read()
            if not ok or frame is None:
                continue
            read_ok += 1
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            tr, tc = scan_edge(gray, True)
            br, bc = scan_edge(gray, False)
            if tr > 0: top_hits.append((sample_i, tr, tc))
            if br > 0: bottom_hits.append((sample_i, br, bc))

        if read_ok < 3:
            return None

        def choose_scene_margin(hits: list[tuple[int, int, float]]) -> int:
            if not hits:
                return 0
            # Agrupa alturas parecidas. Cada troca de câmera pode ter uma barra diferente.
            tol = max(6, int(round(height * 0.014)))
            sorted_hits = sorted(hits, key=lambda x: x[1])
            clusters: list[list[tuple[int, int, float]]] = []
            for hit in sorted_hits:
                placed = False
                for cl in clusters:
                    med = float(np.median([x[1] for x in cl]))
                    if abs(hit[1] - med) <= tol:
                        cl.append(hit); placed = True; break
                if not placed:
                    clusters.append([hit])

            accepted: list[int] = []
            for cl in clusters:
                sample_ids = sorted(x[0] for x in cl)
                runs = [x[1] for x in cl]
                confs = [x[2] for x in cl]
                # Basta uma pequena sequência de frames/cena. Não exigimos mais 55% do Short.
                consecutive = any((b - a) <= 2 for a, b in zip(sample_ids, sample_ids[1:]))
                enough = len(cl) >= 2 and consecutive
                # Uma única detecção só entra se for uma barra muito grande e extremamente clara.
                single_strong = len(cl) == 1 and runs[0] >= int(height * 0.075) and confs[0] >= 1.45
                if not (enough or single_strong):
                    continue
                # Usa percentil alto para remover a maior barra recorrente daquela cena,
                # sem deixar um outlier isolado causar zoom exagerado.
                margin = int(round(float(np.percentile(np.array(runs, dtype=np.float32), 85))))
                accepted.append(margin)

            if not accepted:
                return 0
            # Queremos garantir que nenhuma cena aceita deixe barra: pega o maior envelope.
            margin = max(accepted)
            extra = max(3, int(round(height * 0.0025)))
            return min(int(round(height * 0.30)), margin + extra)

        top = choose_scene_margin(top_hits)
        bottom = choose_scene_margin(bottom_hits)
        if top <= 0 and bottom <= 0:
            return None
        # Proteção contra falso positivo absurdo; 48% ainda permite letterbox forte assimétrico.
        if top + bottom >= int(height * 0.48):
            return None
        return max(0, top), max(0, bottom)
    finally:
        cap.release()

def _ffmpeg_detect_final_horizontal_bars(ffmpeg: str, video_path: Path) -> tuple[int, int] | None:
    """Detector independente de OpenCV para o MP4 FINAL.

    Usa cropdetect em vários frames e aceita apenas crops que preservam praticamente
    100% da largura. Isso é importante: uma cena escura pode enganar cropdetect, mas
    normalmente também corta as laterais; letterbox real mantém a largura e remove
    apenas topo/rodapé.
    """
    crop_re = re.compile(r"crop=(\d+):(\d+):(\d+):(\d+)")
    size_re = re.compile(r"Video:[^\r\n]*?\b(\d{2,5})x(\d{2,5})\b")
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "info", "-i", str(video_path),
        "-vf", "fps=5,cropdetect=limit=24:round=2:reset=1", "-an", "-f", "null", "-",
    ]
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=120,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        return None
    blob = (r.stderr or "") + "\n" + (r.stdout or "")
    sm = size_re.search(blob)
    crops = [tuple(map(int, m.groups())) for m in crop_re.finditer(blob)]
    if not sm or not crops:
        return None
    src_w, src_h = int(sm.group(1)), int(sm.group(2))

    top_hits: list[int] = []
    bottom_hits: list[int] = []
    for w, h, x, y in crops:
        # Somente horizontal: praticamente toda a largura original deve sobreviver.
        if w < int(src_w * 0.985):
            continue
        top = max(0, y)
        bottom = max(0, src_h - (y + h))
        # ignora micro-linhas de codec
        min_px = max(4, int(round(src_h * 0.004)))
        if top >= min_px:
            top_hits.append(top)
        if bottom >= min_px:
            bottom_hits.append(bottom)

    if not top_hits and not bottom_hits:
        return None

    def robust_max(values: list[int]) -> int:
        if not values:
            return 0
        values = sorted(values)
        # Queremos eliminar inclusive cenas com barras maiores, mas ignorar um único
        # outlier absurdo. Percentil ~95 funciona bem para cortes de câmera variados.
        idx = min(len(values)-1, max(0, int(round((len(values)-1) * 0.95))))
        val = values[idx]
        return min(int(src_h * 0.32), val + max(2, int(round(src_h * 0.002))))

    top = robust_max(top_hits)
    bottom = robust_max(bottom_hits)
    if top <= 0 and bottom <= 0:
        return None
    if top + bottom >= int(src_h * 0.46):
        return None
    return top, bottom


def _merge_final_bar_detections(*detections: tuple[int, int] | None) -> tuple[int, int] | None:
    """Une detectores diferentes sem deixar uma faixa detectada por um deles escapar."""
    tops = [int(d[0]) for d in detections if d and int(d[0]) > 0]
    bottoms = [int(d[1]) for d in detections if d and int(d[1]) > 0]
    if not tops and not bottoms:
        return None
    return (max(tops) if tops else 0, max(bottoms) if bottoms else 0)


def _normalize_even_bar_crop(top: int, bottom: int, frame_height: int) -> tuple[int, int, int] | None:
    """Normaliza crop para YUV420/H.264.

    A v3.5.4 podia detectar corretamente a faixa e ainda assim o FFmpeg falhar em
    determinados clipes quando a altura resultante era ímpar. Como a exceção era
    silenciosa, o MP4 original com barras acabava sendo entregue. Aqui sempre usamos
    top/altura pares e removemos 1px extra quando necessário, nunca deixando a barra.
    """
    top = max(0, int(top))
    bottom = max(0, int(bottom))
    h = max(2, int(frame_height))
    if top <= 0 and bottom <= 0:
        return None
    # Arredonda PARA CIMA, porque arredondar para baixo pode deixar 1 px preto.
    if top % 2:
        top += 1
    if bottom % 2:
        bottom += 1
    # margem mínima extra de segurança contra halo de compressão
    if top > 0:
        top += 2
    if bottom > 0:
        bottom += 2
    top = min(top, int(h * 0.34))
    bottom = min(bottom, int(h * 0.34))
    crop_h = h - top - bottom
    if crop_h % 2:
        # remove mais 1 px do lado que já tinha barra; nunca reintroduz preto
        if bottom > 0:
            bottom += 1
        else:
            top += 1
        crop_h = h - top - bottom
    if crop_h < int(h * 0.52) or crop_h < 2:
        return None
    return top, bottom, crop_h


def _apply_final_no_bar_crop(ffmpeg: str, video_path: Path, width: int, height: int, top: int, bottom: int, pass_no: int) -> bool:
    norm = _normalize_even_bar_crop(top, bottom, height)
    if not norm:
        return False
    top, bottom, crop_h = norm
    temp = video_path.with_name(video_path.stem + f".nobars{pass_no}.mp4")
    # Quadro único. Sem pad, sem overlay, sem fundo artificial.
    vf = (
        f"crop=iw:{crop_h}:0:{top},"
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},setsar=1"
    )

    # 1ª tentativa: reencoda áudio também. É mais previsível do que -c:a copy entre
    # arquivos temporários e evita um segundo ponto de falha silenciosa.
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(video_path),
        "-map", "0:v:0", "-map", "0:a?", "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart",
        "-threads", "2", str(temp),
    ]
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=1200,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if r.returncode != 0 or not temp.exists() or temp.stat().st_size < 20_000:
            try:
                temp.unlink(missing_ok=True)
            except Exception:
                pass
            return False
        temp.replace(video_path)
        return True
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def _force_final_fit_without_black_bars(ffmpeg: str, video_path: Path, width: int, height: int) -> bool:
    """Garantia final do modo FIT, agora sem depender de um único detector.

    Pipeline por passe:
      OpenCV scene-aware + FFmpeg cropdetect -> união das margens -> crop par ->
      scale/crop 9:16 -> nova validação.

    Se OpenCV não carregar no Windows, FFmpeg sozinho continua capaz de remover as
    barras. Se uma margem ímpar for detectada, ela é normalizada antes da codificação.
    """
    changed = False
    for pass_no in range(4):
        cv_margins = None
        try:
            cv_margins = _detect_final_horizontal_black_bars(video_path)
        except Exception:
            cv_margins = None
        ff_margins = None
        try:
            ff_margins = _ffmpeg_detect_final_horizontal_bars(ffmpeg, video_path)
        except Exception:
            ff_margins = None

        margins = _merge_final_bar_detections(cv_margins, ff_margins)
        if not margins:
            break
        top, bottom = margins
        if top <= 0 and bottom <= 0:
            break
        if top + bottom >= int(height * 0.46):
            break
        if not _apply_final_no_bar_crop(ffmpeg, video_path, width, height, top, bottom, pass_no):
            break
        changed = True
    return changed


def _source_crop_prefix(crop: tuple[int, int, int, int] | None) -> str:
    if not crop:
        return ""
    w, h, x, y = crop
    return f"crop={w}:{h}:{x}:{y},"


def _smart_points_after_source_crop(analysis: dict[str, Any], crop: tuple[int, int, int, int] | None) -> list[tuple[float, float]]:
    points = list(analysis.get("points") or [])
    if not crop:
        return points
    src_w = float(analysis.get("source_width") or 0)
    if src_w <= 0:
        return points
    crop_w, _crop_h, crop_x, _crop_y = crop
    if crop_w <= 0:
        return points
    out: list[tuple[float, float]] = []
    for t, center in points:
        px = float(center) * src_w
        adjusted = (px - float(crop_x)) / float(crop_w)
        out.append((float(t), max(0.0, min(1.0, adjusted))))
    return out


def _smart_center_expression(points: list[tuple[float, float]]) -> str:
    if not points:
        return "0.5"
    clean = [(max(0.0, float(t)), max(0.0, min(1.0, float(c)))) for t, c in points]
    expr = f"{clean[-1][1]:.6f}"
    for i in range(len(clean) - 2, -1, -1):
        t0, c0 = clean[i]
        t1, c1 = clean[i + 1]
        dt = max(0.001, t1 - t0)
        slope = c1 - c0
        seg = f"({c0:.6f}+({slope:.6f})*(t-{t0:.3f})/{dt:.3f})"
        expr = f"if(lt(t,{t1:.3f}),{seg},{expr})"
    return expr


def _smart_enable_expression(intervals: list[tuple[float, float, int]], level: int) -> str:
    parts = [f"between(t,{a:.3f},{b:.3f})" for a, b, lev in intervals if int(lev) == int(level) and b > a]
    return "+".join(parts) if parts else "0"


def _build_smart_follow_full_chain(width: int, height: int, analysis: dict[str, Any], source_crop: tuple[int, int, int, int] | None = None) -> str:
    """
    Preenchimento total + seguir pessoa.

    Esta cadeia parte da MESMA regra visual aprovada na v3.4.7:
      scale(..., force_original_aspect_ratio=increase) -> crop(9:16).

    A única diferença é o X do crop, que acompanha a pessoa. Não existe overlay,
    pad, fundo, fit/decrease ou redimensionamento do quadro principal.
    """
    center = _smart_center_expression(_smart_points_after_source_crop(analysis, source_crop))
    crop_x = f"max(0,min(iw-{width},({center})*iw-{width}/2))"
    pre = _source_crop_prefix(source_crop)
    return (
        f"[0:v]setpts=PTS-STARTPTS,{pre}"
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height}:x='{crop_x}',setsar=1[base]"
    )


def _build_smart_video_chain(width: int, height: int, analysis: dict[str, Any], *, compose: bool, source_crop: tuple[int, int, int, int] | None = None) -> str:
    center = _smart_center_expression(_smart_points_after_source_crop(analysis, source_crop))
    pre = _source_crop_prefix(source_crop)
    # Apos scale=increase, iw/ih sempre cobrem o canvas. O centro inteligente move somente
    # quando necessario; y permanece central para nao criar movimentos verticais artificiais.
    crop_x = f"max(0,min(iw-{width},({center})*iw-{width}/2))"
    intervals = list(analysis.get("compose_intervals") or []) if compose else []
    has_l1 = any(int(x[2]) == 1 for x in intervals)
    has_l2 = any(int(x[2]) == 2 for x in intervals)
    has_l3 = any(int(x[2]) == 3 for x in intervals)
    levels = int(has_l1) + int(has_l2) + int(has_l3)

    if levels == 0:
        return (
            f"[0:v]setpts=PTS-STARTPTS,{pre}scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height}:x='{crop_x}':y='max(0,(ih-{height})/2)'[base]"
        )

    split_count = 1 + levels
    labels = ["smartbasesrc"]
    if has_l1: labels.append("smartfg1src")
    if has_l2: labels.append("smartfg2src")
    if has_l3: labels.append("smartfg3src")
    chain = f"[0:v]setpts=PTS-STARTPTS,{pre}split={split_count}" + "".join(f"[{x}]" for x in labels) + ";"
    chain += (
        f"[smartbasesrc]scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height}:x='{crop_x}':y='max(0,(ih-{height})/2)'[smartclean];"
        f"[smartclean]split=2[smartbase][smartbgseed];"
        f"[smartbgseed]boxblur={max(12, int(width/48))}:2,eq=brightness=-0.035:saturation=0.94[smartbg]"
    )
    if levels > 1:
        bg_labels = []
        if has_l1: bg_labels.append("smartbg1")
        if has_l2: bg_labels.append("smartbg2")
        if has_l3: bg_labels.append("smartbg3")
        chain += f";[smartbg]split={levels}" + "".join(f"[{x}]" for x in bg_labels)
    else:
        only_level = 1 if has_l1 else (2 if has_l2 else 3)
        chain += f";[smartbg]null[smartbg{only_level}]"

    comps: list[str] = []
    if has_l1:
        fh = max(2, int(round(height * 0.78 / 2.0) * 2))
        fg_x = f"max(0,min(iw-ow,({center})*iw-ow/2))"
        chain += (
            f";[smartfg1src]scale=-2:{fh},crop='min(iw,{width})':ih:x='{fg_x}':y=0[smartfg1];"
            f"[smartbg1][smartfg1]overlay=(W-w)/2:(H-h)/2[smartcomp1]"
        )
        comps.append("1")
    if has_l2:
        fh = max(2, int(round(height * 0.55 / 2.0) * 2))
        fg_x = f"max(0,min(iw-ow,({center})*iw-ow/2))"
        chain += (
            f";[smartfg2src]scale=-2:{fh},crop='min(iw,{width})':ih:x='{fg_x}':y=0[smartfg2];"
            f"[smartbg2][smartfg2]overlay=(W-w)/2:(H-h)/2[smartcomp2]"
        )
        comps.append("2")

    if has_l3:
        fh = max(2, int(round(height * 0.38 / 2.0) * 2))
        fg_x = f"max(0,min(iw-ow,({center})*iw-ow/2))"
        chain += (
            f";[smartfg3src]scale=-2:{fh},crop='min(iw,{width})':ih:x='{fg_x}':y=0[smartfg3];"
            f"[smartbg3][smartfg3]overlay=(W-w)/2:(H-h)/2[smartcomp3]"
        )
        comps.append("3")

    current = "smartbase"
    mix_idx = 0
    for lev in comps:
        mix_idx += 1
        enable = _smart_enable_expression(intervals, int(lev))
        out_label = "base" if mix_idx == len(comps) else f"smartmix{mix_idx}"
        chain += f";[{current}][smartcomp{lev}]overlay=0:0:enable='{enable}'[{out_label}]"
        current = out_label
    return chain

def _probe_media_duration(ffmpeg: str, source: Path) -> float:
    """Retorna a duração real do vídeo fonte sem depender da transcrição.

    Isso é usado como fallback para o Shorts Studio: se a legenda vier esparsa,
    mal segmentada ou com timestamps incompletos, ainda é possível montar a
    quantidade solicitada de Shorts a partir da duração do próprio vídeo.
    """
    # 1) OpenCV é rápido quando disponível.
    try:
        import cv2  # type: ignore
        cap = cv2.VideoCapture(str(source))
        try:
            if cap.isOpened():
                fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
                frames = float(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0.0)
                if fps > 0.01 and frames > 0:
                    dur = frames / fps
                    if dur > 0.5:
                        return float(dur)
        finally:
            cap.release()
    except Exception:
        pass

    # 2) FFmpeg como fallback universal.
    try:
        r = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(source)],
            capture_output=True, text=True, timeout=25,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        blob = (r.stderr or "") + "\n" + (r.stdout or "")
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", blob)
        if m:
            h, mi, sec = int(m.group(1)), int(m.group(2)), float(m.group(3))
            dur = h * 3600 + mi * 60 + sec
            if dur > 0.5:
                return float(dur)
    except Exception:
        pass
    return 0.0


def register_shorts_tools(app, core) -> None:
    """Register the user-triggered Shorts Studio without adding startup work."""

    def tasks_path(user_id: str) -> Path:
        return core._user_dir(user_id) / "shorts_tasks.json"

    def task_root(user_id: str, task_id: str) -> Path:
        path = core.DATA_ROOT / "shorts" / user_id / task_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    # V3.4.3: a Biblioteca de Shorts é independente do histórico de tarefas.
    # O arquivo renderizado fica preservado no armazenamento interno do RedScribe
    # para poder ser assistido e salvo novamente mesmo depois de limpar o histórico.
    def shorts_library_path(user_id: str) -> Path:
        return core._user_dir(user_id) / "shorts_library.json"

    def shorts_library_root(user_id: str) -> Path:
        path = core.DATA_ROOT / "shorts_library" / user_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def shorts_trash_path(user_id: str) -> Path:
        return core._user_dir(user_id) / "shorts_library_trash.json"

    def load_shorts_trash(user_id: str) -> list[dict[str, Any]]:
        path = shorts_trash_path(user_id)
        if not path.exists():
            return []
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
            return rows if isinstance(rows, list) else []
        except Exception:
            return []

    def write_shorts_trash(user_id: str, rows: list[dict[str, Any]]) -> None:
        core._atomic_write_json(shorts_trash_path(user_id), rows[:1000])

    def deleted_shorts_path(user_id: str) -> Path:
        return core._user_dir(user_id) / "shorts_library_deleted.json"

    def load_deleted_short_ids(user_id: str) -> set[str]:
        path = deleted_shorts_path(user_id)
        if not path.exists():
            return set()
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
            return {str(x) for x in rows if re.fullmatch(r"[a-f0-9]{32}", str(x))} if isinstance(rows, list) else set()
        except Exception:
            return set()

    def write_deleted_short_ids(user_id: str, ids: set[str]) -> None:
        core._atomic_write_json(deleted_shorts_path(user_id), sorted(ids)[-2000:])

    def load_shorts_library(user_id: str) -> list[dict[str, Any]]:
        path = shorts_library_path(user_id)
        if not path.exists():
            return []
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
            return rows if isinstance(rows, list) else []
        except Exception:
            return []

    def write_shorts_library(user_id: str, rows: list[dict[str, Any]]) -> None:
        core._atomic_write_json(shorts_library_path(user_id), rows[:1000])

    def short_asset_id(task_id: str, index: int) -> str:
        return uuid.uuid5(uuid.NAMESPACE_URL, f"redscribe-short:{task_id}:{int(index)}").hex

    def library_asset_path(user_id: str, asset_id: str) -> Path:
        return shorts_library_root(user_id) / f"{asset_id}.mp4"

    def _preserve_short_file(source: Path, destination: Path) -> None:
        if destination.exists() and destination.stat().st_size > 0:
            return
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            # Em NTFS, hardlink preserva o Short sem duplicar o espaço em disco.
            os.link(source, destination)
        except OSError:
            shutil.copy2(source, destination)

    def persist_short_asset(user_id: str, task: dict[str, Any], output: dict[str, Any], source: Path, *, selection_method: str | None = None, layout: str | None = None, quality: str | None = None) -> dict[str, Any]:
        index = int(output.get("index") or 1)
        asset_id = short_asset_id(str(task.get("id") or ""), index)
        destination = library_asset_path(user_id, asset_id)
        _preserve_short_file(source, destination)
        now = int(time.time())
        row = {
            "id": asset_id,
            "task_id": str(task.get("id") or ""),
            "index": index,
            "title": str(task.get("title") or "Vídeo").strip()[:180],
            "short_title": f"{str(task.get('title') or 'Vídeo').strip()[:150]} - Short {index:02d}",
            "channel": str(task.get("channel") or "YouTube").strip()[:120],
            "source_url": str(task.get("url") or "").strip(),
            "video_id": str(task.get("video_id") or "").strip(),
            "thumbnail_url": str(task.get("thumbnail_url") or "").strip(),
            "created_at": int(task.get("created_at") or now),
            "updated_at": now,
            "start": float(output.get("start") or 0),
            "end": float(output.get("end") or 0),
            "duration": float(output.get("duration") or 0),
            "captions_requested": bool(output.get("captions_requested", False)),
            "captions_applied": bool(output.get("captions_applied", False)),
            "selection_method": selection_method or str(task.get("selection_method") or ""),
            "layout": layout or str(task.get("layout") or ""),
            "quality": quality or str(task.get("quality") or ""),
            "output_format": str(output.get("output_format") or task.get("output_format") or "vertical"),
            "smart_follow": bool(output.get("smart_follow", task.get("smart_follow", False))),
            "smart_compose": bool(output.get("smart_compose", task.get("smart_compose", False))),
            "smart_motion": str(output.get("smart_motion") or task.get("smart_motion") or "smooth"),
            "project_id": str(output.get("project_id") or task.get("project_id") or "").strip() or None,
            "saved_path": output.get("saved_path"),
            "size_bytes": destination.stat().st_size if destination.exists() else None,
        }
        with _SHORTS_LOCK:
            rows = load_shorts_library(user_id)
            previous = next((x for x in rows if str(x.get("id") or "") == asset_id), None)
            if previous:
                # Preserve informações de salvamento já existentes.
                row["saved_path"] = row.get("saved_path") or previous.get("saved_path")
                row["saved_at"] = previous.get("saved_at")
                row["project_id"] = row.get("project_id") or previous.get("project_id")
            rows = [row] + [x for x in rows if str(x.get("id") or "") != asset_id]
            write_shorts_library(user_id, rows)
        return row

    def update_short_library_asset(user_id: str, asset_id: str, **changes: Any) -> dict[str, Any] | None:
        with _SHORTS_LOCK:
            rows = load_shorts_library(user_id)
            found = None
            for row in rows:
                if str(row.get("id") or "") == asset_id:
                    row.update(changes)
                    row["updated_at"] = int(time.time())
                    found = dict(row)
                    break
            if found is not None:
                write_shorts_library(user_id, rows)
            return found

    def sync_existing_shorts_to_library(user_id: str) -> None:
        """Migra Shorts concluídos por versões 3.4.0–3.4.2 somente ao abrir o filtro Shorts."""
        known = {str(x.get("id") or "") for x in load_shorts_library(user_id)}
        deleted = load_deleted_short_ids(user_id)
        for task in load_tasks(user_id):
            if task.get("kind") != "generate" or task.get("status") != "done":
                continue
            for output in task.get("outputs") or []:
                # Shorts que o usuário moveu para a Lixeira ficam preservados no disco,
                # mas NÃO podem reaparecer automaticamente na Biblioteca durante a migração lazy.
                if bool(output.get("library_trashed", False)):
                    continue
                # v3.5.14+: estes Shorts aguardam escolha explícita do usuário e não
                # podem ser migrados automaticamente ao abrir a Biblioteca.
                if bool(output.get("library_pending", False)) and not output.get("library_id"):
                    continue
                try:
                    index = int(output.get("index") or 0)
                except Exception:
                    continue
                if index < 1:
                    continue
                asset_id = short_asset_id(str(task.get("id") or ""), index)
                if asset_id in known or asset_id in deleted:
                    continue
                source = core.DATA_ROOT / "shorts" / user_id / str(task.get("id") or "") / str(output.get("filename") or "")
                if not source.exists() or not source.is_file():
                    continue
                try:
                    persist_short_asset(user_id, task, output, source)
                    known.add(asset_id)
                except Exception:
                    continue

    def load_tasks(user_id: str) -> list[dict[str, Any]]:
        path = tasks_path(user_id)
        if not path.exists():
            return []
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
            return rows if isinstance(rows, list) else []
        except Exception:
            return []

    def write_tasks(user_id: str, rows: list[dict[str, Any]]) -> None:
        core._atomic_write_json(tasks_path(user_id), rows[:_SHORTS_MAX_TASKS])

    def get_task(user_id: str, task_id: str) -> dict[str, Any] | None:
        return next((x for x in load_tasks(user_id) if str(x.get("id") or "") == task_id), None)

    def update_task(user_id: str, task_id: str, **changes: Any) -> dict[str, Any] | None:
        with _SHORTS_LOCK:
            rows = load_tasks(user_id)
            found = None
            for row in rows:
                if str(row.get("id") or "") == task_id:
                    row.update(changes)
                    row["updated_at"] = int(time.time())
                    found = dict(row)
                    break
            if found is not None:
                write_tasks(user_id, rows)
            return found

    def create_task(user_id: str, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        now = int(time.time())
        task = {
            "id": uuid.uuid4().hex,
            "kind": kind,
            "status": "queued",
            "stage": "Na fila",
            "progress": 0,
            "url": str(payload.get("url") or "").strip(),
            "video_id": str(payload.get("video_id") or "").strip(),
            "source_job_id": str(payload.get("source_job_id") or "").strip() or None,
            "title": str(payload.get("title") or "Vídeo do YouTube").strip()[:180],
            "channel": str(payload.get("channel") or "YouTube").strip()[:120],
            "thumbnail_url": str(payload.get("thumbnail_url") or "").strip(),
            "output_format": str(payload.get("output_format") or "vertical"),
            "layout": str(payload.get("layout") or ""),
            "quality": str(payload.get("quality") or ""),
            "performance_profile": str(payload.get("performance_profile") or "fast"),
            "smart_follow": _flag(payload.get("smart_follow", False)),
            "smart_compose": _flag(payload.get("smart_compose", False)),
            "smart_motion": str(payload.get("smart_motion") or "smooth"),
            "target_count": max(0, int(payload.get("count") or 0)) if str(payload.get("count") or "").strip() else 0,
            "duration_seconds": max(0, int(payload.get("duration_seconds") or 0)) if str(payload.get("duration_seconds") or "").strip() else 0,
            "created_at": now,
            "updated_at": now,
            "error": None,
            "outputs": [],
        }
        with _SHORTS_LOCK:
            rows = [task] + load_tasks(user_id)
            write_tasks(user_id, rows)
        return task

    def as_segment_dicts(raw: Any) -> list[dict[str, Any]]:
        """Normaliza legendas/transcrições de formatos antigos e novos.

        Algumas fontes entregam start+duration; outras start+end. Há também
        históricos antigos em que a duração ficou ausente. O Shorts Studio
        não deve parar por causa dessa diferença de formato.
        """
        out: list[dict[str, Any]] = []

        def num(value: Any, default: float = 0.0) -> float:
            try:
                return float(value)
            except Exception:
                return float(default)

        for seg in raw or []:
            if isinstance(seg, dict):
                text_value = seg.get("text") or seg.get("caption") or seg.get("sentence") or ""
                start_value = seg.get("start")
                if start_value is None:
                    start_value = seg.get("start_time", seg.get("begin", seg.get("offset", 0)))
                end_value = seg.get("end")
                if end_value is None:
                    end_value = seg.get("end_time")
                duration_value = seg.get("duration")
            else:
                text_value = getattr(seg, "text", "") or ""
                start_value = getattr(seg, "start", getattr(seg, "start_time", 0))
                end_value = getattr(seg, "end", getattr(seg, "end_time", None))
                duration_value = getattr(seg, "duration", None)

            text_value = str(text_value or "").strip()
            if not text_value:
                continue
            start = max(0.0, num(start_value, 0.0))
            duration = num(duration_value, 0.0) if duration_value is not None else 0.0
            if duration <= 0.0 and end_value is not None:
                duration = max(0.0, num(end_value, start) - start)
            out.append({"text": text_value, "start": start, "duration": max(0.0, duration)})

        out.sort(key=lambda x: float(x.get("start") or 0.0))
        # Infere durações ausentes a partir do próximo timestamp. Isso mantém
        # compatibilidade com transcrições salvas por versões anteriores.
        positive = [float(x.get("duration") or 0.0) for x in out if float(x.get("duration") or 0.0) > 0.08]
        default_duration = sorted(positive)[len(positive)//2] if positive else 2.0
        default_duration = max(0.5, min(8.0, default_duration))
        for i, row in enumerate(out):
            dur = float(row.get("duration") or 0.0)
            if dur > 0.08:
                continue
            start = float(row.get("start") or 0.0)
            if i + 1 < len(out):
                nxt = float(out[i+1].get("start") or 0.0)
                inferred = nxt - start
                if inferred > 0.08:
                    row["duration"] = max(0.10, min(12.0, inferred))
                    continue
            row["duration"] = default_duration
        return out

    def speech_segments(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        noise = re.compile(r"^\s*[\[(]?(música|music|som|sound|aplausos|applause|silêncio|silence)[\])]?\s*$", re.I)
        return [x for x in rows if str(x.get("text") or "").strip() and not noise.match(str(x.get("text") or "").strip())]

    def find_library_source(user_id: str, video_id: str):
        for job in core._user_jobs(user_id):
            if str(job.get("video_id") or "") != video_id or job.get("status") != "done":
                continue
            video = core.find_job_video(str(job.get("id") or "")) if job.get("video_ready") else None
            segments = as_segment_dicts(job.get("segments") or []) if job.get("transcript_available") else []
            return job, video, segments
        return None, None, []

    def find_local_library_source(user_id: str, job_id: str):
        job = next((item for item in core._user_jobs(user_id) if str(item.get("id") or "") == str(job_id)), None)
        if not job or job.get("status") != "done" or not job.get("video_ready"):
            return None, None, []
        video = core.find_job_video(str(job.get("id") or ""))
        if not video or not Path(video).exists():
            return None, None, []
        segments = as_segment_dicts(job.get("segments") or []) if job.get("transcript_available") else []
        return job, Path(video), segments

    def new_internal_job(user_id: str, url: str, video_id: str, quality: str = "1080") -> dict[str, Any]:
        jid = uuid.uuid4().hex
        now = int(time.time())
        job = {
            "id": jid,
            "user_id": user_id,
            "url": url,
            "video_id": video_id,
            "language": "auto",
            "timestamps": True,
            "allow_whisper": True,
            "video_quality_request": quality,
            "project_id": None,
            "favorite": False,
            "tags": [],
            "source_type": "youtube",
            "thumbnail_url": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
            "transcript_available": False,
            "media_only": False,
            "segments": [],
            "trashed_at": None,
            "status": "processing",
            "stage": "Preparando Shorts...",
            "progress": 1,
            "title": "Fonte temporária do Shorts Studio",
            "source": None,
            "audio_ready": False,
            "video_ready": False,
            "video_quality": None,
            "video_height": None,
            "video_is_full_hd": False,
            "error": None,
            "internal_hidden": True,
            "created_at": now,
            "updated_at": now,
        }
        core.save_job(job)
        return job

    def cleanup_internal(job: dict[str, Any] | None) -> None:
        if not job:
            return
        try:
            core._delete_job_files(job)
        except Exception:
            pass

    def get_transcript_and_video(user_id: str, task_id: str, url: str, video_id: str, quality: str, source_job_id: str | None = None, performance_profile: str = "fast"):
        if source_job_id:
            library_job, library_video, library_segments = find_local_library_source(user_id, source_job_id)
            if not library_job or not library_video:
                raise RuntimeError("A mídia selecionada não está disponível na Biblioteca.")
            return library_video, speech_segments(library_segments), str(library_job.get("detected_language") or "auto"), None, True
        library_job, library_video, library_segments = find_library_source(user_id, video_id)
        temp_job = None
        video_path = library_video
        segments = speech_segments(library_segments)
        detected = str((library_job or {}).get("detected_language") or "auto")
        reused = bool(video_path or segments)
        try:
            if not segments:
                update_task(user_id, task_id, stage="Procurando legendas do vídeo...", progress=18)
                try:
                    caps, detected = core.fetch_youtube_captions(video_id, "auto")
                    segments = speech_segments(as_segment_dicts(caps))
                except Exception:
                    segments = []
                if not segments:
                    if str(performance_profile) == "fast":
                        update_task(user_id, task_id, stage="Sem legenda útil. Modo rápido vai usar a timeline da mídia...", progress=26, media_only=True)
                    else:
                        temp_job = new_internal_job(user_id, url, video_id, quality)
                        update_task(user_id, task_id, stage="Sem legenda útil. Transcrevendo com Whisper...", progress=26)
                        whisper_rows, detected, _ = core.whisper_transcribe(url, "auto", temp_job["id"])
                        segments = speech_segments(as_segment_dicts(whisper_rows))
            if not video_path:
                if temp_job is None:
                    temp_job = new_internal_job(user_id, url, video_id, quality)
                update_task(user_id, task_id, stage="Baixando o vídeo fonte...", progress=42)
                video_path = core.download_video_preview(url, temp_job["id"])
            if not video_path or not Path(video_path).exists():
                raise RuntimeError("O vídeo fonte não ficou disponível para a montagem.")
            if not segments:
                update_task(user_id, task_id, stage="Sem fala útil. Selecionando trechos pela timeline da mídia...", progress=48, media_only=True)
            return Path(video_path), segments, detected, temp_job, reused
        except Exception:
            cleanup_internal(temp_job)
            raise

    def tokenize(text: str) -> list[str]:
        stop = {
            "para", "com", "que", "uma", "por", "como", "isso", "esse", "essa", "dos", "das", "mais", "muito", "tem", "não", "sim", "the", "and", "you", "that", "this", "with", "from", "have", "uma", "pra", "porque", "quando", "então", "ele", "ela", "eles", "elas", "ser", "estar", "foi", "são",
        }
        return [w for w in re.findall(r"[A-Za-zÀ-ÿ0-9]{3,}", text.casefold()) if w not in stop]

    def build_candidates(segments: list[dict[str, Any]], target_seconds: int) -> list[dict[str, Any]]:
        if not segments:
            return []
        all_tokens = Counter(tokenize(" ".join(str(x.get("text") or "") for x in segments)))
        hooks = re.compile(r"\b(segredo|atenção|olha|importante|melhor|pior|nunca|sempre|descobri|verdade|erro|problema|resultado|como|por que|porque|você|imagine|agora|what|why|how|secret|important|never|best|worst|mistake|result)\b", re.I)
        candidates: list[dict[str, Any]] = []
        step = max(1, len(segments) // 80)
        for idx in range(0, len(segments), step):
            start = max(0.0, float(segments[idx]["start"]) - 0.35)
            desired_end = start + target_seconds
            chosen = [s for s in segments[idx:] if float(s["start"]) < desired_end and float(s["start"]) + float(s["duration"]) > start]
            if not chosen:
                continue
            actual_end = min(desired_end, max(float(s["start"]) + float(s["duration"]) for s in chosen) + 0.25)
            if actual_end - start < min(8.0, target_seconds * 0.45):
                continue
            text = re.sub(r"\s+", " ", " ".join(str(s["text"]) for s in chosen)).strip()
            words = tokenize(text)
            if len(words) < 10:
                continue
            hook_score = len(hooks.findall(text)) * 4.0
            punctuation = text.count("?") * 5.0 + text.count("!") * 2.5
            numeric = len(re.findall(r"\b\d+(?:[.,]\d+)?\b", text)) * 1.2
            rare = sum(1.0 / max(1, all_tokens[w]) for w in set(words)) * 8.0
            density = min(len(words), target_seconds * 2.8) / max(1.0, target_seconds) * 5.0
            opening_penalty = 3.0 if start < 4.0 else 0.0
            score = hook_score + punctuation + numeric + rare + density - opening_penalty
            candidates.append({
                "id": len(candidates), "start": round(start, 3), "end": round(actual_end, 3),
                "duration": round(actual_end - start, 3), "text": text[:1500], "score": round(score, 3),
            })
        candidates.sort(key=lambda x: float(x["score"]), reverse=True)
        return candidates[:60]

    def duration_fallback_candidates(segments: list[dict[str, Any]], count: int, target_seconds: int, media_duration: float) -> list[dict[str, Any]]:
        """Cria janelas válidas diretamente na timeline do vídeo.

        É um fallback, não substitui a análise de melhores momentos. Ele entra
        apenas quando a transcrição não produz candidatos suficientes (ex.:
        letras de música muito esparsas, timestamps antigos ou legenda mal
        segmentada). Assim um vídeo longo nunca falha só por causa da legenda.
        """
        count = max(1, int(count))
        target = max(1.0, float(target_seconds))
        transcript_end = 0.0
        for s in segments:
            transcript_end = max(transcript_end, float(s.get("start") or 0.0) + max(0.0, float(s.get("duration") or 0.0)))
        total = max(float(media_duration or 0.0), transcript_end)
        if total <= 0.5:
            return []

        clip_len = min(target, total)
        max_start = max(0.0, total - clip_len)
        starts: list[float] = []

        # Quando cabe tudo sem sobreposição, distribui as janelas pela timeline.
        if total >= clip_len * count:
            free = max(0.0, total - clip_len * count)
            gap = free / float(count + 1)
            for i in range(count):
                starts.append(gap + i * (clip_len + gap))
        elif count == 1:
            starts = [max_start / 2.0]
        else:
            # Se o usuário pedir mais duração do que o vídeo comporta sem
            # sobreposição, ainda gera a quantidade solicitada, espaçando os inícios.
            starts = [max_start * i / float(count - 1) for i in range(count)]

        rows: list[dict[str, Any]] = []
        for i, start in enumerate(starts):
            start = max(0.0, min(max_start, start))
            end = min(total, start + clip_len)
            overlap = [s for s in segments if float(s.get("start") or 0.0) < end and float(s.get("start") or 0.0) + float(s.get("duration") or 0.0) > start]
            text_value = re.sub(r"\s+", " ", " ".join(str(s.get("text") or "") for s in overlap)).strip()
            rows.append({
                "id": 100000 + i,
                "start": round(start, 3),
                "end": round(end, 3),
                "duration": round(max(0.1, end - start), 3),
                "text": text_value[:1500],
                "score": -1000.0 + i,
                "fallback": True,
            })
        return rows

    def non_overlapping(rows: list[dict[str, Any]], count: int) -> list[dict[str, Any]]:
        picked: list[dict[str, Any]] = []
        for row in rows:
            if any(min(float(row["end"]), float(p["end"])) - max(float(row["start"]), float(p["start"])) > min(float(row["duration"]), float(p["duration"])) * 0.30 for p in picked):
                continue
            picked.append(row)
            if len(picked) >= count:
                break
        return picked

    def ai_choose(user_id: str, candidates: list[dict[str, Any]], count: int) -> list[int]:
        if not candidates or not core._load_zen_key(user_id):
            return []
        compact = []
        for row in candidates[:35]:
            compact.append({"id": row["id"], "inicio": row["start"], "fim": row["end"], "texto": row["text"][:520]})
        prompt = (
            "Você está selecionando os melhores trechos de um vídeo para vídeos verticais curtos. "
            "Escolha momentos que funcionem isoladamente, tenham começo compreensível, ideia forte, curiosidade, emoção, explicação útil ou conclusão clara. "
            "Evite trechos redundantes e escolha momentos diferentes entre si. "
            f"Escolha exatamente {count} IDs. Responda SOMENTE JSON no formato {{\"ids\":[1,2]}}.\n\nCANDIDATOS:\n"
            + json.dumps(compact, ensure_ascii=False)
        )
        try:
            text = core._claude_generate(prompt, user_id, timeout=120)
            match = re.search(r"\{[\s\S]*?\}", text)
            data = json.loads(match.group(0) if match else text)
            ids = [int(x) for x in (data.get("ids") or []) if str(x).lstrip("-").isdigit()]
            valid = {int(x["id"]) for x in candidates}
            return [x for x in ids if x in valid][:count]
        except Exception:
            return []

    def choose_moments(user_id: str, segments: list[dict[str, Any]], count: int, target_seconds: int, use_ai: bool, media_duration: float = 0.0):
        candidates = build_candidates(segments, target_seconds)
        fallback = duration_fallback_candidates(segments, count, target_seconds, media_duration)

        # Não bloqueia mais a montagem apenas porque a legenda veio mal segmentada.
        if not candidates:
            if fallback:
                return fallback[:count], "Timeline do vídeo (fallback de transcrição)"
            raise RuntimeError("Não foi possível identificar a duração do vídeo para montar os Shorts.")

        method = "Análise local da transcrição"
        ordered = candidates
        if use_ai:
            ids = ai_choose(user_id, candidates, count)
            if ids:
                by_id = {int(x["id"]): x for x in candidates}
                preferred = [by_id[x] for x in ids if x in by_id]
                remaining = [x for x in candidates if int(x["id"]) not in set(ids)]
                ordered = preferred + remaining
                method = "IA + análise da transcrição"

        picked = non_overlapping(ordered, count)
        if len(picked) < count:
            for row in candidates:
                if row not in picked:
                    picked.append(row)
                    if len(picked) >= count:
                        break

        # Se a análise textual não fornecer a quantidade pedida, completa com
        # janelas da duração real do vídeo, evitando sobreposição forte com as já escolhidas.
        if len(picked) < count and fallback:
            for row in fallback:
                if any(min(float(row["end"]), float(p["end"])) - max(float(row["start"]), float(p["start"])) > min(float(row["duration"]), float(p["duration"])) * 0.40 for p in picked):
                    continue
                picked.append(row)
                if len(picked) >= count:
                    break
            # Se ainda faltar, quantidade solicitada tem prioridade sobre não sobrepor.
            if len(picked) < count:
                for row in fallback:
                    if row not in picked:
                        picked.append(row)
                        if len(picked) >= count:
                            break
            if any(bool(x.get("fallback")) for x in picked):
                method += " + fallback pela duração do vídeo"

        return picked[:count], method

    def ass_time(seconds: float) -> str:
        seconds = max(0.0, seconds)
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = seconds % 60
        return f"{h}:{m:02d}:{s:05.2f}"

    def ass_escape(text: str) -> str:
        text = re.sub(r"\s+", " ", text).strip().replace("{", "(").replace("}", ")")
        if len(text) > 90:
            cut = text.rfind(" ", 0, 55)
            if cut < 25:
                cut = 55
            text = text[:cut] + r"\N" + text[cut:].lstrip()
        return text

    def write_ass(path: Path, segments: list[dict[str, Any]], clip_start: float, clip_end: float, width: int, height: int) -> bool:
        lines = [
            "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "WrapStyle: 2", "ScaledBorderAndShadow: yes", "",
            "[V4+ Styles]",
            "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
            f"Style: Shorts,Arial,{max(38, int(height*0.035))},&H00FFFFFF,&H00FFFFFF,&H00000000,&H60000000,-1,0,0,0,100,100,0,0,1,4,1,2,70,70,{max(90,int(height*0.09))},1", "",
            "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
        ]
        added = 0
        for seg in segments:
            seg_start = float(seg["start"])
            seg_end = seg_start + float(seg["duration"])
            if seg_end <= clip_start or seg_start >= clip_end:
                continue
            start = max(0.0, seg_start - clip_start)
            end = min(clip_end - clip_start, seg_end - clip_start)
            if end - start < 0.08:
                continue
            lines.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Shorts,,0,0,0,,{ass_escape(str(seg['text']))}")
            added += 1
        path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
        return bool(added)

    def render_short(ffmpeg: str, source: Path, out: Path, segments: list[dict[str, Any]], moment: dict[str, Any], captions: bool, layout: str, quality: str, output_format: str, index: int, *, performance_profile: str = "fast", smart_follow: bool = False, smart_compose: bool = False, smart_motion: str = "smooth") -> tuple[bool, str]:
        width, height = _output_dimensions(output_format, quality)
        start = float(moment["start"])
        duration = max(1.0, float(moment["end"]) - start)
        caption_applied = False
        ass_name = f"short_{index:02d}.ass"
        ass_path = out.parent / ass_name
        if captions:
            caption_applied = write_ass(ass_path, segments, start, start + duration, width, height)

        smart_enabled = bool((smart_follow or smart_compose) and layout in {"crop", "fit"})
        smart_analysis = None
        if smart_enabled:
            try:
                smart_analysis = _smart_reframe_analysis(
                    source, start, duration, follow=bool(smart_follow), compose=bool(smart_compose), motion=smart_motion
                )
            except Exception:
                smart_analysis = None

        # Alguns vídeos do YouTube já trazem letterbox/pillarbox gravado dentro do arquivo.
        # Scale/crop sozinho não consegue apagar barras que fazem parte dos pixels do vídeo.
        # No Preenchimento Total removemos essas bordas primeiro e só então criamos o 9:16.
        source_crop = None
        if layout in {"fit", "safe"}:
            try:
                source_crop = _detect_embedded_black_bars(ffmpeg, source, start, duration)
            except Exception:
                source_crop = None

        # IMPORTANTE: o modo FIT é decidido primeiro e isolado dos demais.
        # Isso impede qualquer caminho do Auto Reframe de trocar o preenchimento total
        # aprovado na v3.4.7 por uma composição com barras/fundo/overlay.
        if layout == "fit":
            if smart_analysis and int(smart_analysis.get("detected_samples") or 0) > 0 and bool(smart_compose):
                # Só a Composição Inteligente tem autorização para abrir/adaptar a cena.
                video_chain = _build_smart_video_chain(width, height, smart_analysis, compose=True, source_crop=source_crop)
            elif smart_analysis and int(smart_analysis.get("detected_samples") or 0) > 0 and bool(smart_follow):
                # Seguir pessoa NÃO muda o tipo de preenchimento: apenas desloca o crop horizontal.
                video_chain = _build_smart_follow_full_chain(width, height, smart_analysis, source_crop=source_crop)
            else:
                # Cadeia exata da v3.4.7, com SAR normalizado.
                pre = _source_crop_prefix(source_crop)
                video_chain = (
                    f"[0:v]{pre}scale={width}:{height}:force_original_aspect_ratio=increase,"
                    f"crop={width}:{height},setsar=1[base]"
                )
        elif layout == "crop":
            if smart_analysis and int(smart_analysis.get("detected_samples") or 0) > 0:
                video_chain = _build_smart_video_chain(width, height, smart_analysis, compose=bool(smart_compose))
            else:
                video_chain = f"[0:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},setsar=1[base]"
        elif layout == "safe":
            # Remove somente as bordas genuínas da fonte e preserva a composição
            # principal sobre um fundo tratado. Assim não há barras pretas sem aplicar
            # o zoom agressivo necessário para preencher todo o canvas.
            blur = max(12, int(width / 60))
            pre = _source_crop_prefix(source_crop)
            video_chain = (
                f"[0:v]{pre}scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},boxblur={blur}:2[bg];"
                f"[0:v]{pre}scale={width}:{height}:force_original_aspect_ratio=decrease[fg];"
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[base]"
            )
        else:
            blur = max(12, int(width / 60))
            video_chain = (
                f"[0:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},boxblur={blur}:2[bg];"
                f"[0:v]scale={width}:{height}:force_original_aspect_ratio=decrease[fg];"
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[base]"
            )
        if caption_applied:
            # cwd is the task folder, so a simple relative ASS path also works on Windows paths containing spaces.
            filter_complex = video_chain + f";[base]ass={ass_name}[vout]"
        else:
            filter_complex = video_chain.rsplit("[base]", 1)[0] + "[vout]"

        base = [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{start:.3f}", "-i", str(source), "-t", f"{duration:.3f}",
            "-filter_complex", filter_complex, "-map", "[vout]", "-map", "0:a?",
        ]
        trailer = ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart", str(out)]
        try:
            failures: list[str] = []
            for encoder_label, encoder_args in _encoder_attempts(ffmpeg, performance_profile, quality):
                try:
                    out.unlink(missing_ok=True)
                except OSError:
                    pass
                cmd = [*base, *encoder_args, *trailer]
                result = subprocess.run(cmd, cwd=str(out.parent), capture_output=True, text=True, timeout=1200, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                final_caption_applied = bool(caption_applied)
                if result.returncode == 0 and out.exists() and out.stat().st_size >= 20_000:
                    return final_caption_applied, encoder_label
                detail = (result.stderr or result.stdout or "FFmpeg não gerou o arquivo.")[-700:]
                if caption_applied:
                    fallback = video_chain.rsplit("[base]", 1)[0] + "[vout]"
                    cmd2 = cmd[:]
                    pos = cmd2.index("-filter_complex") + 1
                    cmd2[pos] = fallback
                    result2 = subprocess.run(cmd2, cwd=str(out.parent), capture_output=True, text=True, timeout=1200, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                    if result2.returncode == 0 and out.exists() and out.stat().st_size >= 20_000:
                        return False, encoder_label
                    detail = (result2.stderr or result2.stdout or detail)[-700:]
                failures.append(f"{encoder_label}: {detail}")
            raise RuntimeError(f"Falha ao renderizar o Short: {' | '.join(failures)[-1600:]}")
        finally:
            try:
                ass_path.unlink(missing_ok=True)
            except Exception:
                pass

    def download_worker(user_id: str, task_id: str, url: str, video_id: str, title: str, quality: str) -> None:
        temp_job = None
        with _SHORTS_PROCESSING:
            try:
                update_task(user_id, task_id, status="processing", stage="Preparando download do vídeo...", progress=12)
                library_job, library_video, _ = find_library_source(user_id, video_id)
                source = library_video
                if source is None:
                    temp_job = new_internal_job(user_id, url, video_id, quality)
                    source = core.download_video_preview(url, temp_job["id"])
                update_task(user_id, task_id, stage="Salvando na pasta Vídeo...", progress=88)
                _, folders = core._ensure_storage_tree(user_id)
                filename = core._safe_download_name(title, "video") + (Path(source).suffix.lower() or ".mp4")
                dest = core._unique_destination(folders["video"], filename)
                shutil.copy2(source, dest)
                pseudo = {"id": task_id, "title": title, "url": url}
                try:
                    core._log_download(user_id, pseudo, "video", dest.name, dest.stat().st_size, str(dest))
                except Exception:
                    pass
                update_task(user_id, task_id, status="done", stage="Vídeo salvo", progress=100, saved_path=str(dest), filename=dest.name)
            except Exception as exc:
                update_task(user_id, task_id, status="error", stage="Falha no download", error=str(exc), progress=100)
            finally:
                cleanup_internal(temp_job)

    def generate_worker(user_id: str, task_id: str, payload: dict[str, Any]) -> None:
        temp_job = None
        with _SHORTS_PROCESSING:
            try:
                url = str(payload.get("url") or ""); video_id = str(payload.get("video_id") or "")
                count = int(payload["count"]); duration = int(payload["duration_seconds"])
                captions = bool(payload["captions"]); use_ai = bool(payload["use_ai"])
                layout = str(payload["layout"]); quality = str(payload["quality"])
                output_format = str(payload.get("output_format") or "vertical")
                performance_profile, _ = _render_profile(str(payload.get("performance_profile") or "fast"))
                smart_follow = _flag(payload.get("smart_follow", False))
                smart_compose = _flag(payload.get("smart_compose", False))
                smart_motion = str(payload.get("smart_motion") or "smooth")
                source_job_id = str(payload.get("source_job_id") or "").strip() or None
                update_task(user_id, task_id, status="processing", stage="Preparando a fonte...", progress=6)
                source, segments, detected, temp_job, reused = get_transcript_and_video(user_id, task_id, url, video_id, quality, source_job_id, performance_profile)
                ffmpeg = core._ffmpeg_location()
                if not ffmpeg:
                    raise RuntimeError("FFmpeg não foi encontrado. Execute o reparo/instalador do RedScribe novamente.")
                media_duration = _probe_media_duration(ffmpeg, source)
                effective_quality, source_height = _effective_render_quality(source, quality)
                if effective_quality != quality:
                    update_task(user_id, task_id, stage=f"A fonte está em {source_height}p. Renderizando na melhor qualidade nativa...", progress=50)
                captions = bool(captions and segments)
                update_task(user_id, task_id, stage="Escolhendo os melhores momentos...", progress=52, detected_language=detected, reused_library=reused)
                moments, method = choose_moments(user_id, segments, count, duration, use_ai, media_duration=media_duration)
                folder = task_root(user_id, task_id)
                folder.mkdir(parents=True, exist_ok=True)
                if (smart_follow or smart_compose) and layout in {"crop", "fit"}:
                    update_task(user_id, task_id, stage="Preparando enquadramento inteligente...", progress=56)

                total = len(moments)
                worker_count = _render_worker_count(performance_profile, effective_quality, total)
                update_task(
                    user_id, task_id,
                    stage=f"Renderizando {total} Short(s)...",
                    progress=58,
                    selection_method=method,
                    render_workers=worker_count,
                    source_reused=bool(reused),
                    output_format=output_format,
                    requested_quality=quality,
                    effective_quality=effective_quality,
                    source_height=source_height,
                    performance_profile=performance_profile,
                    captions_skipped_no_speech=bool(payload.get("captions") and not segments),
                )

                def render_one(idx: int, moment: dict[str, Any]):
                    out = folder / f"short_{idx:02d}.mp4"
                    caption_applied, encoder_used = render_short(
                        ffmpeg, source, out, segments, moment, captions, layout, effective_quality, output_format, idx,
                        performance_profile=performance_profile, smart_follow=smart_follow, smart_compose=smart_compose, smart_motion=smart_motion,
                    )
                    output_row = {
                        "index": idx, "filename": out.name, "url": f"/shorts/media/{task_id}/{out.name}",
                        "start": moment["start"], "end": moment["end"], "duration": moment["duration"],
                        "captions_requested": captions, "captions_applied": bool(caption_applied), "saved_path": None,
                        "smart_follow": smart_follow, "smart_compose": smart_compose, "smart_motion": smart_motion,
                        "output_format": output_format, "quality": effective_quality, "encoder": encoder_used,
                        "library_pending": True,
                    }
                    return idx, output_row

                outputs_by_index: dict[int, dict[str, Any]] = {}
                with ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="redscribe-short") as executor:
                    futures = [executor.submit(render_one, idx, moment) for idx, moment in enumerate(moments, start=1)]
                    for future in as_completed(futures):
                        idx, output_row = future.result()
                        outputs_by_index[idx] = output_row
                        outputs = [outputs_by_index[key] for key in sorted(outputs_by_index)]
                        ready = len(outputs)
                        progress = 58 + int(ready / max(1, total) * 40)
                        update_task(
                            user_id, task_id,
                            stage=f"{ready} de {total} Short(s) prontos — o restante continua renderizando..." if ready < total else f"{total} Short(s) renderizado(s)",
                            progress=min(98, progress),
                            outputs=outputs,
                        )

                outputs = [outputs_by_index[key] for key in sorted(outputs_by_index)]
                update_task(user_id, task_id, status="done", stage=f"{len(outputs)} Short(s) pronto(s)", progress=100, outputs=outputs, selection_method=method)
            except Exception as exc:
                update_task(user_id, task_id, status="error", stage="Falha ao montar Shorts", error=str(exc), progress=100)
            finally:
                cleanup_internal(temp_job)

    @app.get("/api/shorts/tasks")
    @core.login_required
    def shorts_tasks_api():
        user = core.current_user()
        rows = load_tasks(user["id"])
        return jsonify({"items": rows[:40]})

    @app.get("/api/shorts/library-sources")
    @core.login_required
    def shorts_library_sources_api():
        user = core.current_user()
        items = []
        for job in core._user_jobs(user["id"]):
            if job.get("status") != "done" or not job.get("video_ready"):
                continue
            if not core.find_job_video(str(job.get("id") or "")):
                continue
            items.append({
                "id": str(job.get("id") or ""), "title": str(job.get("title") or "Mídia da Biblioteca"),
                "channel": "Arquivo da Biblioteca", "duration_label": str(job.get("duration_label") or ""),
                "thumbnail_url": str(job.get("thumbnail_url") or ""), "source_kind": str(job.get("source_type") or "local"),
            })
        return jsonify({"items": items[:80]})

    @app.get("/api/shorts/tasks/<task_id>")
    @core.login_required
    def shorts_task_api(task_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", task_id):
            return jsonify({"error": "Tarefa inválida."}), 400
        task = get_task(user["id"], task_id)
        if not task:
            return jsonify({"error": "Tarefa de Shorts não encontrada."}), 404
        return jsonify(task)

    @app.post("/api/shorts/download")
    @core.login_required
    def shorts_download_api():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        if not bool(payload.get("confirmed_rights", False)):
            return jsonify({"error": "Confirme que você tem permissão para baixar/reutilizar este conteúdo."}), 400
        url = str(payload.get("url") or "").strip()
        try:
            video_id = core.extract_video_id(url)
        except Exception as exc:
            return jsonify({"error": str(exc)}), 400
        quality = str(payload.get("quality") or "1080")
        if quality not in {"720", "1080", "2160", "best"}: quality = "1080"
        enriched = dict(payload); enriched["video_id"] = video_id
        task = create_task(user["id"], "download", enriched)
        threading.Thread(target=download_worker, args=(user["id"], task["id"], url, video_id, task["title"], quality), daemon=True).start()
        return jsonify({"task": task}), 202

    @app.post("/api/shorts/generate")
    @core.login_required
    def shorts_generate_api():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        if not bool(payload.get("confirmed_rights", False)):
            return jsonify({"error": "Confirme que você tem permissão para reutilizar este conteúdo na criação dos Shorts."}), 400
        source_job_id = str(payload.get("source_job_id") or "").strip()
        url = str(payload.get("url") or "").strip()
        if source_job_id:
            source_job, source_video, _ = find_local_library_source(user["id"], source_job_id)
            if not source_job or not source_video:
                return jsonify({"error": "A mídia selecionada não está disponível na Biblioteca."}), 404
            video_id = f"library-{source_job_id}"
            payload = {**payload, "title": str(source_job.get("title") or "Mídia da Biblioteca"), "channel": "Arquivo da Biblioteca", "thumbnail_url": str(source_job.get("thumbnail_url") or "")}
        else:
            try:
                video_id = core.extract_video_id(url)
            except Exception as exc:
                return jsonify({"error": str(exc)}), 400
        try:
            count = max(1, min(50, int(payload.get("count") or 2)))
            duration = max(15, min(900, int(payload.get("duration_seconds") or 60)))
        except Exception:
            return jsonify({"error": "Quantidade ou duração inválida."}), 400
        output_format = str(payload.get("output_format") or "vertical")
        if output_format not in _FORMAT_PRESETS: output_format = "vertical"
        layout = str(payload.get("layout") or "blur")
        if layout not in {"blur", "crop", "fit", "safe"}: layout = "blur"
        quality = str(payload.get("quality") or "1080")
        if quality not in {"720", "1080", "2160"}: quality = "1080"
        performance_profile, _ = _render_profile(str(payload.get("performance_profile") or "fast"))
        smart_follow = _flag(payload.get("smart_follow", False))
        smart_compose = _flag(payload.get("smart_compose", False))
        smart_motion = str(payload.get("smart_motion") or "smooth")
        if smart_motion not in {"smooth", "normal", "dynamic"}: smart_motion = "smooth"
        # Auto Reframe so e aplicado em modos que realmente ocupam o 9:16.
        if layout not in {"crop", "fit"}:
            smart_follow = False
            smart_compose = False
        normalized = dict(payload)
        normalized.update({
            "video_id": video_id, "source_job_id": source_job_id or None, "count": count, "duration_seconds": duration, "output_format": output_format, "layout": layout, "quality": quality, "performance_profile": performance_profile,
            "captions": bool(payload.get("captions", True)), "use_ai": bool(payload.get("use_ai", True)),
            "smart_follow": smart_follow, "smart_compose": smart_compose, "smart_motion": smart_motion,
        })
        task = create_task(user["id"], "generate", normalized)
        threading.Thread(target=generate_worker, args=(user["id"], task["id"], normalized), daemon=True).start()
        return jsonify({"task": task}), 202

    @app.post("/api/shorts/library/add/<task_id>/<int:index>")
    @core.login_required
    def shorts_add_to_library_api(task_id: str, index: int):
        user = core.current_user()
        task = get_task(user["id"], task_id)
        if not task:
            return jsonify({"error": "Tarefa não encontrada."}), 404
        output = next((x for x in task.get("outputs") or [] if int(x.get("index") or 0) == index), None)
        if not output:
            return jsonify({"error": "Short não encontrado."}), 404
        if output.get("library_id"):
            return jsonify({"ok": True, "library_id": output.get("library_id"), "already_added": True})
        source = task_root(user["id"], task_id) / str(output.get("filename") or "")
        if not source.exists():
            return jsonify({"error": "Arquivo do Short não foi encontrado."}), 404
        library_row = persist_short_asset(
            user["id"], task, output, source,
            selection_method=str(task.get("selection_method") or ""),
            layout=str(task.get("layout") or "crop"),
            quality=str(task.get("quality") or "1080"),
        )
        # Se o usuário removeu e depois decidiu adicionar novamente, libera o ID.
        deleted = load_deleted_short_ids(user["id"])
        if library_row["id"] in deleted:
            deleted.discard(library_row["id"])
            write_deleted_short_ids(user["id"], deleted)
        outputs = []
        for row in task.get("outputs") or []:
            item = dict(row)
            if int(item.get("index") or 0) == index:
                item["library_id"] = library_row["id"]
                item["library_pending"] = False
                item.pop("library_removed", None)
            outputs.append(item)
        update_task(user["id"], task_id, outputs=outputs)
        return jsonify({"ok": True, "library_id": library_row["id"], "item": library_row})

    @app.post("/api/shorts/tasks/<task_id>/cleanup-outputs")
    @core.login_required
    def shorts_cleanup_outputs_api(task_id: str):
        """Remove do armazenamento temporário os Shorts gerados que o usuário decidiu não manter.

        Shorts já enviados para a Biblioteca nunca são apagados por esta limpeza. `keep_indexes`
        preserva os clipes ainda selecionados na tela para que possam ser adicionados depois.
        """
        user = core.current_user()
        task = get_task(user["id"], task_id)
        if not task:
            return jsonify({"error": "Tarefa não encontrada."}), 404
        payload = request.get_json(silent=True) or {}
        raw_keep = payload.get("keep_indexes") if isinstance(payload.get("keep_indexes"), list) else []
        keep: set[int] = set()
        for value in raw_keep:
            try:
                idx = int(value)
                if idx > 0: keep.add(idx)
            except Exception:
                pass
        folder = task_root(user["id"], task_id)
        preserved: list[dict[str, Any]] = []
        removed_indexes: list[int] = []
        for output in task.get("outputs") or []:
            item = dict(output)
            try: idx = int(item.get("index") or 0)
            except Exception: idx = 0
            if item.get("library_id") or idx in keep:
                preserved.append(item)
                continue
            filename = str(item.get("filename") or "")
            if filename:
                try: (folder / filename).unlink(missing_ok=True)
                except Exception: pass
            if idx > 0:
                try: (folder / f"short_{idx:02d}.ass").unlink(missing_ok=True)
                except Exception: pass
                removed_indexes.append(idx)
        update_task(user["id"], task_id, outputs=preserved)
        return jsonify({"ok": True, "removed": len(removed_indexes), "removed_indexes": removed_indexes, "kept": sorted(keep)})

    @app.post("/api/shorts/save/<task_id>/<int:index>")
    @core.login_required
    def shorts_save_api(task_id: str, index: int):
        user = core.current_user(); task = get_task(user["id"], task_id)
        if not task:
            return jsonify({"error": "Tarefa não encontrada."}), 404
        output = next((x for x in task.get("outputs") or [] if int(x.get("index") or 0) == index), None)
        if not output:
            return jsonify({"error": "Short não encontrado."}), 404
        source = task_root(user["id"], task_id) / str(output.get("filename") or "")
        if not source.exists():
            return jsonify({"error": "Arquivo do Short não foi encontrado."}), 404
        _, folders = core._ensure_storage_tree(user["id"])
        folder = folders["shorts"]
        base = core._safe_download_name(str(task.get("title") or "short"), "short")
        dest = core._unique_destination(folder, f"{base} - Short {index:02d}.mp4")
        shutil.copy2(source, dest)
        outputs = []
        for row in task.get("outputs") or []:
            new = dict(row)
            if int(new.get("index") or 0) == index:
                new["saved_path"] = str(dest)
            outputs.append(new)
        update_task(user["id"], task_id, outputs=outputs)
        asset_id = str(output.get("library_id") or short_asset_id(task_id, index))
        update_short_library_asset(user["id"], asset_id, saved_path=str(dest), saved_at=int(time.time()))
        pseudo = {"id": task_id, "title": f"{task.get('title') or 'Short'} - Short {index:02d}", "url": task.get("url")}
        try:
            core._log_download(user["id"], pseudo, "short", dest.name, dest.stat().st_size, str(dest))
        except Exception:
            pass
        return jsonify({"ok": True, "filename": dest.name, "path": str(dest)})

    @app.get("/api/shorts/library")
    @core.login_required
    def shorts_library_api():
        user = core.current_user()
        # Migração é lazy: zero custo na inicialização do RedScribe.
        sync_existing_shorts_to_library(user["id"])
        items = []
        for row in load_shorts_library(user["id"]):
            asset_id = str(row.get("id") or "")
            path = library_asset_path(user["id"], asset_id) if re.fullmatch(r"[a-f0-9]{32}", asset_id) else None
            if not path or not path.exists():
                continue
            item = dict(row)
            item["url"] = f"/shorts/library/media/{asset_id}"
            item["available"] = True
            saved = Path(str(item.get("saved_path") or "")) if item.get("saved_path") else None
            item["saved_exists"] = bool(saved and saved.exists())
            items.append(item)
        return jsonify({"items": items[:500], "count": len(items)})

    @app.patch("/api/shorts/library/<asset_id>/project")
    @core.login_required
    def shorts_library_project_api(asset_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", asset_id):
            return jsonify({"error": "Short inválido."}), 400
        payload = request.get_json(silent=True) or {}
        project_id = str(payload.get("project_id") or "").strip() or None
        if project_id and not core._project_by_id(user["id"], project_id):
            return jsonify({"error": "Projeto não encontrado."}), 400
        row = update_short_library_asset(user["id"], asset_id, project_id=project_id)
        if not row:
            return jsonify({"error": "Short não encontrado na Biblioteca."}), 404
        return jsonify({"ok": True, "item": row})

    @app.post("/api/shorts/library/save/<asset_id>")
    @core.login_required
    def shorts_library_save_api(asset_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", asset_id):
            return jsonify({"error": "Short inválido."}), 400
        row = next((x for x in load_shorts_library(user["id"]) if str(x.get("id") or "") == asset_id), None)
        source = library_asset_path(user["id"], asset_id)
        if not row or not source.exists():
            return jsonify({"error": "Short não encontrado na Biblioteca."}), 404
        _, folders = core._ensure_storage_tree(user["id"])
        base = core._safe_download_name(str(row.get("title") or "short"), "short")
        index = max(1, int(row.get("index") or 1))
        dest = core._unique_destination(folders["shorts"], f"{base} - Short {index:02d}.mp4")
        shutil.copy2(source, dest)
        update_short_library_asset(user["id"], asset_id, saved_path=str(dest), saved_at=int(time.time()))
        pseudo = {
            "id": str(row.get("task_id") or asset_id),
            "title": str(row.get("short_title") or row.get("title") or "Short"),
            "url": row.get("source_url"),
        }
        try:
            core._log_download(user["id"], pseudo, "short", dest.name, dest.stat().st_size, str(dest))
        except Exception:
            pass
        return jsonify({"ok": True, "filename": dest.name, "path": str(dest)})

    @app.post("/api/shorts/library/<asset_id>/trash")
    @core.login_required
    def shorts_library_trash_api(asset_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", asset_id):
            return jsonify({"error": "Short inválido."}), 400
        with _SHORTS_LOCK:
            rows = load_shorts_library(user["id"])
            row = next((dict(x) for x in rows if str(x.get("id") or "") == asset_id), None)
            if not row:
                return jsonify({"error": "Short não encontrado na Biblioteca."}), 404
            write_shorts_library(user["id"], [x for x in rows if str(x.get("id") or "") != asset_id])
            row["trashed_at"] = int(time.time())
            trash = [row] + [x for x in load_shorts_trash(user["id"]) if str(x.get("id") or "") != asset_id]
            write_shorts_trash(user["id"], trash)
            task_id = str(row.get("task_id") or "")
            tasks = load_tasks(user["id"]); changed = False
            for task in tasks:
                if str(task.get("id") or "") != task_id: continue
                out_rows=[]
                for output in task.get("outputs") or []:
                    item=dict(output)
                    if str(item.get("library_id") or "") == asset_id:
                        item.pop("library_id",None); item["library_trashed"]=True; changed=True
                    out_rows.append(item)
                task["outputs"]=out_rows; break
            if changed: write_tasks(user["id"],tasks)
        return jsonify({"ok": True, "trashed": asset_id})

    @app.get("/api/shorts/trash")
    @core.login_required
    def shorts_trash_api():
        user = core.current_user(); items=[]
        for row in load_shorts_trash(user["id"]):
            asset_id=str(row.get("id") or "")
            path=library_asset_path(user["id"],asset_id) if re.fullmatch(r"[a-f0-9]{32}",asset_id) else None
            if not path or not path.exists():
                continue
            item=dict(row); item["url"]=f"/shorts/trash/media/{asset_id}"; item["available"]=True
            items.append(item)
        return jsonify({"items":items})

    @app.get("/shorts/trash/media/<asset_id>")
    @core.login_required
    def shorts_trash_media(asset_id: str):
        user=core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}",asset_id):
            return jsonify({"error":"Arquivo não encontrado."}),404
        if not any(str(x.get("id") or "")==asset_id for x in load_shorts_trash(user["id"])):
            return jsonify({"error":"Arquivo não encontrado."}),404
        path=library_asset_path(user["id"],asset_id)
        if not path.exists(): return jsonify({"error":"Arquivo não encontrado."}),404
        return send_file(path, conditional=True)

    @app.post("/api/shorts/trash/<asset_id>/restore")
    @core.login_required
    def shorts_trash_restore_api(asset_id: str):
        user=core.current_user()
        with _SHORTS_LOCK:
            trash=load_shorts_trash(user["id"])
            row=next((dict(x) for x in trash if str(x.get("id") or "")==asset_id),None)
            if not row: return jsonify({"error":"Short não encontrado na Lixeira."}),404
            row.pop("trashed_at",None); row["updated_at"]=int(time.time())
            library=[row]+[x for x in load_shorts_library(user["id"]) if str(x.get("id") or "")!=asset_id]
            write_shorts_library(user["id"],library)
            write_shorts_trash(user["id"],[x for x in trash if str(x.get("id") or "")!=asset_id])
            deleted=load_deleted_short_ids(user["id"]); deleted.discard(asset_id); write_deleted_short_ids(user["id"],deleted)
            task_id=str(row.get("task_id") or ""); index=int(row.get("index") or 0)
            tasks=load_tasks(user["id"]); changed=False
            for task in tasks:
                if str(task.get("id") or "")!=task_id: continue
                out_rows=[]
                for output in task.get("outputs") or []:
                    item=dict(output)
                    if int(item.get("index") or 0)==index:
                        item["library_id"]=asset_id; item.pop("library_trashed",None); item["library_pending"]=False; changed=True
                    out_rows.append(item)
                task["outputs"]=out_rows; break
            if changed: write_tasks(user["id"],tasks)
        return jsonify({"ok":True,"restored":asset_id})

    @app.delete("/api/shorts/trash/<asset_id>/permanent")
    @core.login_required
    def shorts_trash_permanent_api(asset_id: str):
        user=core.current_user()
        with _SHORTS_LOCK:
            trash=load_shorts_trash(user["id"])
            if not any(str(x.get("id") or "")==asset_id for x in trash):
                return jsonify({"error":"Short não encontrado na Lixeira."}),404
            write_shorts_trash(user["id"],[x for x in trash if str(x.get("id") or "")!=asset_id])
            deleted=load_deleted_short_ids(user["id"]); deleted.add(asset_id); write_deleted_short_ids(user["id"],deleted)
        try: library_asset_path(user["id"],asset_id).unlink(missing_ok=True)
        except Exception: pass
        try: shutil.rmtree(core.DATA_ROOT / "studio" / user["id"] / asset_id, ignore_errors=True)
        except Exception: pass
        return jsonify({"ok":True,"removed":asset_id})

    @app.delete("/api/shorts/library/<asset_id>")
    @core.login_required
    def shorts_library_delete_api(asset_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", asset_id):
            return jsonify({"error": "Short inválido."}), 400
        with _SHORTS_LOCK:
            rows = load_shorts_library(user["id"])
            row = next((x for x in rows if str(x.get("id") or "") == asset_id), None)
            if not row:
                return jsonify({"error": "Short não encontrado na Biblioteca."}), 404
            write_shorts_library(user["id"], [x for x in rows if str(x.get("id") or "") != asset_id])
            deleted = load_deleted_short_ids(user["id"])
            deleted.add(asset_id)
            write_deleted_short_ids(user["id"], deleted)

            # Atualiza o histórico da tarefa para o card atual não continuar mostrando
            # que o Short está na Biblioteca. O arquivo temporário da tarefa é mantido.
            task_id = str(row.get("task_id") or "")
            tasks = load_tasks(user["id"])
            changed = False
            for task in tasks:
                if str(task.get("id") or "") != task_id:
                    continue
                outputs = []
                for output in task.get("outputs") or []:
                    item = dict(output)
                    if str(item.get("library_id") or "") == asset_id:
                        item.pop("library_id", None)
                        item["library_removed"] = True
                        changed = True
                    outputs.append(item)
                task["outputs"] = outputs
                break
            if changed:
                write_tasks(user["id"], tasks)
        try:
            library_asset_path(user["id"], asset_id).unlink(missing_ok=True)
        except Exception:
            pass
        # O Studio acompanha a Biblioteca: ao excluir o Short, remove também o rascunho
        # e as mídias exclusivas deste item (B-roll, avatar e marca d'água).
        try:
            shutil.rmtree(core.DATA_ROOT / "studio" / user["id"] / asset_id, ignore_errors=True)
        except Exception:
            pass
        return jsonify({"ok": True, "removed": asset_id})

    @app.get("/shorts/library/media/<asset_id>")
    @core.login_required
    def shorts_library_media(asset_id: str):
        user = core.current_user()
        if not re.fullmatch(r"[a-f0-9]{32}", asset_id):
            return jsonify({"error": "Arquivo não encontrado."}), 404
        row = next((x for x in load_shorts_library(user["id"]) if str(x.get("id") or "") == asset_id), None)
        path = library_asset_path(user["id"], asset_id)
        if not row or not path.exists():
            return jsonify({"error": "Arquivo não encontrado."}), 404
        return send_file(path, mimetype="video/mp4", conditional=True, max_age=0)

    @app.get("/shorts/media/<task_id>/<filename>")
    @core.login_required
    def shorts_media(task_id: str, filename: str):
        user = core.current_user(); task = get_task(user["id"], task_id)
        if not task or Path(filename).name != filename:
            return jsonify({"error": "Arquivo não encontrado."}), 404
        allowed = {str(x.get("filename") or "") for x in task.get("outputs") or []}
        if filename not in allowed:
            return jsonify({"error": "Arquivo não encontrado."}), 404
        path = task_root(user["id"], task_id) / filename
        if not path.exists():
            return jsonify({"error": "Arquivo não encontrado."}), 404
        return send_file(path, mimetype="video/mp4", conditional=True, max_age=0)

    @app.delete("/api/shorts/tasks")
    @core.login_required
    def shorts_clear_tasks_api():
        """Limpa apenas o histórico concluído/erro; Shorts da Biblioteca ficam preservados."""
        user = core.current_user()
        with _SHORTS_LOCK:
            rows = load_tasks(user["id"])
            running = [x for x in rows if str(x.get("status") or "") in {"queued", "processing"}]
            removed = [x for x in rows if str(x.get("status") or "") not in {"queued", "processing"}]
            write_tasks(user["id"], running)
        for row in removed:
            task_id = str(row.get("id") or "")
            if re.fullmatch(r"[a-f0-9]{32}", task_id):
                shutil.rmtree(core.DATA_ROOT / "shorts" / user["id"] / task_id, ignore_errors=True)
        return jsonify({"ok": True, "removed": len(removed), "preserved_running": len(running)})

    @app.delete("/api/shorts/tasks/<task_id>")
    @core.login_required
    def shorts_delete_task_api(task_id: str):
        user = core.current_user()
        with _SHORTS_LOCK:
            rows = load_tasks(user["id"])
            old = len(rows)
            rows = [x for x in rows if str(x.get("id") or "") != task_id]
            if len(rows) == old:
                return jsonify({"error": "Tarefa não encontrada."}), 404
            write_tasks(user["id"], rows)
        shutil.rmtree(core.DATA_ROOT / "shorts" / user["id"] / task_id, ignore_errors=True)
        return jsonify({"ok": True})
