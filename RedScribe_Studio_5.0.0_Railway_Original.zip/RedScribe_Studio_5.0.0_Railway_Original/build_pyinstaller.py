from __future__ import annotations

from pathlib import Path

import PyInstaller.__main__

ROOT = Path(__file__).resolve().parent

args = [
    "--noconfirm",
    "--clean",
    "--workpath",
    str(ROOT / ".pyinstaller-work"),
    "--distpath",
    str(ROOT / "dist"),
    str(ROOT / "RedScribe.spec"),
]

print("Executando PyInstaller com argumentos:")
for item in args:
    print("  ", item)

PyInstaller.__main__.run(args)
