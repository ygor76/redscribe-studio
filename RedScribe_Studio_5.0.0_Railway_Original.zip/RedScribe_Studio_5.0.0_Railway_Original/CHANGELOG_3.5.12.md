# RedScribe v3.5.12

## Studio — legendas e fluxo de edição

- Geração automática de legendas revisada para priorizar, nesta ordem, legendas do próprio YouTube, transcrição já conhecida pelo RedScribe e Whisper em modo de maior precisão.
- O Whisper usa áudio preparado apenas para reconhecimento, VAD mais rígido, beam search, timestamps por palavra e filtros contra trechos de baixa confiança e repetições.
- Adicionado botão **Legenda no tempo atual** para criar manualmente uma fala na posição atual do player.
- Cada legenda agora permite editar início, fim e texto, ir até a fala e excluir o trecho individualmente.
- A prévia e a renderização final passaram a compartilhar a mesma referência 1080×1920 para posição, tamanho, cor e contorno da legenda, reduzindo diferenças entre o que é visto no editor e o arquivo final.

## Studio — elementos e interface

- Selo do canal agora aceita uma foto opcional dentro do avatar circular; sem foto, continua usando a inicial.
- Faixa visual ganhou controle de largura, além de altura, posição, cor e opacidade.
- Painéis do Estúdio foram reorganizados para separar melhor legendas, elementos, B-roll e saída.
- Renderização ganhou overlay de progresso animado com estágio, tempo decorrido e barra de progresso visual.

## Shorts e Biblioteca

- Ao clicar em **Montar Shorts**, a interface rola automaticamente até o painel de geração.
- Uma geração em andamento continua sendo acompanhada mesmo ao navegar para outras áreas do RedScribe; o ID da tarefa ativa também é preservado no navegador para retomada do acompanhamento.
- Ao excluir um Short da Biblioteca, o rascunho e as mídias exclusivas correspondentes do Estúdio também são removidos.
- O motor de seleção e renderização dos Shorts foi preservado; a única alteração no backend de Shorts é a limpeza sincronizada do Estúdio ao excluir um item da Biblioteca.
