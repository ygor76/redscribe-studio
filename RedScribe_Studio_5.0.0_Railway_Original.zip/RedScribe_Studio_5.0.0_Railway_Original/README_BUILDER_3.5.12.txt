RedScribe Desktop EXE Builder v3.5.14

Base: v3.5.11.
Foco desta versão: Studio de legendas/elementos, fidelidade preview-render, feedback de renderização e continuidade do fluxo de Shorts.

Teste recomendado:
1. Gere um Short normalmente para confirmar o motor estável.
2. Abra no Estúdio e gere legendas automáticas.
3. Edite início/fim de uma fala, exclua outra e use “Legenda no tempo atual”.
4. Ajuste posição/cor/tamanho e renderize; compare a nova versão na Biblioteca.
5. Adicione foto ao selo do canal e ajuste largura de uma faixa.
6. Em Shorts, clique em Montar Shorts e navegue para outra seção enquanto processa.
7. Exclua um Short na Biblioteca e confirme que ele some do Estúdio.
