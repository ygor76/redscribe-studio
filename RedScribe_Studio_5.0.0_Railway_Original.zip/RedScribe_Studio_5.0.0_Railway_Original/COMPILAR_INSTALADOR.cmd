@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RedScribe Studio - Compilador do Instalador

echo.
echo ============================================================
echo  RedScribe Studio - Compilacao do instalador Windows
echo ============================================================
echo.
echo Esta janela ficara aberta ao final do processo.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_INSTALLER.ps1"
set "BUILD_EXIT=%ERRORLEVEL%"

echo.
if "%BUILD_EXIT%"=="0" (
  echo ============================================================
  echo  CONCLUIDO - verifique a pasta installer_output
  echo ============================================================
) else (
  echo ============================================================
  echo  A COMPILACAO PAROU COM ERRO %BUILD_EXIT%
  echo ============================================================
  echo Os arquivos diagnostico_build.txt e build_log.txt foram criados nesta pasta.
  if exist "%~dp0diagnostico_build.txt" (
    echo.
    echo --- Diagnostico final ---
    type "%~dp0diagnostico_build.txt"
    echo --- Fim do diagnostico ---
    start "Diagnostico RedScribe" notepad.exe "%~dp0diagnostico_build.txt"
  )
)
echo.
pause
exit /b %BUILD_EXIT%
