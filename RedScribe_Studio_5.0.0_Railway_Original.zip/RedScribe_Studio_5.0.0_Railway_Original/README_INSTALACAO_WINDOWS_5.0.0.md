# Compilação e instalação — RedScribe Studio 5.0.0

Este documento descreve como gerar e instalar a distribuição Windows do **RedScribe Studio 5.0.0**. O resultado final é um instalador nativo, e não uma execução direta de arquivos de desenvolvimento.

## Gerar o instalador

Em um computador com **Windows 10 ou Windows 11 de 64 bits**, extraia o pacote do código-fonte em uma pasta gravável, por exemplo `C:\RedScribeStudioBuilder`. Em seguida, execute `GERAR_INSTALADOR_WINDOWS.bat` com um duplo clique e aguarde a conclusão.

| Etapa preparada pelo builder | Resultado esperado |
|---|---|
| Ambiente de compilação | Python 3.12 x64 isolado e dependências do aplicativo. |
| Ferramentas de mídia | FFmpeg, Deno e o motor do YouTube adicionados ao pacote. |
| Aplicação | `dist\RedScribe\RedScribe.exe` gerado pelo PyInstaller. |
| Verificação | Autoteste do executável congelado antes da montagem do instalador. |
| Instalador | `installer_output\RedScribe_Studio_Setup_5.0.0_x64.exe`. |

O primeiro build requer internet para preparar os componentes de compilação. O builder cria `build_log.txt` e `diagnostico_build.txt`; conserve esses arquivos caso seja necessário investigar uma falha.

> Não altere o conteúdo de `dist\RedScribe` depois que o autoteste terminar. Qualquer alteração exige executar o builder novamente para que o instalador represente exatamente o aplicativo validado.

## Instalar o RedScribe Studio

Copie somente `RedScribe_Studio_Setup_5.0.0_x64.exe` para o computador de destino. Execute o arquivo, escolha a pasta de instalação se necessário e conclua o assistente. O instalador cria o atalho do menu Iniciar, registra o desinstalador e pode abrir o RedScribe Studio ao finalizar.

Na primeira abertura, crie uma conta ou entre com uma conta já existente. A landing apresenta o acesso ao estúdio; depois do login, o fluxo principal é pesquisar uma fonte, selecionar o vídeo e montar Shorts.

## Checklist de aceitação

Antes de distribuir o instalador, valide os itens abaixo no Windows de destino.

| Verificação | Critério de aprovação |
|---|---|
| Ícone | A marca monocromática do RedScribe aparece no instalador, menu Iniciar e janela do aplicativo. |
| Abertura | O RedScribe Studio abre sem pedir Python, Node, Git ou Inno Setup ao usuário final. |
| Conta | É possível criar conta, encerrar sessão e entrar novamente. |
| Busca | Uma consulta do YouTube retorna cartões com miniatura, canal, duração e visualizações. |
| Shorts | A seleção de fonte habilita a montagem e mostra progresso detalhado. |
| Prévia | Um Short concluído pode ser assistido no player integrado antes do download. |
| Remoção | O item **Desinstalar RedScribe Studio** aparece nas configurações de aplicativos do Windows. |

## Observação sobre a compilação

O executável é produzido com componentes específicos do Windows. Por esse motivo, a compilação e o teste final do arquivo `.exe` devem ocorrer em Windows. O pacote de código-fonte contém o builder completo e validado no lado Python; a execução do builder no Windows gera o instalador distribuível acima.
