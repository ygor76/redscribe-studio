# RedScribe v3.4.7

## Ajuste do enquadramento “Preenchimento total · 9:16 sem faixas pretas”

- Removida a sobreposição do vídeo menor no centro do Short.
- O modo `fit` agora gera um único quadro 9:16 contínuo, sem barras pretas e sem “caixa central”.
- Mantidos os demais ajustes de layout responsivo dos Shorts e da Biblioteca.
