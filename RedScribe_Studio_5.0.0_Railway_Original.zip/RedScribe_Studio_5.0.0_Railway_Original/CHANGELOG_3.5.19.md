# RedScribe v3.5.19

## Interface e identidade
- Removidas referências visíveis a “aplicativo local”, “conta local”, “Whisper local” e similares.
- Atualização técnica deixa de expor o nome yt-dlp na interface; o usuário vê somente RedScribe e seus componentes essenciais.
- Campo de pesquisa do YouTube ganhou proteção contra preenchimento acidental pelo e-mail do login.

## Armazenamento
- Uso de espaço passa a considerar a árvore de dados do RedScribe e a pasta de arquivos salvos.
- Exibe categorias compreensíveis: Shorts, Vídeos, Áudios, Estúdio, Textos e legendas, Backups e Outros dados.

## Estúdio
- Elementos e vídeo podem ser desselecionados clicando fora do objeto, sem perder nenhuma edição.
- Elementos podem ser selecionados novamente pela prévia ou pelo painel.

## Shorts Studio
- Nova animação de processamento baseada em quadro vertical + scan line + waveform, sem efeito de piscar.
- Shorts concluídos aparecem imediatamente enquanto os demais continuam renderizando.
- O DOM dos Shorts já prontos não é recriado durante o polling, permitindo dar play sem o vídeo reiniciar quando o próximo Short termina.
- Progresso mostra quantos Shorts já estão prontos em relação ao total pedido.
