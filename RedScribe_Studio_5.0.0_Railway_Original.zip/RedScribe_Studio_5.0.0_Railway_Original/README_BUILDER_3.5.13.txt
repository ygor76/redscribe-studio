RedScribe Desktop EXE Builder v3.5.14
Studio captions direct edit + text watermark + flexible bars.
