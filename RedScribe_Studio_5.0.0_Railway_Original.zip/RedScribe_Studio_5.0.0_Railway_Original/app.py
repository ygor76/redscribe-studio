from __future__ import annotations

import html
import json
import base64
import ctypes
import queue
import socket
import mimetypes
import os
import sys
import re
import shutil
import subprocess
import threading
import time
import uuid
import zipfile
import tempfile
import urllib.request
import urllib.error
from datetime import timedelta
from functools import wraps
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from claude_zen_gateway import ZenAnthropicGateway
from integrated_ai import response_from_prompt as _integrated_ai_response
from integrated_ai import streamed_response as _integrated_ai_stream

from flask import Flask, jsonify, render_template, request, send_file, session, redirect, url_for, Response, stream_with_context
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import (
    CouldNotRetrieveTranscript,
    NoTranscriptFound,
    TranscriptsDisabled,
    VideoUnavailable,
)

BASE_DIR = Path(__file__).resolve().parent

def _persistent_windows_data_root() -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "RedScribe" / "data"
    return Path.home() / "AppData" / "Local" / "RedScribe" / "data"


def _migrate_legacy_desktop_data(target: Path) -> None:
    """Move o armazenamento antigo por-versão para um local fixo do Windows."""
    try:
        if (target / "accounts.json").exists():
            return
        candidates: list[Path] = []
        direct = BASE_DIR / "data"
        if direct.exists():
            candidates.append(direct)
        for parent in (BASE_DIR.parent, BASE_DIR.parent.parent):
            try:
                for pattern in ("*/data/accounts.json", "*/*/data/accounts.json"):
                    for accounts in parent.glob(pattern):
                        d = accounts.parent
                        if d.resolve() != target.resolve():
                            candidates.append(d)
            except Exception:
                pass
        candidates = [c for c in candidates if (c / "accounts.json").exists()]
        if not candidates:
            return
        source = max(candidates, key=lambda c: (c / "accounts.json").stat().st_mtime)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target, dirs_exist_ok=True)
    except Exception:
        pass


def _desktop_data_root() -> Path:
    override = os.environ.get("REDSCRIBE_DATA_ROOT")
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        target = _persistent_windows_data_root()
        _migrate_legacy_desktop_data(target)
        return target
    return BASE_DIR / "data"

DATA_ROOT = _desktop_data_root()
DATA_DIR = DATA_ROOT / "jobs"
USERS_DIR = DATA_ROOT / "users"
ACCOUNTS_FILE = DATA_ROOT / "accounts.json"
SECRET_FILE = DATA_ROOT / ".session_secret"
DATA_DIR.mkdir(parents=True, exist_ok=True)
USERS_DIR.mkdir(parents=True, exist_ok=True)

if not SECRET_FILE.exists():
    SECRET_FILE.write_text(uuid.uuid4().hex + uuid.uuid4().hex, encoding="utf-8")

app = Flask(__name__)
app.secret_key = SECRET_FILE.read_text(encoding="utf-8").strip()
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024 * 1024
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=180)
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_HTTPONLY"] = True

_jobs: dict[str, dict[str, Any]] = {}
_jobs_disk_cache_loaded = False
_jobs_disk_cache_lock = threading.RLock()
_lock = threading.RLock()
_account_lock = threading.RLock()
_processing_semaphore = threading.Semaphore(1)
APP_VERSION = "5.0.0-desktop"
DEFAULT_AI_MODEL = "deepseek-v4-flash-free"
FREE_AI_FALLBACK_MODELS = [
    "mimo-v2.5-free",
    "laguna-s-2.1-free",
    "nemotron-3.5-lightning-free",
    "hy3-free",
    "nemotron-3-ultra-free",
]
AI_PROVIDER_NAME = "OpenCode Zen"
ZEN_CHAT_COMPLETIONS_URL = "https://opencode.ai/zen/v1/chat/completions"

SUPPORTED_HOSTS = {
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "youtu.be",
    "music.youtube.com",
}

LANGUAGE_MAP = {
    "auto": [],
    "pt": ["pt", "pt-BR", "pt-PT"],
    "en": ["en", "en-US", "en-GB"],
    "es": ["es", "es-419", "es-ES"],
    "fr": ["fr", "fr-FR"],
    "de": ["de", "de-DE"],
    "it": ["it", "it-IT"],
}


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def _load_accounts() -> list[dict[str, Any]]:
    with _account_lock:
        if not ACCOUNTS_FILE.exists(): return []
        try:
            data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception: return []


def _save_accounts(accounts: list[dict[str, Any]]) -> None:
    with _account_lock: _atomic_write_json(ACCOUNTS_FILE, accounts)


def _public_user(user: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": user.get("id"),
        "name": user.get("name"),
        "email": user.get("email"),
        "created_at": user.get("created_at"),
        "last_login_at": user.get("last_login_at"),
        # Preparado para ativação comercial futura. Nesta versão, nenhuma conta
        # local é limitada por plano ou período de teste.
        "access_mode": user.get("access_mode", "full"),
        "plan": user.get("plan", "preview"),
        "shorts_quota": user.get("shorts_quota"),
        "plan_expires_at": user.get("plan_expires_at"),
    }


def _find_user_by_email(email: str) -> dict[str, Any] | None:
    normalized = (email or "").strip().lower()
    return next((u for u in _load_accounts() if u.get("email", "").lower() == normalized), None)


def _find_user_by_id(user_id: str | None) -> dict[str, Any] | None:
    if not user_id: return None
    return next((u for u in _load_accounts() if u.get("id") == user_id), None)


def current_user() -> dict[str, Any] | None:
    return _find_user_by_id(session.get("user_id"))


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            if request.path.startswith(("/api/", "/audio/", "/video/", "/download/", "/shorts/")):
                return jsonify({"error": "Faça login para continuar."}), 401
            return redirect(url_for("login_page"))
        return view(*args, **kwargs)
    return wrapped


def _user_dir(user_id: str) -> Path:
    path = USERS_DIR / user_id; path.mkdir(parents=True, exist_ok=True); return path


def _downloads_path(user_id: str) -> Path: return _user_dir(user_id) / "downloads.json"


def _load_downloads(user_id: str) -> list[dict[str, Any]]:
    path = _downloads_path(user_id)
    if not path.exists(): return []
    try:
        data = json.loads(path.read_text(encoding="utf-8")); return data if isinstance(data, list) else []
    except Exception: return []



def _projects_path(user_id: str) -> Path:
    return _user_dir(user_id) / "projects.json"


def _load_projects(user_id: str) -> list[dict[str, Any]]:
    path = _projects_path(user_id)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_projects(user_id: str, items: list[dict[str, Any]]) -> None:
    _atomic_write_json(_projects_path(user_id), items)


def _project_by_id(user_id: str, project_id: str | None) -> dict[str, Any] | None:
    if not project_id:
        return None
    return next((p for p in _load_projects(user_id) if p.get("id") == project_id), None)


def _trash_days_left(job: dict[str, Any]) -> int | None:
    trashed_at = int(job.get("trashed_at") or 0)
    if not trashed_at:
        return None
    elapsed = max(0, int(time.time()) - trashed_at)
    return max(0, 30 - elapsed // 86400)


def _purge_expired_trash(user_id: str) -> int:
    removed = 0
    threshold = int(time.time()) - 30 * 86400
    for job in _user_jobs(user_id, include_trashed=True):
        if int(job.get("trashed_at") or 0) and int(job.get("trashed_at") or 0) < threshold:
            _delete_job_files(job)
            removed += 1
    return removed


def _dir_size(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for item in path.rglob("*"):
        try:
            if item.is_file():
                total += item.stat().st_size
        except OSError:
            pass
    return total


def _storage_breakdown(user_id: str) -> dict[str, Any]:
    """Return a real disk-usage view grouped by what the user understands.

    Previous builds only counted files copied to the export folder and labelled the
    whole jobs directory as cache. That made Shorts/Videos look almost empty even
    while they occupied hundreds of MB inside the RedScribe library. This version
    counts both the persistent RedScribe data tree and user export folders.
    """
    root, folders = _ensure_storage_tree(user_id)
    video_exts = {".mp4", ".mkv", ".mov", ".avi", ".m4v", ".webm", ".mpeg", ".mpg"}
    audio_exts = {".m4a", ".mp3", ".wav", ".aac", ".flac", ".ogg", ".opus"}
    doc_exts = {".txt", ".pdf", ".docx", ".srt", ".vtt"}

    job_video = job_audio = job_docs = 0
    if DATA_DIR.exists():
        for item in DATA_DIR.rglob("*"):
            try:
                if not item.is_file():
                    continue
                suffix = item.suffix.lower()
                name = item.name.lower()
                size = item.stat().st_size
                # yt-dlp may produce audio.webm, so filename intent wins over suffix.
                if name.startswith("audio") or suffix in audio_exts:
                    job_audio += size
                elif name.startswith("video") or suffix in video_exts:
                    job_video += size
                elif suffix in doc_exts or suffix == ".json":
                    job_docs += size
            except OSError:
                pass

    internal_shorts = _dir_size(DATA_ROOT / "shorts_library") + _dir_size(DATA_ROOT / "shorts")
    studio_bytes = _dir_size(DATA_ROOT / "studio")

    exported_shorts = _dir_size(folders["shorts"])
    exported_video = _dir_size(folders["video"])
    exported_audio = _dir_size(folders["audio"])
    exported_docs = sum(_dir_size(folders[k]) for k in ("txt", "pdf", "docx", "srt"))
    backup_bytes = _dir_size(folders["backup"])

    categories: dict[str, int] = {
        "Shorts": internal_shorts + exported_shorts,
        "Vídeos": job_video + exported_video,
        "Áudios": job_audio + exported_audio,
        "Estúdio": studio_bytes,
        "Textos e legendas": job_docs + exported_docs,
        "Backups": backup_bytes,
    }

    data_bytes = _dir_size(DATA_ROOT)
    export_bytes = _dir_size(root)
    try:
        data_resolved = DATA_ROOT.resolve()
        export_resolved = root.resolve()
        if export_resolved == data_resolved or data_resolved in export_resolved.parents:
            total_bytes = export_bytes
        elif export_resolved in data_resolved.parents:
            total_bytes = data_bytes
        else:
            total_bytes = data_bytes + export_bytes
    except Exception:
        total_bytes = data_bytes + export_bytes

    known = sum(categories.values())
    if total_bytes > known:
        categories["Outros dados"] = total_bytes - known
    # Generated task files and job media are the areas cleanup can meaningfully reclaim.
    cache_size = _dir_size(DATA_ROOT / "shorts") + _dir_size(DATA_DIR)
    return {
        "root": str(root),
        "total_bytes": total_bytes,
        "data_bytes": data_bytes,
        "exports_bytes": export_bytes,
        "cache_bytes": cache_size,
        "categories": categories,
    }

def _settings_path(user_id: str) -> Path:
    return _user_dir(user_id) / "settings.json"


def _default_storage_parent() -> Path:
    downloads = Path.home() / "Downloads"
    return downloads if downloads.exists() else Path.home()


def _load_user_settings(user_id: str) -> dict[str, Any]:
    defaults = {"storage_parent": str(_default_storage_parent()), "ai_model": DEFAULT_AI_MODEL, "onboarding_seen": False}
    path = _settings_path(user_id)
    if not path.exists():
        return defaults
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            defaults.update({k: v for k, v in data.items() if v is not None})
    except Exception:
        pass
    # A partir da v3.2 a IA usa um modelo fixo via Claude Code + OpenCode Zen.
    if str(defaults.get("ai_model") or "").strip() != DEFAULT_AI_MODEL:
        defaults["ai_model"] = DEFAULT_AI_MODEL
        try:
            _atomic_write_json(path, defaults)
        except Exception:
            pass
    return defaults


def _save_user_settings(user_id: str, settings: dict[str, Any]) -> None:
    _atomic_write_json(_settings_path(user_id), settings)


def _storage_root(user_id: str) -> Path:
    settings = _load_user_settings(user_id)
    parent = Path(str(settings.get("storage_parent") or _default_storage_parent())).expanduser()
    return parent if parent.name.lower() == "redscribe" else parent / "RedScribe"


def _ensure_storage_tree(user_id: str) -> tuple[Path, dict[str, Path]]:
    root = _storage_root(user_id)
    folders = {
        "txt": root / "Texto",
        "pdf": root / "PDF",
        "docx": root / "Documento",
        "srt": root / "Legendas",
        "vtt": root / "Legendas",
        "audio": root / "Áudio",
        "video": root / "Vídeo",
        "shorts": root / "Shorts",
        "backup": root / "Backup",
    }
    root.mkdir(parents=True, exist_ok=True)
    for folder in folders.values():
        folder.mkdir(parents=True, exist_ok=True)
    return root, folders


def _unique_destination(folder: Path, filename: str) -> Path:
    candidate = folder / filename
    if not candidate.exists():
        return candidate
    stem, suffix = candidate.stem, candidate.suffix
    index = 2
    while True:
        candidate = folder / f"{stem} ({index}){suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def _log_download(user_id: str, job: dict[str, Any], kind: str, filename: str, size_bytes: int | None = None, saved_path: str | None = None) -> None:
    items = _load_downloads(user_id)
    items.insert(0, {
        "id": uuid.uuid4().hex,
        "job_id": job.get("id"),
        "kind": kind,
        "title": job.get("title") or "Transcrição",
        "filename": filename,
        "size_bytes": size_bytes,
        "saved_path": saved_path,
        "downloaded_at": int(time.time()),
    })
    _atomic_write_json(_downloads_path(user_id), items[:1000])


def _job_owned_by(job: dict[str, Any] | None, user: dict[str, Any] | None) -> bool:
    return bool(job and user and job.get("user_id") == user.get("id"))


def _ensure_jobs_disk_cache() -> None:
    """Load persisted jobs only once per RedScribe process.

    Older builds reparsed every large job JSON on every /history, /projects and
    recovery request. A job may contain the full transcript and thousands of
    segments, so repeated scans could starve the desktop UI as the library grew.
    """
    global _jobs_disk_cache_loaded
    if _jobs_disk_cache_loaded:
        return
    with _jobs_disk_cache_lock:
        if _jobs_disk_cache_loaded:
            return
        loaded: dict[str, dict[str, Any]] = {}
        for idx, path in enumerate(DATA_DIR.glob("*.json")):
            try:
                item = _normalize_job_record(json.loads(path.read_text(encoding="utf-8")))
                jid = str(item.get("id") or path.stem)
                if jid:
                    loaded[jid] = item
            except Exception:
                continue
            # Yield the GIL periodically during a legacy-library warmup.
            if idx and idx % 8 == 0:
                time.sleep(0)
        with _lock:
            # Never overwrite a newer in-memory object created while the disk
            # warmup was happening.
            for jid, item in loaded.items():
                _jobs.setdefault(jid, item)
        _jobs_disk_cache_loaded = True


def _user_jobs(user_id: str, include_trashed: bool = False) -> list[dict[str, Any]]:
    _ensure_jobs_disk_cache()
    with _lock:
        values = list(_jobs.values())
    jobs = []
    for raw in values:
        try:
            item = _normalize_job_record(raw)
            if item.get("user_id") != user_id:
                continue
            # Internal jobs are temporary workers used by tools such as Shorts Studio.
            # They must never appear in Biblioteca/Home/Fila or be auto-recovered.
            if item.get("internal_hidden"):
                continue
            if not include_trashed and item.get("trashed_at"):
                continue
            jobs.append(item)
        except Exception:
            continue
    jobs.sort(key=lambda x: int(x.get("created_at") or 0), reverse=True)
    return jobs


def _job_summary(job: dict[str, Any]) -> dict[str, Any]:
    transcript=job.get("transcript") or ""; preview=re.sub(r"\s+", " ", transcript).strip()[:180]
    return {
        "id":job.get("id"),"title":job.get("title"),"url":job.get("url"),
        "status":job.get("status"),"stage":job.get("stage"),"progress":job.get("progress"),
        "source":job.get("source"),"source_type":job.get("source_type","youtube"),
        "detected_language":job.get("detected_language"),"word_count":job.get("word_count"),
        "duration_label":job.get("duration_label"),"duration_seconds":job.get("duration_seconds"),
        "audio_ready":bool(job.get("audio_ready")),"video_ready":bool(job.get("video_ready")),
        "video_quality":job.get("video_quality"),"video_is_full_hd":bool(job.get("video_is_full_hd")),
        "created_at":job.get("created_at"),"updated_at":job.get("updated_at"),"preview":preview,
        "error":job.get("error"),"favorite":bool(job.get("favorite")),"tags":job.get("tags") or [],"project_id":job.get("project_id"),
        "thumbnail_url":job.get("thumbnail_url"),"transcript_available":bool(job.get("transcript_available", bool(transcript.strip()))),
        "media_only":bool(job.get("media_only")),"trashed_at":job.get("trashed_at"),
        "trash_days_left":_trash_days_left(job),"queue_order":job.get("queue_order"),
    }


def _delete_job_files(job: dict[str, Any]) -> None:
    job_id = str(job.get("id") or "")
    if not job_id:
        return
    with _lock:
        _jobs.pop(job_id, None)
    try:
        path = job_path(job_id)
        if path.exists(): path.unlink()
        folder = DATA_DIR / job_id
        if folder.exists(): shutil.rmtree(folder, ignore_errors=True)
        for ext in (".txt", ".pdf", ".docx", ".srt", ".vtt"):
            generated = DATA_DIR / f"{job_id}{ext}"
            if generated.exists(): generated.unlink()
    except OSError:
        pass



def _claim_legacy_jobs(user_id: str) -> int:
    claimed = 0
    for path in DATA_DIR.glob("*.json"):
        try:
            item = json.loads(path.read_text(encoding="utf-8"))
            if item.get("user_id"):
                continue
            item["user_id"] = user_id
            _atomic_write_json(path, item)
            with _lock:
                _jobs[item.get("id", path.stem)] = item
            claimed += 1
        except Exception:
            continue
    return claimed

def _safe_download_name(title: str, fallback: str = "arquivo") -> str:
    value = re.sub(r"[^A-Za-z0-9À-ÿ _.-]+", "", title or "")[:80].strip(); return value or fallback


def _asset_source(job: dict[str, Any], filetype: str) -> tuple[Path, str, str]:
    safe_title = _safe_download_name(job.get("title", "transcricao"), "transcricao")
    job_id = str(job.get("id") or "")
    text_available = bool(job.get("transcript_available", bool((job.get("transcript") or "").strip())))
    if filetype in {"txt", "pdf", "docx", "srt", "vtt"} and not text_available:
        raise FileNotFoundError("Este conteúdo não possui fala detectada para exportar como texto ou legenda.")
    if filetype == "txt":
        path = make_txt(job); filename = f"{safe_title}.txt"
        return path, filename, "text/plain; charset=utf-8"
    if filetype == "pdf":
        path = make_pdf(job); filename = f"{safe_title}.pdf"
        return path, filename, "application/pdf"
    if filetype == "docx":
        path = make_docx(job); filename = f"{safe_title}.docx"
        return path, filename, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    if filetype == "srt":
        path = make_srt(job); filename = f"{safe_title}.srt"
        return path, filename, "application/x-subrip; charset=utf-8"
    if filetype == "vtt":
        path = make_vtt(job); filename = f"{safe_title}.vtt"
        return path, filename, "text/vtt; charset=utf-8"
    if filetype == "audio":
        path = find_job_audio(job_id)
        if not path:
            raise FileNotFoundError(job.get("audio_error") or "Áudio não encontrado.")
        extension = path.suffix.lower() or ".audio"
        return path, f"{safe_title}{extension}", audio_mimetype(path)
    if filetype == "video":
        path = find_job_video(job_id)
        if not path:
            raise FileNotFoundError(job.get("video_error") or "Vídeo não encontrado.")
        extension = path.suffix.lower() or ".video"
        return path, f"{safe_title}{extension}", video_mimetype(path)
    raise ValueError("Formato inválido.")


def _save_asset_copy(user: dict[str, Any], job: dict[str, Any], filetype: str) -> tuple[Path, str, int]:
    source, filename, _ = _asset_source(job, filetype)
    _, folders = _ensure_storage_tree(user["id"])
    destination = _unique_destination(folders[filetype], filename)
    shutil.copy2(source, destination)
    size = destination.stat().st_size
    _log_download(user["id"], job, filetype, destination.name, size, str(destination))
    return destination, destination.name, size


@dataclass
class TranscriptSegment:
    text: str
    start: float
    duration: float
    no_speech_prob: float = 0.0
    avg_logprob: float = 0.0


def extract_video_id(value: str) -> str:
    value = (value or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", value):
        return value

    try:
        parsed = urlparse(value)
    except Exception as exc:
        raise ValueError("Link do YouTube inválido.") from exc

    host = (parsed.hostname or "").lower()
    if host not in SUPPORTED_HOSTS:
        raise ValueError("Use apenas links do YouTube.")

    if host == "youtu.be":
        candidate = parsed.path.strip("/").split("/")[0]
    elif parsed.path == "/watch":
        candidate = parse_qs(parsed.query).get("v", [""])[0]
    else:
        parts = [p for p in parsed.path.split("/") if p]
        candidate = ""
        if len(parts) >= 2 and parts[0] in {"shorts", "embed", "live"}:
            candidate = parts[1]

    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate or ""):
        raise ValueError("Não consegui identificar o ID do vídeo nesse link.")
    return candidate


def seconds_to_stamp(value: float) -> str:
    total = max(0, int(value))
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def clean_caption_text(text: str) -> str:
    text = html.unescape(text or "")
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("\u200b", " ")
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def join_segments(segments: list[TranscriptSegment], timestamps: bool) -> str:
    lines: list[str] = []
    for seg in segments:
        text = clean_caption_text(seg.text)
        if not text:
            continue
        if timestamps:
            lines.append(f"[{seconds_to_stamp(seg.start)}] {text}")
        else:
            lines.append(text)
    return "\n".join(lines).strip()



def _segment_payloads(segments: list[TranscriptSegment]) -> list[dict[str, Any]]:
    return [
        {"text": clean_caption_text(s.text), "start": round(float(s.start), 3), "duration": round(float(s.duration), 3), "no_speech_prob": round(float(getattr(s, "no_speech_prob", 0.0) or 0.0), 4), "avg_logprob": round(float(getattr(s, "avg_logprob", 0.0) or 0.0), 4)}
        for s in segments if clean_caption_text(s.text)
    ]


def _meaningful_speech(segments: list[TranscriptSegment]) -> bool:
    if not segments:
        return False
    noise_re = re.compile(r"^(?:[\[\(]?(?:music|música|musica|applause|aplausos|som|sound|instrumental|silence|silêncio|silencio|noise|ruído|ruido)[\]\)]?|[♪♫♬]+)$", re.I)
    meaningful: list[str] = []
    trusted_segments = 0
    speech_duration = 0.0
    for seg in segments:
        text = clean_caption_text(seg.text)
        text = re.sub(r"[♪♫♬]", " ", text).strip()
        if not text or noise_re.match(text):
            continue
        no_speech = float(getattr(seg, "no_speech_prob", 0.0) or 0.0)
        avg_logprob = float(getattr(seg, "avg_logprob", 0.0) or 0.0)
        # Campos de confiança ficam em zero para legendas do YouTube; nesse caso não filtramos.
        if no_speech > 0.72:
            continue
        if avg_logprob and avg_logprob < -1.25:
            continue
        words = re.findall(r"[A-Za-zÀ-ÿ0-9']+", text)
        if words:
            meaningful.extend(words)
            trusted_segments += 1
            speech_duration += max(0.0, float(seg.duration or 0))
    joined = " ".join(meaningful)
    caption_like = all(float(getattr(s, "avg_logprob", 0.0) or 0.0) == 0.0 and float(getattr(s, "no_speech_prob", 0.0) or 0.0) == 0.0 for s in segments)
    if caption_like:
        # Legendas fornecidas pelo YouTube são evidência forte de fala, mesmo em vídeos muito curtos.
        return len(meaningful) >= 1 and len(joined) >= 2
    # Para Whisper, exigimos mais evidência para evitar transformar música em texto alucinado.
    return len(meaningful) >= 3 and len(joined) >= 10 and trusted_segments >= 1 and speech_duration >= 0.35


def _subtitle_time(seconds: float, srt: bool = True) -> str:
    ms = max(0, int(round(float(seconds) * 1000)))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    sec, milli = divmod(rem, 1000)
    sep = "," if srt else "."
    return f"{h:02d}:{m:02d}:{sec:02d}{sep}{milli:03d}"


def _job_segments(job: dict[str, Any]) -> list[dict[str, Any]]:
    raw = job.get("segments") or []
    return [x for x in raw if isinstance(x, dict) and str(x.get("text") or "").strip()]


def make_srt(job: dict[str, Any]) -> Path:
    path = DATA_DIR / f"{job['id']}.srt"
    lines = []
    for idx, seg in enumerate(_job_segments(job), start=1):
        start = float(seg.get("start") or 0)
        end = start + max(0.05, float(seg.get("duration") or 0))
        lines += [str(idx), f"{_subtitle_time(start)} --> {_subtitle_time(end)}", str(seg.get("text") or "").strip(), ""]
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def make_vtt(job: dict[str, Any]) -> Path:
    path = DATA_DIR / f"{job['id']}.vtt"
    lines = ["WEBVTT", ""]
    for seg in _job_segments(job):
        start = float(seg.get("start") or 0)
        end = start + max(0.05, float(seg.get("duration") or 0))
        lines += [f"{_subtitle_time(start, False)} --> {_subtitle_time(end, False)}", str(seg.get("text") or "").strip(), ""]
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def make_docx(job: dict[str, Any]) -> Path:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("O exportador DOCX não está instalado. Execute INSTALAR_WINDOWS.bat novamente.") from exc
    path = DATA_DIR / f"{job['id']}.docx"
    doc = Document()
    doc.add_heading(job.get("title") or "Transcrição", 0)
    meta = doc.add_paragraph()
    meta.add_run(f"Fonte: {job.get('url') or job.get('original_filename') or 'Arquivo enviado'}\n")
    meta.add_run(f"Idioma: {job.get('detected_language') or '—'} · Método: {job.get('source') or '—'} · Duração: {job.get('duration_label') or '—'}")
    for paragraph in [p.strip() for p in (job.get("transcript") or "").split("\n") if p.strip()]:
        doc.add_paragraph(paragraph)
    doc.save(path)
    return path


def _ai_context(job: dict[str, Any], action: str, question: str = "") -> str:
    """Mantém o prompt leve o bastante para responder bem em CPU sem travar a interface."""
    transcript = str(job.get("transcript") or "").strip()
    if len(transcript) <= 18000:
        return transcript

    if action == "ask" and question:
        terms = [t for t in re.findall(r"[\wÀ-ÿ]{4,}", question.lower()) if len(t) >= 4]
        segments = _job_segments(job)
        scored = []
        for idx, seg in enumerate(segments):
            text = str(seg.get("text") or "")
            low = text.lower()
            score = sum(1 for term in terms if term in low)
            if score:
                lo = max(0, idx - 2); hi = min(len(segments), idx + 3)
                block = " ".join(str(segments[j].get("text") or "") for j in range(lo, hi))
                scored.append((score, idx, block))
        if scored:
            scored.sort(key=lambda x: (-x[0], x[1]))
            unique = []
            seen = set()
            for _, idx, block in scored:
                if idx in seen:
                    continue
                seen.add(idx); unique.append(block)
                if sum(len(x) for x in unique) >= 15000:
                    break
            return "\n".join(unique)[:16000]

    # Amostra começo, meio e fim para manter cobertura do vídeo sem enviar um prompt enorme.
    third = 5600
    middle = max(0, (len(transcript) // 2) - (third // 2))
    return (
        transcript[:third]
        + "\n\n[... trecho intermediário da transcrição ...]\n\n"
        + transcript[middle:middle + third]
        + "\n\n[... trecho final da transcrição ...]\n\n"
        + transcript[-third:]
    )


# ---------------------------------------------------------------------------
# IA do RedScribe: Claude Code + gateway interno + OpenCode Zen
# ---------------------------------------------------------------------------
# O Claude Code roda localmente em modo print/bare, sem ferramentas. O RedScribe
# abre um gateway Anthropic-format temporário em 127.0.0.1 para cada chamada e
# converte o stream para o endpoint OpenAI-compatible do Zen. A chave Zen nunca
# é passada ao processo Claude Code e nunca é embutida no executável: fica
# criptografada por usuário com Windows DPAPI.

_claude_lock = threading.RLock()
_ai_runtime_state: dict[str, Any] = {
    "status": "idle",
    "message": "Aguardando verificação da IA.",
    "updated_at": 0,
}


def _app_resource_path(*parts: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", BASE_DIR))
    return base.joinpath(*parts)


def _claude_runtime_root() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / ".redscribe"
    return base / "RedScribe" / "claude-runtime"


def _claude_runtime_manifest() -> dict[str, Any]:
    path = _claude_runtime_root() / "runtime.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _claude_runtime_paths() -> tuple[Path | None, Path | None]:
    """Return ``(claude_exe, None)`` for the native Claude Code runtime.

    RedScribe 3.2.3 no longer depends on the npm package layout (``cli.js`` or
    ``claude.cmd``). Anthropic's current Windows installer ships a native
    ``claude.exe``. The second tuple item is kept as ``None`` only for backwards
    compatibility with older call sites while user data migrates.
    """
    data = _claude_runtime_manifest()

    candidates: list[Path] = []
    for key in ("claude_exe", "claude_native", "claude"):
        raw = str(data.get(key) or "").strip()
        if raw and raw.lower().endswith(".exe"):
            candidates.append(Path(raw))

    # Official native installer location on Windows.
    if os.name == "nt":
        candidates.append(Path.home() / ".local" / "bin" / "claude.exe")

    # Also accept a private native binary copied into RedScribe's runtime folder
    # by a future installer/repair routine.
    candidates.append(_claude_runtime_root() / "claude.exe")

    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = str(candidate.resolve(strict=False)).lower()
        except Exception:
            resolved = str(candidate).lower()
        if resolved in seen:
            continue
        seen.add(resolved)
        if candidate.is_file():
            return candidate, None
    return None, None

def _zen_secret_path(user_id: str) -> Path:
    return _user_dir(user_id) / "zen_api_key.dat"


def _machine_zen_secret_path() -> Path:
    # A machine/user-profile fallback lets the Windows installer configure the
    # key before a RedScribe account exists. It is still protected with DPAPI
    # and therefore only decrypts for the same Windows user.
    return DATA_ROOT.parent / "zen_api_key.dat"


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _dpapi_local_free(ptr) -> None:
    if not ptr or os.name != "nt":
        return
    kernel32 = ctypes.windll.kernel32
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    kernel32.LocalFree(ctypes.cast(ptr, ctypes.c_void_p))


def _dpapi_encrypt_text(value: str) -> str:
    raw = value.encode("utf-8")
    if os.name != "nt":
        # Somente para desenvolvimento/testes fora do Windows.
        return "dev:" + base64.b64encode(raw).decode("ascii")
    buffer = ctypes.create_string_buffer(raw)
    in_blob = _DATA_BLOB(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    out_blob = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(in_blob), "RedScribe Zen", None, None, None, 0,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError("O Windows não conseguiu proteger a chave da IA.")
    try:
        encrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        return "dpapi:" + base64.b64encode(encrypted).decode("ascii")
    finally:
        _dpapi_local_free(out_blob.pbData)


def _dpapi_decrypt_text(value: str) -> str:
    if value.startswith("dev:") and os.name != "nt":
        return base64.b64decode(value[4:]).decode("utf-8")
    if not value.startswith("dpapi:"):
        raise RuntimeError("Formato da chave Zen inválido.")
    if os.name != "nt":
        raise RuntimeError("A chave Zen protegida pelo Windows só pode ser aberta no Windows.")
    raw = base64.b64decode(value[6:])
    buffer = ctypes.create_string_buffer(raw)
    in_blob = _DATA_BLOB(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    out_blob = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise OSError("O Windows não conseguiu abrir a chave Zen deste usuário.")
    try:
        decrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        return decrypted.decode("utf-8")
    finally:
        _dpapi_local_free(out_blob.pbData)


def _validate_zen_key(api_key: str) -> str:
    api_key = api_key.strip()
    if len(api_key) < 20 or not api_key.startswith("sk-"):
        raise ValueError("A chave do OpenCode Zen parece inválida.")
    return api_key


def _save_zen_key(user_id: str, api_key: str) -> None:
    api_key = _validate_zen_key(api_key)
    path = _zen_secret_path(user_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_dpapi_encrypt_text(api_key), encoding="utf-8")


def _save_machine_zen_key(api_key: str) -> None:
    api_key = _validate_zen_key(api_key)
    path = _machine_zen_secret_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_dpapi_encrypt_text(api_key), encoding="utf-8")


def _read_protected_zen_key(path: Path) -> str | None:
    if not path.exists():
        return None
    try:
        return _dpapi_decrypt_text(path.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def _load_zen_key(user_id: str) -> str | None:
    # Per-account key wins. If absent, use the optional installer-configured key
    # protected for this Windows profile.
    return _read_protected_zen_key(_zen_secret_path(user_id)) or _read_protected_zen_key(_machine_zen_secret_path())


def _delete_zen_key(user_id: str) -> None:
    for path in (_zen_secret_path(user_id), _machine_zen_secret_path()):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def _claude_home() -> Path:
    home = _claude_runtime_root() / "home"
    home.mkdir(parents=True, exist_ok=True)
    return home


def _claude_child_env(gateway_base_url: str | None = None) -> dict[str, str]:
    env = dict(os.environ)
    home = _claude_home()
    # Keep the real Windows HOME/USERPROFILE. The native Claude launcher lives
    # under the real user profile and may use it to resolve installed versions.
    # CLAUDE_CONFIG_DIR isolates RedScribe state without breaking the launcher.
    env["CLAUDE_CONFIG_DIR"] = str(home / ".claude")
    env["NO_COLOR"] = "1"
    env["CI"] = "1"
    env["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1"
    env["CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS"] = "1"
    env["CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING"] = "1"
    env["CLAUDE_CODE_ATTRIBUTION_HEADER"] = "0"
    env["DISABLE_TELEMETRY"] = "1"
    env["DISABLE_ERROR_REPORTING"] = "1"
    env["DISABLE_AUTOUPDATER"] = "1"
    env["CLAUDE_CODE_SKIP_PROMPT_HISTORY"] = "1"
    env["CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY"] = "0"
    env["API_TIMEOUT_MS"] = "300000"
    # Explicitly clear alternate providers inherited from the user's shell.
    for name in (
        "ANTHROPIC_API_KEY", "CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX",
        "CLAUDE_CODE_USE_FOUNDRY", "CLAUDE_CODE_USE_MANTLE",
    ):
        env.pop(name, None)

    claude_exe, _ = _claude_runtime_paths()
    if claude_exe:
        env["PATH"] = os.pathsep.join([str(claude_exe.parent), env.get("PATH", "")])

    if gateway_base_url:
        env["ANTHROPIC_BASE_URL"] = gateway_base_url
        # This is only a local gateway credential. The real Zen key remains in
        # the Python process and is never exposed to Claude Code.
        env["ANTHROPIC_AUTH_TOKEN"] = "redscribe-local"
    else:
        env.pop("ANTHROPIC_BASE_URL", None)
        env.pop("ANTHROPIC_AUTH_TOKEN", None)
    return env

def _claude_popen(
    claude_path: Path,
    args: list[str],
    prompt: str,
    *,
    env: dict[str, str],
    cwd: Path,
) -> subprocess.Popen:
    """Start native Claude Code and feed the prompt through stdin.

    The native Windows binary avoids npm ``.cmd`` wrappers, Node.js package
    layout changes, quoting/codepage issues, and Windows command-line length
    limits. The actual prompt/transcription never appears in CreateProcess'
    command line.
    """
    argv = [str(claude_path), *args]
    kwargs: dict[str, Any] = {
        "cwd": str(cwd),
        "env": env,
        "stdin": subprocess.PIPE,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.STDOUT,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
        "bufsize": 1,
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(argv, **kwargs)

    def _write_prompt() -> None:
        try:
            if proc.stdin is not None:
                proc.stdin.write(prompt)
                proc.stdin.close()
        except (BrokenPipeError, OSError, ValueError):
            pass

    threading.Thread(target=_write_prompt, daemon=True).start()
    return proc

def _runtime_installer_script() -> Path:
    return _app_resource_path("runtime_scripts", "install_claude_code.ps1")


def _set_runtime_ai_state(status: str, message: str) -> None:
    with _claude_lock:
        _ai_runtime_state.update({"status": status, "message": message, "updated_at": int(time.time())})


def claude_ai_status(user_id: str) -> dict[str, Any]:
    return {
        "status": "ready",
        "message": "IA integrada pronta para resumir, organizar, criar roteiros e ajudar na seleção de trechos.",
        "runtime_installed": True,
        "key_configured": True,
        "gateway": "Núcleo integrado do RedScribe",
        "provider": "RedScribe IA integrada",
        "model": "Núcleo editorial local",
        "fallback_models": [],
        "cloud": False,
        "free_tier_note": "Funciona nesta instalação sem chave, login técnico ou configuração adicional.",
    }


def _install_claude_runtime_worker() -> None:
    script = _runtime_installer_script()
    if not script.exists():
        _set_runtime_ai_state("error", "O instalador interno do Claude Code não foi encontrado.")
        return
    _set_runtime_ai_state("installing", "Instalando/atualizando Claude Code...")
    try:
        args = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)]
        kwargs: dict[str, Any] = {"capture_output": True, "text": True, "timeout": 1800}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(args, **kwargs)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()[-1000:]
            raise RuntimeError(detail or f"PowerShell retornou {result.returncode}.")
        _set_runtime_ai_state("idle", "Claude Code foi preparado.")
    except Exception as exc:
        _set_runtime_ai_state("error", f"Falha ao preparar Claude Code: {exc}")


def prepare_claude_runtime_async() -> bool:
    with _claude_lock:
        if _ai_runtime_state.get("status") == "installing":
            return False
        _ai_runtime_state.update({"status": "installing", "message": "Preparando Claude Code...", "updated_at": int(time.time())})
    threading.Thread(target=_install_claude_runtime_worker, daemon=True).start()
    return True


def _claude_prompt_args() -> list[str]:
    # Claude Code is intentionally restricted to text-only. No Bash/read/edit/MCP
    # tools are exposed, because the upstream DeepSeek model is reached through a
    # compatibility gateway rather than a supported Anthropic provider.
    # IMPORTANT: the actual prompt is piped through stdin, never passed here.
    return [
        "-p",
        "--bare",
        "--no-session-persistence",
        "--tools", "",
        "--disallowedTools", "mcp__*",
        "--disable-slash-commands",
        "--max-turns", "1",
        "--output-format", "stream-json",
        "--verbose",
        "--include-partial-messages",
        "--model", "sonnet",
        "--system-prompt", (
            "Você é a IA integrada ao RedScribe. Responda com clareza, em português "
            "do Brasil quando o usuário escrever em português. Use apenas o contexto "
            "fornecido quando a pergunta for sobre uma transcrição."
        ),
        "--no-chrome",
    ]


def _extract_claude_text_event(event: dict[str, Any]) -> str:
    # Claude Code stream-json can expose partial text as stream_event and the final
    # answer as a result event. We support both and de-duplicate repeated text.
    if event.get("type") == "stream_event":
        inner = event.get("event") if isinstance(event.get("event"), dict) else {}
        if inner.get("type") == "content_block_delta":
            delta = inner.get("delta") if isinstance(inner.get("delta"), dict) else {}
            if delta.get("type") in {"text_delta", None}:
                return str(delta.get("text") or "")
    if event.get("type") == "assistant":
        message = event.get("message") if isinstance(event.get("message"), dict) else {}
        parts = message.get("content") if isinstance(message.get("content"), list) else []
        texts = [str(p.get("text") or "") for p in parts if isinstance(p, dict) and p.get("type") == "text"]
        return "".join(texts)
    return ""


def _claude_generate_stream(prompt: str, user_id: str, timeout: int = 300):
    # Mantém o contrato dos fluxos legados, porém a resposta padrão agora é
    # produzida pelo núcleo integrado e não depende de credencial externa.
    yield from _integrated_ai_stream(prompt)
    return
    api_key = _load_zen_key(user_id)
    if not api_key:
        yield {"type": "error", "error": "Configure sua chave do OpenCode Zen em Configurações > IA."}
        return
    claude_exe, _ = _claude_runtime_paths()
    if not claude_exe:
        yield {"type": "error", "error": "Claude Code não está instalado corretamente. Use Configurações > IA > Preparar / reparar."}
        return

    gateway = ZenAnthropicGateway(
        api_key,
        ZEN_CHAT_COMPLETIONS_URL,
        DEFAULT_AI_MODEL,
        fallback_models=FREE_AI_FALLBACK_MODELS,
    )
    proc = None
    try:
        gateway_url = gateway.start()
        env = _claude_child_env(gateway_url)
        yield {"type": "status", "message": "Claude Code está analisando..."}
        proc = _claude_popen(claude_exe, _claude_prompt_args(), prompt, env=env, cwd=_claude_home())
        q: queue.Queue[tuple[str, str | None]] = queue.Queue()

        def reader() -> None:
            try:
                assert proc is not None and proc.stdout is not None
                for line in proc.stdout:
                    q.put(("line", line))
            finally:
                q.put(("eof", None))

        threading.Thread(target=reader, daemon=True).start()
        deadline = time.time() + timeout
        emitted = ""
        final_result = ""
        diagnostics: list[str] = []
        eof_seen = False
        while time.time() < deadline:
            try:
                kind, value = q.get(timeout=0.5)
            except queue.Empty:
                if proc.poll() is not None:
                    eof_seen = True
                    break
                continue
            if kind == "eof":
                eof_seen = True
                break
            line = (value or "").strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                diagnostics.append(line)
                diagnostics = diagnostics[-12:]
                continue
            text = _extract_claude_text_event(event)
            if text:
                if emitted and text.startswith(emitted):
                    text = text[len(emitted):]
                if text:
                    emitted += text
                    yield {"type": "token", "text": text}
            if event.get("type") == "result":
                final_result = str(event.get("result") or "")
                if event.get("is_error"):
                    detail = str(event.get("result") or event.get("error") or "Erro no Claude Code.")
                    raise RuntimeError(detail)
        if eof_seen:
            try:
                code = proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                try:
                    proc.terminate()
                except Exception:
                    pass
                raise TimeoutError("Claude Code terminou o fluxo, mas não encerrou corretamente.")
        elif proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
            raise TimeoutError("A IA demorou mais de 5 minutos para responder.")
        else:
            code = proc.wait(timeout=10)
        if not emitted.strip() and final_result.strip():
            emitted = final_result
            yield {"type": "token", "text": final_result}
        if code != 0 and not emitted.strip():
            extra = " | ".join(diagnostics[-4:])
            raise RuntimeError(f"Claude Code encerrou com código {code}. {extra}".strip())
        if not emitted.strip():
            extra = " | ".join(diagnostics[-4:])
            raise RuntimeError(("Claude Code terminou sem retornar texto. " + extra).strip())
        yield {"type": "done"}
    except TimeoutError as exc:
        yield {"type": "error", "error": str(exc)}
    except Exception as exc:
        yield {"type": "error", "error": f"Falha na IA: {exc}"}
    finally:
        if proc and proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass
        gateway.close()


def _claude_generate(prompt: str, user_id: str, timeout: int = 300) -> str:
    parts: list[str] = []
    error = None
    for event in _claude_generate_stream(prompt, user_id, timeout=timeout):
        if event.get("type") == "token":
            parts.append(str(event.get("text") or ""))
        if event.get("type") == "error":
            error = str(event.get("error") or "Erro na IA.")
    if error:
        raise RuntimeError(error)
    result = "".join(parts).strip()
    if not result:
        raise RuntimeError("A IA terminou sem resposta.")
    return result


_AI_ATTACHMENT_ALLOWED = {".txt", ".md", ".markdown", ".csv", ".json", ".log", ".srt", ".vtt", ".pdf", ".docx", ".py", ".js", ".ts", ".html", ".css", ".xml", ".yaml", ".yml", ".ini", ".toml", ".sql", ".ps1", ".bat", ".sh", ".java", ".c", ".cpp", ".h", ".hpp", ".zip"}
_AI_ATTACHMENT_ZIP_MEMBER_ALLOWED = _AI_ATTACHMENT_ALLOWED - {".zip"}
_AI_ATTACHMENT_MAX_BYTES = 12 * 1024 * 1024
_AI_ATTACHMENT_ZIP_MAX_BYTES = 24 * 1024 * 1024
_AI_ATTACHMENT_ZIP_MAX_FILES = 80
_AI_ATTACHMENT_ZIP_MAX_MEMBER_BYTES = 8 * 1024 * 1024
_AI_ATTACHMENT_ZIP_MAX_UNCOMPRESSED = 40 * 1024 * 1024
_AI_ATTACHMENT_ZIP_MAX_RATIO = 120
_AI_ATTACHMENT_ZIP_IGNORED_DIRS = {"node_modules", ".git", ".svn", ".hg", "__pycache__", ".venv", "venv", "dist", "build", ".idea", ".vscode"}
_AI_ATTACHMENT_TEXT_LIMIT = 90000
_AI_ATTACHMENT_TOTAL_CONTEXT = 140000
_dictation_model_lock = threading.RLock()
_dictation_model = None


def _ai_attachment_dir(user_id: str) -> Path:
    path = _user_dir(user_id) / "ai_attachments"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _ai_attachment_meta_path(user_id: str, attachment_id: str) -> Path:
    return _ai_attachment_dir(user_id) / f"{attachment_id}.json"


def _clean_attachment_text(text: str) -> str:
    text = (text or "").replace("\x00", "")
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def _extract_ai_attachment_text(path: Path, ext: str) -> str:
    ext = ext.lower()
    if ext in {".txt", ".md", ".markdown", ".csv", ".json", ".log", ".srt", ".vtt", ".py", ".js", ".ts", ".html", ".css", ".xml", ".yaml", ".yml", ".ini", ".toml", ".sql", ".ps1", ".bat", ".sh", ".java", ".c", ".cpp", ".h", ".hpp"}:
        raw = path.read_bytes()
        for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
            try:
                return _clean_attachment_text(raw.decode(enc))[:_AI_ATTACHMENT_TEXT_LIMIT]
            except UnicodeDecodeError:
                continue
        return _clean_attachment_text(raw.decode("utf-8", errors="replace"))[:_AI_ATTACHMENT_TEXT_LIMIT]
    if ext == ".docx":
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("O leitor DOCX não está disponível.") from exc
        doc = Document(str(path))
        text = "\n".join(p.text for p in doc.paragraphs if (p.text or "").strip())
        for table in doc.tables:
            for row in table.rows:
                values = [cell.text.strip() for cell in row.cells]
                if any(values):
                    text += "\n" + " | ".join(values)
        return _clean_attachment_text(text)[:_AI_ATTACHMENT_TEXT_LIMIT]
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("O leitor PDF não está disponível nesta instalação.") from exc
        reader = PdfReader(str(path))
        parts: list[str] = []
        total = 0
        for page in reader.pages:
            try:
                page_text = page.extract_text() or ""
            except Exception:
                page_text = ""
            if page_text.strip():
                parts.append(page_text)
                total += len(page_text)
            if total >= _AI_ATTACHMENT_TEXT_LIMIT:
                break
        return _clean_attachment_text("\n\n".join(parts))[:_AI_ATTACHMENT_TEXT_LIMIT]
    if ext == ".zip":
        try:
            with zipfile.ZipFile(path, "r") as zf:
                infos = [info for info in zf.infolist() if not info.is_dir()]
                if len(infos) > 5000:
                    raise RuntimeError("Este ZIP contém arquivos demais para análise segura. Remova dependências/cache e tente novamente.")
                parts: list[str] = []
                used_files = 0
                skipped_files = 0
                total_uncompressed = 0
                total_text = 0
                with tempfile.TemporaryDirectory(prefix="redscribe-ai-zip-") as tmp:
                    tmp_dir = Path(tmp)
                    for info in infos:
                        raw_name = str(info.filename or "arquivo").replace("\\", "/")
                        clean_parts = [part for part in raw_name.split("/") if part not in {"", ".", ".."}]
                        clean_name = "/".join(clean_parts) or "arquivo"
                        if any(part.lower() in _AI_ATTACHMENT_ZIP_IGNORED_DIRS for part in clean_parts[:-1]):
                            skipped_files += 1
                            continue
                        member_ext = Path(clean_name).suffix.lower()
                        if member_ext not in _AI_ATTACHMENT_ZIP_MEMBER_ALLOWED:
                            skipped_files += 1
                            continue
                        if info.flag_bits & 0x1:
                            skipped_files += 1
                            continue
                        if used_files >= _AI_ATTACHMENT_ZIP_MAX_FILES:
                            skipped_files += 1
                            continue
                        member_size = int(info.file_size or 0)
                        compressed_size = max(1, int(info.compress_size or 0))
                        if member_size > _AI_ATTACHMENT_ZIP_MAX_MEMBER_BYTES:
                            skipped_files += 1
                            continue
                        if member_size > compressed_size * _AI_ATTACHMENT_ZIP_MAX_RATIO:
                            raise RuntimeError("O ZIP parece ter uma taxa de compactação insegura e foi bloqueado.")
                        total_uncompressed += member_size
                        if total_uncompressed > _AI_ATTACHMENT_ZIP_MAX_UNCOMPRESSED:
                            raise RuntimeError("O conteúdo descompactado do ZIP é grande demais para análise segura.")
                        try:
                            with zf.open(info, "r") as source:
                                raw = source.read(_AI_ATTACHMENT_ZIP_MAX_MEMBER_BYTES + 1)
                        except (RuntimeError, zipfile.BadZipFile, NotImplementedError):
                            skipped_files += 1
                            continue
                        if len(raw) > _AI_ATTACHMENT_ZIP_MAX_MEMBER_BYTES:
                            skipped_files += 1
                            continue
                        member_path = tmp_dir / f"member_{used_files:03d}{member_ext}"
                        member_path.write_bytes(raw)
                        try:
                            member_text = _extract_ai_attachment_text(member_path, member_ext)
                        except Exception:
                            skipped_files += 1
                            continue
                        if not member_text.strip():
                            skipped_files += 1
                            continue
                        header = f"\n\n### ARQUIVO NO ZIP: {clean_name}\n"
                        remaining = _AI_ATTACHMENT_TEXT_LIMIT - total_text - len(header)
                        if remaining <= 0:
                            break
                        member_text = member_text[:remaining]
                        parts.append(header + member_text)
                        total_text += len(header) + len(member_text)
                        used_files += 1
                        if total_text >= _AI_ATTACHMENT_TEXT_LIMIT:
                            break
                if not parts:
                    raise RuntimeError("O ZIP não contém documentos suportados com texto legível.")
                summary = f"ZIP analisado: {used_files} arquivo(s) legível(is)"
                if skipped_files:
                    summary += f"; {skipped_files} arquivo(s) ignorado(s) por formato, tamanho ou segurança"
                return (summary + "\n" + "".join(parts))[:_AI_ATTACHMENT_TEXT_LIMIT]
        except zipfile.BadZipFile as exc:
            raise RuntimeError("O arquivo ZIP está corrompido ou não é um ZIP válido.") from exc
    raise RuntimeError("Formato de anexo não suportado para análise de texto.")


def _load_ai_attachment(user_id: str, attachment_id: str) -> dict[str, Any] | None:
    if not re.fullmatch(r"[a-f0-9]{32}", attachment_id or ""):
        return None
    meta_path = _ai_attachment_meta_path(user_id, attachment_id)
    if not meta_path.exists():
        return None
    try:
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("user_id") != user_id:
            return None
        return data
    except Exception:
        return None


def _attachment_context(user_id: str, attachment_ids: list[str]) -> tuple[str, list[dict[str, Any]]]:
    blocks: list[str] = []
    public_items: list[dict[str, Any]] = []
    total = 0
    for raw_id in attachment_ids[:8]:
        item = _load_ai_attachment(user_id, str(raw_id))
        if not item:
            continue
        text = str(item.get("text") or "")
        if not text.strip():
            continue
        remaining = _AI_ATTACHMENT_TOTAL_CONTEXT - total
        if remaining <= 0:
            break
        text = text[:remaining]
        total += len(text)
        name = str(item.get("name") or "Arquivo")
        blocks.append(f"\n\n--- ANEXO: {name} ---\n{text}")
        public_items.append({"id": item.get("id"), "name": name, "size": int(item.get("size") or 0), "ext": item.get("ext")})
    return "".join(blocks), public_items


def _dictation_whisper_model():
    global _dictation_model
    with _dictation_model_lock:
        if _dictation_model is not None:
            return _dictation_model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError("Reconhecimento avançado não está disponível para ditado.") from exc
        model_path = BASE_DIR / "models" / "faster-whisper-small"
        model_name = os.environ.get("WHISPER_MODEL", str(model_path) if model_path.exists() else "small")
        device = os.environ.get("WHISPER_DEVICE", "cpu")
        compute_type = os.environ.get("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
        _dictation_model = WhisperModel(model_name, device=device, compute_type=compute_type)
        return _dictation_model


def _transcribe_dictation_file(path: Path, language: str = "pt") -> str:
    model = _dictation_whisper_model()
    lang = None if language == "auto" else (language if language in LANGUAGE_MAP else "pt")
    segments, _ = model.transcribe(str(path), language=lang, vad_filter=True, beam_size=3)
    parts = [(seg.text or "").strip() for seg in segments]
    return _clean_attachment_text(" ".join(p for p in parts if p))

def _ai_history_path(user_id: str) -> Path:
    return _user_dir(user_id) / "ai_history.json"


def _load_ai_history(user_id: str) -> list[dict[str, Any]]:
    path = _ai_history_path(user_id)
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        if not isinstance(data, list): return []
        out = []
        for item in data[-40:]:
            if not isinstance(item, dict): continue
            role = str(item.get("role") or "")
            text = str(item.get("text") or "").strip()
            if role in {"user", "assistant"} and text:
                attachments = item.get("attachments") if isinstance(item.get("attachments"), list) else []
                safe_attachments = []
                for attachment in attachments[:8]:
                    if isinstance(attachment, dict):
                        safe_attachments.append({
                            "id": str(attachment.get("id") or ""),
                            "name": str(attachment.get("name") or "Arquivo")[:180],
                            "size": int(attachment.get("size") or 0),
                            "ext": str(attachment.get("ext") or "")[:12],
                        })
                out.append({"role": role, "text": text[:30000], "created_at": int(item.get("created_at") or 0), "attachments": safe_attachments})
        return out
    except Exception:
        return []


def _save_ai_history(user_id: str, items: list[dict[str, Any]]) -> None:
    _atomic_write_json(_ai_history_path(user_id), items[-40:])


def _general_ai_prompt(
    user_id: str,
    message: str,
    job: dict[str, Any] | None = None,
    attachment_context: str = "",
) -> str:
    history = _load_ai_history(user_id)[-10:]
    conversation = "\n".join(("Usuário" if x["role"] == "user" else "Assistente") + ": " + x["text"] for x in history)
    context = ""
    if job and job.get("transcript_available"):
        context = _ai_context(job, "ask", message)
        context = f"\n\nCONTEXTO DO CONTEÚDO SELECIONADO ({job.get('title') or 'sem título'}):\n{context}"
    return (
        "Você é a IA do RedScribe. Responda em português do Brasil, com clareza e objetividade. "
        "Organize respostas com Markdown legível: use títulos curtos quando fizer sentido, parágrafos curtos, "
        "listas com marcadores ou numeradas para passos, **negrito** para pontos importantes e blocos de código somente quando necessário. "
        "Nunca devolva uma parede única de texto e não exiba os marcadores Markdown como se fossem texto literal. "
        "Quando houver contexto de uma transcrição ou de arquivos anexados, não invente fatos que não estejam neles. "
        "Se faltar informação no material enviado, diga isso claramente. "
        "Não diga que é Claude, DeepSeek ou OpenCode a menos que a pessoa pergunte sobre a tecnologia.\n\n"
        + ("HISTÓRICO RECENTE:\n" + conversation + "\n\n" if conversation else "")
        + "MENSAGEM ATUAL:\n" + message + context + attachment_context
    )


def _find_text_timestamp(job: dict[str, Any], query: str) -> float | None:
    q = (query or "").strip().lower()
    if not q:
        return None
    for seg in _job_segments(job):
        if q in str(seg.get("text") or "").lower():
            return float(seg.get("start") or 0)
    return None


def _local_media_audio(source: Path, job_id: str) -> Path:
    work = audio_dir(job_id)
    existing = find_job_audio(job_id)
    if existing:
        return existing
    ffmpeg = _ffmpeg_location()
    if not ffmpeg:
        raise RuntimeError("FFmpeg não foi encontrado para extrair o áudio do arquivo enviado.")
    destination = work / "audio.m4a"
    cmd = [ffmpeg, "-y", "-i", str(source), "-vn", "-c:a", "aac", "-b:a", "192k", str(destination)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if result.returncode != 0 or not destination.exists():
        # Áudio puro pode ser copiado quando FFmpeg não consegue remuxar para m4a.
        if source.suffix.lower() in {".mp3", ".m4a", ".aac", ".wav", ".ogg", ".opus", ".flac"}:
            destination = work / f"audio{source.suffix.lower()}"
            shutil.copy2(source, destination)
            return destination
        raise RuntimeError("Não foi possível extrair o áudio do arquivo enviado.")
    return destination


def _is_video_file(path: Path) -> bool:
    return path.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}


def _is_image_file(path: Path) -> bool:
    return path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}


def _image_to_silent_video(source: Path, work: Path) -> Path:
    ffmpeg = _ffmpeg_location()
    if not ffmpeg:
        raise RuntimeError("FFmpeg não foi encontrado para preparar a imagem como vídeo.")
    destination = work / "video.mp4"
    filter_chain = "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black,format=yuv420p"
    command = [
        ffmpeg, "-y", "-loop", "1", "-i", str(source),
        "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
        "-t", "15", "-vf", filter_chain,
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-c:a", "aac", "-b:a", "128k", "-shortest", "-movflags", "+faststart", str(destination),
    ]
    result = subprocess.run(command, capture_output=True, text=True, timeout=3600)
    if result.returncode != 0 or not destination.exists():
        raise RuntimeError("Não foi possível preparar a imagem como vídeo.")
    return destination


def _audio_to_visual_video(source: Path, work: Path) -> Path:
    ffmpeg = _ffmpeg_location()
    if not ffmpeg:
        raise RuntimeError("FFmpeg não foi encontrado para preparar o áudio como vídeo.")
    destination = work / "video.mp4"
    filter_chain = "[0:a]showwaves=s=1080x1920:mode=line:colors=white:draw=full,format=yuv420p[v]"
    command = [
        ffmpeg, "-y", "-i", str(source), "-filter_complex", filter_chain,
        "-map", "[v]", "-map", "0:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "160k", "-shortest", "-movflags", "+faststart", str(destination),
    ]
    result = subprocess.run(command, capture_output=True, text=True, timeout=3600)
    if result.returncode != 0 or not destination.exists():
        raise RuntimeError("Não foi possível preparar o áudio como vídeo.")
    return destination


def _probe_media_duration(path: Path) -> float:
    ffmpeg = _ffmpeg_location()
    if not ffmpeg or not path.exists():
        return 0.0
    try:
        result = subprocess.run([ffmpeg, "-i", str(path)], capture_output=True, text=True, timeout=60)
        text = (result.stderr or "") + "\n" + (result.stdout or "")
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
        if not match:
            return 0.0
        h, m, sec = int(match.group(1)), int(match.group(2)), float(match.group(3))
        return h * 3600 + m * 60 + sec
    except Exception:
        return 0.0


def _thumbnail_for_job(job: dict[str, Any]) -> str | None:
    if job.get("thumbnail_url"):
        return str(job.get("thumbnail_url"))
    if job.get("video_id"):
        return f"https://i.ytimg.com/vi/{job['video_id']}/hqdefault.jpg"
    return None


def queued_worker(job_id: str) -> None:
    with _processing_semaphore:
        worker(job_id)


def job_path(job_id: str) -> Path:
    return DATA_DIR / f"{job_id}.json"


def save_job(job: dict[str, Any]) -> None:
    with _lock:
        _jobs[job["id"]] = job
        job_path(job["id"]).write_text(
            json.dumps(job, ensure_ascii=False, indent=2), encoding="utf-8"
        )


def _normalize_job_record(job: dict[str, Any]) -> dict[str, Any]:
    transcript = str(job.get("transcript") or "")
    job.setdefault("transcript_available", bool(transcript.strip()))
    job.setdefault("media_only", bool(job.get("status") == "done" and not transcript.strip() and (job.get("audio_ready") or job.get("video_ready"))))
    job.setdefault("segments", [])
    if not job.get("segments") and transcript.strip():
        parsed_segments = []
        pattern = re.compile(r"^\[(\d{2}):(\d{2}):(\d{2})\]\s*(.+)$")
        rows = []
        for line in transcript.splitlines():
            match = pattern.match(line.strip())
            if match:
                start = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + int(match.group(3))
                rows.append((float(start), match.group(4).strip()))
        for idx, (start, text) in enumerate(rows):
            next_start = rows[idx + 1][0] if idx + 1 < len(rows) else start + 5.0
            parsed_segments.append({"text": text, "start": start, "duration": max(0.5, next_start - start)})
        if parsed_segments:
            job["segments"] = parsed_segments
    job.setdefault("favorite", False)
    job.setdefault("tags", [])
    job.setdefault("project_id", None)
    job.setdefault("source_type", "youtube")
    job.setdefault("trashed_at", None)
    if not job.get("thumbnail_url") and job.get("video_id"):
        job["thumbnail_url"] = f"https://i.ytimg.com/vi/{job['video_id']}/hqdefault.jpg"
    return job


def get_job(job_id: str) -> dict[str, Any] | None:
    with _lock:
        if job_id in _jobs:
            return _normalize_job_record(_jobs[job_id])
    path = job_path(job_id)
    if path.exists():
        try:
            job = _normalize_job_record(json.loads(path.read_text(encoding="utf-8")))
            with _lock:
                _jobs[job_id] = job
            return job
        except Exception:
            return None
    return None


def update_job(job_id: str, **changes: Any) -> None:
    job = get_job(job_id)
    if not job:
        return
    job.update(changes)
    job["updated_at"] = int(time.time())
    save_job(job)


def fetch_title(url: str) -> str:
    try:
        import yt_dlp

        opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
            "extract_flat": False,
        }
        opts.update(_youtube_runtime_opts())
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return (info or {}).get("title") or "Transcrição do YouTube"
    except Exception:
        return "Transcrição do YouTube"


def fetch_youtube_captions(video_id: str, language_key: str) -> tuple[list[TranscriptSegment], str]:
    api = YouTubeTranscriptApi()
    transcript_list = api.list(video_id)
    preferred = LANGUAGE_MAP.get(language_key, [])

    selected = None
    if preferred:
        try:
            selected = transcript_list.find_transcript(preferred)
        except NoTranscriptFound:
            selected = None

    if selected is None:
        available = list(transcript_list)
        if not available:
            raise RuntimeError('Nenhuma faixa de legenda foi encontrada para este vídeo.')
        selected = available[0]

    fetched = selected.fetch()
    segments = [
        TranscriptSegment(text=item.text, start=float(item.start), duration=float(item.duration))
        for item in fetched
    ]
    return segments, selected.language_code


def audio_dir(job_id: str) -> Path:
    path = DATA_DIR / job_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def find_job_audio(job_id: str) -> Path | None:
    job = get_job(job_id)
    if job:
        filename = job.get("audio_filename")
        if filename:
            candidate = audio_dir(job_id) / Path(filename).name
            if candidate.exists() and candidate.is_file():
                return candidate

    work_dir = audio_dir(job_id)
    candidates = sorted(
        [p for p in work_dir.glob("audio.*") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def audio_mimetype(path: Path) -> str:
    extension = path.suffix.lower()
    known = {
        ".m4a": "audio/mp4",
        ".mp4": "audio/mp4",
        ".mp3": "audio/mpeg",
        ".webm": "audio/webm",
        ".opus": "audio/ogg",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".aac": "audio/aac",
        ".flac": "audio/flac",
    }
    return known.get(extension) or mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def find_job_video(job_id: str) -> Path | None:
    job = get_job(job_id)
    if job:
        filename = job.get("video_filename")
        if filename:
            candidate = audio_dir(job_id) / Path(filename).name
            if candidate.exists() and candidate.is_file():
                return candidate

    work_dir = audio_dir(job_id)
    candidates = sorted(
        [p for p in work_dir.glob("video.*") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def video_mimetype(path: Path) -> str:
    extension = path.suffix.lower()
    known = {
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".mkv": "video/x-matroska",
        ".mov": "video/quicktime",
        ".m4v": "video/x-m4v",
    }
    return known.get(extension) or mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def _clean_yt_error(value: object) -> str:
    # yt-dlp can emit ANSI color sequences in exception text. Do not leak those into the UI.
    text = str(value or "")
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _remove_attempt_files(work_dir: Path, prefix: str) -> None:
    for candidate in work_dir.glob(f"{prefix}*"):
        try:
            if candidate.is_file():
                candidate.unlink()
        except OSError:
            pass


def _internal_tool(name: str) -> Path | None:
    """Locate a bundled RedScribe tool without relying only on the user's PATH."""
    found = shutil.which(name)
    if found and Path(found).exists():
        return Path(found)
    candidates = [
        BASE_DIR / "tools" / name,
        Path(getattr(sys, "_MEIPASS", BASE_DIR)) / "tools" / name,
        Path(sys.executable).resolve().parent / "tools" / name,
        Path(sys.executable).resolve().parent / "_internal" / "tools" / name,
    ]
    for candidate in candidates:
        try:
            if candidate.exists():
                return candidate
        except OSError:
            pass
    return None


def _deno_runtime() -> Path | None:
    return _internal_tool("deno.exe" if os.name == "nt" else "deno")


def _official_ytdlp() -> Path | None:
    # On Windows the builder bundles the official yt-dlp executable. It contains the
    # matching EJS scripts, making the frozen app independent of PyInstaller package-data quirks.
    return _internal_tool("yt-dlp.exe" if os.name == "nt" else "yt-dlp")


def _has_js_runtime() -> bool:
    return _deno_runtime() is not None


def _youtube_runtime_opts() -> dict[str, Any]:
    deno = _deno_runtime()
    if not deno:
        return {}
    return {"js_runtimes": {"deno": {"path": str(deno)}}}


def _run_official_ytdlp_download(
    url: str,
    output_template: str,
    format_selector: str,
    *,
    ffmpeg: str | None = None,
    merge_mp4: bool = False,
    force_ipv4: bool = False,
) -> tuple[Path, str]:
    exe = _official_ytdlp()
    deno = _deno_runtime()
    if not exe:
        raise RuntimeError("Motor yt-dlp.exe interno não foi encontrado.")
    if not deno:
        raise RuntimeError("Runtime Deno interno não foi encontrado.")

    cmd = [
        str(exe),
        "--ignore-config",
        "--no-playlist",
        "--no-progress",
        "--retries", "5",
        "--fragment-retries", "5",
        "--file-access-retries", "3",
        "--socket-timeout", "25",
        "--force-overwrites",
        "--windows-filenames" if os.name == "nt" else "--restrict-filenames",
        "--js-runtimes", f"deno:{deno}",
        "-f", format_selector,
        "-o", output_template,
    ]
    if force_ipv4:
        cmd.append("--force-ipv4")
    if ffmpeg:
        cmd.extend(["--ffmpeg-location", str(ffmpeg)])
    if merge_mp4:
        cmd.extend(["--merge-output-format", "mp4"])
    cmd.append(url)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=1800,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    detail = _clean_yt_error((result.stderr or "") + " " + (result.stdout or ""))
    if result.returncode != 0:
        raise RuntimeError(detail[-1600:] or f"yt-dlp.exe terminou com código {result.returncode}")

    template_path = Path(output_template)
    prefix = template_path.name.split("%(", 1)[0]
    candidates = [
        item for item in template_path.parent.glob(prefix + "*")
        if item.is_file() and item.suffix.lower() not in {".part", ".ytdl", ".temp"}
    ]
    candidates.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    if not candidates:
        raise RuntimeError("yt-dlp.exe terminou sem gerar um arquivo utilizável.")
    return candidates[0], detail


def download_audio_preview(url: str, job_id: str) -> Path:
    existing = find_job_audio(job_id)
    if existing:
        return existing

    work_dir = audio_dir(job_id)
    errors: list[str] = []

    # First choice in the installed app: the official yt-dlp executable bundled by
    # the ZERO-SETUP builder, with an explicit path to the bundled Deno runtime.
    try:
        _remove_attempt_files(work_dir, "audio_try0")
        update_job(job_id, stage="Preparando áudio com motor YouTube interno...", progress=96)
        downloaded, _ = _run_official_ytdlp_download(
            url,
            str(work_dir / "audio_try0.%(ext)s"),
            "bestaudio[ext=m4a]/bestaudio/best",
        )
        final_path = work_dir / f"audio{downloaded.suffix.lower()}"
        if final_path.exists():
            final_path.unlink()
        downloaded.replace(final_path)
        _remove_attempt_files(work_dir, "audio_try0")
        update_job(
            job_id,
            audio_filename=final_path.name,
            audio_ready=True,
            audio_error=None,
            audio_strategy="yt-dlp.exe + Deno/EJS",
            youtube_engine="official-exe",
        )
        return final_path
    except Exception as exc:
        errors.append(f"motor oficial: {_clean_yt_error(exc)}")
        _remove_attempt_files(work_dir, "audio_try0")

    # Fallback: Python API. The frozen package now also bundles yt_dlp_ejs explicitly.
    try:
        import yt_dlp
    except ImportError as exc:
        errors.append(f"API Python ausente: {_clean_yt_error(exc)}")
        yt_dlp = None

    # YouTube changes its delivery clients frequently. Instead of depending on one format/client,
    # try a small set of official yt-dlp-compatible strategies. The second attempt excludes
    # android_sdkless because this client has recently produced 403s for some videos.
    attempts: list[dict[str, Any]] = [
        {
            "name": "padrão",
            "format": "bestaudio[ext=m4a]/bestaudio/best",
            "extractor_args": {},
            "force_ipv4": False,
        },
        {
            "name": "cliente padrão sem android_sdkless",
            "format": "bestaudio[ext=m4a]/bestaudio/best",
            "extractor_args": {"youtube": {"player_client": ["default,-android_sdkless"]}},
            "force_ipv4": False,
        },
        {
            "name": "IPv4",
            "format": "bestaudio/best",
            "extractor_args": {"youtube": {"player_client": ["default,-android_sdkless"]}},
            "force_ipv4": True,
        },
        {
            "name": "HLS",
            "format": "bestaudio[protocol^=m3u8]/bestaudio/best",
            "extractor_args": {"youtube": {"player_client": ["default,-android_sdkless"]}},
            "force_ipv4": True,
        },
    ]

    for index, attempt in enumerate(attempts, start=1):
        prefix = f"audio_try{index}."
        _remove_attempt_files(work_dir, f"audio_try{index}")
        output_template = str(work_dir / f"audio_try{index}.%(ext)s")
        update_job(
            job_id,
            stage=f"Preparando áudio... tentativa {index}/{len(attempts)} ({attempt['name']})",
            progress=min(99, 96 + index // 2),
        )

        opts: dict[str, Any] = {
            "format": attempt["format"],
            "outtmpl": output_template,
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "restrictfilenames": True,
            "retries": 3,
            "fragment_retries": 3,
            "file_access_retries": 2,
            "socket_timeout": 20,
            "continuedl": True,
            "overwrites": True,
        }
        if attempt["extractor_args"]:
            opts["extractor_args"] = attempt["extractor_args"]
        if attempt["force_ipv4"]:
            opts["source_address"] = "0.0.0.0"
        opts.update(_youtube_runtime_opts())

        try:
            if yt_dlp is None:
                raise RuntimeError("API Python do yt-dlp não está disponível.")
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                prepared = Path(ydl.prepare_filename(info))

            candidates = [prepared] if prepared.exists() else []
            candidates += [
                p for p in work_dir.glob(f"audio_try{index}.*")
                if p.is_file() and p.suffix not in {".part", ".ytdl"}
            ]
            candidates = sorted(set(candidates), key=lambda p: p.stat().st_mtime, reverse=True)
            if not candidates:
                raise RuntimeError("yt-dlp terminou sem gerar o arquivo de áudio.")

            downloaded = candidates[0]
            final_path = work_dir / f"audio{downloaded.suffix.lower()}"
            if final_path.exists():
                final_path.unlink()
            downloaded.replace(final_path)

            # Remove leftovers from failed/older attempts after success.
            for stale in work_dir.glob("audio_try*.*"):
                try:
                    if stale.is_file():
                        stale.unlink()
                except OSError:
                    pass

            update_job(
                job_id,
                audio_filename=final_path.name,
                audio_ready=True,
                audio_error=None,
                audio_strategy=attempt["name"],
            )
            return final_path
        except Exception as exc:
            errors.append(f"{attempt['name']}: {_clean_yt_error(exc)}")
            _remove_attempt_files(work_dir, f"audio_try{index}")

    runtime_note = ""
    if not _has_js_runtime():
        runtime_note = (
            " Deno não foi detectado no computador. Execute REPARAR_YOUTUBE.bat; "
            "ele atualiza o yt-dlp/EJS e tenta instalar o runtime recomendado."
        )

    compact_errors = " | ".join(errors[-2:])
    if len(compact_errors) > 900:
        compact_errors = compact_errors[-900:]
    raise RuntimeError(
        "O YouTube recusou todas as tentativas de preparar o áudio."
        + runtime_note
        + (f" Detalhe: {compact_errors}" if compact_errors else "")
    )


def _ffmpeg_location() -> str | None:
    """Return an FFmpeg executable/location usable by yt-dlp when available."""
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg
    try:
        import imageio_ffmpeg

        bundled = imageio_ffmpeg.get_ffmpeg_exe()
        if bundled and Path(bundled).exists():
            return bundled
    except Exception:
        pass
    return None


def _video_height_from_info(info: dict[str, Any] | None) -> int | None:
    if not info:
        return None
    values: list[int] = []
    for candidate in [info, *(info.get("requested_formats") or [])]:
        try:
            height = int(candidate.get("height") or 0)
        except Exception:
            height = 0
        if height > 0:
            values.append(height)
    return max(values) if values else None


def download_video_preview(url: str, job_id: str) -> Path:
    existing = find_job_video(job_id)
    if existing:
        return existing

    ffmpeg = _ffmpeg_location()
    if not ffmpeg:
        raise RuntimeError(
            "FFmpeg não foi encontrado. Execute INSTALAR_WINDOWS.bat novamente para habilitar vídeo Full HD."
        )

    work_dir = audio_dir(job_id)
    errors: list[str] = []

    job = get_job(job_id) or {}
    requested_quality = str(job.get("video_quality_request") or "1080").lower()
    if requested_quality not in {"360", "720", "1080", "2160", "best"}:
        requested_quality = "1080"

    if requested_quality == "best":
        primary_format = (
            "bestvideo[ext=mp4][vcodec^=avc1]+bestaudio[ext=m4a]/"
            "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
        )
        attempt_label = "Melhor qualidade"
    else:
        target = int(requested_quality)
        exact = (
            f"bestvideo[height={target}][ext=mp4][vcodec^=avc1]+bestaudio[ext=m4a]/"
            f"bestvideo[height={target}][ext=mp4]+bestaudio[ext=m4a]/"
            f"bestvideo[height={target}]+bestaudio/best[height={target}]"
        )
        fallback = (
            f"bestvideo[height<={target}][ext=mp4][vcodec^=avc1]+bestaudio[ext=m4a]/"
            f"bestvideo[height<={target}][ext=mp4]+bestaudio[ext=m4a]/"
            f"bestvideo[height<={target}]+bestaudio/best[height<={target}]/best"
        )
        primary_format = f"{exact}/{fallback}"
        attempt_label = f"até {target}p"

    # Use official yt-dlp.exe first. This is deliberately independent from the
    # embedded Python package so Shorts keeps working on a newly formatted PC.
    try:
        _remove_attempt_files(work_dir, "video_try0")
        update_job(job_id, stage="Preparando vídeo com motor YouTube interno...", progress=97)
        downloaded, _ = _run_official_ytdlp_download(
            url,
            str(work_dir / "video_try0.%(ext)s"),
            primary_format,
            ffmpeg=ffmpeg,
            merge_mp4=True,
        )
        final_path = work_dir / f"video{downloaded.suffix.lower()}"
        if final_path.exists():
            final_path.unlink()
        downloaded.replace(final_path)
        _remove_attempt_files(work_dir, "video_try0")
        target_height = None if requested_quality == "best" else int(requested_quality)
        update_job(
            job_id,
            video_filename=final_path.name,
            video_ready=True,
            video_error=None,
            video_strategy="yt-dlp.exe + Deno/EJS",
            youtube_engine="official-exe",
            video_height=target_height,
            video_quality=(f"até {target_height}p" if target_height else "Melhor disponível"),
            video_is_full_hd=bool(target_height and target_height >= 1080),
        )
        return final_path
    except Exception as exc:
        errors.append(f"motor oficial: {_clean_yt_error(exc)}")
        _remove_attempt_files(work_dir, "video_try0")

    try:
        import yt_dlp
    except ImportError as exc:
        errors.append(f"API Python ausente: {_clean_yt_error(exc)}")
        yt_dlp = None

    attempts: list[dict[str, Any]] = [
        {
            "name": attempt_label,
            "format": primary_format,
            "extractor_args": {},
            "force_ipv4": False,
        },
        {
            "name": f"{attempt_label} sem android_sdkless",
            "format": primary_format,
            "extractor_args": {"youtube": {"player_client": ["default,-android_sdkless"]}},
            "force_ipv4": False,
        },
        {
            "name": f"{attempt_label} IPv4",
            "format": primary_format,
            "extractor_args": {"youtube": {"player_client": ["default,-android_sdkless"]}},
            "force_ipv4": True,
        },
    ]

    for index, attempt in enumerate(attempts, start=1):
        _remove_attempt_files(work_dir, f"video_try{index}")
        output_template = str(work_dir / f"video_try{index}.%(ext)s")
        update_job(
            job_id,
            stage=f"Preparando vídeo... tentativa {index}/{len(attempts)} ({attempt['name']})",
            progress=min(99, 97 + index // 2),
        )

        opts: dict[str, Any] = {
            "format": attempt["format"],
            "outtmpl": output_template,
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "restrictfilenames": True,
            "retries": 3,
            "fragment_retries": 3,
            "file_access_retries": 2,
            "socket_timeout": 25,
            "continuedl": True,
            "overwrites": True,
            "ffmpeg_location": ffmpeg,
            "merge_output_format": "mp4",
        }
        if attempt["extractor_args"]:
            opts["extractor_args"] = attempt["extractor_args"]
        if attempt["force_ipv4"]:
            opts["source_address"] = "0.0.0.0"
        opts.update(_youtube_runtime_opts())

        try:
            if yt_dlp is None:
                raise RuntimeError("API Python do yt-dlp não está disponível.")
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                prepared = Path(ydl.prepare_filename(info))

            candidates = [prepared] if prepared.exists() else []
            candidates += [
                p for p in work_dir.glob(f"video_try{index}.*")
                if p.is_file() and p.suffix not in {".part", ".ytdl"}
            ]
            candidates = sorted(set(candidates), key=lambda p: p.stat().st_mtime, reverse=True)
            if not candidates:
                raise RuntimeError("yt-dlp terminou sem gerar o arquivo de vídeo.")

            downloaded = candidates[0]
            final_path = work_dir / f"video{downloaded.suffix.lower()}"
            if final_path.exists():
                final_path.unlink()
            downloaded.replace(final_path)

            for stale in work_dir.glob("video_try*.*"):
                try:
                    if stale.is_file():
                        stale.unlink()
                except OSError:
                    pass

            height = _video_height_from_info(info)
            quality = f"{height}p" if height else "Melhor disponível"
            update_job(
                job_id,
                video_filename=final_path.name,
                video_ready=True,
                video_error=None,
                video_strategy=attempt["name"],
                video_height=height,
                video_quality=quality,
                video_is_full_hd=bool(height and height >= 1080),
                duration_seconds=float(info.get("duration") or (get_job(job_id) or {}).get("duration_seconds") or 0),
            )
            return final_path
        except Exception as exc:
            errors.append(f"{attempt['name']}: {_clean_yt_error(exc)}")
            _remove_attempt_files(work_dir, f"video_try{index}")

    runtime_note = ""
    if not _has_js_runtime():
        runtime_note = (
            " Deno não foi detectado. Execute REPARAR_YOUTUBE.bat para atualizar "
            "o suporte do YouTube."
        )

    compact_errors = " | ".join(errors[-2:])
    if len(compact_errors) > 900:
        compact_errors = compact_errors[-900:]
    raise RuntimeError(
        "O YouTube recusou todas as tentativas de preparar o vídeo."
        + runtime_note
        + (f" Detalhe: {compact_errors}" if compact_errors else "")
    )


def whisper_transcribe(url: str, language_key: str, job_id: str) -> tuple[list[TranscriptSegment], str, Path]:
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError(
            "O modo Whisper não está instalado. Execute INSTALAR_WINDOWS.bat novamente."
        ) from exc

    update_job(job_id, stage="Baixando o áudio para transcrição...", progress=35)
    downloaded = download_audio_preview(url, job_id)

    update_job(job_id, stage="Carregando o modelo Reconhecimento avançado...", progress=50)
    model_name = os.environ.get("WHISPER_MODEL", str(BASE_DIR / "models" / "faster-whisper-small") if (BASE_DIR / "models" / "faster-whisper-small").exists() else "small")
    device = os.environ.get("WHISPER_DEVICE", "cpu")
    compute_type = os.environ.get("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
    model = WhisperModel(model_name, device=device, compute_type=compute_type)

    lang = None if language_key == "auto" else language_key
    update_job(job_id, stage="Transcrevendo o vídeo com Whisper...", progress=60)
    segment_iter, info_obj = model.transcribe(
        str(downloaded),
        language=lang,
        vad_filter=True,
        beam_size=5,
    )

    segments: list[TranscriptSegment] = []
    for index, seg in enumerate(segment_iter, start=1):
        segments.append(
            TranscriptSegment(
                text=(seg.text or "").strip(),
                start=float(seg.start),
                duration=max(0.0, float(seg.end) - float(seg.start)),
                no_speech_prob=float(getattr(seg, "no_speech_prob", 0.0) or 0.0),
                avg_logprob=float(getattr(seg, "avg_logprob", 0.0) or 0.0),
            )
        )
        if index % 12 == 0:
            # Faster Whisper does not expose an exact global progress percentage here.
            pseudo = min(92, 60 + index // 3)
            update_job(job_id, stage=f"Transcrevendo... {index} trechos processados", progress=pseudo)

    detected = getattr(info_obj, "language", None) or language_key or "auto"
    return segments, detected, downloaded


def _transcribe_audio_file(audio_file: Path, language_key: str, job_id: str) -> tuple[list[TranscriptSegment], str]:
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError("O modo Whisper não está instalado. Execute INSTALAR_WINDOWS.bat novamente.") from exc

    update_job(job_id, stage="Carregando o Reconhecimento avançado...", progress=48)
    model_name = os.environ.get("WHISPER_MODEL", str(BASE_DIR / "models" / "faster-whisper-small") if (BASE_DIR / "models" / "faster-whisper-small").exists() else "small")
    device = os.environ.get("WHISPER_DEVICE", "cpu")
    compute_type = os.environ.get("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
    model = WhisperModel(model_name, device=device, compute_type=compute_type)
    lang = None if language_key == "auto" else language_key
    update_job(job_id, stage="Analisando fala e sons...", progress=58)
    segment_iter, info_obj = model.transcribe(str(audio_file), language=lang, vad_filter=True, beam_size=5)
    segments: list[TranscriptSegment] = []
    for index, seg in enumerate(segment_iter, start=1):
        text = (seg.text or "").strip()
        if text:
            segments.append(TranscriptSegment(text=text, start=float(seg.start), duration=max(0.0, float(seg.end) - float(seg.start)), no_speech_prob=float(getattr(seg, "no_speech_prob", 0.0) or 0.0), avg_logprob=float(getattr(seg, "avg_logprob", 0.0) or 0.0)))
        if index % 12 == 0:
            update_job(job_id, stage=f"Analisando áudio... {index} trechos", progress=min(88, 58 + index // 3))
    detected = getattr(info_obj, "language", None) or language_key or "auto"
    return segments, detected


def worker(job_id: str) -> None:
    job = get_job(job_id)
    if not job:
        return

    try:
        url = job["url"]
        video_id = job["video_id"]
        language = job["language"]
        timestamps = bool(job["timestamps"])
        allow_whisper = bool(job["allow_whisper"])

        update_job(job_id, status="processing", stage="Lendo informações do vídeo...", progress=10)
        title = fetch_title(url)
        update_job(job_id, title=title, thumbnail_url=f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg", stage="Procurando legendas disponíveis...", progress=22)

        source = "YouTube captions"
        audio_file: Path | None = None
        segments: list[TranscriptSegment] = []
        detected_language = language
        try:
            segments, detected_language = fetch_youtube_captions(video_id, language)
        except (TranscriptsDisabled, NoTranscriptFound, CouldNotRetrieveTranscript, RuntimeError) as caption_error:
            if allow_whisper:
                source = "Reconhecimento avançado"
                segments, detected_language, audio_file = whisper_transcribe(url, language, job_id)
            else:
                # Sem legenda e sem Whisper: ainda preservamos mídia em vez de transformar isso em falha total.
                source = "Sem transcrição"
                segments = []
        except VideoUnavailable as exc:
            raise RuntimeError("O vídeo está indisponível, privado ou não pode ser acessado.") from exc

        # Se a legenda disponível contém apenas [Música]/[Som], confirme com o áudio real antes de concluir que não há fala.
        if source == "YouTube captions" and not _meaningful_speech(segments) and allow_whisper:
            try:
                source = "Reconhecimento avançado"
                segments, detected_language, audio_file = whisper_transcribe(url, language, job_id)
            except Exception:
                # Se a verificação por Whisper falhar, ainda preservamos a mídia e usamos a evidência das legendas.
                pass

        speech_available = _meaningful_speech(segments)
        if segments and not speech_available and source == "YouTube captions":
            source = "Mídia sem fala detectada"
        transcript_text = join_segments(segments, timestamps) if speech_available else ""
        plain_text = join_segments(segments, False) if speech_available else ""
        word_count = len(re.findall(r"\S+", plain_text)) if speech_available else 0
        segment_payloads = _segment_payloads(segments) if speech_available else []
        speech_duration = max((s.start + s.duration for s in segments), default=0.0) if speech_available else 0.0

        audio_error = None
        if audio_file is None:
            try:
                update_job(job_id, stage="Preparando o áudio...", progress=92)
                audio_file = download_audio_preview(url, job_id)
            except Exception as audio_exc:
                audio_error = str(audio_exc)

        video_file: Path | None = None
        video_error = None
        try:
            update_job(job_id, stage="Preparando o vídeo...", progress=96)
            video_file = download_video_preview(url, job_id)
        except Exception as video_exc:
            video_error = str(video_exc)

        refreshed = get_job(job_id) or {}
        duration = float(refreshed.get("duration_seconds") or speech_duration or 0)
        if not speech_available:
            source = "Mídia sem fala detectada"

        update_job(
            job_id,
            status="done",
            stage="Concluído — mídia sem fala" if not speech_available else "Concluído",
            progress=100,
            source=source,
            detected_language=detected_language if speech_available else None,
            transcript=transcript_text,
            transcript_available=speech_available,
            media_only=not speech_available,
            word_count=word_count,
            duration_seconds=round(duration, 2),
            duration_label=seconds_to_stamp(duration),
            segment_count=len(segment_payloads),
            segments=segment_payloads,
            audio_ready=bool(audio_file and audio_file.exists()),
            audio_filename=audio_file.name if audio_file and audio_file.exists() else None,
            audio_url=f"/audio/{job_id}" if audio_file and audio_file.exists() else None,
            audio_error=audio_error,
            video_ready=bool(video_file and video_file.exists()),
            video_filename=video_file.name if video_file and video_file.exists() else None,
            video_url=f"/video/{job_id}" if video_file and video_file.exists() else None,
            video_error=video_error,
            error=None,
        )
    except Exception as exc:
        update_job(job_id, status="error", stage="Falha no processamento", progress=100, error=str(exc))


def local_worker(job_id: str) -> None:
    job = get_job(job_id)
    if not job:
        return
    try:
        source_path = Path(str(job.get("local_source_path") or ""))
        if not source_path.exists():
            raise RuntimeError("O arquivo enviado não foi encontrado.")
        language = str(job.get("language") or "auto")
        timestamps = bool(job.get("timestamps", True))
        update_job(job_id, status="processing", stage="Preparando arquivo enviado...", progress=12)
        work = audio_dir(job_id)

        video_file: Path | None = None
        if _is_image_file(source_path):
            update_job(job_id, stage="Preparando imagem para o vídeo...", progress=20)
            video_file = _image_to_silent_video(source_path, work)
            thumb = work / "thumbnail.jpg"
            ffmpeg = _ffmpeg_location()
            if ffmpeg:
                try:
                    subprocess.run([ffmpeg, "-y", "-ss", "1", "-i", str(video_file), "-frames:v", "1", "-q:v", "4", str(thumb)], capture_output=True, timeout=90)
                except Exception:
                    pass
            update_job(job_id, video_ready=True, video_filename=video_file.name, video_url=f"/video/{job_id}", video_quality="Imagem convertida", thumbnail_url=f"/thumb/{job_id}" if thumb.exists() else None)
        elif _is_video_file(source_path):
            ext = source_path.suffix.lower() or ".mp4"
            video_file = work / f"video{ext}"
            if source_path.resolve() != video_file.resolve():
                shutil.copy2(source_path, video_file)
            thumb = work / "thumbnail.jpg"
            ffmpeg = _ffmpeg_location()
            if ffmpeg:
                try:
                    subprocess.run([ffmpeg, "-y", "-ss", "1", "-i", str(video_file), "-frames:v", "1", "-q:v", "4", str(thumb)], capture_output=True, timeout=90)
                except Exception:
                    pass
            update_job(job_id, video_ready=True, video_filename=video_file.name, video_url=f"/video/{job_id}", video_quality="Arquivo enviado", thumbnail_url=f"/thumb/{job_id}" if thumb.exists() else None)

        update_job(job_id, stage="Extraindo áudio...", progress=26)
        audio_file = _local_media_audio(video_file if _is_image_file(source_path) else source_path, job_id)
        update_job(job_id, audio_ready=True, audio_filename=audio_file.name, audio_url=f"/audio/{job_id}")

        if not video_file and not _is_video_file(source_path):
            update_job(job_id, stage="Criando visual para o áudio...", progress=38)
            video_file = _audio_to_visual_video(audio_file, work)
            thumb = work / "thumbnail.jpg"
            ffmpeg = _ffmpeg_location()
            if ffmpeg:
                try:
                    subprocess.run([ffmpeg, "-y", "-ss", "1", "-i", str(video_file), "-frames:v", "1", "-q:v", "4", str(thumb)], capture_output=True, timeout=90)
                except Exception:
                    pass
            update_job(job_id, video_ready=True, video_filename=video_file.name, video_url=f"/video/{job_id}", video_quality="Visual de áudio", thumbnail_url=f"/thumb/{job_id}" if thumb.exists() else None)

        segments, detected = _transcribe_audio_file(audio_file, language, job_id)
        speech_available = _meaningful_speech(segments)
        transcript_text = join_segments(segments, timestamps) if speech_available else ""
        plain_text = join_segments(segments, False) if speech_available else ""
        payloads = _segment_payloads(segments) if speech_available else []
        duration = max((s.start + s.duration for s in segments), default=0.0)
        if duration <= 0:
            duration = _probe_media_duration(video_file if video_file else source_path)

        update_job(
            job_id,
            status="done",
            stage="Concluído — mídia sem fala" if not speech_available else "Concluído",
            progress=100,
            source="Reconhecimento avançado" if speech_available else "Mídia sem fala detectada",
            detected_language=detected if speech_available else None,
            transcript=transcript_text,
            transcript_available=speech_available,
            media_only=not speech_available,
            word_count=len(re.findall(r"\S+", plain_text)) if speech_available else 0,
            duration_seconds=round(duration, 2),
            duration_label=seconds_to_stamp(duration),
            segment_count=len(payloads),
            segments=payloads,
            audio_ready=True,
            audio_filename=audio_file.name,
            audio_url=f"/audio/{job_id}",
            video_ready=bool(video_file),
            video_filename=video_file.name if video_file else None,
            video_url=f"/video/{job_id}" if video_file else None,
            error=None,
        )
    except Exception as exc:
        update_job(job_id, status="error", stage="Falha no processamento", progress=100, error=str(exc))


def queued_local_worker(job_id: str) -> None:
    with _processing_semaphore:
        local_worker(job_id)


def make_txt(job: dict[str, Any]) -> Path:
    path = DATA_DIR / f"{job['id']}.txt"
    header = (
        f"{job.get('title', 'Transcrição do YouTube')}\n"
        f"Fonte: {job.get('url', '')}\n"
        f"Idioma: {job.get('detected_language', '')}\n"
        f"Método: {job.get('source', '')}\n"
        f"Duração: {job.get('duration_label', '')}\n\n"
    )
    path.write_text(header + job.get("transcript", ""), encoding="utf-8")
    return path


def pdf_safe(text: str) -> str:
    # Standard PDF fonts cover common Western European characters but not all Unicode.
    return text.encode("cp1252", errors="replace").decode("cp1252")


def make_pdf(job: dict[str, Any]) -> Path:
    path = DATA_DIR / f"{job['id']}.pdf"
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        title=pdf_safe(job.get("title", "Transcrição do YouTube")),
        author="RedScribe",
    )
    styles = getSampleStyleSheet()
    title_style = styles["Title"]
    meta_style = ParagraphStyle(
        "Meta",
        parent=styles["Normal"],
        fontSize=9,
        leading=12,
        textColor="#555555",
        spaceAfter=3 * mm,
    )
    body_style = ParagraphStyle(
        "Body",
        parent=styles["BodyText"],
        fontSize=10.5,
        leading=15,
        spaceAfter=2.5 * mm,
    )

    story = [
        Paragraph(html.escape(pdf_safe(job.get("title", "Transcrição do YouTube"))), title_style),
        Paragraph(
            html.escape(
                pdf_safe(
                    f"Fonte: {job.get('url', '')}<br/>"
                    f"Idioma: {job.get('detected_language', '')} | "
                    f"Método: {job.get('source', '')} | "
                    f"Duração: {job.get('duration_label', '')}"
                )
            ).replace("&lt;br/&gt;", "<br/>"),
            meta_style,
        ),
        Spacer(1, 3 * mm),
    ]

    transcript = job.get("transcript", "")
    paragraphs = [p.strip() for p in transcript.split("\n") if p.strip()]
    for paragraph in paragraphs:
        story.append(Paragraph(html.escape(pdf_safe(paragraph)), body_style))

    doc.build(story)
    return path


@app.get("/")
def index():
    if current_user():
        return redirect(url_for("app_page"))
    return render_template("landing.html")


@app.get("/login")
def login_page():
    if current_user():
        return redirect(url_for("app_page"))
    return render_template("auth.html", mode="login")


@app.get("/register")
def register_page():
    if current_user():
        return redirect(url_for("app_page"))
    return render_template("auth.html", mode="register")


@app.get("/app")
@login_required
def app_page():
    return render_template("dashboard.html", user=_public_user(current_user()))


@app.post("/api/auth/register")
def api_register():
    payload = request.get_json(silent=True) or {}
    name = re.sub(r"\s+", " ", str(payload.get("name") or "")).strip()[:60]
    email = str(payload.get("email") or "").strip().lower()
    password = str(payload.get("password") or "")

    if len(name) < 2:
        return jsonify({"error": "Digite seu nome."}), 400
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return jsonify({"error": "Digite um e-mail válido."}), 400
    if len(password) < 6:
        return jsonify({"error": "A senha precisa ter pelo menos 6 caracteres."}), 400
    if _find_user_by_email(email):
        return jsonify({"error": "Já existe uma conta com este e-mail."}), 409

    now = int(time.time())
    user = {
        "id": uuid.uuid4().hex,
        "name": name,
        "email": email,
        "password_hash": generate_password_hash(password),
        "created_at": now,
        "last_login_at": now,
        "access_mode": "full",
        "plan": "preview",
        "shorts_quota": None,
        "plan_expires_at": None,
    }
    accounts = _load_accounts()
    first_local_account = len(accounts) == 0
    accounts.append(user)
    _save_accounts(accounts)
    _user_dir(user["id"])
    if first_local_account:
        _claim_legacy_jobs(user["id"])
    session.clear()
    session.permanent = True
    session["user_id"] = user["id"]
    return jsonify({"ok": True, "user": _public_user(user), "redirect": "/app"})


@app.post("/api/auth/login")
def api_login():
    payload = request.get_json(silent=True) or {}
    email = str(payload.get("email") or "").strip().lower()
    password = str(payload.get("password") or "")
    user = _find_user_by_email(email)
    if not user or not check_password_hash(user.get("password_hash", ""), password):
        return jsonify({"error": "E-mail ou senha incorretos."}), 401

    accounts = _load_accounts()
    now = int(time.time())
    for item in accounts:
        if item.get("id") == user.get("id"):
            item["last_login_at"] = now
            user = item
            break
    _save_accounts(accounts)
    session.clear()
    session.permanent = True
    session["user_id"] = user["id"]
    return jsonify({"ok": True, "user": _public_user(user), "redirect": "/app"})


@app.post("/api/auth/logout")
def api_logout():
    session.clear()
    return jsonify({"ok": True, "redirect": "/"})


@app.get("/api/me")
@login_required
def api_me():
    user = current_user()
    return jsonify({"user": _public_user(user)})


@app.post("/api/plan/select")
@login_required
def select_plan_api():
    payload = request.get_json(silent=True) or {}
    selected = str(payload.get("plan") or "").strip().lower()
    available = {"essencial", "studio", "equipe"}
    if selected not in available:
        return jsonify({"error": "Escolha um plano disponível."}), 400
    user = current_user()
    accounts = _load_accounts()
    updated = None
    for account in accounts:
        if account.get("id") == user.get("id"):
            account["plan"] = selected
            account["plan_selected_at"] = int(time.time())
            account["access_mode"] = "full"
            account["shorts_quota"] = None
            account["plan_expires_at"] = None
            updated = account
            break
    if not updated:
        return jsonify({"error": "Conta não encontrada."}), 404
    _save_accounts(accounts)
    return jsonify({"ok": True, "user": _public_user(updated), "message": "Plano salvo. Todos os recursos continuam liberados nesta edição."})


@app.get("/api/history")
@login_required
def history_api():
    user = current_user()
    kind = (request.args.get("kind") or "all").lower()
    jobs = _user_jobs(user["id"])
    project_id = str(request.args.get("project_id") or "").strip() or None
    if project_id:
        jobs = [j for j in jobs if j.get("project_id") == project_id]
    if kind == "transcript":
        jobs = [j for j in jobs if j.get("status") == "done" and j.get("transcript_available")]
    elif kind == "audio":
        jobs = [j for j in jobs if j.get("audio_ready")]
    elif kind == "video":
        jobs = [j for j in jobs if j.get("video_ready")]
    elif kind == "processing":
        jobs = [j for j in jobs if j.get("status") in {"queued", "processing"}]
    elif kind == "favorites":
        jobs = [j for j in jobs if j.get("favorite")]
    elif kind == "media":
        jobs = [j for j in jobs if j.get("media_only")]
    elif kind not in {"all", "transcript", "audio", "video", "processing", "favorites", "media"}:
        return jsonify({"error": "Filtro inválido."}), 400

    all_jobs = jobs if not project_id and kind == "all" else _user_jobs(user["id"])
    downloads = _load_downloads(user["id"])
    stats = {
        "jobs": len(all_jobs),
        "completed": sum(1 for j in all_jobs if j.get("status") == "done"),
        "audio": sum(1 for j in all_jobs if j.get("audio_ready")),
        "video": sum(1 for j in all_jobs if j.get("video_ready")),
        "downloads": len(downloads),
        "favorites": sum(1 for j in all_jobs if j.get("favorite")),
        "media_only": sum(1 for j in all_jobs if j.get("media_only")),
        "queued": sum(1 for j in all_jobs if j.get("status") in {"queued", "processing"}),
    }
    return jsonify({"items": [_job_summary(j) for j in jobs], "stats": stats})


@app.get("/api/downloads")
@login_required
def downloads_api():
    user = current_user()
    items = _load_downloads(user["id"])
    enriched = []
    for item in items:
        job = get_job(item.get("job_id", ""))
        copy = dict(item)
        saved_path = item.get("saved_path")
        copy["saved_exists"] = bool(saved_path and Path(saved_path).exists())
        copy["available"] = bool(_job_owned_by(job, user) and job.get("status") == "done")
        copy["save_url"] = f"/api/save/{item.get('job_id')}/{item.get('kind')}" if copy["available"] else None
        enriched.append(copy)
    return jsonify({"items": enriched})


@app.delete("/api/downloads")
@login_required
def clear_downloads_api():
    user = current_user()
    _atomic_write_json(_downloads_path(user["id"]), [])
    return jsonify({"ok": True})



@app.get("/api/projects")
@login_required
def projects_api():
    user = current_user()
    projects = _load_projects(user["id"])
    counts = {}
    audio_counts = {}
    for job in _user_jobs(user["id"]):
        pid = job.get("project_id")
        if not pid:
            continue
        counts[pid] = counts.get(pid, 0) + 1
        if job.get("status") == "done" and job.get("audio_ready"):
            audio_counts[pid] = audio_counts.get(pid, 0) + 1
    short_counts = {}
    try:
        short_path = _user_dir(user["id"]) / "shorts_library.json"
        rows = json.loads(short_path.read_text(encoding="utf-8")) if short_path.exists() else []
        for row in rows if isinstance(rows, list) else []:
            pid = str(row.get("project_id") or "").strip()
            if pid:
                short_counts[pid] = short_counts.get(pid, 0) + 1
    except Exception:
        pass
    return jsonify({
        "items": [
            {**p, "count": counts.get(p.get("id"), 0) + short_counts.get(p.get("id"), 0),
             "job_count": counts.get(p.get("id"), 0), "short_count": short_counts.get(p.get("id"), 0),
             "audio_count": audio_counts.get(p.get("id"), 0)}
            for p in projects
        ]
    })


@app.post("/api/projects")
@login_required
def create_project_api():
    user = current_user()
    payload = request.get_json(silent=True) or {}
    name = re.sub(r"\s+", " ", str(payload.get("name") or "")).strip()[:60]
    if len(name) < 2:
        return jsonify({"error": "Digite um nome para o projeto."}), 400
    items = _load_projects(user["id"])
    project = {"id": uuid.uuid4().hex[:12], "name": name, "created_at": int(time.time())}
    items.append(project)
    _save_projects(user["id"], items)
    return jsonify({"item": project}), 201


@app.patch("/api/projects/<project_id>")
@login_required
def update_project_api(project_id: str):
    user = current_user()
    payload = request.get_json(silent=True) or {}
    name = re.sub(r"\s+", " ", str(payload.get("name") or "")).strip()[:60]
    if len(name) < 2:
        return jsonify({"error": "Digite um nome para o projeto."}), 400
    items = _load_projects(user["id"])
    target = next((p for p in items if p.get("id") == project_id), None)
    if not target:
        return jsonify({"error": "Projeto não encontrado."}), 404
    target["name"] = name
    _save_projects(user["id"], items)
    return jsonify({"item": target})


@app.delete("/api/projects/<project_id>")
@login_required
def delete_project_api(project_id: str):
    user = current_user()
    items = _load_projects(user["id"])
    if not any(p.get("id") == project_id for p in items):
        return jsonify({"error": "Projeto não encontrado."}), 404
    _save_projects(user["id"], [p for p in items if p.get("id") != project_id])
    for job in _user_jobs(user["id"]):
        if job.get("project_id") == project_id:
            update_job(job["id"], project_id=None)
    try:
        short_path = _user_dir(user["id"]) / "shorts_library.json"
        if short_path.exists():
            rows = json.loads(short_path.read_text(encoding="utf-8"))
            changed = False
            if isinstance(rows, list):
                for row in rows:
                    if str(row.get("project_id") or "") == project_id:
                        row["project_id"] = None
                        row["updated_at"] = int(time.time())
                        changed = True
                if changed:
                    _atomic_write_json(short_path, rows)
    except Exception:
        pass
    return jsonify({"ok": True})


@app.patch("/api/jobs/<job_id>/meta")
@login_required
def update_job_meta_api(job_id: str):
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user):
        return jsonify({"error": "Trabalho não encontrado."}), 404
    payload = request.get_json(silent=True) or {}
    changes: dict[str, Any] = {}
    if "favorite" in payload:
        changes["favorite"] = bool(payload.get("favorite"))
    if "project_id" in payload:
        project_id = str(payload.get("project_id") or "").strip() or None
        if project_id and not _project_by_id(user["id"], project_id):
            return jsonify({"error": "Projeto não encontrado."}), 400
        changes["project_id"] = project_id
    if "title" in payload:
        title = re.sub(r"\s+", " ", str(payload.get("title") or "")).strip()[:120]
        if title:
            changes["title"] = title
    if not changes:
        return jsonify({"error": "Nenhuma alteração enviada."}), 400
    update_job(job_id, **changes)
    return jsonify({"ok": True, "item": _job_summary(get_job(job_id) or job)})


@app.get("/api/search")
@login_required
def advanced_search_api():
    user = current_user()
    query = re.sub(r"\s+", " ", str(request.args.get("q") or "")).strip()
    if len(query) < 2:
        return jsonify({"items": []})
    q = query.lower()
    project_id = str(request.args.get("project_id") or "").strip() or None
    results = []
    for job in _user_jobs(user["id"]):
        if project_id and job.get("project_id") != project_id:
            continue
        title = str(job.get("title") or "")
        transcript = str(job.get("transcript") or "")
        haystack = f"{title}\n{transcript}".lower()
        if q not in haystack:
            continue
        start = _find_text_timestamp(job, query)
        pos = transcript.lower().find(q)
        if pos >= 0:
            lo = max(0, pos - 90); hi = min(len(transcript), pos + len(query) + 140)
            snippet = re.sub(r"\s+", " ", transcript[lo:hi]).strip()
        else:
            snippet = str(job.get("preview") or transcript[:220])
        results.append({**_job_summary(job), "match_snippet": snippet, "match_start": start})
    return jsonify({"items": results[:100], "query": query})


@app.get("/api/trash")
@login_required
def trash_api():
    user = current_user()
    _purge_expired_trash(user["id"])
    items = [j for j in _user_jobs(user["id"], include_trashed=True) if j.get("trashed_at")]
    return jsonify({"items": [_job_summary(j) for j in items]})


@app.post("/api/jobs/<job_id>/restore")
@login_required
def restore_job_api(job_id: str):
    user = current_user(); job = get_job(job_id)
    if not _job_owned_by(job, user) or not job.get("trashed_at"):
        return jsonify({"error": "Item não encontrado na lixeira."}), 404
    update_job(job_id, trashed_at=None)
    return jsonify({"ok": True})


@app.delete("/api/jobs/<job_id>/permanent")
@login_required
def permanent_delete_job_api(job_id: str):
    user = current_user(); job = get_job(job_id)
    if not _job_owned_by(job, user):
        return jsonify({"error": "Trabalho não encontrado."}), 404
    _delete_job_files(job)
    return jsonify({"ok": True})


@app.post("/api/jobs/<job_id>/ai")
@login_required
def job_ai_api(job_id: str):
    user = current_user(); job = get_job(job_id)
    if not _job_owned_by(job, user) or not job.get("transcript_available"):
        return jsonify({"error": "Este trabalho não possui fala transcrita para analisar."}), 400
    payload = request.get_json(silent=True) or {}
    action = str(payload.get("action") or "summary")
    question = str(payload.get("question") or "").strip()
    transcript = _ai_context(job, action, question)
    if action == "summary":
        instruction = "Resuma a transcrição em português, com contexto, pontos importantes e conclusão, sem inventar informações."
    elif action == "points":
        instruction = "Extraia os principais pontos da transcrição em tópicos claros e objetivos, sem inventar informações."
    elif action == "script":
        instruction = "Transforme a transcrição em um roteiro organizado, natural e fiel ao conteúdo, sem inventar fatos."
    elif action == "ask":
        if not question: return jsonify({"error": "Digite uma pergunta sobre o vídeo."}), 400
        instruction = f"Responda somente com base na transcrição. Pergunta: {question}. Se a resposta não estiver no conteúdo, diga isso claramente."
    else:
        return jsonify({"error": "Ação de IA inválida."}), 400
    try:
        result = _claude_generate(f"{instruction}\n\nTRANSCRIÇÃO:\n{transcript}", user["id"])
        return jsonify({"result": result, "model": DEFAULT_AI_MODEL, "provider": AI_PROVIDER_NAME})
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 503


@app.post("/api/jobs/<job_id>/ai/stream")
@login_required
def job_ai_stream_api(job_id: str):
    user = current_user(); job = get_job(job_id)
    if not _job_owned_by(job, user) or not job.get("transcript_available"):
        return jsonify({"error": "Este trabalho não possui fala transcrita para analisar."}), 400
    payload = request.get_json(silent=True) or {}
    action = str(payload.get("action") or "summary")
    question = str(payload.get("question") or "").strip()
    if action == "summary": instruction = "Resuma a transcrição em português, com contexto, pontos importantes e conclusão. Seja direto e não invente informações."
    elif action == "points": instruction = "Extraia os principais pontos da transcrição em tópicos claros e objetivos, sem inventar informações."
    elif action == "script": instruction = "Transforme a transcrição em um roteiro organizado, natural e fiel ao conteúdo, sem inventar fatos."
    elif action == "ask":
        if not question: return jsonify({"error": "Digite uma pergunta sobre o vídeo."}), 400
        instruction = f"Responda somente com base na transcrição. Pergunta: {question}. Se a resposta não estiver no conteúdo, diga isso claramente."
    else: return jsonify({"error": "Ação de IA inválida."}), 400
    transcript = _ai_context(job, action, question)
    prompt = f"{instruction}\n\nTRANSCRIÇÃO:\n{transcript}"
    def event_stream():
        for event in _claude_generate_stream(prompt, user["id"], timeout=300):
            yield json.dumps(event, ensure_ascii=False) + "\n"
    response = Response(stream_with_context(event_stream()), mimetype="application/x-ndjson")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response


@app.get("/api/storage/stats")
@login_required
def storage_stats_api():
    user = current_user()
    return jsonify(_storage_breakdown(user["id"]))



@app.post("/api/storage/cleanup")
@login_required
def storage_cleanup_api():
    user = current_user()
    payload = request.get_json(silent=True) or {}
    clear_media = bool(payload.get("media", True))
    freed = 0
    for job in _user_jobs(user["id"]):
        jid = str(job.get("id") or "")
        # Arquivos temporários gerados podem ser recriados depois.
        for ext in (".txt", ".pdf", ".docx", ".srt", ".vtt"):
            f = DATA_DIR / f"{jid}{ext}"
            try:
                if f.exists(): freed += f.stat().st_size; f.unlink()
            except OSError:
                pass
        if clear_media:
            folder = DATA_DIR / jid
            if folder.exists():
                try: freed += _dir_size(folder)
                except Exception: pass
                shutil.rmtree(folder, ignore_errors=True)
                update_job(jid, audio_ready=False, audio_filename=None, audio_url=None, video_ready=False, video_filename=None, video_url=None, cache_cleared=True)
    return jsonify({"ok": True, "freed_bytes": freed})

@app.post("/api/backup/export")
@login_required
def backup_export_api():
    user = current_user()
    payload = request.get_json(silent=True) or {}
    include_media = bool(payload.get("include_media", False))
    root, folders = _ensure_storage_tree(user["id"])
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    destination = _unique_destination(folders["backup"], f"RedScribe_Backup_{stamp}.zip")
    manifest = {
        "product": "RedScribe", "version": APP_VERSION, "created_at": int(time.time()),
        "user": _public_user(user), "settings": _load_user_settings(user["id"]),
        "projects": _load_projects(user["id"]), "downloads": _load_downloads(user["id"]),
        "jobs": [_job_summary(j) for j in _user_jobs(user["id"], include_trashed=True)],
    }
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        for job in _user_jobs(user["id"], include_trashed=True):
            jp = job_path(job["id"])
            if jp.exists(): zf.write(jp, f"jobs/{jp.name}")
            if include_media:
                folder = DATA_DIR / job["id"]
                if folder.exists():
                    for file in folder.rglob("*"):
                        if file.is_file(): zf.write(file, f"media/{job['id']}/{file.relative_to(folder)}")
    return jsonify({"ok": True, "saved_path": str(destination), "filename": destination.name, "size_bytes": destination.stat().st_size})


@app.post("/api/backup/restore")
@login_required
def backup_restore_api():
    user = current_user()
    uploaded = request.files.get("backup")
    if not uploaded or not uploaded.filename:
        return jsonify({"error": "Selecione um backup ZIP do RedScribe."}), 400
    with tempfile.TemporaryDirectory(prefix="redscribe_restore_") as tmp:
        temp_zip = Path(tmp) / "backup.zip"
        uploaded.save(temp_zip)
        try:
            with zipfile.ZipFile(temp_zip, "r") as zf:
                names = zf.namelist()
                if "manifest.json" not in names:
                    return jsonify({"error": "Backup inválido: manifest.json não encontrado."}), 400
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
                settings = manifest.get("settings") if isinstance(manifest.get("settings"), dict) else None
                projects = manifest.get("projects") if isinstance(manifest.get("projects"), list) else None
                downloads = manifest.get("downloads") if isinstance(manifest.get("downloads"), list) else None
                if settings: _save_user_settings(user["id"], settings)
                if projects is not None: _save_projects(user["id"], projects)
                if downloads is not None: _atomic_write_json(_downloads_path(user["id"]), downloads)
                restored = 0
                for name in names:
                    if not name.startswith("jobs/") or not name.endswith(".json"):
                        continue
                    data = json.loads(zf.read(name).decode("utf-8")); data["user_id"] = user["id"]
                    jid = str(data.get("id") or "")
                    if not re.fullmatch(r"[a-f0-9]{32}", jid):
                        continue
                    save_job(data); restored += 1
                for name in names:
                    if not name.startswith("media/") or name.endswith("/"):
                        continue
                    parts = Path(name).parts
                    if len(parts) < 3 or not re.fullmatch(r"[a-f0-9]{32}", parts[1]) or any(part in {"..", "."} for part in parts[2:]):
                        continue
                    dest = DATA_DIR / parts[1] / Path(*parts[2:])
                    try:
                        dest.resolve().relative_to((DATA_DIR / parts[1]).resolve())
                    except ValueError:
                        continue
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(name) as src, dest.open("wb") as out: shutil.copyfileobj(src, out)
        except (zipfile.BadZipFile, json.JSONDecodeError) as exc:
            return jsonify({"error": "O arquivo selecionado não é um backup válido do RedScribe."}), 400
    return jsonify({"ok": True, "restored_jobs": restored})


@app.get("/api/update/status")
@login_required
def update_status_api():
    try:
        import yt_dlp
        yt_version = getattr(getattr(yt_dlp, "version", None), "__version__", None) or getattr(yt_dlp, "__version__", "instalado")
    except Exception:
        yt_version = "não instalado"
    latest = None
    manifest_url = os.environ.get("REDSCRIBE_UPDATE_MANIFEST", "").strip()
    if manifest_url:
        try:
            with urllib.request.urlopen(manifest_url, timeout=8) as response:
                latest = json.loads(response.read().decode("utf-8"))
        except Exception:
            latest = None
    return jsonify({"app_version": APP_VERSION, "yt_dlp": str(yt_version), "manifest": latest, "packaged": bool(getattr(sys, "frozen", False))})


@app.post("/api/update/components")
@login_required
def update_components_api():
    if getattr(sys, "frozen", False):
        return jsonify({
            "error": "Na versão instalada, os componentes essenciais fazem parte do RedScribe. Instale uma atualização do aplicativo para atualizar o RedScribe por completo."
        }), 409
    cmd = [os.sys.executable, "-m", "pip", "install", "-U", "--pre", "yt-dlp[default]", "youtube-transcript-api", "imageio-ffmpeg"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        output = (result.stdout or result.stderr or "")[-4000:]
        if result.returncode != 0:
            return jsonify({"error": "A atualização dos componentes falhou.", "detail": output}), 500
        return jsonify({"ok": True, "detail": output})
    except Exception as exc:
        return jsonify({"error": f"Não foi possível atualizar os componentes: {exc}"}), 500


def _format_search_duration(value: Any) -> str:
    try:
        seconds = int(float(value or 0))
    except (TypeError, ValueError):
        return ""
    if seconds <= 0:
        return ""
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    return f"{hours}:{minutes:02d}:{secs:02d}" if hours else f"{minutes}:{secs:02d}"


@app.get("/api/youtube/search")
@login_required
def youtube_search_api():
    query = str(request.args.get("q") or "").strip()
    if len(query) < 2:
        return jsonify({"error": "Digite pelo menos 2 caracteres para pesquisar no YouTube."}), 400
    if len(query) > 180:
        query = query[:180]
    try:
        offset = max(0, min(90, int(request.args.get("offset") or 0)))
        limit = max(1, min(20, int(request.args.get("limit") or 10)))
    except (TypeError, ValueError):
        offset, limit = 0, 10
    total = min(100, offset + limit)
    try:
        import yt_dlp
        opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "extract_flat": "in_playlist",
            "playlistend": total,
            "noplaylist": False,
        }
        opts.update(_youtube_runtime_opts())
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch{total}:{query}", download=False) or {}
        entries = list(info.get("entries") or [])
        results = []
        for entry in entries[offset:total]:
            if not isinstance(entry, dict):
                continue
            video_id = str(entry.get("id") or "").strip()
            url = str(entry.get("webpage_url") or entry.get("url") or "").strip()
            if video_id and (not url or not url.startswith("http")):
                url = f"https://www.youtube.com/watch?v={video_id}"
            if not video_id or not url:
                continue
            ie_key = str(entry.get("ie_key") or entry.get("extractor_key") or "").lower()
            if ie_key and "youtube" not in ie_key:
                continue
            title = str(entry.get("title") or "Vídeo do YouTube").strip()
            channel = str(entry.get("channel") or entry.get("uploader") or entry.get("channel_id") or "YouTube").strip()
            thumb = str(entry.get("thumbnail") or "").strip() or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
            results.append({
                "id": video_id,
                "url": url,
                "title": title,
                "channel": channel,
                "duration": entry.get("duration"),
                "duration_label": _format_search_duration(entry.get("duration")),
                "thumbnail_url": thumb,
                "view_count": entry.get("view_count"),
            })
        return jsonify({
            "query": query,
            "items": results,
            "offset": offset,
            "limit": limit,
            "next_offset": offset + len(results),
            "has_more": bool(results) and total < 100,
        })
    except Exception as exc:
        return jsonify({"error": f"Não foi possível pesquisar no YouTube agora: {_clean_yt_error(exc)}"}), 502


@app.post("/api/transcribe/batch")
@login_required
def batch_transcription_api():
    payload = request.get_json(silent=True) or {}
    urls = payload.get("urls") or []
    if isinstance(urls, str):
        urls = [line.strip() for line in urls.splitlines() if line.strip()]
    urls = list(dict.fromkeys([str(x).strip() for x in urls if str(x).strip()]))[:30]
    if not urls:
        return jsonify({"error": "Adicione pelo menos um link."}), 400
    if not bool(payload.get("confirmed_rights", False)):
        return jsonify({"error": "Confirme que você tem permissão para processar os conteúdos."}), 400
    user = current_user(); created = []; errors = []
    language = str(payload.get("language") or "auto"); timestamps = bool(payload.get("timestamps", True)); allow_whisper = bool(payload.get("allow_whisper", True))
    quality = str(payload.get("quality") or "1080"); project_id = str(payload.get("project_id") or "").strip() or None
    if language not in LANGUAGE_MAP: language = "auto"
    if quality not in {"360","720","1080","best"}: quality = "1080"
    for url in urls:
        try:
            video_id = extract_video_id(url)
        except ValueError as exc:
            errors.append({"url": url, "error": str(exc)}); continue
        jid = uuid.uuid4().hex
        job = {"id":jid,"user_id":user["id"],"url":url,"video_id":video_id,"language":language,"timestamps":timestamps,"allow_whisper":allow_whisper,"video_quality_request":quality,"project_id":project_id,"favorite":False,"source_type":"youtube","thumbnail_url":f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg","transcript_available":False,"media_only":False,"segments":[],"trashed_at":None,"status":"queued","stage":"Na fila","progress":0,"title":"Transcrição do YouTube","source":None,"detected_language":None,"transcript":None,"word_count":None,"duration_seconds":None,"duration_label":None,"segment_count":None,"audio_ready":False,"audio_filename":None,"audio_url":None,"audio_error":None,"video_ready":False,"video_filename":None,"video_url":None,"video_error":None,"video_height":None,"video_quality":None,"video_is_full_hd":False,"error":None,"created_at":int(time.time()),"updated_at":int(time.time())}
        save_job(job); threading.Thread(target=queued_worker,args=(jid,),daemon=True).start(); created.append(jid)
    return jsonify({"job_ids": created, "errors": errors}), 202


@app.post("/api/upload")
@login_required
def upload_local_media_api():
    user = current_user()
    media = request.files.get("media")
    if not media or not media.filename:
        return jsonify({"error": "Selecione uma imagem, um arquivo de áudio ou um vídeo."}), 400
    ext = Path(media.filename).suffix.lower()
    allowed = {".mp4",".mov",".mkv",".webm",".avi",".m4v",".mp3",".m4a",".aac",".wav",".ogg",".opus",".flac",".jpg",".jpeg",".png",".webp"}
    if ext not in allowed:
        return jsonify({"error": "Formato não suportado. Use imagem JPG, PNG ou WEBP, vídeo MP4, MOV, MKV, WEBM ou áudio MP3, M4A, WAV, OGG, OPUS e FLAC."}), 400
    language = str(request.form.get("language") or "auto")
    if language not in LANGUAGE_MAP: language = "auto"
    timestamps = str(request.form.get("timestamps") or "true").lower() != "false"
    project_id = str(request.form.get("project_id") or "").strip() or None
    if project_id and not _project_by_id(user["id"], project_id): project_id = None
    jid = uuid.uuid4().hex; work = audio_dir(jid)
    safe = secure_filename(media.filename) or f"arquivo{ext}"
    source = work / f"input_{safe}"
    media.save(source)
    job = {"id":jid,"user_id":user["id"],"url":"","video_id":None,"original_filename":media.filename,"local_source_path":str(source),"language":language,"timestamps":timestamps,"allow_whisper":True,"project_id":project_id,"favorite":False,"source_type":"image" if _is_image_file(source) else "local","thumbnail_url":None,"transcript_available":False,"media_only":False,"segments":[],"trashed_at":None,"status":"queued","stage":"Na fila","progress":0,"title":Path(media.filename).stem[:120] or "Arquivo enviado","source":None,"detected_language":None,"transcript":None,"word_count":None,"duration_seconds":None,"duration_label":None,"segment_count":None,"audio_ready":False,"audio_filename":None,"audio_url":None,"audio_error":None,"video_ready":False,"video_filename":None,"video_url":None,"video_error":None,"video_height":None,"video_quality":"Imagem convertida" if _is_image_file(source) else ("Arquivo enviado" if _is_video_file(source) else None),"video_is_full_hd":False,"error":None,"created_at":int(time.time()),"updated_at":int(time.time())}
    save_job(job); threading.Thread(target=queued_local_worker,args=(jid,),daemon=True).start()
    return jsonify({"job_id": jid}), 202


@app.get("/thumb/<job_id>")
@login_required
def thumbnail_route(job_id: str):
    user = current_user(); job = get_job(job_id)
    if not _job_owned_by(job,user): return jsonify({"error":"Não encontrado."}),404
    thumb = DATA_DIR / job_id / "thumbnail.jpg"
    if thumb.exists(): return send_file(thumb,mimetype="image/jpeg",max_age=3600)
    return jsonify({"error":"Miniatura indisponível."}),404


@app.get("/api/ai/status")
@login_required
def ai_status_api():
    user = current_user()
    return jsonify(claude_ai_status(user["id"]))


@app.post("/api/ai/repair")
@login_required
def ai_repair_api():
    started = prepare_claude_runtime_async()
    user = current_user()
    return jsonify({"ok": True, "started": started, "status": claude_ai_status(user["id"])}), 202


@app.post("/api/ai/key")
@login_required
def ai_key_api():
    user = current_user(); payload = request.get_json(silent=True) or {}
    api_key = str(payload.get("api_key") or "").strip()
    try:
        _save_zen_key(user["id"], api_key)
        return jsonify({"ok": True, "status": claude_ai_status(user["id"])})
    except (ValueError, OSError, RuntimeError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.delete("/api/ai/key")
@login_required
def ai_key_delete_api():
    user = current_user()
    _delete_zen_key(user["id"])
    return jsonify({"ok": True, "status": claude_ai_status(user["id"])})


@app.post("/api/ai/test")
@login_required
def ai_test_api():
    user = current_user()
    try:
        result = _claude_generate("Responda exatamente: RedScribe IA pronta", user["id"], timeout=180)
        return jsonify({"ok": True, "result": result, "status": claude_ai_status(user["id"])})
    except RuntimeError as exc:
        return jsonify({"error": str(exc), "status": claude_ai_status(user["id"])}), 503


@app.get("/api/ai/history")
@login_required
def ai_history_api():
    user = current_user()
    return jsonify({"items": _load_ai_history(user["id"])})


@app.delete("/api/ai/history")
@login_required
def ai_history_clear_api():
    user = current_user()
    _save_ai_history(user["id"], [])
    attachment_dir = _ai_attachment_dir(user["id"])
    try:
        shutil.rmtree(attachment_dir, ignore_errors=True)
        attachment_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return jsonify({"ok": True})



@app.post("/api/ai/attachments")
@login_required
def ai_attachment_upload_api():
    user = current_user()
    uploads = request.files.getlist("files") or ([request.files.get("file")] if request.files.get("file") else [])
    uploads = [f for f in uploads if f and f.filename]
    if not uploads:
        return jsonify({"error": "Selecione pelo menos um arquivo."}), 400
    if len(uploads) > 8:
        return jsonify({"error": "Envie no máximo 8 arquivos por vez."}), 400
    results = []
    for upload in uploads:
        original = upload.filename or "arquivo"
        ext = Path(original).suffix.lower()
        if ext not in _AI_ATTACHMENT_ALLOWED:
            return jsonify({"error": f"Formato {ext or 'sem extensão'} não suportado. Use ZIP, documentos de texto, código, PDF, DOCX, SRT ou VTT."}), 400
        attachment_id = uuid.uuid4().hex
        safe = secure_filename(original) or f"arquivo{ext}"
        path = _ai_attachment_dir(user["id"]) / f"{attachment_id}_{safe}"
        upload.save(path)
        try:
            size = path.stat().st_size
            max_bytes = _AI_ATTACHMENT_ZIP_MAX_BYTES if ext == ".zip" else _AI_ATTACHMENT_MAX_BYTES
            if size > max_bytes:
                path.unlink(missing_ok=True)
                max_mb = max_bytes // (1024 * 1024)
                return jsonify({"error": f"{original} excede o limite de {max_mb} MB."}), 400
            text = _extract_ai_attachment_text(path, ext)
            if not text.strip():
                path.unlink(missing_ok=True)
                return jsonify({"error": f"Não encontrei texto legível em {original}."}), 400
            meta = {"id": attachment_id, "user_id": user["id"], "name": original[:180], "safe_name": safe, "path": str(path), "ext": ext, "size": size, "text": text, "created_at": int(time.time())}
            _atomic_write_json(_ai_attachment_meta_path(user["id"], attachment_id), meta)
            results.append({"id": attachment_id, "name": original[:180], "ext": ext, "size": size, "preview": text[:220]})
        except Exception:
            try: path.unlink(missing_ok=True)
            except OSError: pass
            raise
    return jsonify({"items": results})


@app.delete("/api/ai/attachments/<attachment_id>")
@login_required
def ai_attachment_delete_api(attachment_id: str):
    user = current_user()
    item = _load_ai_attachment(user["id"], attachment_id)
    if not item:
        return jsonify({"error": "Anexo não encontrado."}), 404
    try:
        Path(str(item.get("path") or "")).unlink(missing_ok=True)
        _ai_attachment_meta_path(user["id"], attachment_id).unlink(missing_ok=True)
    except OSError:
        pass
    return jsonify({"ok": True})


@app.post("/api/ai/dictate")
@login_required
def ai_dictate_api():
    audio = request.files.get("audio")
    if not audio or not audio.filename:
        return jsonify({"error": "Nenhum áudio de ditado foi recebido."}), 400
    ext = Path(audio.filename).suffix.lower() or ".webm"
    if ext not in {".webm", ".wav", ".mp3", ".m4a", ".ogg", ".opus", ".mp4"}:
        ext = ".webm"
    with tempfile.TemporaryDirectory(prefix="redscribe-dictate-") as tmp:
        path = Path(tmp) / f"dictado{ext}"
        audio.save(path)
        if path.stat().st_size > 18 * 1024 * 1024:
            return jsonify({"error": "O ditado excedeu o limite de tamanho."}), 400
        try:
            text = _transcribe_dictation_file(path, str(request.form.get("language") or "pt"))
        except Exception as exc:
            return jsonify({"error": f"Não foi possível transcrever o ditado: {exc}"}), 500
    if not text:
        return jsonify({"error": "Não consegui identificar fala no áudio."}), 400
    return jsonify({"text": text})


@app.post("/api/ai/chat/stream")
@login_required
def ai_chat_stream_api():
    user = current_user(); payload = request.get_json(silent=True) or {}
    message = str(payload.get("message") or "").strip()
    message = re.sub(r"[ \t]+", " ", message)
    message = re.sub(r"\n{4,}", "\n\n\n", message)
    attachment_ids = payload.get("attachment_ids") if isinstance(payload.get("attachment_ids"), list) else []
    attachment_context, public_attachments = _attachment_context(user["id"], [str(x) for x in attachment_ids])
    if not message and not public_attachments: return jsonify({"error": "Digite uma mensagem ou anexe um arquivo para a IA."}), 400
    if len(message) > 24000: return jsonify({"error": "A mensagem é muito longa."}), 400
    if not message and public_attachments:
        message = "Analise os arquivos anexados e apresente os pontos mais importantes de forma organizada."
    job = None
    job_id = str(payload.get("job_id") or "").strip()
    if job_id:
        candidate = get_job(job_id)
        if _job_owned_by(candidate, user) and candidate and candidate.get("transcript_available"):
            job = candidate
    prompt = _general_ai_prompt(user["id"], message, job, attachment_context)
    def event_stream():
        assistant_parts: list[str] = []
        had_error = False
        for event in _claude_generate_stream(prompt, user["id"], timeout=300):
            if event.get("type") == "token": assistant_parts.append(str(event.get("text") or ""))
            if event.get("type") == "error": had_error = True
            yield json.dumps(event, ensure_ascii=False) + "\n"
        answer = "".join(assistant_parts).strip()
        if not had_error and answer:
            history = _load_ai_history(user["id"])
            now = int(time.time())
            history.extend([{"role": "user", "text": message, "created_at": now, "attachments": public_attachments}, {"role": "assistant", "text": answer, "created_at": now, "attachments": []}])
            _save_ai_history(user["id"], history)
    response = Response(stream_with_context(event_stream()), mimetype="application/x-ndjson")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response


@app.get("/api/settings")
@login_required
def settings_api():
    user = current_user()
    settings = _load_user_settings(user["id"])
    return jsonify({
        "storage_parent": settings.get("storage_parent"),
        "storage_root": str(_storage_root(user["id"])),
        "default_storage_parent": str(_default_storage_parent()),
        "ai_model": "Núcleo editorial local",
        "ai_provider": "RedScribe IA integrada",
        "ai_key_configured": True,
        "notifications": bool(settings.get("notifications", True)),
        "sync_transcript": bool(settings.get("sync_transcript", True)),
        "onboarding_seen": bool(settings.get("onboarding_seen", False)),
        "version": APP_VERSION,
    })



@app.patch("/api/settings/preferences")
@login_required
def update_preferences_api():
    user = current_user(); payload = request.get_json(silent=True) or {}
    settings = _load_user_settings(user["id"])
    if "notifications" in payload:
        settings["notifications"] = bool(payload.get("notifications"))
    if "sync_transcript" in payload:
        settings["sync_transcript"] = bool(payload.get("sync_transcript"))
    _save_user_settings(user["id"], settings)
    return jsonify({"ok": True, "settings": settings})


@app.post("/api/settings/onboarding/complete")
@login_required
def complete_onboarding_api():
    user = current_user()
    settings = _load_user_settings(user["id"])
    settings["onboarding_seen"] = True
    _save_user_settings(user["id"], settings)
    return jsonify({"ok": True, "onboarding_seen": True})

@app.patch("/api/settings/storage")
@login_required
def update_storage_api():
    user = current_user()
    payload = request.get_json(silent=True) or {}
    raw = str(payload.get("directory") or "").strip().strip('"')
    if not raw:
        return jsonify({"error": "Informe a pasta onde o RedScribe deve salvar os arquivos."}), 400
    try:
        parent = Path(raw).expanduser()
        if not parent.is_absolute():
            return jsonify({"error": "Use um caminho completo para a pasta."}), 400
        parent.mkdir(parents=True, exist_ok=True)
        settings = _load_user_settings(user["id"])
        settings["storage_parent"] = str(parent)
        _save_user_settings(user["id"], settings)
        root, _ = _ensure_storage_tree(user["id"])
    except OSError as exc:
        return jsonify({"error": f"Não foi possível usar essa pasta: {exc}"}), 400
    return jsonify({"ok": True, "storage_parent": str(parent), "storage_root": str(root)})


@app.post("/api/settings/storage/reset")
@login_required
def reset_storage_api():
    user = current_user()
    settings = _load_user_settings(user["id"])
    settings["storage_parent"] = str(_default_storage_parent())
    _save_user_settings(user["id"], settings)
    root, _ = _ensure_storage_tree(user["id"])
    return jsonify({"ok": True, "storage_parent": str(_default_storage_parent()), "storage_root": str(root)})


@app.post("/api/settings/storage/pick")
@login_required
def pick_storage_api():
    if os.name != "nt":
        return jsonify({"error": "O seletor de pasta automático está disponível no Windows. Digite o caminho manualmente."}), 400
    script = "\n".join([
        "Add-Type -AssemblyName System.Windows.Forms",
        "$dialog = New-Object System.Windows.Forms.FolderBrowserDialog",
        "$dialog.Description = 'Escolha onde a pasta RedScribe sera criada'",
        "$dialog.ShowNewFolderButton = $true",
        "if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $dialog.SelectedPath }",
    ])
    try:
        result = subprocess.run(["powershell.exe", "-NoProfile", "-STA", "-Command", script], capture_output=True, text=True, timeout=120)
        selected_lines = (result.stdout or "").strip().splitlines()
        selected = selected_lines[-1].strip() if selected_lines else ""
        if not selected:
            return jsonify({"cancelled": True})
        parent = Path(selected)
        user = current_user()
        settings = _load_user_settings(user["id"])
        settings["storage_parent"] = str(parent)
        _save_user_settings(user["id"], settings)
        root, _ = _ensure_storage_tree(user["id"])
        return jsonify({"ok": True, "storage_parent": str(parent), "storage_root": str(root)})
    except Exception as exc:
        return jsonify({"error": f"Não foi possível abrir o seletor de pastas: {exc}"}), 500


@app.post("/api/save/<job_id>/<filetype>")
@login_required
def save_asset_api(job_id: str, filetype: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    if filetype not in {"txt", "pdf", "docx", "srt", "vtt", "audio", "video"}:
        return jsonify({"error": "Formato inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user) or job.get("status") != "done":
        return jsonify({"error": "Arquivo ainda não está disponível."}), 404
    try:
        destination, filename, size = _save_asset_copy(user, job, filetype)
    except (OSError, ValueError, FileNotFoundError) as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify({"ok": True, "filename": filename, "saved_path": str(destination), "size_bytes": size})


@app.post("/api/transcribe")
@login_required
def create_transcription():
    payload = request.get_json(silent=True) or {}
    user = current_user()
    url = (payload.get("url") or "").strip()
    language = (payload.get("language") or "auto").strip()
    timestamps = bool(payload.get("timestamps", True))
    allow_whisper = bool(payload.get("allow_whisper", True))
    confirmed_rights = bool(payload.get("confirmed_rights", False))
    quality = str(payload.get("quality") or "1080").lower()
    project_id = str(payload.get("project_id") or "").strip() or None

    if not confirmed_rights:
        return jsonify({"error": "Confirme que você tem permissão para transcrever o conteúdo."}), 400
    if language not in LANGUAGE_MAP:
        return jsonify({"error": "Idioma inválido."}), 400
    if quality not in {"360", "720", "1080", "best"}:
        return jsonify({"error": "Qualidade de vídeo inválida."}), 400
    if project_id and not _project_by_id(user["id"], project_id):
        return jsonify({"error": "Projeto não encontrado."}), 400

    try:
        video_id = extract_video_id(url)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    job_id = uuid.uuid4().hex
    job = {
        "id": job_id,
        "user_id": user["id"],
        "url": url,
        "video_id": video_id,
        "language": language,
        "timestamps": timestamps,
        "allow_whisper": allow_whisper,
        "video_quality_request": quality,
        "project_id": project_id,
        "favorite": False,
        "source_type": "youtube",
        "thumbnail_url": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
        "transcript_available": False,
        "media_only": False,
        "segments": [],
        "trashed_at": None,
        "status": "queued",
        "stage": "Na fila",
        "progress": 0,
        "title": "Transcrição do YouTube",
        "source": None,
        "detected_language": None,
        "transcript": None,
        "word_count": None,
        "duration_seconds": None,
        "duration_label": None,
        "segment_count": None,
        "audio_ready": False,
        "audio_filename": None,
        "audio_url": None,
        "audio_error": None,
        "video_ready": False,
        "video_filename": None,
        "video_url": None,
        "video_error": None,
        "video_height": None,
        "video_quality": None,
        "video_is_full_hd": False,
        "error": None,
        "created_at": int(time.time()),
        "updated_at": int(time.time()),
    }
    save_job(job)
    threading.Thread(target=queued_worker, args=(job_id,), daemon=True).start()
    return jsonify({"job_id": job_id}), 202


@app.get("/api/jobs/<job_id>/progress")
@login_required
def job_progress(job_id: str):
    """Small no-cache progress payload for the live transcription UI.

    The Queue already works with summaries. Nova transcrição now polls this
    lightweight endpoint instead of repeatedly transferring the full job JSON.
    """
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user):
        return jsonify({"error": "Transcrição não encontrada."}), 404
    payload = {
        "id": job.get("id"),
        "status": job.get("status"),
        "stage": job.get("stage"),
        "progress": max(0, min(100, int(job.get("progress") or 0))),
        "title": job.get("title"),
        "updated_at": job.get("updated_at"),
        "error": job.get("error"),
        "transcript_available": bool(job.get("transcript_available")),
        "media_only": bool(job.get("media_only")),
    }
    response = jsonify(payload)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/api/jobs/<job_id>")
@login_required
def job_status(job_id: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user):
        return jsonify({"error": "Transcrição não encontrada."}), 404
    payload = dict(job)
    payload.pop("user_id", None)
    response = jsonify(payload)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return response


@app.patch("/api/jobs/<job_id>/transcript")
@login_required
def update_transcript(job_id: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user) or job.get("status") != "done":
        return jsonify({"error": "Transcrição não encontrada ou ainda não concluída."}), 404
    payload = request.get_json(silent=True) or {}
    transcript = payload.get("transcript")
    if not isinstance(transcript, str) or not transcript.strip():
        return jsonify({"error": "A transcrição não pode ficar vazia."}), 400
    transcript = transcript.strip()
    update_job(job_id, transcript=transcript, word_count=len(re.findall(r"\S+", transcript)))
    return jsonify({"ok": True})


@app.delete("/api/jobs/<job_id>")
@login_required
def delete_job(job_id: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user):
        return jsonify({"error": "Transcrição não encontrada."}), 404
    update_job(job_id, trashed_at=int(time.time()))
    return jsonify({"ok": True, "trashed": True, "retention_days": 30})


@app.get("/audio/<job_id>")
@login_required
def stream_audio(job_id: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user) or job.get("status") != "done":
        return jsonify({"error": "Áudio ainda não está disponível."}), 404
    audio_file = find_job_audio(job_id)
    if not audio_file:
        return jsonify({"error": job.get("audio_error") or "Áudio não encontrado."}), 404
    return send_file(audio_file, mimetype=audio_mimetype(audio_file), as_attachment=False, conditional=True, max_age=0)


@app.get("/video/<job_id>")
@login_required
def stream_video(job_id: str):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user) or job.get("status") != "done":
        return jsonify({"error": "Vídeo ainda não está disponível."}), 404
    video_file = find_job_video(job_id)
    if not video_file:
        return jsonify({"error": job.get("video_error") or "Vídeo não encontrado."}), 404
    return send_file(video_file, mimetype=video_mimetype(video_file), as_attachment=False, conditional=True, max_age=0)


@app.get("/download/<job_id>/<filetype>")
@login_required
def download(job_id: str, filetype: str):
    # Compatibilidade com links de versões anteriores. A interface atual usa /api/save.
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"error": "ID inválido."}), 400
    user = current_user()
    job = get_job(job_id)
    if not _job_owned_by(job, user) or job.get("status") != "done":
        return jsonify({"error": "Arquivo ainda não está disponível."}), 404
    try:
        source, filename, mimetype = _asset_source(job, filetype)
        _save_asset_copy(user, job, filetype)
    except (OSError, ValueError, FileNotFoundError) as exc:
        return jsonify({"error": str(exc)}), 400
    return send_file(source, as_attachment=True, download_name=filename, mimetype=mimetype, conditional=True, max_age=0)



# V3.4.3: preserva a base estável e adiciona Biblioteca permanente de Shorts.
from power_tools import register_power_tools
register_power_tools(app, sys.modules[__name__])
from shorts_tools import register_shorts_tools
register_shorts_tools(app, sys.modules[__name__])
from studio_tools import register_studio_tools
register_studio_tools(app, sys.modules[__name__])

@app.get("/health")
def health():
    return jsonify({"ok": True, "product": "RedScribe"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5050"))
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)
