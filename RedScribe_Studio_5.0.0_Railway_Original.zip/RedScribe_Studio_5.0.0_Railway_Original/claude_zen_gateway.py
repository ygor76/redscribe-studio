from __future__ import annotations

import json
import queue
import threading
import time
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse


class ZenGatewayError(RuntimeError):
    pass


def _flatten_text(value: Any) -> str:
    """Extract plain text from Anthropic-style content blocks."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                typ = str(item.get("type") or "")
                if typ in {"text", "input_text", "output_text"}:
                    text = item.get("text")
                    if isinstance(text, str) and text:
                        parts.append(text)
                elif typ == "tool_result":
                    # Tools are disabled in RedScribe, but keeping textual tool
                    # results makes the bridge resilient if Claude Code emits one.
                    content = item.get("content")
                    text = _flatten_text(content)
                    if text:
                        parts.append(text)
        return "\n".join(p for p in parts if p)
    if isinstance(value, dict):
        return _flatten_text(value.get("text") or value.get("content"))
    return str(value)


def _anthropic_to_openai(body: dict[str, Any], model: str) -> dict[str, Any]:
    # We deliberately do not forward Claude Code's large coding-agent system
    # prompt to a non-Claude model. RedScribe uses Claude Code in text-only,
    # tool-less print mode and supplies the task/context in the user prompt.
    messages: list[dict[str, str]] = [{
        "role": "system",
        "content": (
            "Você é a IA integrada ao RedScribe. Responda ao pedido do usuário "
            "com clareza e objetividade. Preserve fatos e contexto fornecidos na "
            "mensagem. Quando o pedido estiver em português, responda em português "
            "do Brasil. Não invente informações ausentes da transcrição."
        ),
    }]

    for item in body.get("messages") or []:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "user")
        if role not in {"user", "assistant"}:
            role = "user"
        text = _flatten_text(item.get("content"))
        if text:
            messages.append({"role": role, "content": text})

    if len(messages) == 1:
        messages.append({"role": "user", "content": "Responda brevemente."})

    requested_max = body.get("max_tokens")
    try:
        max_tokens = int(requested_max)
    except (TypeError, ValueError):
        max_tokens = 4096
    max_tokens = max(256, min(max_tokens, 8192))

    return {
        "model": model,
        "messages": messages,
        "stream": True,
        "max_tokens": max_tokens,
    }


def _estimate_tokens(body: dict[str, Any]) -> int:
    chunks: list[str] = []
    chunks.append(_flatten_text(body.get("system")))
    for item in body.get("messages") or []:
        if isinstance(item, dict):
            chunks.append(_flatten_text(item.get("content")))
    text = "\n".join(x for x in chunks if x)
    # Conservative approximation; Claude Code treats this endpoint as optional.
    return max(1, (len(text) + 3) // 4)


class _GatewayState:
    def __init__(self, api_key: str, upstream_url: str, model: str, fallback_models: list[str] | None = None):
        self.api_key = api_key
        self.upstream_url = upstream_url
        self.model = model
        self.fallback_models = [m for m in (fallback_models or []) if m and m != model]
        self.last_model = model

    @property
    def models(self) -> list[str]:
        return [self.model, *self.fallback_models]


class _Handler(BaseHTTPRequestHandler):
    server_version = "RedScribeZenGateway/1.0"
    protocol_version = "HTTP/1.1"

    @property
    def state(self) -> _GatewayState:
        return self.server.redscribe_state  # type: ignore[attr-defined]

    def log_message(self, _fmt: str, *_args: Any) -> None:
        return

    def _path(self) -> str:
        return urlparse(self.path).path

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)
        self.wfile.flush()

    def _read_json(self) -> dict[str, Any]:
        try:
            size = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            size = 0
        if size <= 0:
            return {}
        if size > 16 * 1024 * 1024:
            raise ZenGatewayError("Requisição da IA excedeu o limite interno.")
        raw = self.rfile.read(size)
        try:
            data = json.loads(raw.decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception as exc:
            raise ZenGatewayError("Claude Code enviou JSON inválido ao gateway.") from exc

    def do_HEAD(self) -> None:  # noqa: N802
        if self._path() == "/api/hello":
            self.send_response(200)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_response(404)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        path = self._path()
        if path == "/api/hello":
            self._send_json(200, {"ok": True})
            return
        if path == "/v1/models":
            # Discovery is disabled in RedScribe, but this keeps the gateway
            # well-behaved if Claude Code probes it in a future release.
            self._send_json(200, {"data": [{"id": "claude-redscribe-zen", "display_name": "RedScribe Zen"}]})
            return
        self._send_json(404, {"type": "error", "error": {"type": "not_found_error", "message": "Endpoint não encontrado."}})

    def do_POST(self) -> None:  # noqa: N802
        path = self._path()
        try:
            body = self._read_json()
            if path == "/v1/messages/count_tokens":
                self._send_json(200, {"input_tokens": _estimate_tokens(body)})
                return
            if path == "/v1/messages":
                self._proxy_messages(body)
                return
            self._send_json(404, {"type": "error", "error": {"type": "not_found_error", "message": "Endpoint não encontrado."}})
        except ZenGatewayError as exc:
            self._send_json(400, {"type": "error", "error": {"type": "invalid_request_error", "message": str(exc)}})
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as exc:
            self._send_json(500, {"type": "error", "error": {"type": "api_error", "message": f"Falha no gateway RedScribe: {exc}"}})

    def _sse(self, event: str, payload: dict[str, Any]) -> None:
        raw = f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False, separators=(',', ':'))}\n\n".encode("utf-8")
        self.wfile.write(raw)
        self.wfile.flush()

    @staticmethod
    def _rate_limited(status: int, detail: str) -> bool:
        low = (detail or "").lower()
        return status == 429 or "freeusagelimiterror" in low or "rate limit" in low or "too many requests" in low

    def _open_upstream(self, body: dict[str, Any]):
        failures: list[str] = []
        models = self.state.models
        for index, model in enumerate(models):
            upstream_payload = _anthropic_to_openai(body, model)
            raw_payload = json.dumps(upstream_payload, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(
                self.state.upstream_url,
                data=raw_payload,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self.state.api_key}",
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                    "User-Agent": "RedScribe/3.2.7",
                },
            )
            try:
                response = urllib.request.urlopen(req, timeout=90)
                self.state.last_model = model
                return response, model
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read().decode("utf-8", errors="replace")[:3000]
                except Exception:
                    pass
                failures.append(f"{model}: HTTP {exc.code} {detail[:240]}")
                if self._rate_limited(exc.code, detail) and index < len(models) - 1:
                    time.sleep(min(1.25 * (index + 1), 4.0))
                    continue
                if self._rate_limited(exc.code, detail):
                    raise ZenGatewayError(
                        "Os modelos gratuitos do OpenCode Zen atingiram o limite temporário de uso. "
                        "Sua conversa foi preservada. Aguarde alguns minutos e tente novamente."
                    ) from exc
                message = detail.strip() or f"OpenCode Zen retornou HTTP {exc.code}."
                raise ZenGatewayError(message) from exc
            except Exception as exc:
                failures.append(f"{model}: {exc}")
                if index < len(models) - 1:
                    time.sleep(0.5)
                    continue
                raise ZenGatewayError(f"Não foi possível conectar ao OpenCode Zen: {exc}") from exc
        raise ZenGatewayError("Nenhum modelo gratuito do OpenCode Zen ficou disponível.")

    def _proxy_messages(self, body: dict[str, Any]) -> None:
        try:
            response, active_model = self._open_upstream(body)
        except ZenGatewayError as exc:
            message = str(exc)
            status = 429 if "limite temporário" in message.lower() else 502
            self._send_json(status, {
                "type": "error",
                "error": {"type": "rate_limit_error" if status == 429 else "api_error", "message": message},
            })
            return

        content_type = str(response.headers.get("Content-Type") or "")
        if getattr(response, "status", 200) >= 400:
            detail = response.read().decode("utf-8", errors="replace")[:3000]
            self._send_json(getattr(response, "status", 502), {
                "type": "error", "error": {"type": "api_error", "message": detail or "Falha no OpenCode Zen."}
            })
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self._sse("ping", {"type": "ping", "model": active_model})

        requested_model = str(body.get("model") or "claude-sonnet-4-6")
        msg_id = "msg_redscribe_" + uuid.uuid4().hex[:18]
        input_tokens = _estimate_tokens(body)
        output_chars = 0
        started = False

        self._sse("message_start", {
            "type": "message_start",
            "message": {
                "id": msg_id,
                "type": "message",
                "role": "assistant",
                "model": requested_model,
                "content": [],
                "stop_reason": None,
                "stop_sequence": None,
                "usage": {"input_tokens": input_tokens, "output_tokens": 0},
            },
        })
        self._sse("content_block_start", {
            "type": "content_block_start", "index": 0,
            "content_block": {"type": "text", "text": ""},
        })
        started = True

        q: queue.Queue[tuple[str, Any]] = queue.Queue()

        def read_upstream() -> None:
            try:
                # Zen's OpenAI-compatible endpoint uses SSE when stream=true.
                # If it unexpectedly returns JSON, handle it as a single chunk.
                if "text/event-stream" not in content_type.lower():
                    raw = response.read()
                    try:
                        payload = json.loads(raw.decode("utf-8"))
                        q.put(("json", payload))
                    except Exception as exc:
                        q.put(("error", f"Resposta inesperada do Zen: {exc}"))
                    return
                for raw_line in response:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line or line.startswith(":"):
                        continue
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        q.put(("chunk", json.loads(data)))
                    except json.JSONDecodeError:
                        continue
            except Exception as exc:
                q.put(("error", str(exc)))
            finally:
                try:
                    response.close()
                except Exception:
                    pass
                q.put(("eof", None))

        threading.Thread(target=read_upstream, daemon=True).start()
        last_data = time.monotonic()
        eof = False
        upstream_error: str | None = None

        while not eof:
            try:
                kind, payload = q.get(timeout=8.0)
            except queue.Empty:
                # Keep Claude Code's byte watchdog alive during a slow first token.
                self._sse("ping", {"type": "ping"})
                if time.monotonic() - last_data > 180:
                    upstream_error = "O OpenCode Zen ficou sem responder por tempo demais."
                    break
                continue

            last_data = time.monotonic()
            if kind == "eof":
                eof = True
                break
            if kind == "error":
                upstream_error = str(payload or "Falha no streaming do OpenCode Zen.")
                break

            text = ""
            if kind == "chunk" and isinstance(payload, dict):
                choices = payload.get("choices") if isinstance(payload.get("choices"), list) else []
                if choices and isinstance(choices[0], dict):
                    delta = choices[0].get("delta") if isinstance(choices[0].get("delta"), dict) else {}
                    content = delta.get("content")
                    if isinstance(content, str):
                        text = content
            elif kind == "json" and isinstance(payload, dict):
                choices = payload.get("choices") if isinstance(payload.get("choices"), list) else []
                if choices and isinstance(choices[0], dict):
                    message = choices[0].get("message") if isinstance(choices[0].get("message"), dict) else {}
                    content = message.get("content")
                    if isinstance(content, str):
                        text = content

            if text:
                output_chars += len(text)
                self._sse("content_block_delta", {
                    "type": "content_block_delta", "index": 0,
                    "delta": {"type": "text_delta", "text": text},
                })

        if upstream_error and output_chars == 0:
            # At this point headers have already been streamed. Emit an Anthropic
            # SSE error event so Claude Code can surface the real cause.
            self._sse("error", {"type": "error", "error": {"type": "api_error", "message": upstream_error}})
            return

        if started:
            self._sse("content_block_stop", {"type": "content_block_stop", "index": 0})
        self._sse("message_delta", {
            "type": "message_delta",
            "delta": {"stop_reason": "end_turn", "stop_sequence": None},
            "usage": {"output_tokens": max(1, (output_chars + 3) // 4)},
        })
        self._sse("message_stop", {"type": "message_stop"})


class ZenAnthropicGateway:
    """Temporary localhost Anthropic-format gateway backed by OpenCode Zen."""

    def __init__(self, api_key: str, upstream_url: str, model: str, fallback_models: list[str] | None = None):
        self._state = _GatewayState(api_key=api_key, upstream_url=upstream_url, model=model, fallback_models=fallback_models)
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> str:
        if self._server is not None:
            host, port = self._server.server_address[:2]
            return f"http://{host}:{port}"
        server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        server.daemon_threads = True
        server.redscribe_state = self._state  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True)
        thread.start()
        self._server = server
        self._thread = thread
        host, port = server.server_address[:2]
        return f"http://{host}:{port}"

    def close(self) -> None:
        server = self._server
        self._server = None
        if server is not None:
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except Exception:
                pass
        thread = self._thread
        self._thread = None
        if thread and thread.is_alive():
            thread.join(timeout=1.5)

    def __enter__(self) -> "ZenAnthropicGateway":
        self.start()
        return self

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        self.close()
