@echo off
chcp 65001 >nul
title Instalador de contingência - RedScribe Studio
cd /d "%~dp0"

echo ========================================
echo   RedScribe Studio - Instalacao de contingencia
 echo ========================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
  set PY=py
) else (
  where python >nul 2>&1
  if %errorlevel% neq 0 (
    echo Python nao foi encontrado.
    echo Instale Python 3.10 ou superior e marque "Add Python to PATH".
    pause
    exit /b 1
  )
  set PY=python
)

if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente virtual...
  %PY% -m venv .venv
  if %errorlevel% neq 0 goto :fail
)

echo Atualizando pip...
.venv\Scripts\python.exe -m pip install --upgrade pip
if %errorlevel% neq 0 goto :fail

echo Instalando e atualizando dependencias...
.venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
if %errorlevel% neq 0 goto :fail

echo.
echo Verificando runtime JavaScript recomendado pelo yt-dlp...
where deno >nul 2>&1
if %errorlevel%==0 goto :done

where winget >nul 2>&1
if %errorlevel% neq 0 goto :deno_warning

echo Deno nao encontrado. Tentando instalar automaticamente...
winget install --id DenoLand.Deno -e --accept-package-agreements --accept-source-agreements
if %errorlevel% neq 0 goto :deno_warning

echo Deno instalado. Talvez seja necessario fechar e abrir o terminal uma vez.
goto :done

:deno_warning
echo AVISO: Deno nao foi instalado automaticamente.
echo Se aparecer erro 403 no audio, execute REPARAR_YOUTUBE.bat.

:done
echo.
echo Instalacao concluida.
echo Use ABRIR_WINDOWS.bat para iniciar.
pause
exit /b 0

:fail
echo.
echo Houve um erro na instalacao. Confira sua conexao e tente novamente.
pause
exit /b 1
