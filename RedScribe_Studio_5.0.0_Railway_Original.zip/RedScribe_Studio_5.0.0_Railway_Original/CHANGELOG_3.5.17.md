# RedScribe v3.5.17

## Studio — padrão da última edição
- O visual do último Short editado passa a ser salvo automaticamente como padrão do usuário.
- Ao abrir um Short novo sem rascunho, o RedScribe reaplica estilo da legenda, elementos visuais, selo/marca d'água e transformação do vídeo.
- As falas/legendas não são copiadas: cada vídeo continua gerando suas próprias legendas.
- O usuário pode ativar/desativar o padrão automático e reaplicá-lo manualmente.
- Mídias usadas em selo e marca d'água são copiadas para o preset persistente.

## Studio — Desenquadrar vídeo
- Nova opção para liberar o próprio vídeo dentro do canvas 9:16.
- Vídeo pode ser arrastado livremente.
- Oito alças permitem redimensionar por cima, baixo, lados e cantos.
- A renderização final reproduz posição e tamanho dentro de um canvas 1080x1920.
- Desligado, o pipeline visual permanece idêntico ao da v3.5.16.

## Faixa preta
- Ao adicionar faixa, o usuário escolhe Horizontal ou Vertical.
- Horizontal nasce preenchendo toda a largura; Vertical nasce preenchendo toda a altura lateral.
- Largura e altura aceitam valores livres (1 = dimensão inteira da tela).
- Topo, rodapé, esquerda, direita e posição livre.

## Lixeira
- Novo modo Selecionar.
- Selecionar todos.
- Exclusão definitiva em lote de trabalhos e Shorts.
- Exclusão definitiva de Short também sincroniza com o Estúdio.

## Segurança de regressão
- Motor de geração dos Shorts (`shorts_tools.py`) preservado sem alteração.
- `shorts.js` preservado sem alteração.
- Algoritmo Ultra de legendas automáticas preservado byte a byte na função `auto_captions`.
