# RedScribe v3.5.9

## RedScribe Studio + Central de Publicação

- Nova área **Estúdio** isolada do motor de Shorts.
- Botões **Editar** e **Publicar** nos Shorts recém-gerados e na Biblioteca.
- Editor não destrutivo: corte de início/fim, legendas automáticas via Whisper, edição de texto, fonte, tamanho, contorno e posição arrastável.
- B-roll com fotos/vídeos, duração, reordenação por arrastar e transições, preservando o áudio original.
- Renderização cria **nova versão** na Biblioteca; o Short original é preservado.
- Central de Publicação prepara cópia do MP4 + TXT em `RedScribe/Publicar/...` e abre TikTok Studio, YouTube Studio ou Instagram para o usuário finalizar manualmente.
- O arquivo `shorts_tools.py` da v3.5.8 foi preservado sem alteração funcional nesta atualização.
