from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path
from typing import Any
from collections import Counter
from urllib.parse import urlparse

from flask import jsonify, request, Response, stream_with_context


_RECOVERY_LOCK = threading.RLock()
_RECOVERY_STARTED: set[str] = set()
_PROCESS_STARTED_AT = int(time.time())
_RECOMMENDATION_LOCK = threading.RLock()
_RECOMMENDATION_BUILDING: set[str] = set()


def register_power_tools(app, core) -> None:
    """Enhancements layered on top of the stable 3.2.7 core."""

    def user_file(user_id: str, name: str) -> Path:
        return core._user_dir(user_id) / name

    def read_json(path: Path, default):
        try:
            if not path.exists():
                return default
            value = json.loads(path.read_text(encoding="utf-8"))
            return value
        except Exception:
            return default

    def write_json(path: Path, value) -> None:
        core._atomic_write_json(path, value)

    def normalize_tags(value: Any) -> list[str]:
        if isinstance(value, str):
            value = re.split(r"[,;\n]+", value)
        if not isinstance(value, list):
            return []
        out: list[str] = []
        seen: set[str] = set()
        for raw in value:
            tag = re.sub(r"\s+", " ", str(raw or "")).strip()[:28]
            key = tag.casefold()
            if len(tag) >= 2 and key not in seen:
                seen.add(key); out.append(tag)
            if len(out) >= 12:
                break
        return out

    def summary(job: dict[str, Any]) -> dict[str, Any]:
        item = core._job_summary(job)
        item["tags"] = normalize_tags(job.get("tags") or [])
        item["video_id"] = job.get("video_id")
        return item

    def existing_video_map(user_id: str) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        for job in core._user_jobs(user_id, include_trashed=True):
            vid = str(job.get("video_id") or "").strip()
            if vid and not job.get("trashed_at"):
                result.setdefault(vid, job)
        return result

    # ---------- YouTube search history + enriched search ----------
    def search_history_path(user_id: str) -> Path:
        return user_file(user_id, "youtube_searches.json")

    def load_search_history(user_id: str) -> list[dict[str, Any]]:
        data = read_json(search_history_path(user_id), [])
        return data if isinstance(data, list) else []

    def remember_search(user_id: str, query: str) -> None:
        query = re.sub(r"\s+", " ", query).strip()[:180]
        if len(query) < 2:
            return
        rows = [r for r in load_search_history(user_id) if str(r.get("query") or "").casefold() != query.casefold()]
        rows.insert(0, {"query": query, "at": int(time.time())})
        write_json(search_history_path(user_id), rows[:20])

    @app.get("/api/youtube/search/v2")
    @core.login_required
    def power_youtube_search():
        user = core.current_user()
        query = re.sub(r"\s+", " ", str(request.args.get("q") or "")).strip()[:180]
        if len(query) < 2:
            return jsonify({"error": "Digite pelo menos 2 caracteres para pesquisar no YouTube."}), 400
        try:
            offset = max(0, min(180, int(request.args.get("offset") or 0)))
            limit = max(1, min(30, int(request.args.get("limit") or 12)))
        except Exception:
            offset, limit = 0, 12
        sort = str(request.args.get("sort") or "relevance")
        duration_filter = str(request.args.get("duration") or "any")
        prefix = "ytsearchdate" if sort == "recent" else "ytsearch"
        total = min(200, max(offset + limit + 18, 24))
        remember = str(request.args.get("remember") or "0").lower() in {"1", "true", "yes"}
        if remember:
            remember_search(user["id"], query)
        try:
            import yt_dlp
            opts = {
                "quiet": True, "no_warnings": True, "skip_download": True,
                "extract_flat": "in_playlist", "playlistend": total, "noplaylist": False,
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(f"{prefix}{total}:{query}", download=False) or {}
            existing = existing_video_map(user["id"])
            filtered: list[dict[str, Any]] = []
            for entry in list(info.get("entries") or []):
                if not isinstance(entry, dict):
                    continue
                video_id = str(entry.get("id") or "").strip()
                if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", video_id):
                    continue
                duration = float(entry.get("duration") or 0)
                if duration_filter == "short" and duration > 240: continue
                if duration_filter == "medium" and (duration <= 240 or duration > 1200): continue
                if duration_filter == "long" and duration <= 1200: continue
                url = str(entry.get("webpage_url") or "").strip() or f"https://www.youtube.com/watch?v={video_id}"
                old = existing.get(video_id)
                filtered.append({
                    "id": video_id, "url": url,
                    "title": str(entry.get("title") or "Vídeo do YouTube").strip(),
                    "channel": str(entry.get("channel") or entry.get("uploader") or "YouTube").strip(),
                    "duration": duration, "duration_label": core._format_search_duration(duration),
                    "thumbnail_url": str(entry.get("thumbnail") or "").strip() or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
                    "view_count": entry.get("view_count"), "upload_date": entry.get("upload_date"),
                    "in_library": bool(old), "existing_job": summary(old) if old else None,
                })
            if sort == "views":
                filtered.sort(key=lambda row: int(row.get("view_count") or 0), reverse=True)
            page = filtered[offset:offset + limit]
            # Recommendation learning is passive: reuse results from searches the
            # user already requested. Never launch a second yt-dlp search in the
            # background just to feed the Home screen.
            if remember and offset == 0:
                try:
                    _remember_recommendation_candidates(user["id"], query, filtered[:18])
                    _refresh_local_recommendation_cache(user["id"])
                except Exception:
                    pass
            return jsonify({
                "query": query, "items": page, "offset": offset, "limit": limit,
                "next_offset": offset + len(page), "has_more": offset + len(page) < len(filtered) or len(filtered) >= total,
                "sort": sort, "duration": duration_filter,
            })
        except Exception as exc:
            return jsonify({"error": f"Não foi possível pesquisar no YouTube agora: {core._clean_yt_error(exc)}"}), 502

    @app.get("/api/youtube/search-history")
    @core.login_required
    def power_search_history():
        user = core.current_user()
        return jsonify({"items": load_search_history(user["id"])[:12]})

    @app.delete("/api/youtube/search-history")
    @core.login_required
    def power_clear_search_history():
        user = core.current_user(); write_json(search_history_path(user["id"]), [])
        return jsonify({"ok": True})

    # ---------- Local watch history + personalized recommendations ----------
    _REC_STOPWORDS = {
        "para","com","sem","uma","umas","uns","dos","das","por","que","como","mais","menos","isso","essa","esse","este","esta","seu","sua","meu","minha","the","and","for","with","from","this","that","your","you","video","videos","vídeo","vídeos","official","oficial","live","ao","vivo","letra","lyrics","audio","áudio","clip","clipe","music","musica","música","completo","completa","hd","4k","ft","feat"
    }
    _REC_BLOCKED = {
        "cassino","casino","aposta","apostas","betting","sportsbook","roleta","poker","vape","cigarro","nicotina","maconha","cannabis","weed","thc","cbd","cocaine","cocaina","cocaína","porn","porno","pornografia","xxx","onlyfans","gun","guns","rifle","pistol","arma","armas","municao","munição","faca tatica","faca tática","switchblade","taser","desafio perigoso","roleta russa"
    }

    def watch_history_path(user_id: str) -> Path:
        return user_file(user_id, "youtube_watch_history.json")

    def recommendation_state_path(user_id: str) -> Path:
        return user_file(user_id, "youtube_recommendations.json")

    def recommendation_candidates_path(user_id: str) -> Path:
        return user_file(user_id, "youtube_recommendation_candidates.json")

    def _remember_recommendation_candidates(user_id: str, query: str, items: list[dict[str, Any]]) -> None:
        now = int(time.time())
        old = read_json(recommendation_candidates_path(user_id), [])
        old = old if isinstance(old, list) else []
        incoming = []
        for row in items[:18]:
            if not isinstance(row, dict):
                continue
            video_id = str(row.get("id") or "").strip()
            title = str(row.get("title") or "Vídeo do YouTube").strip()
            if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", video_id) or not _rec_safe_text(title):
                continue
            incoming.append({
                "id": video_id,
                "url": str(row.get("url") or f"https://www.youtube.com/watch?v={video_id}"),
                "title": title,
                "channel": str(row.get("channel") or "YouTube"),
                "duration": float(row.get("duration") or 0),
                "duration_label": str(row.get("duration_label") or ""),
                "thumbnail_url": str(row.get("thumbnail_url") or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"),
                "query": str(query or "")[:180],
                "at": now,
            })
        merged = incoming + old
        seen = set(); clean = []
        for row in merged:
            vid = str(row.get("id") or "")
            if not vid or vid in seen:
                continue
            seen.add(vid); clean.append(row)
            if len(clean) >= 90:
                break
        write_json(recommendation_candidates_path(user_id), clean)

    def _rec_safe_text(text: str) -> bool:
        low = re.sub(r"\s+", " ", str(text or "").casefold())
        return not any(term in low for term in _REC_BLOCKED)

    def _rec_tokens(text: str) -> list[str]:
        parts = re.findall(r"[\wÀ-ÿ]{3,}", str(text or "").casefold(), flags=re.UNICODE)
        return [p for p in parts if p not in _REC_STOPWORDS and not p.isdigit() and _rec_safe_text(p)]

    def _load_watch_history(user_id: str) -> list[dict[str, Any]]:
        rows = read_json(watch_history_path(user_id), [])
        return rows if isinstance(rows, list) else []

    @app.post("/api/youtube/watch-event")
    @core.login_required
    def power_watch_event():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        video_id = str(payload.get("id") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", video_id):
            return jsonify({"error":"Vídeo inválido."}), 400
        title = str(payload.get("title") or "Vídeo do YouTube").strip()[:240]
        channel = str(payload.get("channel") or "YouTube").strip()[:160]
        query = str(payload.get("query") or "").strip()[:180]
        rows = [r for r in _load_watch_history(user["id"]) if str(r.get("id") or "") != video_id]
        rows.insert(0,{"id":video_id,"url":str(payload.get("url") or f"https://www.youtube.com/watch?v={video_id}"),"title":title,"channel":channel,"query":query,"at":int(time.time())})
        write_json(watch_history_path(user["id"]), rows[:60])
        # Re-rank only the small local candidate pool. This is intentionally
        # network-free and never starts yt-dlp in the background.
        try:
            _refresh_local_recommendation_cache(user["id"])
        except Exception:
            pass
        return jsonify({"ok":True})

    def _recommendation_profile(user_id: str) -> tuple[list[str], str]:
        phrase_scores: Counter[str] = Counter(); token_scores: Counter[str] = Counter()
        searches = load_search_history(user_id)[:20]
        for idx,row in enumerate(searches):
            q = re.sub(r"\s+"," ",str(row.get("query") or "")).strip()
            if len(q)>=2 and _rec_safe_text(q):
                phrase_scores[q] += max(2, 8 - idx//3)
                for t in _rec_tokens(q): token_scores[t] += 4
        watches = _load_watch_history(user_id)[:35]
        for idx,row in enumerate(watches):
            q=str(row.get("query") or "").strip(); title=str(row.get("title") or "")
            if q and _rec_safe_text(q): phrase_scores[q] += max(2, 7 - idx//5)
            for t in _rec_tokens(title): token_scores[t] += max(1, 4 - idx//12)
        # Do not scan full transcription/job JSONs here. Search and watch
        # history are tiny local files and are enough to learn the user's taste
        # without competing with the desktop startup.
        seeds=[]
        for phrase,_ in phrase_scores.most_common(5):
            if phrase.casefold() not in {x.casefold() for x in seeds}: seeds.append(phrase)
        if len(seeds)<5:
            top=[t for t,_ in token_scores.most_common(10) if _rec_safe_text(t)]
            for i in range(0,len(top),2):
                q=" ".join(top[i:i+2]).strip()
                if q and q.casefold() not in {x.casefold() for x in seeds}: seeds.append(q)
                if len(seeds)>=5: break
        reason=""
        if seeds:
            reason=f"Sugestões baseadas principalmente em: {seeds[0]}"
        return seeds[:3], reason

    def _extract_recommendations(user_id: str, seeds: list[str], dismissed: set[str]) -> list[dict[str, Any]]:
        rows = read_json(recommendation_candidates_path(user_id), [])
        rows = rows if isinstance(rows, list) else []
        seed_tokens = set()
        for seed in seeds:
            seed_tokens.update(_rec_tokens(seed))
        now = int(time.time()); scored = []; seen = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            video_id = str(row.get("id") or "").strip(); title = str(row.get("title") or "").strip()
            if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", video_id) or video_id in dismissed or video_id in seen:
                continue
            if not _rec_safe_text(title):
                continue
            seen.add(video_id)
            tokens = set(_rec_tokens(title + " " + str(row.get("query") or "")))
            overlap = len(tokens & seed_tokens)
            age_hours = max(0.0, (now - int(row.get("at") or now)) / 3600.0)
            recency = max(0.0, 8.0 - min(8.0, age_hours / 24.0))
            score = overlap * 12.0 + recency
            scored.append((score, int(row.get("at") or 0), row))
        scored.sort(key=lambda x: (-x[0], -x[1]))
        return [dict(row) for _, _, row in scored[:6]]

    def _refresh_local_recommendation_cache(user_id: str) -> dict[str, Any]:
        state = read_json(recommendation_state_path(user_id), {})
        if not isinstance(state, dict):
            state = {}
        dismissed = set(str(x) for x in (state.get("dismissed") or []) if x)
        seeds, reason = _recommendation_profile(user_id)
        items = _extract_recommendations(user_id, seeds, dismissed) if seeds else []
        state = {
            "generated_at": int(time.time()),
            "items": items,
            "reason": reason,
            "dismissed": list(dismissed)[-120:],
            "needs_history": not bool(seeds),
        }
        write_json(recommendation_state_path(user_id), state)
        return state

    @app.get("/api/recommendations")
    @core.login_required
    def power_recommendations():
        user = core.current_user(); user_id = user["id"]; settings = core._load_user_settings(user_id)
        if settings.get("recommendations_enabled", True) is False:
            return jsonify({"items": [], "disabled": True, "reason": ""})
        refresh = str(request.args.get("refresh") or "0").lower() in {"1", "true", "yes"}
        cache_only = str(request.args.get("cache_only") or "0").lower() in {"1", "true", "yes"}
        state = read_json(recommendation_state_path(user_id), {})
        if not isinstance(state, dict):
            state = {}
        if refresh and not cache_only:
            state = _refresh_local_recommendation_cache(user_id)
        dismissed = set(str(x) for x in (state.get("dismissed") or []) if x)
        cached = [x for x in (state.get("items") or []) if isinstance(x, dict) and str(x.get("id") or "") not in dismissed]
        return jsonify({
            "items": cached[:6],
            "reason": str(state.get("reason") or ""),
            "cached": bool(cached),
            "stale": False,
            "needs_history": bool(state.get("needs_history", False)),
            "loading": False,
            "passive": True,
        })

    @app.post("/api/recommendations/dismiss")
    @core.login_required
    def power_recommendation_dismiss():
        user=core.current_user(); payload=request.get_json(silent=True) or {}; video_id=str(payload.get("id") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}",video_id): return jsonify({"error":"Vídeo inválido."}),400
        state=read_json(recommendation_state_path(user["id"]),{})
        if not isinstance(state,dict): state={}
        dismissed=[str(x) for x in (state.get("dismissed") or []) if x and str(x)!=video_id]; dismissed.append(video_id)
        state["dismissed"]=dismissed[-120:]; state["items"]=[x for x in (state.get("items") or []) if isinstance(x,dict) and str(x.get("id") or "")!=video_id]
        write_json(recommendation_state_path(user["id"]),state); return jsonify({"ok":True})


    @app.get("/api/duplicates/check")
    @core.login_required
    def power_duplicate_check():
        user = core.current_user(); url = str(request.args.get("url") or "").strip()
        try: vid = core.extract_video_id(url)
        except Exception as exc: return jsonify({"error": str(exc)}), 400
        old = existing_video_map(user["id"]).get(vid)
        return jsonify({"duplicate": bool(old), "item": summary(old) if old else None})

    @app.post("/api/transcribe/batch/v2")
    @core.login_required
    def power_batch_v2():
        payload = request.get_json(silent=True) or {}; user = core.current_user()
        urls = payload.get("urls") or []
        if isinstance(urls, str): urls = [x.strip() for x in urls.splitlines() if x.strip()]
        urls = list(dict.fromkeys(str(x).strip() for x in urls if str(x).strip()))[:100]
        if not urls: return jsonify({"error":"Adicione pelo menos um vídeo."}), 400
        if not bool(payload.get("confirmed_rights", False)): return jsonify({"error":"Confirme que você tem permissão para processar os conteúdos."}), 400
        language = str(payload.get("language") or "auto"); quality = str(payload.get("quality") or "1080")
        timestamps = bool(payload.get("timestamps", True)); allow_whisper = bool(payload.get("allow_whisper", True)); project_id = str(payload.get("project_id") or "").strip() or None
        if language not in core.LANGUAGE_MAP: language = "auto"
        if quality not in {"360","720","1080","best"}: quality = "1080"
        if project_id and not core._project_by_id(user["id"], project_id): project_id = None
        force = bool(payload.get("force", False)); existing = existing_video_map(user["id"]); created=[]; duplicates=[]; errors=[]
        for url in urls:
            try: vid = core.extract_video_id(url)
            except Exception as exc: errors.append({"url":url,"error":str(exc)}); continue
            if vid in existing and not force:
                duplicates.append(summary(existing[vid])); continue
            jid=uuid.uuid4().hex
            job={"id":jid,"user_id":user["id"],"url":url,"video_id":vid,"language":language,"timestamps":timestamps,"allow_whisper":allow_whisper,"video_quality_request":quality,"project_id":project_id,"favorite":False,"tags":[],"source_type":"youtube","thumbnail_url":f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg","transcript_available":False,"media_only":False,"segments":[],"trashed_at":None,"status":"queued","stage":"Na fila","progress":0,"title":"Transcrição do YouTube","source":None,"detected_language":None,"transcript":None,"word_count":None,"duration_seconds":None,"duration_label":None,"segment_count":None,"audio_ready":False,"audio_filename":None,"audio_url":None,"audio_error":None,"video_ready":False,"video_filename":None,"video_url":None,"video_error":None,"video_height":None,"video_quality":None,"video_is_full_hd":False,"error":None,"created_at":int(time.time()),"updated_at":int(time.time())}
            core.save_job(job); threading.Thread(target=core.queued_worker,args=(jid,),daemon=True).start(); created.append({"job_id":jid,"url":url})
        return jsonify({"job_ids":[row["job_id"] for row in created],"created":created,"duplicates":duplicates,"errors":errors}), 202

    # ---------- Playlist import ----------
    @app.get("/api/youtube/playlist")
    @core.login_required
    def power_playlist_preview():
        user = core.current_user()
        url = str(request.args.get("url") or "").strip()
        if not url:
            return jsonify({"error": "Cole o link de uma playlist do YouTube."}), 400
        try:
            parsed = urlparse(url)
            if parsed.hostname and parsed.hostname.lower() not in core.SUPPORTED_HOSTS:
                raise ValueError("Use uma playlist do YouTube.")
            import yt_dlp
            opts = {
                "quiet": True, "no_warnings": True, "skip_download": True,
                "extract_flat": True, "playlistend": 150, "noplaylist": False,
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False) or {}
            entries = list(info.get("entries") or [])
            if not entries:
                return jsonify({"error": "Não encontrei vídeos nessa playlist."}), 404
            existing = existing_video_map(user["id"])
            items: list[dict[str, Any]] = []
            for entry in entries[:150]:
                if not isinstance(entry, dict): continue
                vid = str(entry.get("id") or "").strip()
                if not vid: continue
                video_url = str(entry.get("webpage_url") or "").strip() or f"https://www.youtube.com/watch?v={vid}"
                old = existing.get(vid)
                items.append({
                    "id": vid, "url": video_url, "title": str(entry.get("title") or "Vídeo").strip(),
                    "channel": str(entry.get("channel") or entry.get("uploader") or "YouTube").strip(),
                    "duration": entry.get("duration"), "duration_label": core._format_search_duration(entry.get("duration")),
                    "thumbnail_url": str(entry.get("thumbnail") or "").strip() or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    "in_library": bool(old), "existing_job": summary(old) if old else None,
                })
            return jsonify({
                "title": str(info.get("title") or "Playlist do YouTube").strip(),
                "channel": str(info.get("channel") or info.get("uploader") or "YouTube").strip(),
                "count": len(items), "items": items,
            })
        except Exception as exc:
            return jsonify({"error": f"Não foi possível abrir a playlist: {core._clean_yt_error(exc)}"}), 502

    # ---------- Project workspace ----------
    @app.get("/api/projects/<project_id>/detail")
    @core.login_required
    def power_project_detail(project_id: str):
        user = core.current_user(); project = core._project_by_id(user["id"], project_id)
        if not project: return jsonify({"error": "Projeto não encontrado."}), 404
        q = re.sub(r"\s+", " ", str(request.args.get("q") or "")).strip().casefold()
        sort = str(request.args.get("sort") or "recent")
        jobs = [j for j in core._user_jobs(user["id"]) if j.get("project_id") == project_id]
        short_items: list[dict[str, Any]] = []
        try:
            short_path = core._user_dir(user["id"]) / "shorts_library.json"
            rows = json.loads(short_path.read_text(encoding="utf-8")) if short_path.exists() else []
            for row in rows if isinstance(rows, list) else []:
                if str(row.get("project_id") or "") != project_id:
                    continue
                aid = str(row.get("id") or "")
                media = core.DATA_ROOT / "shorts_library" / user["id"] / f"{aid}.mp4"
                if not re.fullmatch(r"[a-f0-9]{32}", aid) or not media.exists():
                    continue
                short_items.append({
                    "id": aid, "item_type": "short", "title": str(row.get("short_title") or row.get("title") or "Short"),
                    "created_at": int(row.get("created_at") or 0), "updated_at": int(row.get("updated_at") or 0),
                    "duration_seconds": float(row.get("duration") or 0), "duration_label": core._format_search_duration(row.get("duration")),
                    "thumbnail_url": str(row.get("thumbnail_url") or ""), "project_id": project_id,
                    "video_ready": True, "video_url": f"/shorts/library/media/{aid}", "video_quality": f"{row.get('quality') or '1080'}p",
                    "audio_ready": False, "transcript_available": False, "favorite": False, "tags": [], "status": "done",
                    "channel": str(row.get("channel") or "YouTube"), "short_start": row.get("start"), "short_end": row.get("end"),
                })
        except Exception:
            short_items = []
        job_items = [summary(j) for j in jobs]
        items = job_items + short_items
        if q:
            items = [j for j in items if q in str(j.get("title") or "").casefold() or q in str(j.get("preview") or "").casefold() or any(q in str(t).casefold() for t in (j.get("tags") or []))]
        if sort == "oldest": items.sort(key=lambda j: int(j.get("created_at") or 0))
        elif sort == "title": items.sort(key=lambda j: str(j.get("title") or "").casefold())
        elif sort == "duration": items.sort(key=lambda j: float(j.get("duration_seconds") or 0), reverse=True)
        else: items.sort(key=lambda j: int(j.get("created_at") or 0), reverse=True)
        return jsonify({
            "project": project,
            "items": items,
            "stats": {
                "total": len(items), "audio": sum(bool(j.get("audio_ready")) for j in job_items),
                "video": sum(bool(j.get("video_ready")) for j in items),
                "text": sum(bool(j.get("transcript_available")) for j in job_items),
                "favorites": sum(bool(j.get("favorite")) for j in job_items), "shorts": len(short_items),
            },
        })

    @app.get("/api/tags")
    @core.login_required
    def power_tags():
        user = core.current_user(); counts: dict[str, int] = {}
        for job in core._user_jobs(user["id"]):
            for tag in normalize_tags(job.get("tags") or []): counts[tag] = counts.get(tag, 0) + 1
        return jsonify({"items": [{"name": k, "count": v} for k, v in sorted(counts.items(), key=lambda x: (-x[1], x[0].casefold()))]})

    @app.post("/api/jobs/bulk")
    @core.login_required
    def power_bulk_jobs():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        ids = [str(x) for x in payload.get("job_ids", []) if re.fullmatch(r"[a-f0-9]{32}", str(x))][:200]
        action = str(payload.get("action") or "")
        if not ids: return jsonify({"error": "Selecione pelo menos um trabalho."}), 400
        updated = 0
        for jid in ids:
            job = core.get_job(jid)
            if not core._job_owned_by(job, user): continue
            if action == "move":
                pid = str(payload.get("project_id") or "").strip() or None
                if pid and not core._project_by_id(user["id"], pid): return jsonify({"error": "Projeto não encontrado."}), 400
                core.update_job(jid, project_id=pid); updated += 1
            elif action in {"favorite", "unfavorite"}:
                core.update_job(jid, favorite=action == "favorite"); updated += 1
            elif action == "trash":
                core.update_job(jid, trashed_at=int(time.time())); updated += 1
            elif action in {"tag_add", "tag_remove"}:
                tag = normalize_tags([payload.get("tag")])
                if not tag: return jsonify({"error": "Digite uma tag válida."}), 400
                tags = normalize_tags(job.get("tags") or [])
                if action == "tag_add" and tag[0].casefold() not in {x.casefold() for x in tags}: tags.append(tag[0])
                if action == "tag_remove": tags = [x for x in tags if x.casefold() != tag[0].casefold()]
                core.update_job(jid, tags=tags); updated += 1
            else:
                return jsonify({"error": "Ação em massa inválida."}), 400
        return jsonify({"ok": True, "updated": updated})

    @app.post("/api/jobs/bulk/save")
    @core.login_required
    def power_bulk_save():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        ids = [str(x) for x in payload.get("job_ids", []) if re.fullmatch(r"[a-f0-9]{32}", str(x))][:100]
        kind = str(payload.get("kind") or "audio")
        if kind not in {"txt","pdf","docx","srt","vtt","audio","video"}: return jsonify({"error": "Formato inválido."}), 400
        saved, errors = [], []
        for jid in ids:
            job = core.get_job(jid)
            if not core._job_owned_by(job, user) or job.get("status") != "done": continue
            try:
                dest, filename, size = core._save_asset_copy(user, job, kind)
                saved.append({"job_id": jid, "filename": filename, "saved_path": str(dest), "size_bytes": size})
            except Exception as exc:
                errors.append({"job_id": jid, "title": job.get("title"), "error": str(exc)})
        return jsonify({"ok": True, "saved": saved, "errors": errors})

    @app.post("/api/jobs/bulk/export")
    @core.login_required
    def power_bulk_export():
        user = core.current_user(); payload = request.get_json(silent=True) or {}
        ids = [str(x) for x in payload.get("job_ids", []) if re.fullmatch(r"[a-f0-9]{32}", str(x))][:150]
        jobs = [core.get_job(jid) for jid in ids]
        jobs = [j for j in jobs if core._job_owned_by(j, user) and j and j.get("transcript_available")]
        if not jobs: return jsonify({"error": "Nenhuma transcrição selecionada está disponível para exportar."}), 400
        _, folders = core._ensure_storage_tree(user["id"])
        stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        dest = core._unique_destination(folders["backup"], f"RedScribe_Transcricoes_{stamp}.zip")
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            used: set[str] = set()
            for idx, job in enumerate(jobs, 1):
                base = core._safe_download_name(str(job.get("title") or f"Transcricao {idx}"), f"Transcricao {idx}")
                name = f"{base}.txt"; n = 2
                while name.casefold() in used:
                    name = f"{base} ({n}).txt"; n += 1
                used.add(name.casefold())
                zf.writestr(name, str(job.get("transcript") or ""))
        return jsonify({"ok": True, "saved_path": str(dest), "filename": dest.name, "size_bytes": dest.stat().st_size, "count": len(jobs)})

    # ---------- AI conversations + project context ----------
    def conversations_path(user_id: str) -> Path:
        return user_file(user_id, "ai_conversations.json")

    def load_conversations(user_id: str) -> dict[str, Any]:
        data = read_json(conversations_path(user_id), {})
        if not isinstance(data, dict): data = {}
        items = data.get("items") if isinstance(data.get("items"), list) else []
        if not items:
            legacy = core._load_ai_history(user_id)
            if legacy:
                now = int(time.time()); cid = uuid.uuid4().hex[:16]
                items = [{"id": cid, "title": "Conversa anterior", "created_at": now, "updated_at": now, "messages": legacy[-40:]}]
                data = {"active_id": cid, "items": items}; write_json(conversations_path(user_id), data)
            else:
                data = {"active_id": None, "items": []}
        data["items"] = items
        return data

    def save_conversations(user_id: str, data: dict[str, Any]) -> None:
        items = data.get("items") if isinstance(data.get("items"), list) else []
        for conv in items:
            if isinstance(conv, dict): conv["messages"] = (conv.get("messages") if isinstance(conv.get("messages"), list) else [])[-80:]
        data["items"] = items[-40:]
        write_json(conversations_path(user_id), data)

    def get_conversation(data: dict[str, Any], cid: str) -> dict[str, Any] | None:
        return next((c for c in data.get("items", []) if isinstance(c, dict) and c.get("id") == cid), None)

    def project_context(user_id: str, project_id: str, question: str) -> tuple[str, dict[str, Any] | None]:
        project = core._project_by_id(user_id, project_id)
        if not project: return "", None
        jobs = [j for j in core._user_jobs(user_id) if j.get("project_id") == project_id and j.get("transcript_available")]
        jobs.sort(key=lambda j: int(j.get("created_at") or 0), reverse=True)
        words = [w.casefold() for w in re.findall(r"[A-Za-zÀ-ÿ0-9]{4,}", question or "")][:12]
        scored = []
        for j in jobs:
            text = str(j.get("transcript") or "")
            score = sum(text.casefold().count(w) for w in words) if words else 0
            scored.append((score, j))
        scored.sort(key=lambda x: (x[0], int(x[1].get("created_at") or 0)), reverse=True)
        selected = [j for _, j in scored]
        # Inclui todos os trabalhos com transcrição sempre que possível, dividindo
        # um orçamento seguro entre eles. Assim até projetos grandes participam do contexto.
        budget = 72000; blocks = []; used = 0
        per = max(280, min(7000, budget // max(1, len(selected))))
        for j in selected:
            text = str(j.get("transcript") or "").strip()
            if not text: continue
            remaining = max(0, budget - used)
            if remaining <= 120: break
            excerpt = text[:min(per, remaining)]
            block = f"\n--- {j.get('title') or 'Conteúdo'} ---\n{excerpt}"
            blocks.append(block); used += len(block)
        return f"\n\nCONTEXTO DO PROJETO '{project.get('name')}' ({len(selected)} transcrições):" + "".join(blocks), project

    @app.get("/api/ai/conversations")
    @core.login_required
    def power_ai_conversations():
        user = core.current_user(); data = load_conversations(user["id"])
        items = []
        for c in sorted(data.get("items", []), key=lambda x: int(x.get("updated_at") or 0), reverse=True):
            msgs = c.get("messages") if isinstance(c.get("messages"), list) else []
            preview = next((str(m.get("text") or "") for m in reversed(msgs) if m.get("role") == "user"), "")
            items.append({"id": c.get("id"), "title": c.get("title") or "Conversa", "created_at": c.get("created_at"), "updated_at": c.get("updated_at"), "message_count": len(msgs), "preview": preview[:110]})
        return jsonify({"items": items, "active_id": data.get("active_id")})

    @app.post("/api/ai/conversations")
    @core.login_required
    def power_ai_new_conversation():
        user = core.current_user(); payload = request.get_json(silent=True) or {}; data = load_conversations(user["id"])
        now = int(time.time()); cid = uuid.uuid4().hex[:16]
        title = re.sub(r"\s+", " ", str(payload.get("title") or "Nova conversa")).strip()[:70] or "Nova conversa"
        conv = {"id": cid, "title": title, "created_at": now, "updated_at": now, "messages": []}
        data.setdefault("items", []).append(conv); data["active_id"] = cid; save_conversations(user["id"], data)
        return jsonify({"item": {k:v for k,v in conv.items() if k != "messages"}}), 201

    @app.get("/api/ai/conversations/<cid>/messages")
    @core.login_required
    def power_ai_messages(cid: str):
        user = core.current_user(); data = load_conversations(user["id"]); conv = get_conversation(data, cid)
        if not conv: return jsonify({"error": "Conversa não encontrada."}), 404
        data["active_id"] = cid; save_conversations(user["id"], data)
        return jsonify({"conversation": {"id": cid, "title": conv.get("title")}, "items": conv.get("messages") or []})

    @app.patch("/api/ai/conversations/<cid>")
    @core.login_required
    def power_ai_rename_conversation(cid: str):
        user = core.current_user(); data = load_conversations(user["id"]); conv = get_conversation(data, cid)
        if not conv: return jsonify({"error": "Conversa não encontrada."}), 404
        payload = request.get_json(silent=True) or {}; title = re.sub(r"\s+", " ", str(payload.get("title") or "")).strip()[:70]
        if not title: return jsonify({"error": "Digite um nome para a conversa."}), 400
        conv["title"] = title; conv["updated_at"] = int(time.time()); save_conversations(user["id"], data)
        return jsonify({"ok": True})

    @app.delete("/api/ai/conversations/<cid>")
    @core.login_required
    def power_ai_delete_conversation(cid: str):
        user = core.current_user(); data = load_conversations(user["id"])
        before = len(data.get("items", [])); data["items"] = [c for c in data.get("items", []) if c.get("id") != cid]
        if len(data["items"]) == before: return jsonify({"error": "Conversa não encontrada."}), 404
        if data.get("active_id") == cid: data["active_id"] = data["items"][-1]["id"] if data["items"] else None
        save_conversations(user["id"], data); return jsonify({"ok": True, "active_id": data.get("active_id")})

    @app.post("/api/ai/conversations/<cid>/chat/stream")
    @core.login_required
    def power_ai_conversation_chat(cid: str):
        user = core.current_user(); data = load_conversations(user["id"]); conv = get_conversation(data, cid)
        if not conv: return jsonify({"error": "Conversa não encontrada."}), 404
        payload = request.get_json(silent=True) or {}
        message = re.sub(r"[ \t]+", " ", str(payload.get("message") or "").strip())[:24000]
        attachment_ids = payload.get("attachment_ids") if isinstance(payload.get("attachment_ids"), list) else []
        attachment_context, public_attachments = core._attachment_context(user["id"], [str(x) for x in attachment_ids])
        if not message and not public_attachments: return jsonify({"error": "Digite uma mensagem ou anexe um arquivo."}), 400
        if not message: message = "Analise os arquivos anexados e organize os pontos mais importantes."
        context = ""
        job_id = str(payload.get("job_id") or "").strip()
        project_id = str(payload.get("project_id") or "").strip()
        if project_id:
            project_text, _ = project_context(user["id"], project_id, message); context += project_text
        elif job_id:
            job = core.get_job(job_id)
            if core._job_owned_by(job, user) and job and job.get("transcript_available"):
                context += f"\n\nCONTEXTO DO CONTEÚDO '{job.get('title') or 'Transcrição'}':\n{core._ai_context(job, 'ask', message)}"
        recent = (conv.get("messages") if isinstance(conv.get("messages"), list) else [])[-14:]
        conversation = "\n".join(("Usuário" if m.get("role") == "user" else "Assistente") + ": " + str(m.get("text") or "")[:10000] for m in recent)
        prompt = (
            "Você é a IA do RedScribe. Responda em português do Brasil. Organize a resposta com Markdown bem estruturado, "
            "títulos curtos quando úteis, parágrafos curtos, listas para etapas e **negrito** para pontos importantes. "
            "Se houver transcrições, projeto ou anexos como contexto, baseie afirmações sobre esses materiais somente no conteúdo fornecido. "
            "Não invente informações ausentes.\n\n"
            + ("HISTÓRICO DA CONVERSA:\n" + conversation + "\n\n" if conversation else "")
            + "MENSAGEM ATUAL:\n" + message + context + attachment_context
        )
        def stream():
            parts: list[str] = []; had_error = False
            for event in core._claude_generate_stream(prompt, user["id"], timeout=300):
                if event.get("type") == "token": parts.append(str(event.get("text") or ""))
                if event.get("type") == "error": had_error = True
                yield json.dumps(event, ensure_ascii=False) + "\n"
            answer = "".join(parts).strip()
            if answer and not had_error:
                latest = load_conversations(user["id"]); target = get_conversation(latest, cid)
                if target:
                    now = int(time.time()); msgs = target.setdefault("messages", [])
                    msgs.extend([
                        {"role":"user","text":message,"created_at":now,"attachments":public_attachments},
                        {"role":"assistant","text":answer,"created_at":now,"attachments":[]},
                    ])
                    if str(target.get("title") or "") in {"Nova conversa", "Conversa"}:
                        target["title"] = re.sub(r"\s+", " ", message).strip()[:55] or "Conversa"
                    target["updated_at"] = now; latest["active_id"] = cid; save_conversations(user["id"], latest)
        response = Response(stream_with_context(stream()), mimetype="application/x-ndjson")
        response.headers["Cache-Control"] = "no-cache"; response.headers["X-Accel-Buffering"] = "no"
        return response

    # Extra per-transcript AI actions.
    @app.post("/api/jobs/<job_id>/ai/v2/stream")
    @core.login_required
    def power_job_ai(job_id: str):
        user = core.current_user(); job = core.get_job(job_id)
        if not core._job_owned_by(job, user) or not job.get("transcript_available"):
            return jsonify({"error": "Este trabalho não possui transcrição para analisar."}), 400
        payload = request.get_json(silent=True) or {}; action = str(payload.get("action") or "summary"); question = str(payload.get("question") or "").strip()
        instructions = {
            "summary":"Crie um resumo estruturado com visão geral, pontos centrais e conclusão.",
            "points":"Liste os principais pontos da transcrição em tópicos claros.",
            "script":"Transforme o conteúdo em um roteiro natural e organizado, fiel ao material.",
            "qna":"Crie uma seção de perguntas e respostas que cubra os pontos mais importantes do conteúdo.",
            "titles":"Crie 10 sugestões de títulos objetivos e atraentes baseados somente no conteúdo.",
            "description":"Crie uma descrição organizada do conteúdo, incluindo resumo curto e tópicos abordados.",
            "post":"Transforme o conteúdo em um post curto e legível para rede social, sem inventar fatos.",
            "study":"Transforme o conteúdo em notas de estudo: conceitos, definições, tópicos e revisão final.",
        }
        if action == "ask":
            if not question: return jsonify({"error": "Digite uma pergunta."}), 400
            instruction = f"Responda somente com base na transcrição. Pergunta: {question}. Se não houver resposta no conteúdo, diga isso."
        else:
            instruction = instructions.get(action)
            if not instruction: return jsonify({"error": "Ação de IA inválida."}), 400
        transcript = core._ai_context(job, "ask" if action == "ask" else action, question)
        prompt = f"{instruction}\nOrganize com Markdown, títulos curtos e listas quando fizer sentido. Não invente informações.\n\nTRANSCRIÇÃO:\n{transcript}"
        def stream():
            for event in core._claude_generate_stream(prompt, user["id"], timeout=300):
                yield json.dumps(event, ensure_ascii=False) + "\n"
        response = Response(stream_with_context(stream()), mimetype="application/x-ndjson"); response.headers["Cache-Control"]="no-cache"; response.headers["X-Accel-Buffering"]="no"
        return response

    # ---------- Recovery ----------
    @app.post("/api/recovery/check")
    @core.login_required
    def power_recovery():
        user = core.current_user(); restarted = []
        with _RECOVERY_LOCK:
            for job in core._user_jobs(user["id"]):
                jid = str(job.get("id") or "")
                if jid in _RECOVERY_STARTED or job.get("status") not in {"queued", "processing"}: continue
                if int(job.get("updated_at") or 0) >= _PROCESS_STARTED_AT - 2: continue
                _RECOVERY_STARTED.add(jid)
                core.update_job(jid, status="queued", stage="Retomando processamento interrompido...", progress=min(10, int(job.get("progress") or 0)), error=None)
                target = core.queued_local_worker if job.get("source_type") == "local" else core.queued_worker
                threading.Thread(target=target, args=(jid,), daemon=True).start(); restarted.append(jid)
        return jsonify({"ok": True, "restarted": len(restarted), "job_ids": restarted})


    @app.get("/api/power/preferences")
    @core.login_required
    def power_preferences_get():
        user=core.current_user(); st=core._load_user_settings(user["id"])
        return jsonify({"autosave_transcript":bool(st.get("autosave_transcript",True)),"recover_interrupted":bool(st.get("recover_interrupted",True)),"remember_player":bool(st.get("remember_player",True)),"recommendations_enabled":bool(st.get("recommendations_enabled",True))})

    @app.patch("/api/power/preferences")
    @core.login_required
    def power_preferences_patch():
        user=core.current_user(); payload=request.get_json(silent=True) or {}; st=core._load_user_settings(user["id"])
        for key in ("autosave_transcript","recover_interrupted","remember_player","recommendations_enabled"):
            if key in payload: st[key]=bool(payload.get(key))
        core._save_user_settings(user["id"],st); return jsonify({"ok":True,"settings":st})

    # ---------- Diagnostics ----------
    @app.get("/api/diagnostics")
    @core.login_required
    def power_diagnostics():
        user = core.current_user(); root = core._storage_root(user["id"]); checks = []
        def add(name, ok, detail): checks.append({"name": name, "ok": bool(ok), "detail": str(detail)})
        ffmpeg = core._ffmpeg_location(); add("FFmpeg", bool(ffmpeg and Path(ffmpeg).exists()), ffmpeg or "não encontrado")
        deno = core._deno_runtime()
        deno_detail = str(deno) if deno else "não encontrado"
        if deno:
            try:
                check = subprocess.run([str(deno), "--version"], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                first = (check.stdout or check.stderr or "").splitlines()[0].strip()
                deno_detail = f"{first} | {deno}"
            except Exception:
                pass
        add("Deno / JavaScript", bool(deno), deno_detail)

        yt_exe = core._official_ytdlp()
        yt_detail = str(yt_exe) if yt_exe else "não encontrado"
        if yt_exe:
            try:
                check = subprocess.run([str(yt_exe), "--version"], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                ver = (check.stdout or check.stderr or "").strip().splitlines()[0]
                yt_detail = f"{ver} | {yt_exe}"
            except Exception:
                pass
        add("Motor YouTube (yt-dlp.exe)", bool(yt_exe), yt_detail)

        try:
            import importlib.metadata as importlib_metadata
            ejs_version = importlib_metadata.version("yt-dlp-ejs")
            add("YouTube EJS", True, ejs_version)
        except Exception as exc:
            add("YouTube EJS", False, f"não incluído: {exc}")

        whisper = core.BASE_DIR / "models" / "faster-whisper-small"; add("Whisper Small", whisper.exists(), whisper)
        try:
            claude, _ = core._claude_runtime_paths(); add("Claude Code", bool(claude and Path(claude).exists()), claude or "não encontrado")
        except Exception as exc: add("Claude Code", False, exc)
        add("OpenCode Zen", bool(core._load_zen_key(user["id"])), "chave configurada" if core._load_zen_key(user["id"]) else "chave não configurada")
        try:
            root.mkdir(parents=True, exist_ok=True); probe = root / ".redscribe_write_test"; probe.write_text("ok", encoding="utf-8"); probe.unlink(missing_ok=True); add("Armazenamento", True, root)
        except Exception as exc: add("Armazenamento", False, exc)
        add("WebView2", True, "componente visual usado pelo aplicativo desktop" if getattr(sys, "frozen", False) else "modo de desenvolvimento")
        overall = all(c["ok"] for c in checks if c["name"] not in {"OpenCode Zen"})
        report = [f"RedScribe {core.APP_VERSION}", f"Windows/Python: {sys.platform} / {sys.version.split()[0]}", f"Dados: {core.DATA_ROOT}"]
        report += [f"{'OK' if c['ok'] else 'ERRO'} - {c['name']}: {c['detail']}" for c in checks]
        return jsonify({"ok": overall, "checks": checks, "report": "\n".join(report)})

    # ---------- App update engine ----------
    def parse_version(v: str) -> tuple[int, ...]:
        nums = re.findall(r"\d+", str(v or ""))[:4]
        return tuple(int(x) for x in nums) if nums else (0,)

    @app.get("/api/app-update/check")
    @core.login_required
    def power_update_check():
        manifest_url = os.environ.get("REDSCRIBE_UPDATE_MANIFEST", "").strip()
        if not manifest_url:
            return jsonify({"configured": False, "current": core.APP_VERSION, "available": False, "message": "Canal de atualização ainda não publicado."})
        try:
            with urllib.request.urlopen(manifest_url, timeout=10) as r: manifest = json.loads(r.read().decode("utf-8"))
            latest = str(manifest.get("version") or ""); download_url = str(manifest.get("download_url") or "")
            available = bool(latest and parse_version(latest) > parse_version(core.APP_VERSION) and download_url.startswith("https://"))
            return jsonify({"configured": True, "current": core.APP_VERSION, "latest": latest, "available": available, "notes": manifest.get("notes"), "download_url": download_url if available else None})
        except Exception as exc:
            return jsonify({"error": f"Não foi possível verificar atualizações: {exc}"}), 502

    @app.post("/api/app-update/download")
    @core.login_required
    def power_update_download():
        manifest_url = os.environ.get("REDSCRIBE_UPDATE_MANIFEST", "").strip()
        if not manifest_url: return jsonify({"error": "Canal de atualização ainda não publicado."}), 409
        try:
            with urllib.request.urlopen(manifest_url, timeout=10) as r: manifest = json.loads(r.read().decode("utf-8"))
            url = str(manifest.get("download_url") or ""); expected = str(manifest.get("sha256") or "").lower().strip()
            if not url.startswith("https://"): return jsonify({"error": "Manifesto de atualização inválido."}), 400
            folder = core.DATA_ROOT / "updates"; folder.mkdir(parents=True, exist_ok=True)
            dest = folder / f"RedScribe_Setup_{re.sub(r'[^0-9A-Za-z._-]+','_',str(manifest.get('version') or 'update'))}.exe"
            with urllib.request.urlopen(url, timeout=60) as src, dest.open("wb") as out: shutil.copyfileobj(src, out)
            if expected:
                digest = hashlib.sha256(dest.read_bytes()).hexdigest().lower()
                if digest != expected: dest.unlink(missing_ok=True); return jsonify({"error": "A assinatura SHA-256 da atualização não confere."}), 400
            return jsonify({"ok": True, "saved_path": str(dest), "filename": dest.name})
        except Exception as exc:
            return jsonify({"error": f"Não foi possível baixar a atualização: {exc}"}), 502
