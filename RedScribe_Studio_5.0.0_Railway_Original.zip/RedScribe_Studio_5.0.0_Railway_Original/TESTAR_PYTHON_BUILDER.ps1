﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " RedScribe - teste rapido do builder 3.1.8" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$uvExeItem = Get-ChildItem (Join-Path $PSScriptRoot "build_tools") -Recurse -Filter "uv.exe" -File -ErrorAction SilentlyContinue | Select-Object -First 1
if (!$uvExeItem) {
    Write-Host "uv.exe ainda nao foi baixado. Execute GERAR_INSTALADOR_WINDOWS.bat para prepara-lo." -ForegroundColor Yellow
    exit 2
}
$uvExe = $uvExeItem.FullName
$env:UV_PYTHON_INSTALL_DIR = Join-Path $PSScriptRoot ".uv-python"
$env:UV_CACHE_DIR = Join-Path $PSScriptRoot "build_tools\uv-cache"
foreach ($name in @("UV_PYTHON_PREFERENCE","UV_MANAGED_PYTHON","UV_NO_MANAGED_PYTHON","UV_PYTHON","VIRTUAL_ENV")) {
    Remove-Item ("Env:" + $name) -ErrorAction SilentlyContinue
}

$check = Join-Path $PSScriptRoot "build_runtime_check.py"
if (!(Test-Path $check)) { throw "build_runtime_check.py nao encontrado." }

$uvArgs = @("run", "--no-project", "--managed-python", "--python", "3.12", $check, "runtime")
Write-Host ("uv " + ($uvArgs -join " ")) -ForegroundColor DarkGray
& $uvExe @uvArgs
if ($LASTEXITCODE -ne 0) { throw "O teste nao conseguiu executar Python 3.12 x64." }

Write-Host ""
Write-Host "TESTE OK: Python 3.12 x64 foi executado sem python -c e sem procurar Scripts\python.exe." -ForegroundColor Green
