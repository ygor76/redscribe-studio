# Experiência guiada e montagem incremental — RedScribe Studio 5.0.0

## Apresentação guiada

A apresentação é exibida após o primeiro login de cada conta, usa o mesmo diálogo do aplicativo e possui três passos curtos: **criar**, **produzir** e **organizar**. O estado de conclusão é salvo nas preferências da conta por `onboarding_seen`, para não reaparecer em aberturas posteriores. A pessoa pode avançar, voltar ou encerrar a apresentação; qualquer saída a marca como concluída.

## Recomendações no Shorts Studio

O painel inicial do Shorts Studio reutiliza as recomendações locais já aprendidas pelas pesquisas e vídeos assistidos. Ele não inicia uma busca externa automática. Cada recomendação permite selecionar a fonte para Shorts, assistir e remover a sugestão. Quando não houver histórico suficiente, exibe uma orientação objetiva; após uma pesquisa, o cache existente pode oferecer sugestões futuras.

## Cartões durante a montagem

Ao iniciar uma tarefa de geração, o painel **Seus Shorts** exibe exatamente a quantidade solicitada de cartões com a animação de celular/em montagem. Quando um Short conclui, apenas o cartão correspondente é substituído pelo player real. Em falha parcial ou total, cartões pendentes são removidos e nenhum player fictício é exibido. A atualização incremental preserva players já concluídos e não os recria durante o polling.

## Duração

Os atalhos disponíveis passam a ser 30 s, 1 min, 90 s, 2 min, 10 min e 15 min. A validação de cliente e servidor aceita de 15 s a 900 s.
