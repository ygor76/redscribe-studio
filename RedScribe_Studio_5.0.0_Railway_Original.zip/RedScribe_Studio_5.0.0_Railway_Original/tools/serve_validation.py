from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import app


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5057, debug=False, use_reloader=False)
