from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path("/home/ubuntu/webdev-static-assets/redscribe_app_icon.png")
DESTINATION = ROOT / "assets" / "redscribe.ico"
PNG_DESTINATION = ROOT / "assets" / "redscribe.png"


def main() -> None:
    image = Image.open(SOURCE).convert("RGBA")
    image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (1024, 1024), (9, 9, 11, 255))
    offset = ((canvas.width - image.width) // 2, (canvas.height - image.height) // 2)
    canvas.alpha_composite(image, offset)
    canvas.save(PNG_DESTINATION, format="PNG", optimize=True)
    canvas.save(DESTINATION, format="ICO", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print(f"Ícone criado: {DESTINATION}")


if __name__ == "__main__":
    main()
