from __future__ import annotations

import json
import math
import difflib
import os
import re
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

from flask import jsonify, request, send_file

try:
    from PIL import Image, ImageColor, ImageDraw, ImageFont, ImageOps
except Exception:  # Pillow é opcional até o usuário usar os elementos visuais.
    Image = ImageColor = ImageDraw = ImageFont = ImageOps = None


ALLOWED_MEDIA = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".jpg", ".jpeg", ".png", ".webp"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
ALLOWED_OVERLAY_IMAGES = {".jpg", ".jpeg", ".png", ".webp"}
PLATFORMS = {
    "tiktok": {"name": "TikTok", "folder": "TikTok", "url": "https://www.tiktok.com/tiktokstudio"},
    "youtube": {"name": "YouTube", "folder": "YouTube", "url": "https://studio.youtube.com/"},
    "instagram": {"name": "Instagram", "folder": "Instagram", "url": "https://www.instagram.com/"},
}


def register_studio_tools(app, core) -> None:
    def user_root(user_id: str) -> Path:
        path = core.DATA_ROOT / "studio" / user_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def library_json(user_id: str) -> Path:
        return core._user_dir(user_id) / "shorts_library.json"

    def load_library(user_id: str) -> list[dict[str, Any]]:
        path = library_json(user_id)
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_library(user_id: str, rows: list[dict[str, Any]]) -> None:
        core._atomic_write_json(library_json(user_id), rows[:1200])

    def find_row(user_id: str, asset_id: str) -> dict[str, Any] | None:
        return next((x for x in load_library(user_id) if str(x.get("id") or "") == asset_id), None)

    def asset_path(user_id: str, asset_id: str) -> Path:
        return core.DATA_ROOT / "shorts_library" / user_id / f"{asset_id}.mp4"

    def draft_dir(user_id: str, asset_id: str) -> Path:
        path = user_root(user_id) / asset_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def draft_path(user_id: str, asset_id: str) -> Path:
        return draft_dir(user_id, asset_id) / "draft.json"

    def load_draft(user_id: str, asset_id: str) -> dict[str, Any]:
        path = draft_path(user_id, asset_id)
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save_draft(user_id: str, asset_id: str, data: dict[str, Any]) -> None:
        data["updated_at"] = int(time.time())
        core._atomic_write_json(draft_path(user_id, asset_id), data)

    def ffmpeg_exe() -> str:
        path = core._ffmpeg_location()
        if not path:
            raise RuntimeError("FFmpeg não foi encontrado. Execute INSTALAR_WINDOWS.bat novamente.")
        return path

    def media_duration(path: Path) -> float:
        ffmpeg = ffmpeg_exe()
        try:
            r = subprocess.run([ffmpeg, "-hide_banner", "-i", str(path)], capture_output=True, text=True, timeout=20,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            blob = (r.stderr or "") + "\n" + (r.stdout or "")
            m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", blob)
            if m:
                return int(m.group(1))*3600 + int(m.group(2))*60 + float(m.group(3))
        except Exception:
            pass
        return 0.0

    def safe_name(value: str, fallback: str = "short") -> str:
        text = re.sub(r"[^\w\-. ]+", "", str(value or ""), flags=re.UNICODE).strip().strip(".")
        text = re.sub(r"\s+", " ", text)
        return (text[:100] or fallback)

    def overlay_media_dir(user_id: str, asset_id: str) -> Path:
        path = draft_dir(user_id, asset_id) / "overlay_media"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def overlay_media_file(user_id: str, asset_id: str, media_id: str) -> Path | None:
        safe_id = re.sub(r"[^a-f0-9]", "", str(media_id or "").lower())[:32]
        if not safe_id:
            return None
        folder = overlay_media_dir(user_id, asset_id)
        for p in folder.glob(f"{safe_id}.*"):
            if p.is_file() and p.suffix.lower() in ALLOWED_OVERLAY_IMAGES:
                return p
        return None

    def studio_preset_path(user_id: str) -> Path:
        return user_root(user_id) / "last_edit_preset.json"

    def studio_preset_media_dir(user_id: str) -> Path:
        path = user_root(user_id) / "_preset_media"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def load_studio_preset(user_id: str) -> dict[str, Any]:
        path = studio_preset_path(user_id)
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save_studio_preset(user_id: str, data: dict[str, Any]) -> None:
        data = dict(data or {})
        data["updated_at"] = int(time.time())
        core._atomic_write_json(studio_preset_path(user_id), data)

    def studio_preset_has_visual(preset: dict[str, Any]) -> bool:
        if not isinstance(preset, dict): return False
        if isinstance(preset.get("overlays"), list) and preset.get("overlays"): return True
        if isinstance(preset.get("caption_style"), dict) and preset.get("caption_style"): return True
        vt = preset.get("video_transform") if isinstance(preset.get("video_transform"), dict) else {}
        return bool(vt) and (bool(vt.get("enabled")) or any(abs(float(vt.get(k, d))-d) > 1e-6 for k,d in (("x",.5),("y",.5),("w",1.0),("h",1.0))))

    def preset_media_file(user_id: str, media_id: str) -> Path | None:
        safe_id = re.sub(r"[^a-f0-9]", "", str(media_id or "").lower())[:32]
        if not safe_id:
            return None
        for src in studio_preset_media_dir(user_id).glob(f"{safe_id}.*"):
            if src.is_file() and src.suffix.lower() in ALLOWED_OVERLAY_IMAGES:
                return src
        return None

    def _copy_overlay_media_to_preset(user_id: str, asset_id: str, overlays: list[dict[str, Any]]) -> None:
        target = studio_preset_media_dir(user_id)
        # O preset representa o último visual. Limpar arquivos antigos evita acumular logos abandonados.
        try:
            for old in target.iterdir():
                if old.is_file(): old.unlink(missing_ok=True)
        except Exception:
            pass
        for raw in overlays[:40]:
            if not isinstance(raw, dict):
                continue
            for key in ("media_id", "avatar_media_id"):
                media_id = str(raw.get(key) or "")
                if not media_id:
                    continue
                src = overlay_media_file(user_id, asset_id, media_id)
                if src and src.exists():
                    try: shutil.copy2(src, target / src.name)
                    except Exception: pass

    def save_visual_preset(user_id: str, asset_id: str, payload: dict[str, Any]) -> None:
        previous = load_studio_preset(user_id)
        overlays = payload.get("overlays") if isinstance(payload.get("overlays"), list) else []
        _copy_overlay_media_to_preset(user_id, asset_id, overlays)
        preset = {
            "enabled": bool(previous.get("enabled", True)),
            "caption_style": payload.get("caption_style") if isinstance(payload.get("caption_style"), dict) else {},
            "overlays": json.loads(json.dumps(overlays, ensure_ascii=False)),
            "video_transform": payload.get("video_transform") if isinstance(payload.get("video_transform"), dict) else {"enabled": False, "x": .5, "y": .5, "w": 1.0, "h": 1.0},
            "source_asset_id": asset_id,
        }
        save_studio_preset(user_id, preset)

    def apply_visual_preset(user_id: str, asset_id: str) -> dict[str, Any]:
        preset = load_studio_preset(user_id)
        if not studio_preset_has_visual(preset) or not bool(preset.get("enabled", True)):
            return {}
        overlays = json.loads(json.dumps(preset.get("overlays") if isinstance(preset.get("overlays"), list) else [], ensure_ascii=False))
        target = overlay_media_dir(user_id, asset_id)
        for raw in overlays:
            if not isinstance(raw, dict): continue
            for key in ("media_id", "avatar_media_id"):
                mid = str(raw.get(key) or "")
                if not mid: continue
                src = preset_media_file(user_id, mid)
                if src and src.exists():
                    try: shutil.copy2(src, target / src.name)
                    except Exception: pass
        draft = {
            "caption_style": preset.get("caption_style") if isinstance(preset.get("caption_style"), dict) else {},
            "overlays": overlays,
            "video_transform": preset.get("video_transform") if isinstance(preset.get("video_transform"), dict) else {"enabled": False, "x": .5, "y": .5, "w": 1.0, "h": 1.0},
            # Cada vídeo novo precisa gerar sua própria legenda.
            "cues": [],
            "captions_enabled": False,
            "caption_source": "",
            "caption_exclusions": [],
            "preset_applied": True,
        }
        save_draft(user_id, asset_id, draft)
        return draft

    def draft_has_user_content(draft: dict[str, Any]) -> bool:
        if not isinstance(draft, dict) or not draft:
            return False
        meaningful = {"trim_start","trim_end","caption_style","cues","broll","overlays","title","caption","caption_source","caption_exclusions","video_transform","preset_applied","preset_suppressed"}
        return any(k in draft for k in meaningful)

    def clamp(value: Any, low: float, high: float, default: float) -> float:
        try:
            return max(low, min(high, float(value)))
        except Exception:
            return default

    def color_rgba(value: str, opacity: float = 1.0) -> tuple[int, int, int, int]:
        opacity = clamp(opacity, 0.0, 1.0, 1.0)
        if ImageColor is None:
            return (255, 255, 255, int(round(opacity * 255)))
        try:
            rgb = ImageColor.getrgb(str(value or "#ffffff"))
            if len(rgb) == 4:
                return (rgb[0], rgb[1], rgb[2], int(round(opacity * 255)))
            return (rgb[0], rgb[1], rgb[2], int(round(opacity * 255)))
        except Exception:
            return (255, 255, 255, int(round(opacity * 255)))

    def ass_color(value: str) -> str:
        text = str(value or "").strip()
        if text.upper().startswith("&H"):
            return text
        if ImageColor is None:
            return "&H00FFFFFF"
        try:
            r, g, b = ImageColor.getrgb(text or "#ffffff")[:3]
            return f"&H00{b:02X}{g:02X}{r:02X}"
        except Exception:
            return "&H00FFFFFF"

    def system_font(size: int, *, bold: bool = False):
        if ImageFont is None:
            return None
        size = max(10, int(size))
        windir = Path(os.environ.get("WINDIR") or r"C:\Windows")
        candidates = []
        if os.name == "nt":
            fonts = windir / "Fonts"
            if bold:
                candidates += [fonts / "trebucbd.ttf", fonts / "segoeuib.ttf", fonts / "arialbd.ttf"]
            candidates += [fonts / "trebuc.ttf", fonts / "segoeui.ttf", fonts / "arial.ttf"]
        else:
            if bold:
                candidates += [Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")]
            candidates += [Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
        for font_path in candidates:
            try:
                if font_path.exists():
                    return ImageFont.truetype(str(font_path), size=size)
            except Exception:
                pass
        try:
            return ImageFont.load_default(size=size)
        except TypeError:
            return ImageFont.load_default()

    def render_design_overlay(user_id: str, asset_id: str, overlays: list[dict[str, Any]], destination: Path) -> bool:
        if not overlays:
            return False
        if Image is None or ImageDraw is None or ImageFont is None:
            raise RuntimeError("Os elementos visuais precisam do Pillow. Feche o RedScribe e execute INICIAR_WINDOWS.bat novamente para atualizar os componentes.")
        canvas = Image.new("RGBA", (1080, 1920), (0, 0, 0, 0))
        draw = ImageDraw.Draw(canvas, "RGBA")
        drawn = 0
        for raw in overlays[:40]:
            if not isinstance(raw, dict):
                continue
            kind = str(raw.get("type") or "").lower()
            x = clamp(raw.get("x"), 0.0, 1.0, 0.5) * 1080
            y = clamp(raw.get("y"), 0.0, 1.0, 0.5) * 1920
            opacity = clamp(raw.get("opacity"), 0.0, 1.0, 1.0)
            if opacity <= 0.001:
                continue
            if kind == "bar":
                w = clamp(raw.get("w"), 0.05, 10.0, 1.0) * 1080
                h = clamp(raw.get("h"), 0.01, 10.0, 0.10) * 1920
                fill = color_rgba(str(raw.get("color") or "#000000"), opacity)
                draw.rectangle((x-w/2, y-h/2, x+w/2, y+h/2), fill=fill)
                drawn += 1
            elif kind in {"text", "text_watermark"}:
                # Preserva caracteres como @, # e acentos exatamente como digitados.
                text = str(raw.get("text") or "").strip()
                if not text:
                    continue
                default_size = 46 if kind == "text_watermark" else 64
                size = int(clamp(raw.get("size"), 18, 180, default_size))
                font = system_font(size, bold=(kind == "text"))
                fill = color_rgba(str(raw.get("color") or "#ffffff"), opacity)
                default_stroke = 0 if kind == "text_watermark" else 2
                stroke = max(0, int(round(clamp(raw.get("stroke"), 0, 10, default_stroke))))
                try:
                    draw.multiline_text((x, y), text, font=font, fill=fill, anchor="mm", align="center", spacing=max(2, size//8), stroke_width=stroke, stroke_fill=(0,0,0,int(220*opacity)))
                except TypeError:
                    bbox = draw.multiline_textbbox((0, 0), text, font=font, align="center", spacing=max(2, size//8), stroke_width=stroke)
                    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
                    draw.multiline_text((x-tw/2, y-th/2), text, font=font, fill=fill, align="center", spacing=max(2, size//8), stroke_width=stroke, stroke_fill=(0,0,0,int(220*opacity)))
                drawn += 1
            elif kind == "badge":
                name = str(raw.get("name") or "Canal").strip()[:50] or "Canal"
                initial = (str(raw.get("initial") or name[:1] or "R").strip()[:1] or "R").upper()
                scale = clamp(raw.get("scale"), 0.45, 2.5, 1.0)
                show_check = bool(raw.get("show_check", True))
                font_name = system_font(int(42*scale), bold=True)
                font_initial = system_font(int(46*scale), bold=True)
                try:
                    name_box = draw.textbbox((0,0), name, font=font_name)
                    name_w = name_box[2]-name_box[0]
                except Exception:
                    name_w = int(len(name)*24*scale)
                avatar = int(72*scale)
                check = int(34*scale) if show_check else 0
                gap = int(14*scale)
                pad_x = int(18*scale)
                pad_y = int(10*scale)
                width = avatar + gap + name_w + (gap//2 + check if show_check else 0) + pad_x*2
                height = avatar + pad_y*2
                left, top = x-width/2, y-height/2
                bg = (8, 8, 8, int(185*opacity))
                radius = int(height/2)
                draw.rounded_rectangle((left, top, left+width, top+height), radius=radius, fill=bg)
                av_left = left+pad_x; av_top = top+pad_y
                avatar_media_id = str(raw.get("avatar_media_id") or "")
                avatar_src = overlay_media_file(user_id, asset_id, avatar_media_id) if avatar_media_id else None
                avatar_drawn = False
                if avatar_src and ImageOps is not None:
                    try:
                        avatar_img = Image.open(avatar_src).convert("RGBA")
                        avatar_img = ImageOps.fit(avatar_img, (avatar, avatar), method=Image.Resampling.LANCZOS, centering=(0.5,0.5))
                        mask = Image.new("L", (avatar, avatar), 0)
                        ImageDraw.Draw(mask).ellipse((0,0,avatar-1,avatar-1), fill=int(255*opacity))
                        avatar_img.putalpha(mask)
                        canvas.paste(avatar_img, (int(av_left), int(av_top)), avatar_img)
                        avatar_drawn = True
                    except Exception:
                        avatar_drawn = False
                if not avatar_drawn:
                    draw.ellipse((av_left,av_top,av_left+avatar,av_top+avatar), fill=(255,0,51,int(255*opacity)))
                    draw.text((av_left+avatar/2,av_top+avatar/2), initial, font=font_initial, fill=(255,255,255,int(255*opacity)), anchor="mm")
                tx = av_left+avatar+gap; ty = top+height/2
                draw.text((tx,ty), name, font=font_name, fill=(255,255,255,int(255*opacity)), anchor="lm")
                if show_check:
                    cx = tx+name_w+gap//2+check/2; cy=ty
                    draw.ellipse((cx-check/2,cy-check/2,cx+check/2,cy+check/2), fill=(47,128,237,int(255*opacity)))
                    check_font = system_font(max(12,int(22*scale)), bold=True)
                    draw.text((cx,cy-1), "✓", font=check_font, fill=(255,255,255,int(255*opacity)), anchor="mm")
                drawn += 1
            elif kind == "watermark":
                media_id = str(raw.get("media_id") or "")
                src = overlay_media_file(user_id, asset_id, media_id)
                if not src:
                    continue
                try:
                    mark = Image.open(src).convert("RGBA")
                    scale = clamp(raw.get("scale"), 0.15, 3.0, 1.0)
                    target_w = int(max(40, min(900, 230*scale)))
                    ratio = target_w / float(max(1, mark.width))
                    target_h = max(2, int(round(mark.height*ratio)))
                    if target_h > 900:
                        ratio = 900 / float(target_h)
                        target_h = 900
                        target_w = max(2, int(round(target_w*ratio)))
                    mark = mark.resize((target_w,target_h), Image.Resampling.LANCZOS)
                    alpha = mark.getchannel("A").point(lambda a: int(a*opacity))
                    mark.putalpha(alpha)
                    px = int(round(x-target_w/2)); py = int(round(y-target_h/2))
                    canvas.paste(mark, (px,py), mark)
                    drawn += 1
                except Exception:
                    continue
        if not drawn:
            return False
        destination.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(destination, format="PNG", optimize=True)
        return True

    def absolute_source_start(user_id: str, row: dict[str, Any], depth: int = 0) -> float | None:
        if depth > 8:
            return None
        if row.get("source_start_absolute") is not None:
            try:
                return float(row.get("source_start_absolute"))
            except Exception:
                pass
        if not row.get("edited"):
            try:
                return float(row.get("start") or 0.0)
            except Exception:
                return 0.0
        # Edições antigas (criadas antes da v3.5.14) não gravavam o deslocamento do trim.
        # Não adivinhamos esse valor, pois isso deslocaria as legendas. Nesses casos,
        # o Studio usa o Whisper aprimorado local como fallback seguro.
        return None

    def source_job_for_row(user_id: str, row: dict[str, Any]) -> dict[str, Any] | None:
        video_id = str(row.get("video_id") or "").strip()
        source_url = str(row.get("source_url") or "").strip()
        try:
            jobs = core._user_jobs(user_id, include_trashed=True)
        except TypeError:
            jobs = core._user_jobs(user_id)
        except Exception:
            return None
        for job in jobs:
            if video_id and str(job.get("video_id") or "") == video_id:
                return job
            if source_url and str(job.get("url") or "").strip() == source_url:
                return job
        return None

    def prepare_caption_audio_variants(user_id: str, asset_id: str, src: Path) -> list[tuple[str, Path]]:
        """Cria versões do áudio otimizadas para ASR sem alterar o Short original.

        Em áudio difícil uma única filtragem pode apagar justamente a fala que queremos ouvir.
        Por isso o Studio gera variantes independentes e o reconhecedor compara os resultados.
        """
        work = draft_dir(user_id, asset_id)
        ffmpeg = ffmpeg_exe()
        variants: list[tuple[str, Path]] = []
        specs = [
            (
                "fala limpa",
                work / "caption_ultra_clean_16k.wav",
                "highpass=f=70,lowpass=f=7900,afftdn=nf=-28:tn=1,dynaudnorm=f=120:g=9:p=0.95",
            ),
            (
                "voz focada",
                work / "caption_ultra_voice_16k.wav",
                "highpass=f=110,lowpass=f=6800,afftdn=nf=-24:tn=1,acompressor=threshold=-20dB:ratio=3:attack=12:release=180:makeup=2,dynaudnorm=f=90:g=7:p=0.9",
            ),
            (
                "natural normalizada",
                work / "caption_ultra_natural_16k.wav",
                "highpass=f=55,lowpass=f=8000,dynaudnorm=f=150:g=5:p=0.9",
            ),
        ]
        for label, out, audio_filter in specs:
            try:
                cmd = [
                    ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src),
                    "-vn", "-ac", "1", "-ar", "16000", "-af", audio_filter,
                    "-c:a", "pcm_s16le", str(out),
                ]
                r = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=240,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if r.returncode == 0 and out.exists() and out.stat().st_size > 10_000:
                    variants.append((label, out))
            except Exception:
                continue
        if not variants:
            # Fallback compatível com builds de FFmpeg que não tenham algum filtro acima.
            out = work / "caption_ultra_fallback_16k.wav"
            try:
                cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src),
                       "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(out)]
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=180,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if r.returncode == 0 and out.exists() and out.stat().st_size > 10_000:
                    variants.append(("áudio original", out))
            except Exception:
                pass
        return variants or [("áudio original", src)]

    def prepare_caption_audio(user_id: str, asset_id: str, src: Path) -> Path:
        """Compatibilidade interna: devolve a primeira variante de alta inteligibilidade."""
        return prepare_caption_audio_variants(user_id, asset_id, src)[0][1]

    def captions_from_original_transcript(user_id: str, row: dict[str, Any]) -> list[dict[str, Any]]:
        source_start = absolute_source_start(user_id, row)
        if source_start is None:
            return []
        duration = float(row.get("duration") or 0) or 0.0
        if duration <= 0:
            return []
        candidate = source_job_for_row(user_id, row)
        if not candidate or not candidate.get("transcript_available"):
            return []
        try:
            segments = core._job_segments(candidate)
        except Exception:
            segments = candidate.get("segments") or []
        out=[]; clip_end=source_start+duration
        for seg in segments or []:
            try:
                ss=float(seg.get("start") or 0.0)
                dur=float(seg.get("duration") or max(0.0,float(seg.get("end") or ss)-ss))
                ee=ss+dur
            except Exception:
                continue
            if ss>=clip_end or ee<=source_start:
                continue
            text=str(seg.get("text") or "").strip()
            if not text: continue
            out.append({"id":uuid.uuid4().hex[:10],"start":round(max(0.0,ss-source_start),3),"end":round(min(duration,ee-source_start),3),"text":text})
        return out

    def media_rows(user_id: str, asset_id: str) -> list[dict[str, Any]]:
        path = draft_dir(user_id, asset_id) / "media.json"
        if not path.exists(): return []
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
            return rows if isinstance(rows, list) else []
        except Exception: return []

    def write_media_rows(user_id: str, asset_id: str, rows: list[dict[str, Any]]) -> None:
        core._atomic_write_json(draft_dir(user_id, asset_id) / "media.json", rows[:100])

    def media_file(user_id: str, asset_id: str, media_id: str) -> Path | None:
        row = next((x for x in media_rows(user_id, asset_id) if str(x.get("id") or "") == media_id), None)
        if not row: return None
        p = draft_dir(user_id, asset_id) / "media" / str(row.get("filename") or "")
        return p if p.exists() else None

    def ass_escape(text: str) -> str:
        return str(text or "").replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}").replace("\n", r"\N")

    def ass_time(sec: float) -> str:
        sec = max(0.0, float(sec))
        h = int(sec // 3600); sec -= h*3600
        m = int(sec // 60); sec -= m*60
        return f"{h}:{m:02d}:{sec:05.2f}"

    def wrap_caption_text(text: str, size: int, max_width: int = 910) -> str:
        text = str(text or "").strip()
        if not text:
            return ""
        paragraphs = text.splitlines() or [text]
        font = system_font(size, bold=True)
        measure = ImageDraw.Draw(Image.new("RGB", (8, 8))) if Image is not None and ImageDraw is not None else None
        lines: list[str] = []
        for paragraph in paragraphs:
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                trial = current + " " + word
                try:
                    if measure is not None and font is not None:
                        box = measure.textbbox((0, 0), trial, font=font)
                        fits = (box[2] - box[0]) <= max_width
                    else:
                        fits = len(trial) <= max(18, int(max_width / max(8, size * 0.54)))
                except Exception:
                    fits = len(trial) <= max(18, int(max_width / max(8, size * 0.54)))
                if fits:
                    current = trial
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
        return "\n".join(lines)

    def write_ass(path: Path, cues: list[dict[str, Any]], trim_start: float, duration: float, style: dict[str, Any]) -> bool:
        font = str(style.get("font") or "Trebuchet MS")[:80]
        size = max(24, min(110, int(style.get("size") or 58)))
        x = max(0.08, min(0.92, float(style.get("x") or 0.5)))
        y = max(0.08, min(0.92, float(style.get("y") or 0.78)))
        outline = max(0, min(8, int(style.get("outline") if style.get("outline") is not None else 2)))
        primary = ass_color(str(style.get("color") or "#ffffff"))
        lines = [
            "[Script Info]", "ScriptType: v4.00+", "PlayResX: 1080", "PlayResY: 1920", "ScaledBorderAndShadow: yes", "",
            "[V4+ Styles]",
            "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
            f"Style: Studio,{font},{size},{primary},&H000000FF,&H55000000,&H88000000,-1,0,0,0,100,100,0,0,1,{outline},0,5,30,30,30,1", "",
            "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
        ]
        added = 0
        for cue in cues:
            try:
                start = float(cue.get("start") or 0) - trim_start
                end = float(cue.get("end") or 0) - trim_start
            except Exception:
                continue
            if end <= 0 or start >= duration: continue
            start = max(0.0, start); end = min(duration, end)
            text = str(cue.get("text") or "").strip()
            if not text or end-start < 0.05: continue
            text = wrap_caption_text(text, size, 910)
            px = int(round(1080*x)); py = int(round(1920*y))
            lines.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Studio,,0,0,0,,{{\\an5\\pos({px},{py})}}{ass_escape(text)}")
            added += 1
        if not added: return False
        path.write_text("\n".join(lines)+"\n", encoding="utf-8-sig")
        return True

    def auto_captions(user_id: str, row: dict[str, Any], path: Path) -> tuple[list[dict[str, Any]], str]:
        """Legenda automática Ultra: áudio tratado + múltiplas passagens + consenso + timestamps por palavra.

        O texto final continua vindo do áudio. Legendas do YouTube/transcrições anteriores são usadas
        apenas como contexto linguístico e desempate de baixa confiança, nunca como uma camada extra.
        """
        source_start = absolute_source_start(user_id, row)
        video_id = str(row.get("video_id") or "").strip()
        duration = float(row.get("duration") or 0) or media_duration(path)
        source_job = source_job_for_row(user_id, row)

        # ------------------------------------------------------------------
        # 1. Contexto auxiliar. Não devolvemos estas legendas diretamente.
        # ------------------------------------------------------------------
        reference_cues: list[dict[str, Any]] = []
        reference_language = ""
        if video_id and source_start is not None and duration > 0:
            try:
                yt_segments, yt_lang = core.fetch_youtube_captions(video_id, "auto")
                clip_end = source_start + duration
                for seg in yt_segments or []:
                    ss = float(getattr(seg, "start", 0.0) or 0.0)
                    sd = float(getattr(seg, "duration", 0.0) or 0.0)
                    ee = ss + sd
                    if ss >= clip_end or ee <= source_start:
                        continue
                    txt = str(getattr(seg, "text", "") or "").strip()
                    if not txt or re.fullmatch(r"\[(música|music|som|aplausos|applause)[^\]]*\]", txt, flags=re.I):
                        continue
                    reference_cues.append({"start": max(0.0, ss-source_start), "end": min(duration, ee-source_start), "text": txt})
                reference_language = str(yt_lang or "")
            except Exception:
                pass
        try:
            original_reference = captions_from_original_transcript(user_id, row)
        except Exception:
            original_reference = []
        if not reference_cues and original_reference:
            reference_cues = [{"start": float(x.get("start") or 0), "end": float(x.get("end") or 0), "text": str(x.get("text") or "")} for x in original_reference]

        ref_prompt_parts: list[str] = []
        for cue in reference_cues[:80]:
            txt = re.sub(r"\s+", " ", str(cue.get("text") or "")).strip()
            if txt:
                ref_prompt_parts.append(txt)
        reference_prompt = " ".join(ref_prompt_parts)
        if len(reference_prompt) > 1200:
            reference_prompt = reference_prompt[:1200].rsplit(" ", 1)[0]

        # ------------------------------------------------------------------
        # 2. Modelo. Só o Studio usa esta seleção; transcrição/Shorts ficam intactos.
        # ------------------------------------------------------------------
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError("O Whisper não está instalado. Execute INSTALAR_WINDOWS.bat novamente.") from exc

        explicit = os.environ.get("WHISPER_STUDIO_MODEL")
        large_dir = core.BASE_DIR / "models" / "faster-whisper-large-v3"
        medium_dir = core.BASE_DIR / "models" / "faster-whisper-medium"
        small_dir = core.BASE_DIR / "models" / "faster-whisper-small"
        if explicit:
            preferred_model_name = explicit
        elif (large_dir / "model.bin").exists():
            preferred_model_name = str(large_dir)
        elif (medium_dir / "model.bin").exists():
            preferred_model_name = str(medium_dir)
        else:
            # O Studio usa Medium por padrão: bem mais robusto em português, ruído e música.
            # Na primeira utilização ele pode ser baixado pelo faster-whisper e fica em cache.
            preferred_model_name = "medium"

        device = os.environ.get("WHISPER_DEVICE", "cpu")
        compute = os.environ.get("WHISPER_COMPUTE_TYPE", "int8" if device == "cpu" else "float16")
        cache = getattr(core, "_studio_whisper_model_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            try: setattr(core, "_studio_whisper_model_cache", cache)
            except Exception: pass

        def get_model(name: str):
            key=(str(name),device,compute)
            cached=cache.get(key)
            if cached is not None:
                return cached
            loaded=WhisperModel(name,device=device,compute_type=compute)
            cache[key]=loaded
            return loaded

        model_name = preferred_model_name
        try:
            model = get_model(model_name)
        except Exception:
            # Se não houver internet/cache para o Medium, o Studio nunca deixa de funcionar:
            # cai para o Small já usado pelo RedScribe.
            fallback = str(small_dir) if (small_dir / "model.bin").exists() else os.environ.get("WHISPER_MODEL", "small")
            model_name = fallback
            model = get_model(model_name)

        preferred_lang = None
        detected = str((source_job or {}).get("detected_language") or reference_language or "").strip().lower()
        if detected and detected not in {"auto", "none", "null", "unknown"}:
            preferred_lang = detected.split("-")[0]

        # ------------------------------------------------------------------
        # 3. ASR multipass. Cada passagem escuta uma versão diferente do áudio.
        # ------------------------------------------------------------------
        audio_variants = prepare_caption_audio_variants(user_id, str(row.get("id") or "caption"), path)

        def norm_text(value: str) -> str:
            value = re.sub(r"[^\wÀ-ÿ]+", " ", str(value or "").lower(), flags=re.UNICODE)
            return re.sub(r"\s+", " ", value).strip()

        def similarity(a: str, b: str) -> float:
            aa, bb = norm_text(a), norm_text(b)
            if not aa or not bb:
                return 0.0
            return difflib.SequenceMatcher(None, aa, bb).ratio()

        def overlap_ratio(a0: float, a1: float, b0: float, b1: float) -> float:
            inter = max(0.0, min(a1, b1) - max(a0, b0))
            base = max(0.08, min(max(0.08, a1-a0), max(0.08, b1-b0)))
            return inter / base

        def run_pass(audio: Path, *, aggressive: bool, prompt: str, coverage: bool = False) -> tuple[list[dict[str, Any]], str]:
            # A terceira passagem é deliberadamente voltada para COBERTURA. Ela usa um VAD
            # mais permissivo para não perder falas baixas/cantadas que as passagens mais rígidas
            # podem ignorar. O consenso posterior continua responsável por rejeitar duplicatas e
            # trechos incoerentes, preservando a precisão que já estava boa na v3.5.15.
            if coverage:
                vad_parameters = {
                    "threshold": 0.30,
                    "min_speech_duration_ms": 70,
                    "min_silence_duration_ms": 120,
                    "speech_pad_ms": 320,
                }
            else:
                vad_parameters = {
                    "threshold": 0.48 if aggressive else 0.54,
                    "min_speech_duration_ms": 120 if aggressive else 160,
                    "min_silence_duration_ms": 180 if aggressive else 240,
                    "speech_pad_ms": 220 if aggressive else 180,
                }
            kwargs = dict(
                language=preferred_lang,
                vad_filter=not coverage,
                vad_parameters=vad_parameters,
                beam_size=12 if coverage else (10 if aggressive else 8),
                best_of=12 if coverage else (10 if aggressive else 8),
                temperature=0.0,
                condition_on_previous_text=True,
                word_timestamps=True,
                no_speech_threshold=0.72 if coverage else (0.62 if aggressive else 0.56),
                log_prob_threshold=-1.55 if coverage else (-1.25 if aggressive else -1.05),
                compression_ratio_threshold=2.60 if coverage else (2.45 if aggressive else 2.30),
            )
            if prompt:
                kwargs["initial_prompt"] = prompt
            try:
                segs, info = model.transcribe(str(audio), hallucination_silence_threshold=2.0 if coverage else 1.2, **kwargs)
            except TypeError:
                kwargs["vad_parameters"] = {"min_silence_duration_ms": 120 if coverage else 200, "speech_pad_ms": 300 if coverage else 180}
                try:
                    segs, info = model.transcribe(str(audio), **kwargs)
                except TypeError:
                    # Compatibilidade com builds mais antigos do faster-whisper.
                    kwargs.pop("initial_prompt", None)
                    segs, info = model.transcribe(str(audio), **kwargs)

            words_out: list[dict[str, Any]] = []
            for seg in segs:
                txt = str(getattr(seg, "text", "") or "").strip()
                if not txt:
                    continue
                no_speech = float(getattr(seg, "no_speech_prob", 0.0) or 0.0)
                avg_logprob = float(getattr(seg, "avg_logprob", -0.7) or -0.7)
                compression = float(getattr(seg, "compression_ratio", 1.0) or 1.0)
                if coverage:
                    # A passagem de cobertura não pode descartar justamente a fala difícil que
                    # estamos tentando recuperar. Só rejeita sinais claramente incompatíveis com fala.
                    if no_speech > 0.93 or compression > 3.10 or avg_logprob < -2.15:
                        continue
                elif no_speech > 0.78 or compression > 2.75 or avg_logprob < -1.55:
                    continue
                words = list(getattr(seg, "words", None) or [])
                if words:
                    for word in words:
                        wtxt = str(getattr(word, "word", "") or "").strip()
                        if not wtxt:
                            continue
                        ws = max(0.0, float(getattr(word, "start", getattr(seg, "start", 0.0)) or 0.0))
                        we = max(ws+0.03, float(getattr(word, "end", ws+0.15) or ws+0.15))
                        prob = getattr(word, "probability", None)
                        wp = float(prob) if prob is not None else max(0.05, min(0.98, (avg_logprob + 1.7) / 1.7))
                        # Não apaga uma palavra só porque ficou difícil; apenas reduz a confiança.
                        score = max(0.01, min(0.999, wp * (1.0 - min(0.7, no_speech) * 0.25)))
                        words_out.append({"start":ws,"end":we,"text":wtxt,"score":score,"seg_logprob":avg_logprob})
                else:
                    ss = max(0.0, float(getattr(seg, "start", 0.0) or 0.0))
                    ee = max(ss+0.08, float(getattr(seg, "end", ss+0.5) or ss+0.5))
                    score = max(0.05, min(0.90, (avg_logprob + 1.6) / 1.6))
                    words_out.append({"start":ss,"end":ee,"text":txt,"score":score,"seg_logprob":avg_logprob,"phrase":True})
            lang = str(getattr(info, "language", "") or preferred_lang or "auto")
            return words_out, lang

        def words_to_cues(words: list[dict[str, Any]]) -> list[dict[str, Any]]:
            words = sorted(words, key=lambda w: (float(w.get("start") or 0), float(w.get("end") or 0)))
            cues: list[dict[str, Any]] = []
            chunk: list[dict[str, Any]] = []

            def flush() -> None:
                nonlocal chunk
                if not chunk:
                    return
                start = max(0.0, float(chunk[0].get("start") or 0.0) - 0.085)
                end = float(chunk[-1].get("end") or start+0.1) + 0.075
                if duration > 0:
                    end = min(duration, end)
                txt = re.sub(r"\s+([,.!?;:])", r"\1", " ".join(str(x.get("text") or "").strip() for x in chunk).strip())
                txt = re.sub(r"\s+", " ", txt).strip()
                scores = [float(x.get("score") or 0.0) for x in chunk]
                conf = sum(scores)/len(scores) if scores else 0.0
                if txt and end > start + 0.06:
                    cues.append({"id":uuid.uuid4().hex[:10],"start":round(start,3),"end":round(end,3),"text":txt,"_confidence":conf})
                chunk = []

            for word in words:
                if word.get("phrase"):
                    flush()
                    start=max(0.0,float(word.get("start") or 0)-0.08); end=float(word.get("end") or start+0.3)+0.08
                    cues.append({"id":uuid.uuid4().hex[:10],"start":round(start,3),"end":round(min(duration,end) if duration>0 else end,3),"text":str(word.get("text") or "").strip(),"_confidence":float(word.get("score") or 0)})
                    continue
                if chunk:
                    gap = float(word.get("start") or 0) - float(chunk[-1].get("end") or 0)
                    if gap > 0.52:
                        flush()
                chunk.append(word)
                cstart=float(chunk[0].get("start") or 0); cend=float(chunk[-1].get("end") or cstart)
                txt_len=len(" ".join(str(x.get("text") or "") for x in chunk))
                punct=bool(re.search(r"[.!?…,:;]$", str(word.get("text") or "")))
                if (punct and len(chunk)>=2) or len(chunk)>=7 or (cend-cstart)>=2.65 or txt_len>=48:
                    flush()
            flush()

            # Evita uma legenda começar tarde só porque a anterior terminou perto dela.
            for i, cue in enumerate(cues):
                if i and float(cue["start"]) < float(cues[i-1]["end"]) - 0.02:
                    midpoint=(float(cue["start"])+float(cues[i-1]["end"]))/2
                    cues[i-1]["end"]=round(max(float(cues[i-1]["start"])+0.06, midpoint),3)
                    cue["start"]=round(max(0.0, midpoint),3)
            return cues

        passes: list[tuple[str, list[dict[str, Any]], str]] = []
        # Três leituras complementares do MESMO vídeo:
        # 1) precisão principal; 2) voz focada; 3) cobertura total, mais permissiva.
        # A terceira não substitui as duas primeiras: ela serve principalmente para preencher
        # buracos temporais em que existia fala, mas o VAD mais rígido deixou passar.
        for idx, (label, audio) in enumerate(audio_variants[:3]):
            try:
                words, lang = run_pass(
                    audio,
                    aggressive=bool(idx),
                    prompt=reference_prompt,
                    coverage=bool(idx >= 2),
                )
                cues = words_to_cues(words)
                if cues:
                    passes.append((label, cues, lang))
            except Exception:
                continue
        # Em instalações em que só duas variantes de áudio foram criadas, fazemos uma terceira
        # leitura de cobertura na variante mais natural disponível, sem exigir outro arquivo.
        if len(passes) >= 1 and len(passes) < 3:
            try:
                label, audio = audio_variants[-1]
                words, lang = run_pass(audio, aggressive=True, prompt=reference_prompt, coverage=True)
                cues = words_to_cues(words)
                if cues:
                    passes.append((f"{label} · cobertura", cues, lang))
            except Exception:
                pass
        if not passes:
            raise RuntimeError("Não consegui reconhecer fala suficiente nesse trecho. Verifique se o vídeo possui áudio audível.")

        # ------------------------------------------------------------------
        # 4. Consenso temporal: escolhe, fala a fala, a passagem mais confiável.
        # ------------------------------------------------------------------
        primary = list(passes[0][1])
        secondary = list(passes[1][1]) if len(passes) > 1 else []
        used_secondary: set[int] = set()
        merged: list[dict[str, Any]] = []

        def matching_reference(cue: dict[str, Any]) -> dict[str, Any] | None:
            best = None; best_ov = 0.0
            a0=float(cue.get("start") or 0); a1=float(cue.get("end") or a0)
            for ref in reference_cues:
                ov=overlap_ratio(a0,a1,float(ref.get("start") or 0),float(ref.get("end") or 0))
                if ov > best_ov:
                    best_ov=ov; best=ref
            return best if best_ov >= 0.28 else None

        for cue in primary:
            a0=float(cue.get("start") or 0); a1=float(cue.get("end") or a0)
            best_idx=-1; best_ov=0.0
            for i, alt in enumerate(secondary):
                if i in used_secondary: continue
                ov=overlap_ratio(a0,a1,float(alt.get("start") or 0),float(alt.get("end") or 0))
                if ov > best_ov:
                    best_ov=ov; best_idx=i
            chosen=dict(cue)
            if best_idx >= 0 and best_ov >= 0.35:
                alt=dict(secondary[best_idx]); used_secondary.add(best_idx)
                pc=float(cue.get("_confidence") or 0); ac=float(alt.get("_confidence") or 0)
                ref=matching_reference(cue)
                # Se os dois reconhecimentos divergem, o contexto auxilia no desempate sem inventar timing.
                if ref:
                    p_sim=similarity(str(cue.get("text") or ""),str(ref.get("text") or ""))
                    a_sim=similarity(str(alt.get("text") or ""),str(ref.get("text") or ""))
                else:
                    p_sim=a_sim=0.0
                if ac > pc + 0.045 or (ac >= pc - 0.05 and a_sim > p_sim + 0.16):
                    chosen=alt
                # Em confiança realmente baixa, uma referência temporalmente compatível pode corrigir
                # nomes/palavras difíceis. Mantemos os tempos detectados no áudio.
                conf=float(chosen.get("_confidence") or 0)
                if ref and conf < 0.48:
                    rtxt=str(ref.get("text") or "").strip()
                    if rtxt and max(similarity(str(cue.get("text") or ""),rtxt), similarity(str(alt.get("text") or ""),rtxt)) >= 0.38:
                        chosen["text"]=rtxt
                        chosen["_confidence"]=max(conf,0.50)
            else:
                ref=matching_reference(cue)
                if ref and float(chosen.get("_confidence") or 0) < 0.42:
                    rtxt=str(ref.get("text") or "").strip()
                    if rtxt and similarity(str(chosen.get("text") or ""),rtxt) >= 0.42:
                        chosen["text"]=rtxt
            merged.append(chosen)

        for i, alt in enumerate(secondary):
            if i in used_secondary: continue
            # Cobertura sem sacrificar a precisão: uma fala exclusiva da segunda passagem pode
            # preencher um buraco mesmo com confiança moderada. Se houver referência temporal,
            # o limiar cai um pouco mais porque sabemos que naquele ponto realmente havia fala.
            overlap=max((overlap_ratio(float(alt.get("start") or 0),float(alt.get("end") or 0),float(x.get("start") or 0),float(x.get("end") or 0)) for x in merged), default=0.0)
            if overlap < 0.24:
                ref=matching_reference(alt)
                conf=float(alt.get("_confidence") or 0)
                ref_ok=bool(ref and similarity(str(alt.get("text") or ""),str(ref.get("text") or "")) >= 0.30)
                if conf >= 0.42 or ref_ok:
                    merged.append(dict(alt))

        # Passagens extras (principalmente a de cobertura) só entram onde ainda existe um buraco.
        # Isso evita reescrever trechos que já estavam corretos e recupera falas baixas/cantadas.
        for _label, extra_cues, _lang in passes[2:]:
            for alt in extra_cues:
                a0=float(alt.get("start") or 0); a1=float(alt.get("end") or a0)
                overlap=max((overlap_ratio(a0,a1,float(x.get("start") or 0),float(x.get("end") or 0)) for x in merged), default=0.0)
                if overlap >= 0.20:
                    continue
                conf=float(alt.get("_confidence") or 0)
                ref=matching_reference(alt)
                ref_ok=bool(ref and similarity(str(alt.get("text") or ""),str(ref.get("text") or "")) >= 0.26)
                # A passagem de cobertura existe justamente para resgatar voz difícil. Mantemos
                # um limiar moderado, mas nunca inserimos texto vazio ou um trecho sobreposto.
                if conf >= 0.30 or ref_ok:
                    merged.append(dict(alt))

        # Última rede de segurança: quando o YouTube/transcrição de origem possui uma fala em um
        # intervalo completamente vazio, usamos essa fala SOMENTE para preencher o buraco. Assim
        # o Studio não deixa uma cantora/pessoa falando sem legenda no meio do vídeo inteiro.
        for ref in reference_cues:
            rtxt=re.sub(r"\s+"," ",str(ref.get("text") or "")).strip()
            r0=max(0.0,float(ref.get("start") or 0)); r1=float(ref.get("end") or r0)
            if duration > 0: r1=min(duration,r1)
            if not rtxt or r1 <= r0+0.08:
                continue
            overlap=max((overlap_ratio(r0,r1,float(x.get("start") or 0),float(x.get("end") or 0)) for x in merged), default=0.0)
            if overlap < 0.10:
                merged.append({"id":uuid.uuid4().hex[:10],"start":round(r0,3),"end":round(r1,3),"text":rtxt,"_confidence":0.50,"_coverage_reference":True})

        # ------------------------------------------------------------------
        # 5. Limpeza final e sincronização. Não deixa metadados internos no draft.
        # ------------------------------------------------------------------
        clean: list[dict[str, Any]] = []
        previous_norm = ""
        for cue in sorted(merged, key=lambda x: float(x.get("start") or 0)):
            txt=re.sub(r"\s+"," ",str(cue.get("text") or "")).strip()
            a=max(0.0,float(cue.get("start") or 0)); b=float(cue.get("end") or a)
            if duration > 0: b=min(duration,b)
            if not txt or b <= a+0.05:
                continue
            n=norm_text(txt)
            if n and n==previous_norm and clean and a <= float(clean[-1].get("end") or 0)+0.30:
                clean[-1]["end"]=round(max(float(clean[-1].get("end") or 0),b),3)
                continue
            previous_norm=n
            clean.append({"id":uuid.uuid4().hex[:10],"start":round(a,3),"end":round(b,3),"text":txt})

        if not clean:
            raise RuntimeError("O áudio foi analisado, mas não encontrei fala confiável suficiente para legendar.")
        lang=passes[0][2] if passes else (preferred_lang or "auto")
        model_label="Large-v3" if "large" in str(model_name).lower() else ("Medium" if "medium" in str(model_name).lower() else "Small")
        source=f"Análise Ultra Completa · {model_label} · {len(passes)} passagens · cobertura integral · {lang}"
        return clean, source

    @app.get("/api/studio/session/<asset_id>")
    @core.login_required
    def studio_session(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        src = asset_path(user["id"], asset_id)
        if not row or not src.exists(): return jsonify({"error": "Short não encontrado na Biblioteca."}), 404
        draft = load_draft(user["id"], asset_id)
        applied_now = False
        if not draft_has_user_content(draft) and request.args.get("skip_preset") != "1":
            auto_draft = apply_visual_preset(user["id"], asset_id)
            if auto_draft:
                draft = auto_draft
                applied_now = True
        duration = float(row.get("duration") or 0) or media_duration(src)
        preset = load_studio_preset(user["id"])
        return jsonify({
            "item": {**row, "url": f"/shorts/library/media/{asset_id}", "duration": duration},
            "draft": draft,
            "media": media_rows(user["id"], asset_id),
            "preset": {"exists": studio_preset_has_visual(preset), "enabled": bool(preset.get("enabled", True)) if preset else True, "applied": applied_now or bool(draft.get("preset_applied"))},
        })

    @app.patch("/api/studio/session/<asset_id>")
    @core.login_required
    def studio_save_draft(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        payload = request.get_json(silent=True) or {}
        allowed = {"trim_start", "trim_end", "captions_enabled", "caption_style", "cues", "broll", "overlays", "title", "caption", "caption_source", "caption_exclusions", "video_transform"}
        current = load_draft(user["id"], asset_id)
        for key in allowed:
            if key in payload: current[key] = payload[key]
        save_draft(user["id"], asset_id, current)
        # O rascunho é salvo automaticamente; o padrão visual acompanha a última edição
        # sem exigir que o usuário renderize antes de abrir outro Short.
        try: save_visual_preset(user["id"], asset_id, current)
        except Exception: pass
        return jsonify({"ok": True, "draft": current})

    @app.delete("/api/studio/session/<asset_id>")
    @core.login_required
    def studio_reset_session(asset_id: str):
        user = core.current_user()
        row = find_row(user["id"], asset_id)
        if not row:
            return jsonify({"error": "Short não encontrado."}), 404
        path = user_root(user["id"]) / asset_id
        shutil.rmtree(path, ignore_errors=True)
        # Cancelar edição deve realmente abrir este Short limpo na próxima vez.
        # O usuário ainda pode reaplicar manualmente o padrão pelo botão do Estúdio.
        save_draft(user["id"], asset_id, {"preset_suppressed": True})
        return jsonify({"ok": True})

    @app.get("/api/studio/preset")
    @core.login_required
    def studio_get_preset():
        user = core.current_user(); preset = load_studio_preset(user["id"])
        return jsonify({"exists": studio_preset_has_visual(preset), "enabled": bool(preset.get("enabled", True)) if preset else True, "updated_at": preset.get("updated_at") if preset else None})

    @app.patch("/api/studio/preset")
    @core.login_required
    def studio_update_preset():
        user = core.current_user(); payload = request.get_json(silent=True) or {}; preset = load_studio_preset(user["id"])
        preset["enabled"] = bool(payload.get("enabled", True))
        save_studio_preset(user["id"], preset)
        return jsonify({"ok": True, "exists": studio_preset_has_visual(preset), "enabled": bool(preset.get("enabled", True))})

    @app.post("/api/studio/preset/apply/<asset_id>")
    @core.login_required
    def studio_apply_preset(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        preset = load_studio_preset(user["id"])
        if not studio_preset_has_visual(preset): return jsonify({"error": "Ainda não existe um padrão salvo. Renderize uma edição primeiro."}), 404
        # Aplicação manual respeita o padrão mesmo se o automático estiver desligado.
        was_enabled = bool(preset.get("enabled", True)); preset["enabled"] = True; save_studio_preset(user["id"], preset)
        try: draft = apply_visual_preset(user["id"], asset_id)
        finally:
            preset = load_studio_preset(user["id"]); preset["enabled"] = was_enabled; save_studio_preset(user["id"], preset)
        return jsonify({"ok": True, "draft": draft})

    @app.post("/api/studio/captions/<asset_id>")
    @core.login_required
    def studio_captions(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id); src = asset_path(user["id"], asset_id)
        if not row or not src.exists(): return jsonify({"error": "Short não encontrado."}), 404
        try: cues, caption_source = auto_captions(user["id"], row, src)
        except Exception as exc: return jsonify({"error": str(exc)}), 500
        draft = load_draft(user["id"], asset_id); draft["cues"] = cues; draft["captions_enabled"] = True; draft["caption_source"] = caption_source; save_draft(user["id"], asset_id, draft)
        return jsonify({"cues": cues, "source": caption_source})

    @app.post("/api/studio/media/<asset_id>")
    @core.login_required
    def studio_upload_media(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        files = request.files.getlist("media")
        if not files: return jsonify({"error": "Escolha pelo menos uma foto ou vídeo."}), 400
        folder = draft_dir(user["id"], asset_id) / "media"; folder.mkdir(parents=True, exist_ok=True)
        rows = media_rows(user["id"], asset_id); added = []
        for upload in files[:20]:
            ext = Path(upload.filename or "").suffix.lower()
            if ext not in ALLOWED_MEDIA: continue
            mid = uuid.uuid4().hex[:12]; filename = f"{mid}{ext}"; dest = folder / filename; upload.save(dest)
            item = {"id": mid, "name": safe_name(Path(upload.filename or filename).stem, "Mídia"), "filename": filename, "type": "image" if ext in IMAGE_EXTS else "video", "duration": 3.0 if ext in IMAGE_EXTS else max(1.0, min(60.0, media_duration(dest) or 4.0)), "transition": "fade"}
            rows.append(item); added.append(item)
        write_media_rows(user["id"], asset_id, rows)
        return jsonify({"items": added, "all": rows})

    @app.delete("/api/studio/media/<asset_id>/<media_id>")
    @core.login_required
    def studio_delete_media(asset_id: str, media_id: str):
        user = core.current_user(); rows = media_rows(user["id"], asset_id)
        target = next((x for x in rows if str(x.get("id") or "") == media_id), None)
        if target:
            try: (draft_dir(user["id"], asset_id) / "media" / str(target.get("filename") or "")).unlink(missing_ok=True)
            except Exception: pass
        rows = [x for x in rows if str(x.get("id") or "") != media_id]; write_media_rows(user["id"], asset_id, rows)
        return jsonify({"ok": True, "items": rows})

    @app.get("/studio/media/<asset_id>/<media_id>")
    @core.login_required
    def studio_media(asset_id: str, media_id: str):
        user = core.current_user(); p = media_file(user["id"], asset_id, media_id)
        if not p: return jsonify({"error": "Mídia não encontrada."}), 404
        return send_file(p, conditional=True)

    @app.post("/api/studio/overlay/<asset_id>")
    @core.login_required
    def studio_upload_overlay(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        upload = request.files.get("watermark")
        if not upload or not upload.filename:
            return jsonify({"error": "Escolha uma imagem para a marca d’água."}), 400
        ext = Path(upload.filename).suffix.lower()
        if ext not in ALLOWED_OVERLAY_IMAGES:
            return jsonify({"error": "Use PNG, JPG ou WEBP para a marca d’água."}), 400
        media_id = uuid.uuid4().hex[:16]
        dest = overlay_media_dir(user["id"], asset_id) / f"{media_id}{ext}"
        upload.save(dest)
        return jsonify({
            "ok": True,
            "element": {"id": uuid.uuid4().hex[:12], "type": "watermark", "media_id": media_id, "x": 0.82, "y": 0.12, "scale": 1.0, "opacity": 0.55},
            "url": f"/studio/overlay/{asset_id}/{media_id}",
        })

    @app.post("/api/studio/badge-photo/<asset_id>")
    @core.login_required
    def studio_upload_badge_photo(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        upload = request.files.get("avatar")
        if not upload or not upload.filename:
            return jsonify({"error": "Escolha uma foto para o selo do canal."}), 400
        ext = Path(upload.filename).suffix.lower()
        if ext not in ALLOWED_OVERLAY_IMAGES:
            return jsonify({"error": "Use PNG, JPG ou WEBP para a foto."}), 400
        media_id = uuid.uuid4().hex[:16]
        dest = overlay_media_dir(user["id"], asset_id) / f"{media_id}{ext}"
        upload.save(dest)
        return jsonify({"ok": True, "media_id": media_id, "url": f"/studio/overlay/{asset_id}/{media_id}"})

    @app.get("/studio/overlay/<asset_id>/<media_id>")
    @core.login_required
    def studio_overlay_media(asset_id: str, media_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        path = overlay_media_file(user["id"], asset_id, media_id)
        if not path: return jsonify({"error": "Imagem não encontrada."}), 404
        return send_file(path, conditional=True)

    @app.delete("/api/studio/overlay/<asset_id>/<media_id>")
    @core.login_required
    def studio_delete_overlay_media(asset_id: str, media_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id)
        if not row: return jsonify({"error": "Short não encontrado."}), 404
        path = overlay_media_file(user["id"], asset_id, media_id)
        if path:
            try: path.unlink(missing_ok=True)
            except Exception: pass
        return jsonify({"ok": True})

    @app.post("/api/studio/render/<asset_id>")
    @core.login_required
    def studio_render(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id); src = asset_path(user["id"], asset_id)
        if not row or not src.exists(): return jsonify({"error": "Short não encontrado."}), 404
        payload = request.get_json(silent=True) or {}
        src_duration = float(row.get("duration") or 0) or media_duration(src) or 1.0
        trim_start = max(0.0, min(src_duration-0.2, float(payload.get("trim_start") or 0)))
        trim_end = float(payload.get("trim_end") or src_duration)
        trim_end = max(trim_start+0.2, min(src_duration, trim_end)); duration = trim_end-trim_start
        captions_enabled = bool(payload.get("captions_enabled")); cues = payload.get("cues") if isinstance(payload.get("cues"), list) else []
        style = payload.get("caption_style") if isinstance(payload.get("caption_style"), dict) else {}
        broll_cfg = payload.get("broll") if isinstance(payload.get("broll"), list) else []
        overlays = payload.get("overlays") if isinstance(payload.get("overlays"), list) else []
        video_transform = payload.get("video_transform") if isinstance(payload.get("video_transform"), dict) else {}
        ffmpeg = ffmpeg_exe(); work = draft_dir(user["id"], asset_id); out = work / f"render_{int(time.time())}.mp4"; ass = work / "studio_render.ass"
        use_ass = captions_enabled and write_ass(ass, cues, trim_start, duration, style)
        design_png = work / "studio_design_overlay.png"
        try:
            use_design = render_design_overlay(user["id"], asset_id, overlays, design_png)
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500

        cmd: list[str] = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{trim_start:.3f}", "-i", str(src)]
        media_lookup = {str(x.get("id") or ""): x for x in media_rows(user["id"], asset_id)}
        broll: list[dict[str, Any]] = []
        for cfg in broll_cfg[:20]:
            mid = str(cfg.get("id") or ""); meta = media_lookup.get(mid); path = media_file(user["id"], asset_id, mid)
            if not meta or not path: continue
            dur = max(0.5, min(120.0, float(cfg.get("duration") or meta.get("duration") or 3.0)))
            transition = str(cfg.get("transition") or meta.get("transition") or "fade")
            if transition not in {"cut", "fade"}: transition = "fade"
            broll.append({"id": mid, "path": path, "type": meta.get("type"), "duration": dur, "transition": transition})
        if broll:
            # Garanta que a sequência visual cubra toda a duração editada.
            overlap = 0.45
            effective = sum(x["duration"] for x in broll) - overlap*max(0, len(broll)-1)
            if effective < duration: broll[-1]["duration"] += duration-effective+0.05
            for item in broll:
                if item["type"] == "image": cmd += ["-loop", "1", "-framerate", "30", "-t", f"{item['duration']+1:.3f}", "-i", str(item["path"])]
                else: cmd += ["-stream_loop", "-1", "-i", str(item["path"])]

        design_input_index = None
        if use_design:
            design_input_index = 1 + len(broll)
            cmd += ["-loop", "1", "-framerate", "30", "-t", f"{duration:.3f}", "-i", str(design_png)]

        filters: list[str] = []
        if broll:
            labels = []
            for i, item in enumerate(broll, start=1):
                label = f"br{i}"; labels.append(label)
                d = float(item["duration"])
                chain = f"[{i}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30,trim=duration={d:.3f},setpts=PTS-STARTPTS"
                # Transição robusta: fade curto na saída/entrada. Evita depender do xfade,
                # que varia bastante entre builds do FFmpeg no Windows.
                if str(item.get("transition") or "fade") == "fade":
                    fade_d = min(0.28, max(0.08, d * 0.08))
                    if i > 1:
                        chain += f",fade=t=in:st=0:d={fade_d:.3f}"
                    if i < len(broll):
                        chain += f",fade=t=out:st={max(0.0, d-fade_d):.3f}:d={fade_d:.3f}"
                filters.append(chain + f"[{label}]")
            if len(labels) == 1:
                filters.append(f"[{labels[0]}]trim=duration={duration:.3f},setpts=PTS-STARTPTS[vraw]")
            else:
                filters.append("".join(f"[{x}]" for x in labels) + f"concat=n={len(labels)}:v=1:a=0,trim=duration={duration:.3f},setpts=PTS-STARTPTS[vraw]")
        else:
            # O Short já é 9:16; normalize a resolução sem reabrir/cortar o enquadramento aprovado.
            filters.append(f"[0:v]trim=duration={duration:.3f},setpts=PTS-STARTPTS,scale=1080:1920,setsar=1[vraw]")

        # Desenquadrar vídeo é opcional. Desligado = cadeia visual idêntica às versões anteriores.
        if bool(video_transform.get("enabled")):
            vx = clamp(video_transform.get("x"), -1.5, 2.5, .5)
            vy = clamp(video_transform.get("y"), -1.5, 2.5, .5)
            vw = clamp(video_transform.get("w"), .05, 4.0, 1.0)
            vh = clamp(video_transform.get("h"), .05, 4.0, 1.0)
            px_w = max(2, int(round(1080*vw/2))*2); px_h = max(2, int(round(1920*vh/2))*2)
            px_x = int(round(vx*1080 - px_w/2)); px_y = int(round(vy*1920 - px_h/2))
            filters.append(f"color=c=black:s=1080x1920:r=30:d={duration:.3f}[vcanvas]")
            filters.append(f"[vraw]scale={px_w}:{px_h},setsar=1[vscaled]")
            filters.append(f"[vcanvas][vscaled]overlay=x={px_x}:y={px_y}:shortest=1[vbase]")
        else:
            filters.append("[vraw]null[vbase]")
        if use_ass:
            ass_escaped = ass.name.replace("'", r"\'")
            filters.append(f"[vbase]ass='{ass_escaped}'[vcaption]")
        else:
            filters.append("[vbase]null[vcaption]")
        if use_design and design_input_index is not None:
            filters.append(f"[vcaption][{design_input_index}:v]overlay=0:0:format=auto:shortest=1[vout]")
        else:
            filters.append("[vcaption]null[vout]")

        cmd += ["-filter_complex", ";".join(filters), "-map", "[vout]", "-map", "0:a?", "-t", f"{duration:.3f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "19", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", str(out)]
        try:
            r = subprocess.run(cmd, cwd=str(work), capture_output=True, text=True, timeout=1800, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as exc:
            return jsonify({"error": f"Falha ao renderizar: {exc}"}), 500
        if r.returncode != 0 or not out.exists() or out.stat().st_size < 10000:
            detail = (r.stderr or r.stdout or "FFmpeg não gerou o vídeo.")[-1500:]
            return jsonify({"error": f"Não foi possível concluir a edição. {detail}"}), 500

        new_id = uuid.uuid4().hex
        dest = asset_path(user["id"], new_id); dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(out, dest)
        now = int(time.time())
        new_row = dict(row)
        parent_abs = absolute_source_start(user["id"], row)
        new_row.update({
            "id": new_id, "task_id": str(row.get("task_id") or "") + "-edit", "index": int(row.get("index") or 1),
            "short_title": f"{str(row.get('short_title') or row.get('title') or 'Short')} · Editado",
            "created_at": now, "updated_at": now, "duration": round(duration, 3), "start": 0.0, "end": round(duration, 3),
            "size_bytes": dest.stat().st_size, "saved_path": None, "saved_at": None, "parent_asset_id": asset_id,
            "source_start_absolute": round(parent_abs + trim_start, 3) if parent_abs is not None else None,
            "edited": True, "captions_applied": bool(use_ass) or bool(row.get("captions_applied")), "studio_broll": bool(broll), "studio_overlays": bool(overlays),
        })
        rows = load_library(user["id"]); rows = [new_row] + rows; save_library(user["id"], rows)
        draft = load_draft(user["id"], asset_id); draft.update(payload); draft["last_render_asset_id"] = new_id; save_draft(user["id"], asset_id, draft)
        # O último vídeo renderizado vira o padrão visual do usuário para o próximo Short.
        # Não copiamos as falas: cada vídeo novo gera suas próprias legendas.
        try: save_visual_preset(user["id"], asset_id, payload)
        except Exception: pass
        # A nova versão recebe uma cópia do rascunho para que, se o usuário escolher
        # “Manter os dois”, consiga continuar editando sem perder legendas/elementos.
        try:
            src_draft = user_root(user["id"]) / asset_id
            dst_draft = user_root(user["id"]) / new_id
            if src_draft.exists():
                shutil.copytree(src_draft, dst_draft, dirs_exist_ok=True)
            cloned = dict(draft); cloned["last_render_asset_id"] = new_id; save_draft(user["id"], new_id, cloned)
        except Exception:
            pass
        return jsonify({"ok": True, "item": {**new_row, "url": f"/shorts/library/media/{new_id}"}, "asset_id": new_id})

    @app.post("/api/studio/replace/<original_id>/<rendered_id>")
    @core.login_required
    def studio_replace_rendered(original_id: str, rendered_id: str):
        user = core.current_user()
        original = find_row(user["id"], original_id)
        rendered = find_row(user["id"], rendered_id)
        src = asset_path(user["id"], rendered_id)
        dest = asset_path(user["id"], original_id)
        if not original or not rendered or not src.exists():
            return jsonify({"error": "Não foi possível localizar as versões para substituir."}), 404
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(".replace.tmp.mp4")
            shutil.copy2(src, tmp)
            os.replace(tmp, dest)
            keep_title = str(original.get("short_title") or original.get("title") or "Short")
            merged = dict(original)
            for key in ("duration","size_bytes","captions_applied","studio_broll","studio_overlays","source_start_absolute","edited"):
                if key in rendered:
                    merged[key] = rendered.get(key)
            merged["short_title"] = keep_title
            merged["updated_at"] = int(time.time())
            merged["saved_path"] = None
            merged["saved_at"] = None
            rows = []
            for row in load_library(user["id"]):
                rid = str(row.get("id") or "")
                if rid == rendered_id:
                    continue
                rows.append(merged if rid == original_id else row)
            save_library(user["id"], rows)
            src.unlink(missing_ok=True)
            shutil.rmtree(user_root(user["id"]) / rendered_id, ignore_errors=True)
            # Mantém o rascunho aplicado associado ao Short original.
            rendered_draft = load_draft(user["id"], original_id)
            rendered_draft["last_render_asset_id"] = original_id
            save_draft(user["id"], original_id, rendered_draft)
            return jsonify({"ok": True, "asset_id": original_id, "item": {**merged, "url": f"/shorts/library/media/{original_id}"}})
        except Exception as exc:
            return jsonify({"error": f"Não foi possível substituir o Short atual. {exc}"}), 500

    @app.post("/api/publish/prepare/<asset_id>")
    @core.login_required
    def publish_prepare(asset_id: str):
        user = core.current_user(); row = find_row(user["id"], asset_id); src = asset_path(user["id"], asset_id)
        if not row or not src.exists(): return jsonify({"error": "Short não encontrado."}), 404
        payload = request.get_json(silent=True) or {}; platform = str(payload.get("platform") or "").lower()
        info = PLATFORMS.get(platform)
        if not info: return jsonify({"error": "Plataforma inválida."}), 400
        root = core._storage_root(user["id"]) / "Publicar" / info["folder"]; root.mkdir(parents=True, exist_ok=True)
        base = safe_name(str(payload.get("title") or row.get("short_title") or row.get("title") or "Short"), "Short")
        dest = core._unique_destination(root, base + ".mp4"); shutil.copy2(src, dest)
        caption = str(payload.get("caption") or "").strip(); meta = dest.with_suffix(".txt")
        meta.write_text(f"Título: {base}\n\nLegenda/descrição:\n{caption}\n", encoding="utf-8")
        return jsonify({"ok": True, "platform": platform, "platform_name": info["name"], "upload_url": info["url"], "filename": dest.name, "path": str(dest), "folder": str(root)})

    @app.post("/api/publish/open-folder")
    @core.login_required
    def publish_open_folder():
        user = core.current_user(); payload = request.get_json(silent=True) or {}; platform = str(payload.get("platform") or "").lower(); info = PLATFORMS.get(platform)
        if not info: return jsonify({"error": "Plataforma inválida."}), 400
        folder = core._storage_root(user["id"]) / "Publicar" / info["folder"]; folder.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt": subprocess.Popen(["explorer.exe", str(folder)], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            else: subprocess.Popen(["xdg-open", str(folder)])
        except Exception as exc: return jsonify({"error": str(exc)}), 500
        return jsonify({"ok": True})
