# RedScribe v3.5.9 — Preenchimento Total reforçado

- Corrigidos vídeos do YouTube que já possuem barras pretas gravadas dentro do próprio quadro.
- O modo **Preenchimento total · 9:16 sem faixas pretas** agora detecta letterbox/pillarbox no trecho e remove essas bordas antes de aplicar o 9:16.
- A detecção usa múltiplos pontos do Short e escolhe o crop mais conservador para evitar cortar cenas escuras por engano.
- Funciona também com **Enquadramento Inteligente · seguir pessoa** e com **Composição Inteligente**.
- Vídeos normais, sem barras embutidas, continuam usando o preenchimento aprovado na v3.4.7.
