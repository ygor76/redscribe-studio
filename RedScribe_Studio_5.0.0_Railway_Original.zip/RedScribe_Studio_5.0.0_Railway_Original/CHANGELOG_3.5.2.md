# RedScribe v3.5.9

## Inteligência reforçada para vídeos com bordas pretas embutidas

- O modo **Preenchimento total · 9:16 sem faixas pretas** agora analisa diretamente os pixels do vídeo para detectar barras pretas gravadas no próprio arquivo.
- Se encontrar bordas estáveis em cima/baixo (ou nos lados), remove essas áreas antes do preenchimento 9:16.
- Se o vídeo **não** tiver bordas reais, não aplica recorte extra.
- A detecção híbrida usa **OpenCV + FFmpeg cropdetect**, reduzindo falsos positivos em cenas escuras.
