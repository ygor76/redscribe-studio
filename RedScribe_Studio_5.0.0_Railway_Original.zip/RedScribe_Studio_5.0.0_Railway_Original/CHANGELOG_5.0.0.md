# RedScribe Studio 5.0.0

## Identidade e experiência

A interface recebeu uma camada visual monocromática em preto, grafite e branco. A landing foi redesenhada para concentrar a primeira ação na criação de Shorts, enquanto as telas de conta e dashboard foram alinhadas ao mesmo sistema visual. A navegação foi organizada em **Criar**, **Produzir**, **Organizar** e **Sistema**.

## Shorts Studio

A busca de fontes preserva o modelo de trabalho do aplicativo anterior: consulta, cartões de resultado, miniatura, canal, duração, visualizações e seleção de vídeo. A geração mantém feedback por etapas, barra de progresso e uma área de resultados com player de vídeo para revisar os Shorts antes do download.

## Contas e acesso

Contas, sessão persistente e dados por usuário foram mantidos. A versão 5.0.0 inclui metadados técnicos de acesso e plano para uma etapa comercial futura, porém todas as contas continuam com acesso integral e sem quota nesta edição.

## Instalador Windows

O empacotamento passou a usar a identidade **RedScribe Studio 5.0.0**, com ícone novo multi-resolução para o executável e o instalador. O pipeline combina PyInstaller e Inno Setup, inclui interface, templates, ferramentas de mídia e dependências necessárias no pacote final. Componentes obsoletos não relacionados ao RedScribe Studio foram removidos do instalador.

## Qualidade

Foram adicionados testes de regressão para landing, saúde, cadastro, login, sessão, acesso integral e contrato de resposta da busca do YouTube. Os módulos principais também foram verificados por compilação de sintaxe Python.

## Evolução final de produção

O Shorts Studio passou a oferecer os formatos **9:16, 4:5, 1:1 e 16:9**, com prévia proporcional, enquadramento seguro para evitar zoom agressivo, preservação de preenchimento padrão e renderização em 4K somente quando a fonte suportar a resolução. A montagem sem fala agora usa a duração real da mídia como fallback, permitindo trabalhar com vídeos instrumentais, imagens e faixas de áudio.

Mídias concluídas na Biblioteca podem ser selecionadas diretamente como fonte de Shorts. Imagens são convertidas em vídeo silencioso e áudios instrumentais recebem um visual vertical de forma de onda antes de seguirem para o mesmo fluxo de montagem, prévia e Biblioteca.

## IA e planos

A experiência passou a usar a **IA integrada do RedScribe**, pronta após a instalação e sem campo de chave, autenticação técnica ou configuração manual. O núcleo editorial local cobre resumo, pontos principais, roteiro, títulos, descrição, post, estudo, perguntas e a ordenação de candidatos de Shorts. Trata-se de um assistente editorial local e não de uma promessa de modelo de linguagem em nuvem.

A área Plano ganhou comparativo e seleção persistente de preferência de conta, sem cobrança e sem limitação de acesso nesta edição.

## Validação complementar

A suíte de regressão passou a 11 testes, incluindo o contrato de fonte da Biblioteca e uma conversão real de áudio instrumental em vídeo vertical. A interface foi revisada no navegador nos temas claro e escuro, confirmando os controles de formatos, enquadramento seguro, 4K e a nova fonte da Biblioteca.

## Revisão de desempenho e janela Windows

O RedScribe agora abre dentro da área útil do monitor Windows, com consciência de escala DPI e geometria centralizada. A medida impede que a janela inicie parcialmente fora da tela em configurações com escala de 125% ou 150%, preservando a barra superior, a busca e os comandos do aplicativo.

O Shorts Studio recebeu o perfil **Rápido** como padrão. Ele limita a montagem a um render por vez, reduz a pressão simultânea sobre CPU e memória, prioriza encoders de GPU compatíveis — AMD AMF, NVIDIA NVENC ou Intel Quick Sync — e usa `libx264` otimizado como fallback. Quando o vídeo não traz legenda útil, o perfil rápido deixa de carregar o modelo pesado de transcrição e cria os cortes pela timeline real da mídia; os perfis Equilibrado e Qualidade alta continuam disponíveis quando a prioridade for análise/transcrição mais completa.

## IA editorial contextual

A IA integrada passou a identificar melhor o tema da mensagem, inclusive nichos como canais e projetos, e responde com direção editorial, gancho, prova e fechamento mais específicos. Ela continua inteiramente sem chave e sem modelo adicional baixado. Um modelo local de linguagem completo não foi incluído nesta revisão porque acrescentaria múltiplos gigabytes de memória e iria contra o objetivo de reduzir o consumo observado no computador.
