RedScribe Desktop EXE Builder 3.5.9 — SMART AUTO-REFRAME / ZERO-SETUP

Principais novidades desta versão:
- Enquadramento Inteligente · seguir pessoa (opcional).
- Composição Inteligente · adaptar à cena (opcional).
- Movimento Suave / Normal / Dinâmico.
- Detecção visual local e sob demanda; não roda na inicialização.
- Preenchimento total 9:16 aprovado na v3.4.7 permanece igual com as opções desligadas.

Como usar:
1. Execute GERAR_INSTALADOR_WINDOWS.bat para gerar o instalador.
2. No Shorts Studio, escolha Corte central ou Preenchimento total.
3. Ative uma ou as duas opções do Auto Reframe inteligente.
4. Movimento Suave é o padrão recomendado.
5. Clique em Montar Shorts.

Se a detecção visual não encontrar uma pessoa com confiança, o RedScribe usa automaticamente o enquadramento normal, evitando estragar o Short.

Saída esperada do builder:
installer_output\RedScribe_Setup_3.5.9_x64.exe
