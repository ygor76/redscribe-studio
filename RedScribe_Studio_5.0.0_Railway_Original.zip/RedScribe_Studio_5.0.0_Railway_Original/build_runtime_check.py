from __future__ import annotations

import importlib
import struct
import sys
from pathlib import Path


def runtime_ok() -> bool:
    bits = struct.calcsize("P") * 8
    version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    print(f"Python {version} - {bits} bits")
    print(f"Executavel: {Path(sys.executable)}")
    return sys.version_info[:2] == (3, 12) and bits == 64


def check_dependencies() -> None:
    modules = [
        "flask",
        "webview",
        "yt_dlp",
        "yt_dlp_ejs",
        "faster_whisper",
        "reportlab",
        "imageio_ffmpeg",
        "docx",
        "PyInstaller",
        "youtube_transcript_api",
        "huggingface_hub",
    ]
    failures: list[str] = []
    for name in modules:
        try:
            module = importlib.import_module(name)
            version = getattr(module, "__version__", "") or getattr(module, "VERSION", "")
            print(f"OK  {name} {version}".rstrip())
        except Exception as exc:
            failures.append(f"{name}: {exc}")
    if failures:
        raise RuntimeError("Dependencias com falha:\n- " + "\n- ".join(failures))


def main() -> int:
    mode = sys.argv[1].strip().lower() if len(sys.argv) > 1 else "runtime"
    if not runtime_ok():
        print("ERRO: o runtime precisa ser CPython 3.12 x64.", file=sys.stderr)
        return 7
    if mode == "deps":
        check_dependencies()
        print("Dependencias do build validadas.")
    elif mode != "runtime":
        print(f"Modo desconhecido: {mode}", file=sys.stderr)
        return 8
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
