# RedScribe v3.5.14

- Legendas automáticas preservam o fluxo preciso da v3.5.12, com Trebuchet MS e contorno mais suave como padrão.
- Botão vira **Atualizar legendas** após a primeira geração; atualizações substituem o conjunto automático e preservam correções manuais sem duplicar falas.
- Sincronização da prévia usa atualização por frame durante a reprodução.
- Adicionados **Desfazer**, **Refazer** e **Cancelar edição** no Estúdio.
- Marca d’água em texto preserva `@` e nasce com `@Nome` por padrão.
- Após renderizar, o usuário escolhe **Substituir Short atual** ou **Manter os dois**.
- Quantidade de Shorts agora é digitável (1–50).
- Shorts gerados não entram automaticamente na Biblioteca; o usuário escolhe individualmente ou em lote quais adicionar.
