from pathlib import Path
from huggingface_hub import snapshot_download

root = Path(__file__).resolve().parent
model_dir = root / "models" / "faster-whisper-small"
model_dir.mkdir(parents=True, exist_ok=True)

required = [model_dir / "model.bin", model_dir / "config.json", model_dir / "tokenizer.json"]
if all(p.exists() for p in required) and (model_dir / "model.bin").stat().st_size > 100_000_000:
    print(f"Whisper Small ja esta completo: {model_dir}")
else:
    print("Baixando/completando o modelo Whisper Small...")
    snapshot_download(repo_id="Systran/faster-whisper-small", local_dir=str(model_dir))
    if not all(p.exists() for p in required):
        raise RuntimeError("O Whisper Small nao ficou completo depois do download.")
    print(f"Modelo pronto em: {model_dir}")
