from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path


def resource_path(*parts: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base.joinpath(*parts)


def app_home() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / ".redscribe"
    root = base / "RedScribe"
    root.mkdir(parents=True, exist_ok=True)
    return root


def ensure_single_instance() -> None:
    if os.name != "nt":
        return
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\RedScribe.Desktop.Singleton")
    if not handle:
        return
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        ctypes.windll.user32.MessageBoxW(
            None,
            "O RedScribe já está aberto neste computador.",
            "RedScribe",
            0x40,
        )
        raise SystemExit(0)


def configure_runtime() -> Path:
    root = app_home()
    os.environ["REDSCRIBE_DATA_ROOT"] = str(root / "data")

    tools = resource_path("tools")
    if tools.exists():
        os.environ["PATH"] = str(tools) + os.pathsep + os.environ.get("PATH", "")

    bundled_model = resource_path("models", "faster-whisper-small")
    if bundled_model.exists():
        os.environ.setdefault("WHISPER_MODEL", str(bundled_model))

    os.environ.setdefault("HF_HOME", str(root / "cache" / "huggingface"))
    os.environ.setdefault("XDG_CACHE_HOME", str(root / "cache"))
    return root


def windows_work_area() -> tuple[int, int, int, int] | None:
    """Retorna a área útil do monitor principal em pixels lógicos.

    A consciência DPI é configurada antes da consulta. Isso evita a geometria
    ampliada que pode fazer a janela nascer parcialmente acima da tela em PCs
    Windows com escala de 125% ou 150%.
    """
    if os.name != "nt":
        return None
    try:
        user32 = ctypes.windll.user32
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # Per-monitor DPI aware.
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass
        work = wintypes.RECT()
        if user32.SystemParametersInfoW(48, 0, ctypes.byref(work), 0):  # SPI_GETWORKAREA
            return int(work.left), int(work.top), int(work.right - work.left), int(work.bottom - work.top)
    except Exception:
        return None
    return None


def self_test() -> int:
    """Validates the frozen bundle without opening the desktop window."""
    log_path = Path(tempfile.gettempdir()) / "RedScribe_selftest.log"
    try:
        configure_runtime()
        required_resources = [
            resource_path("templates"),
            resource_path("static"),
            resource_path("assets", "redscribe.ico"),
            resource_path("tools", "ffmpeg.exe"),
            resource_path("tools", "deno.exe"),
            resource_path("tools", "yt-dlp.exe"),
        ]
        missing = [str(path) for path in required_resources if not path.exists()]
        if missing:
            raise RuntimeError("Recursos ausentes no pacote: " + ", ".join(missing))

        for tool, args in [
            (resource_path("tools", "deno.exe"), ["--version"]),
            (resource_path("tools", "yt-dlp.exe"), ["--version"]),
            (resource_path("tools", "ffmpeg.exe"), ["-version"]),
        ]:
            check = subprocess.run([str(tool), *args], capture_output=True, timeout=20, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if check.returncode != 0:
                raise RuntimeError(f"Ferramenta interna nao executa: {tool}")

        import flask  # noqa: F401
        import webview  # noqa: F401
        import yt_dlp  # noqa: F401
        import yt_dlp_ejs  # noqa: F401
        import faster_whisper  # noqa: F401
        import reportlab  # noqa: F401
        import docx  # noqa: F401
        import pypdf  # noqa: F401
        import imageio_ffmpeg  # noqa: F401
        from app import app  # noqa: F401

        log_path.write_text("OK\n", encoding="utf-8")
        return 0
    except Exception:
        log_path.write_text(traceback.format_exc(), encoding="utf-8")
        return 1



def prepare_ai_cli() -> int:
    """Prepares Claude Code runtime. The Zen key is configured inside the app."""
    root = configure_runtime()
    log_path = root / "ai_setup.log"
    script = resource_path("runtime_scripts", "install_claude_code.ps1")
    try:
        if not script.exists():
            raise RuntimeError(f"Instalador interno de Claude Code ausente: {script}")
        import subprocess
        kwargs = {"capture_output": True, "text": True, "timeout": 1800}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)], **kwargs)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or "").strip() or f"Código {result.returncode}")
        log_path.write_text("OK\nClaude Code preparado. Configure a chave Zen no RedScribe.\n", encoding="utf-8")
        return 0
    except Exception:
        log_path.write_text(traceback.format_exc(), encoding="utf-8")
        return 2


def save_zen_key_file_cli(path_text: str) -> int:
    """Store a Zen key protected with Windows DPAPI for first-run use."""
    configure_runtime()
    path = Path(path_text)
    try:
        if not path.exists():
            raise RuntimeError("Arquivo temporário da chave Zen não foi encontrado.")
        api_key = path.read_text(encoding="utf-8-sig").strip()
        from app import _save_machine_zen_key
        _save_machine_zen_key(api_key)
        try:
            # Best effort: remove the plaintext immediately after DPAPI storage.
            path.write_text("", encoding="utf-8")
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return 0
    except Exception:
        log_path = app_home() / "zen_key_setup_error.log"
        log_path.write_text(traceback.format_exc(), encoding="utf-8")
        return 3


class DesktopBridge:
    def __init__(self):
        self._window = None
        self._fullscreen = False
        self._normal_geometry = None

    def toggle_fullscreen(self):
        if self._window is None:
            return False

        if not self._fullscreen:
            try:
                self._normal_geometry = (
                    int(self._window.x),
                    int(self._window.y),
                    int(self._window.width),
                    int(self._window.height),
                )
            except Exception:
                self._normal_geometry = None
            self._window.toggle_fullscreen()
            self._fullscreen = True
            return {"fullscreen": True}

        self._window.toggle_fullscreen()
        self._fullscreen = False

        # pywebview normally restores the prior geometry itself. Reapply the
        # captured geometry as a Windows-safe fallback so F11 always returns
        # to the same position and size the user had before fullscreen.
        if self._normal_geometry:
            x, y, width, height = self._normal_geometry
            try:
                self._window.resize(width, height)
                self._window.move(x, y)
            except Exception:
                pass
        return {"fullscreen": False}


def main() -> None:
    if len(sys.argv) >= 3 and sys.argv[1] == "--set-zen-key-file":
        raise SystemExit(save_zen_key_file_cli(sys.argv[2]))
    ensure_single_instance()
    root = configure_runtime()

    import webview
    from app import app

    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
    webview.settings["ALLOW_DOWNLOADS"] = False

    bridge = DesktopBridge()
    area = windows_work_area()
    if area:
        left, top, available_width, available_height = area
        width = max(920, min(1380, available_width - 32))
        height = max(620, min(860, available_height - 32))
        x = left + max(16, (available_width - width) // 2)
        y = top + max(16, (available_height - height) // 2)
    else:
        width, height, x, y = 1280, 800, None, None
    window = webview.create_window(
        "RedScribe",
        app,
        js_api=bridge,
        width=width,
        height=height,
        x=x,
        y=y,
        min_size=(920, 620),
        resizable=True,
        background_color="#0f0f0f",
        text_select=True,
    )
    bridge._window = window

    webview.start(
        debug=False,
        private_mode=False,
        storage_path=str(root / "webview"),
        icon=str(resource_path("assets", "redscribe.ico")),
    )


if __name__ == "__main__":
    if "--prepare-ai" in sys.argv:
        raise SystemExit(prepare_ai_cli())
    if "--self-test" in sys.argv:
        raise SystemExit(self_test())
    main()
