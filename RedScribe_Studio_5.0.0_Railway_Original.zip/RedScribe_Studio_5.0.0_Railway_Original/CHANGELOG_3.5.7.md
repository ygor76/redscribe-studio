# RedScribe v3.5.9

## Correção — Shorts não falham por transcrição esparsa

- Restaurada a robustez da seleção de trechos sem alterar as correções de bordas pretas da v3.5.6.
- O RedScribe agora normaliza transcrições antigas e novas (`start+duration` e `start+end`).
- Se a transcrição vier esparsa, com timestamps incompletos ou não produzir candidatos suficientes, o sistema usa a duração real do vídeo como fallback.
- Um vídeo de 6:35 pode gerar 5 Shorts de 60s quando houver duração suficiente, mesmo se a legenda estiver mal segmentada.
- A análise por IA continua sendo usada normalmente quando há candidatos textuais válidos.
